"""Round-5 production fixes: regression locks for each confirmed defect.

Evidence base (production log 2026-10-11 08:24–08:37 + task screenshots):

1. **Invite provider** — the composition root used
   ``bot.export_chat_invite_link`` (may rotate the group's PRIMARY link);
   must use ``create_chat_invite_link`` (dedicated link) instead.
2. **DM→group destination hijack** — while the DM-play FSM waits for a
   GROUP link, the music-URL resolver (``links`` router, registered first)
   intercepted ``https://t.me/call/...`` and answered "only links from
   authorized music sources are supported". Call links must be recognized
   and explained as call links; the FSM state must win router priority.
3. **45 MiB download cap aborting group playback** — the voice streaming
   path used the Bot-API-upload-oriented ``max_audio_size_mb`` cap; it now
   uses the dedicated ``voice_max_audio_size_mb`` with an actionable
   user message.
4. **Skip racing a pending natural advance** — a skip pressed while a
   natural track-end advance was mid-download waited for the per-owner
   lock and then advanced AGAIN: duplicate refill + the same track played
   twice back-to-back. The stale-advance guard drops it.
5. **Recommendation served mid-shutdown** — ``cleanup()`` now sets a
   closing flag: no further auto-advances, refills or failure
   notifications once shutdown began.
6. **🤖 Autoplay ON/OFF player button** — dedicated ``grp:auto`` toggle
   bound to the REAL per-group setting (PlaybackSession.autoplay) and
   synced with the group-settings row; labels reflect actual state.
"""

from __future__ import annotations

import ast
import asyncio
import importlib
import inspect
import time
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlparse

import pytest

from app.config import ConfigError, Settings
from app.errors import BotError, DownloadError, FileTooLargeError
from app.playback.controller import PlaybackController
from app.playback.events import EventBus
from app.playback.queue import QueueManager, QueueOwner
from app.playback.session import SessionManager
from app.recommendation.engine import RecommendationEngine
from app.playback.autoplay import AutoplayService
from app.voice.group_access import (
    STATUS_MESSAGES,
    GroupAccessService,
    classify_tme_link,
)

from .conftest import build_services
from .test_playback_controller import (
    FakeAnalyticsRecorder,
    FakeBot,
    FakeHistoryGateway,
    FakeMusicGateway,
    FakeVoiceGateway,
)
from .test_group_new import FakeCallback, FakeMessage, _Recorder, _group_callback


# ======================================================================
# 1. Invite provider: create_chat_invite_link, never export
# ======================================================================
class TestInviteProvider:
    def _provider_source(self) -> str:
        source = Path("app/application.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        for node in ast.walk(tree):
            if isinstance(node, ast.AsyncFunctionDef) and node.name in (
                "_create_group_invite_link",
                "_export_group_invite_link",
            ):
                return ast.get_source_segment(source, node) or ""
        return ""

    def test_provider_uses_create_chat_invite_link(self) -> None:
        source = self._provider_source()
        assert source, "the composition root must define the invite provider"
        assert "create_chat_invite_link" in source
        assert "export_chat_invite_link" not in source
        # A named dedicated link (identifiable in Telegram's link management).
        assert "name=" in source

    def test_provider_validates_returned_object_and_never_logs_link(self) -> None:
        source = self._provider_source()
        assert "invite_link" in source
        # The provider must degrade to None (never raise); the link value
        # itself must not be logged — only chat id and error text.
        assert "return None" in source
        assert "log_extra(chat_id=chat_id" in source

    def test_no_export_chat_invite_link_call_sites_anywhere(self) -> None:
        """Auditing ALL call sites: export may only appear in docstrings."""
        for path in sorted(Path("app").rglob("*.py")):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if isinstance(node, ast.Attribute) and node.attr == (
                    "export_chat_invite_link"
                ):
                    pytest.fail(f"{path}:{node.lineno} still calls export_chat_invite_link")

    async def test_provider_behaviour_on_fake_bot(self) -> None:
        """Duck-typed behavioural mirror of the provider contract."""
        created: list[dict] = []

        class _Link:
            invite_link = "https://t.me/+CreatedDedicatedLink"

        class _Bot:
            async def create_chat_invite_link(self, chat_id: int, name: str | None = None):
                created.append({"chat_id": chat_id, "name": name})
                return _Link()

        class _BrokenBot:
            async def create_chat_invite_link(self, chat_id: int, name: str | None = None):
                raise RuntimeError("bot is not an administrator")

        class _EmptyBot:
            async def create_chat_invite_link(self, chat_id: int, name: str | None = None):
                return SimpleNamespace(invite_link="  ")

        # Success path returns the validated link string.
        provider_calls: list[int] = []

        async def provider(bot, chat_id: int) -> str | None:
            provider_calls.append(chat_id)
            try:
                result = await bot.create_chat_invite_link(
                    chat_id, name="Music bot voice account"
                )
            except Exception:
                return None
            link = str(getattr(result, "invite_link", "") or "").strip()
            return link or None

        assert await provider(_Bot(), -100123) == "https://t.me/+CreatedDedicatedLink"
        assert created == [{"chat_id": -100123, "name": "Music bot voice account"}]
        # Permission failure degrades to None (mapped to invite_unavailable).
        assert await provider(_BrokenBot(), -100123) is None
        # Invalid returned object degrades to None.
        assert await provider(_EmptyBot(), -100123) is None


# ======================================================================
# 2. Call links + DM→group destination validation
# ======================================================================
class TestClassifyTmeLink:
    def test_call_link_recognized(self) -> None:
        for link in (
            "https://t.me/call/abc123",
            "https://t.me/call/",
            "http://t.me/call/xyz",
            "https://telegram.me/call/xyz",
            "https://www.t.me/call/xyz",
        ):
            assert classify_tme_link(link) == "call_link", link

    def test_private_channel_link_is_not_found(self) -> None:
        assert classify_tme_link("https://t.me/c/1234567890/12") == "not_found"

    def test_other_special_kinds_rejected(self) -> None:
        for link in (
            "https://t.me/addstickers/PackName",
            "https://t.me/proxy?server=1.2.3.4",
            "https://t.me/socks?server=1.2.3.4",
            "https://t.me/bg/somehash",
            "https://t.me/share/url?url=x",
        ):
            assert classify_tme_link(link) == "invalid_link", link

    def test_regular_usernames_and_invites_not_classified(self) -> None:
        assert classify_tme_link("https://t.me/musicgroup") is None
        assert classify_tme_link("https://t.me/+AbCdEf") is None
        assert classify_tme_link("https://t.me/joinchat/AbCdEf") is None
        assert classify_tme_link("tg://join?invite=AbCdEf") is None
        assert classify_tme_link("https://example.com/call/x") is None
        assert classify_tme_link("@musicgroup") is None
        assert classify_tme_link("") is None


class TestResolveTargetCallLink:
    async def test_call_link_gets_dedicated_message(self, tmp_path) -> None:
        settings = Settings(
            bot_token="123456789:" + "A" * 33, storage_dir=tmp_path / "storage"
        )
        access = GroupAccessService(settings, None)
        # The client is never touched for special links — a sentinel object
        # proves no resolution RPC was attempted.
        sentinel = object()
        result = await access.resolve_target(sentinel, "https://t.me/call/8SkY9x2Qz")
        assert result.ok is False
        assert result.status == "call_link"
        assert result.user_message and "Telegram call link" in result.user_message
        assert "t.me/call" in result.user_message
        # The message explains what to send instead.
        assert "https://t.me/yourgroup" in result.user_message

    def test_call_link_message_is_html_safe_and_actionable(self) -> None:
        message = STATUS_MESSAGES["call_link"]
        assert "<b>" in message  # intentional bold only
        assert "<script>" not in message and "<i>" not in message
        assert "group" in message.lower()


class TestLinksRouterStateExclusion:
    """The links handler must not fire while waiting for a group link."""

    def _on_link_message_handler(self):
        links = importlib.import_module("app.bot.handlers.links")
        for handler in links.router.message.handlers:
            callback = getattr(handler, "callback", None)
            if getattr(callback, "__name__", "") == "on_link_message":
                return handler
        return None

    def test_handler_excludes_dm_play_waiting_link_state(self) -> None:
        from aiogram.filters import StateFilter
        from app.bot.handlers.dm_play import DmPlayFSM

        handler = self._on_link_message_handler()
        assert handler is not None, "on_link_message handler missing"

        # aiogram shape: FilterObject(callback=_InvertFilter(target=
        # FilterObject(callback=StateFilter(states)))).
        wanted = DmPlayFSM.waiting_link.state  # "DmPlayFSM:waiting_link"
        found = False
        for flt in handler.filters:
            invert = getattr(flt, "callback", None)
            if type(invert).__name__ != "_InvertFilter":
                continue
            target = getattr(invert, "target", None)
            inner = getattr(target, "callback", None)
            if isinstance(inner, StateFilter):
                if any(getattr(s, "state", None) == wanted for s in inner.states):
                    found = True
        assert found, (
            "on_link_message must carry ~StateFilter(DmPlayFSM.waiting_link) "
            "so group-destination input is never hijacked by the URL resolver"
        )

    def test_dm_play_handler_still_consumes_waiting_link_messages(self) -> None:
        """The dm_play router still handles waiting_link input (its own
        StateFilter on on_group_link) — exclusion on one side, consumption
        on the other."""
        from aiogram.filters import StateFilter

        dm_play = importlib.import_module("app.bot.handlers.dm_play")
        found = 0
        for handler in dm_play.router.message.handlers:
            callback = getattr(handler, "callback", None)
            if getattr(callback, "__name__", "") != "on_group_link":
                continue
            for flt in handler.filters:
                inner = getattr(flt, "callback", None)
                if isinstance(inner, StateFilter) and any(
                    getattr(s, "state", None) == "DmPlayFSM:waiting_link"
                    for s in inner.states
                ):
                    found += 1
        assert found == 1


# ======================================================================
# 3. Voice download cap (45 MiB production failure)
# ======================================================================
class TestVoiceCapSettings:
    def test_defaults_split_upload_and_streaming_caps(self) -> None:
        settings = Settings(bot_token="123456789:" + "A" * 33)
        assert settings.max_audio_size_mb == 45
        assert settings.voice_max_audio_size_mb == 200

    def test_env_override_parsed(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from app.config import load_settings

        monkeypatch.setenv("BOT_TOKEN", "123456789:" + "A" * 33)
        monkeypatch.setenv("VOICE_MAX_AUDIO_SIZE_MB", "120")
        monkeypatch.setenv("MAX_AUDIO_SIZE_MB", "30")
        settings = load_settings(env_file=None)
        assert settings.voice_max_audio_size_mb == 120
        assert settings.max_audio_size_mb == 30

    def test_voice_cap_bounds_validated(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from app.config import load_settings, validate_settings

        monkeypatch.setenv("BOT_TOKEN", "123456789:" + "A" * 33)
        monkeypatch.setenv("VOICE_MAX_AUDIO_SIZE_MB", "5000")
        with pytest.raises(ConfigError):
            load_settings(env_file=None)
        # Programmatic construction below the floor is rejected too.
        with pytest.raises(ConfigError):
            validate_settings(
                Settings(bot_token="123456789:" + "A" * 33, voice_max_audio_size_mb=0)
            )
        with pytest.raises(ConfigError):
            validate_settings(
                Settings(bot_token="123456789:" + "A" * 33, voice_max_audio_size_mb=3000)
            )

    def test_env_zero_falls_back_to_documented_default(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.config import load_settings

        monkeypatch.setenv("BOT_TOKEN", "123456789:" + "A" * 33)
        monkeypatch.setenv("VOICE_MAX_AUDIO_SIZE_MB", "0")
        # The project-wide ``or default`` parsing convention maps 0 to the
        # default (same as MAX_AUDIO_SIZE_MB) — never an unbounded cap.
        assert load_settings(env_file=None).voice_max_audio_size_mb == 200

    def test_upload_cap_still_bounded_by_telegram_limit(self) -> None:
        from app.config import validate_settings

        with pytest.raises(ConfigError):
            validate_settings(
                Settings(bot_token="123456789:" + "A" * 33, max_audio_size_mb=60)
            )


class TestFileTooLargeMessages:
    def test_streaming_message_mentions_actual_limit_and_env_var(self) -> None:
        error = FileTooLargeError.with_limit_mb(200, streaming=True)
        assert "200 MB" in error.user_message
        assert "VOICE_MAX_AUDIO_SIZE_MB" in error.user_message

    def test_upload_message_mentions_actual_limit(self) -> None:
        error = FileTooLargeError.with_limit_mb(45)
        assert "45 MB" in error.user_message
        assert "VOICE_MAX_AUDIO_SIZE_MB" not in error.user_message

    def test_is_a_bot_error_with_categorized_semantics(self) -> None:
        assert isinstance(FileTooLargeError.with_limit_mb(200), BotError)
        assert isinstance(FileTooLargeError.with_limit_mb(200), FileTooLargeError)


class TestStreamDownloadVoiceCap:
    """stream_download enforces Content-Length + streamed bytes with the
    actionable voice-cap wording on the streaming path."""

    def _http(self, responses: list):
        from .test_music_download import _FakeHttpSession

        return _FakeHttpSession(responses=responses)

    def _timeout(self):
        import aiohttp

        return aiohttp.ClientTimeout(total=5)

    async def test_streaming_cap_message_on_streamed_bytes(self, tmp_path) -> None:
        from .test_music_download import _FakeResponse
        from app.music.sources.url_resolver import stream_download

        big = b"x" * (1024 * 1024 + 10)  # just over 1 MiB cap
        responses = [
            _FakeResponse(status=200),  # redirect probe
            _FakeResponse(status=200, body=big),  # the download itself
        ]
        target = tmp_path / "cap.mp3"
        with pytest.raises(FileTooLargeError) as excinfo:
            await stream_download(
                "https://cdn.example.com/song.mp3",
                self._http(responses),
                self._timeout(),
                target,
                1024 * 1024,
                streaming=True,
            )
        assert "1 MB" in excinfo.value.user_message
        assert "VOICE_MAX_AUDIO_SIZE_MB" in excinfo.value.user_message
        assert not target.exists(), "partial file must be cleaned up"

    async def test_streaming_cap_message_on_content_length(self, tmp_path) -> None:
        from .test_music_download import _FakeResponse
        from app.music.sources.url_resolver import stream_download

        responses = [
            _FakeResponse(status=200),  # redirect probe
            _FakeResponse(
                status=200,
                body=b"",
                headers={"Content-Length": str(10 * 1024 * 1024)},
            ),
        ]
        target = tmp_path / "cap2.mp3"
        with pytest.raises(FileTooLargeError) as excinfo:
            await stream_download(
                "https://cdn.example.com/song.mp3",
                self._http(responses),
                self._timeout(),
                target,
                1024 * 1024,
                streaming=True,
            )
        assert "1 MB" in excinfo.value.user_message

    async def test_just_below_cap_succeeds(self, tmp_path) -> None:
        from .test_music_download import _FakeResponse
        from app.music.sources.url_resolver import stream_download

        body = b"y" * (1024 * 1024 - 10)  # just under the cap
        responses = [
            _FakeResponse(status=200),
            _FakeResponse(
                status=200, body=body, headers={"Content-Length": str(len(body))}
            ),
        ]
        target = tmp_path / "ok.mp3"
        written = await stream_download(
            "https://cdn.example.com/song.mp3",
            self._http(responses),
            self._timeout(),
            target,
            1024 * 1024,
            streaming=True,
        )
        assert written == len(body)
        assert target.read_bytes() == body


class TestMusicServiceVoiceCap:
    """get_playable_path downloads use the VOICE cap, not the upload cap."""

    async def test_voice_cap_governs_group_download(
        self, tmp_path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from sqlalchemy.ext.asyncio import (
            AsyncSession,
            async_sessionmaker,
            create_async_engine,
        )
        from sqlalchemy.pool import StaticPool

        from app.database.base import Base
        from app.database.repositories.music import TrackRepository
        from app.music.service import MusicService
        from app.storage import StorageService
        from app.cache.redis import MemoryCache

        # Skip SSRF DNS resolution for the fake host.
        monkeypatch.setattr("app.music.service.validate_url", lambda url: url)

        engine = create_async_engine(
            "sqlite+aiosqlite:///:memory:",
            poolclass=StaticPool,
            connect_args={"check_same_thread": False},
        )
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        maker = async_sessionmaker(
            engine, class_=AsyncSession, expire_on_commit=False
        )
        tracks_repo = TrackRepository(maker)

        settings = Settings(
            bot_token="123456789:" + "A" * 33,
            storage_dir=tmp_path / "storage",
            max_audio_size_mb=45,
            voice_max_audio_size_mb=1,  # 1 MiB voice cap < 45 upload cap
        )
        from .test_music_download import (
            _FakeHttpSession,
            _FakeResponse,
            _FakeSource,
            _make_track,
        )

        track = await _make_track(
            tracks_repo, title="Big Mix", source="audius", stream_url="https://cdn.example.com/bigmix.mp3"
        )

        # Body over the 1 MiB voice cap but well under the 45 MB upload
        # cap: only the VOICE cap can reject it.
        body = b"z" * (1024 * 1024 + 512)
        responses = [
            _FakeResponse(status=200),  # redirect probe
            _FakeResponse(status=200, body=body),
        ]
        http = _FakeHttpSession(responses=responses)

        service = MusicService(
            sources=[_FakeSource(settings=settings)],
            aggregator=SimpleNamespace(),  # type: ignore[arg-type]
            resolver=SimpleNamespace(),  # type: ignore[arg-type]
            tracks=tracks_repo,
            metadata=None,  # type: ignore[arg-type]
            storage=StorageService(settings.storage_dir),
            cache=MemoryCache(),
            events=EventBus(),
            analytics=None,
            settings=settings,
            http=http,  # type: ignore[arg-type]
        )

        with pytest.raises(FileTooLargeError) as excinfo:
            await service.get_playable_path(track)
        assert "1 MB" in excinfo.value.user_message
        assert "VOICE_MAX_AUDIO_SIZE_MB" in excinfo.value.user_message
        # No partial files were left behind.
        downloads = settings.storage_dir / "downloads"
        if downloads.exists():
            leftovers = [p for p in downloads.iterdir() if ".part" in p.name]
            assert leftovers == []
        await engine.dispose()

    async def test_upload_cap_still_governs_direct_url_ingestion(
        self, tmp_path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``resolve_direct_audio`` (URL tracks that get SENT as audio files)
        keeps the Bot-API-oriented upload cap."""
        from app.music.sources.url_resolver import resolve_direct_audio
        from .test_music_download import _FakeHttpSession, _FakeResponse

        monkeypatch.setattr(
            "app.music.sources.url_resolver.validate_url", lambda url: url
        )

        settings = Settings(
            bot_token="123456789:" + "A" * 33,
            storage_dir=tmp_path / "storage",
            max_audio_size_mb=1,
            voice_max_audio_size_mb=200,
        )
        body = b"q" * (1024 * 1024 + 512)  # > upload cap, < voice cap
        responses = [
            _FakeResponse(status=200),
            _FakeResponse(status=200, body=body),
        ]
        with pytest.raises(FileTooLargeError) as excinfo:
            await resolve_direct_audio(
                "https://cdn.example.com/song.mp3",
                settings,
                _FakeHttpSession(responses=responses),  # type: ignore[arg-type]
                SimpleNamespace(resolve=lambda rel: tmp_path / rel),  # type: ignore[arg-type]
            )
        # The UPLOAD wording (no voice env var) proves the right cap ran.
        assert "1 MB" in excinfo.value.user_message
        assert "VOICE_MAX_AUDIO_SIZE_MB" not in excinfo.value.user_message


# ======================================================================
# 4. Autoplay button + controller semantics
# ======================================================================
def _labels(markup) -> list[str]:
    return [b.text for row in markup.inline_keyboard for b in row]


def _datas(markup) -> list[str]:
    return [b.callback_data for row in markup.inline_keyboard for b in row]


class TestAutoplayPlayerButton:
    def test_group_panel_carries_stateful_autoplay_button(self) -> None:
        from app.bot.keyboards.group import group_controls_keyboard

        datas = _datas(
            group_controls_keyboard(
                paused=False, shuffle=False, repeat_mode="off", volume=100,
                autoplay=True,
            )
        )
        labels = _labels(
            group_controls_keyboard(
                paused=False, shuffle=False, repeat_mode="off", volume=100,
                autoplay=True,
            )
        )
        assert "grp:auto" in datas
        assert "🤖 Autoplay: ON" in labels
        # OFF state reflected, not a hardcoded label.
        off_labels = _labels(
            group_controls_keyboard(paused=False, autoplay=False)
        )
        assert "🤖 Autoplay: OFF" in off_labels

    def test_controller_group_panel_carries_autoplay(self) -> None:
        datas = _datas(
            PlaybackController._player_keyboard(
                paused=False, group=True, autoplay=True
            )
        )
        assert "grp:auto" in datas
        labels = _labels(
            PlaybackController._player_keyboard(
                paused=False, group=True, autoplay=True
            )
        )
        assert "🤖 Autoplay: ON" in labels

    def test_stateful_toggles_are_full_width_no_clipping(self) -> None:
        """Shuffle/Repeat/Autoplay labels take full-width rows so they never
        truncate on narrow screens (production: "Shuffle: Of…")."""
        from app.bot.keyboards.group import group_controls_keyboard

        markup = group_controls_keyboard(
            paused=False, shuffle=True, repeat_mode="all", volume=100, autoplay=True
        )
        rows = markup.inline_keyboard
        widths = [len(row) for row in rows]
        # Autoplay is the last row, full width.
        assert widths[-1] == 1
        assert rows[-1][0].text == "🤖 Autoplay: ON"
        # Some row carries Shuffle alone (full width).
        assert any(
            len(row) == 1 and row[0].text.startswith("🔀 Shuffle")
            for row in rows
        )
        assert any(
            len(row) == 1 and row[0].text.startswith("🔁 Repeat")
            for row in rows
        )
        # Transport pairs stay two-wide (Pause|Skip, Vol−|Vol+, Queue|Stop).
        assert widths[0] == 2

    def test_queue_keyboard_carries_autoplay_near_queue_info(self) -> None:
        from app.bot.keyboards.group import group_queue_keyboard

        datas = _datas(group_queue_keyboard(autoplay=False))
        labels = _labels(group_queue_keyboard(autoplay=False))
        assert "grp:auto" in datas
        assert "🤖 Autoplay: OFF" in labels

    def test_callback_data_within_telegram_limit(self) -> None:
        assert len("grp:auto".encode()) <= 64


class TestAutoplayHandlerWiring:
    def test_grp_auto_handler_registered(self) -> None:
        groups = importlib.import_module("app.bot.handlers.groups")
        source = inspect.getsource(groups)
        assert 'F.data == "grp:auto"' in source, "grp:auto handler missing"

    def test_settings_toggle_syncs_session_autoplay(self) -> None:
        groups = importlib.import_module("app.bot.handlers.groups")
        source = inspect.getsource(groups)
        assert "set_autoplay" in source, (
            "grp:set:auto must sync the session autoplay (the flag the "
            "controller actually reads) — otherwise the settings toggle "
            "does not gate playback"
        )


class TestAutoplayToggleHandler:
    """Behavioural tests for the ``grp:auto`` callback handler."""

    def _services(
        self,
        *,
        autoplay: bool = True,
        allowed: bool = True,
        now_playing_error: Exception | None = None,
    ):
        set_calls: list[tuple[QueueOwner, bool]] = []
        settings_updates: list[dict] = []

        async def _now_playing(owner):
            if now_playing_error is not None:
                raise now_playing_error
            return {
                "track": SimpleNamespace(
                    id=9, title="Song", artist=None, duration_seconds=100
                ),
                "status": "playing",
                "position_seconds": 5,
                "queue_size": 0,
                "shuffle": False,
                "repeat_mode": "off",
                "autoplay": not autoplay,  # post-toggle state
                "volume": 100,
            }

        playback = SimpleNamespace(
            now_playing=_now_playing,
            set_autoplay=_Recorder(None),
        )
        # Route the recorded set_autoplay through our tracker.
        async def _set_autoplay(owner, enabled):
            set_calls.append((owner, bool(enabled)))
            return bool(enabled)

        playback.set_autoplay = _set_autoplay

        services = SimpleNamespace(
            users=SimpleNamespace(get_or_create=_Recorder(SimpleNamespace(id=1))),
            groups=SimpleNamespace(
                get_or_create=_Recorder(SimpleNamespace(id=10)),
                sync_member=_Recorder(None),
            ),
            permissions=SimpleNamespace(can=_Recorder(allowed)),
            sessions=SimpleNamespace(
                get=_async_return(SimpleNamespace(autoplay=autoplay))
            ),
            playback=playback,
            group_settings=SimpleNamespace(
                update=_Recorder(None),
            ),
        )
        services._set_calls = set_calls
        services._settings_updates = settings_updates
        return services

    async def test_toggle_flips_actual_state_and_syncs_settings(self) -> None:
        from app.bot.handlers.groups import cb_autoplay

        callback = _group_callback("grp:auto")
        services = self._services(autoplay=True, allowed=True)

        await cb_autoplay(callback, services)

        assert services._set_calls and services._set_calls[0][1] is False
        assert callback.answers[0][0] == "🤖 Autoplay: OFF"
        # The player message was refreshed.
        assert callback.message.edited, "player message must be re-rendered"

    async def test_toggle_off_to_on(self) -> None:
        from app.bot.handlers.groups import cb_autoplay

        callback = _group_callback("grp:auto")
        services = self._services(autoplay=False, allowed=True)

        await cb_autoplay(callback, services)

        assert services._set_calls[0][1] is True
        assert callback.answers[0][0] == "🤖 Autoplay: ON"

    async def test_permission_denied_rejects_toggle(self) -> None:
        from app.bot.handlers.groups import cb_autoplay

        callback = _group_callback("grp:auto")
        services = self._services(autoplay=True, allowed=False)

        await cb_autoplay(callback, services)

        assert services._set_calls == []
        denied = [a[0] for a in callback.answers if "permission" in a[0].lower()]
        assert denied, "unauthorized press must be rejected"

    async def test_stale_keyboard_toggle_reads_actual_state(self) -> None:
        """An old keyboard still saying ON (state actually OFF) toggles to ON
        (the inverse of the ACTUAL state) — never trusting the label."""
        from app.bot.handlers.groups import cb_autoplay

        callback = _group_callback("grp:auto")  # label would say ON (stale)
        services = self._services(autoplay=False)  # actual state: OFF

        await cb_autoplay(callback, services)

        assert services._set_calls[0][1] is True  # OFF → ON


def _async_return(value):
    async def _inner(*args, **kwargs):
        return value

    return _inner


# ======================================================================
# Controller semantics: skip race, shutdown, failure surfacing
# ======================================================================
class _GatedMusic(FakeMusicGateway):
    """Music gateway whose get_playable_path can block on an event —
    simulates a long download inside a natural advance."""

    def __init__(self, tracks_repo, tmp_path: Path) -> None:
        super().__init__(tracks_repo, tmp_path)
        self.gate: asyncio.Event | None = None
        self.gated_calls = 0

    async def get_playable_path(self, track) -> Path:
        if self.gate is not None and int(track.id) in self._gated_ids:
            self.gated_calls += 1
            await self.gate.wait()
        return await super().get_playable_path(track)

    _gated_ids: set[int] = set()

    def gate_track(self, track_id: int) -> asyncio.Event:
        self._gated_ids.add(int(track_id))
        self.gate = asyncio.Event()
        return self.gate


class _BotErrorMusic(FakeMusicGateway):
    """Music gateway raising a categorized BotError for one track."""

    def __init__(self, tracks_repo, tmp_path: Path, fail_track_id: int) -> None:
        super().__init__(tracks_repo, tmp_path)
        self._fail_id = int(fail_track_id)

    async def get_playable_path(self, track) -> Path:
        if int(track.id) == self._fail_id:
            raise DownloadError("download failed for the next track")
        return await super().get_playable_path(track)


@pytest.fixture
async def controller_bundle(db_setup, mk_sessions, tmp_path):
    """controller_bundle clone exposing replaceable gateways."""
    services = build_services(mk_sessions)
    events = EventBus()
    queue = QueueManager(services.queue_repo, services.tracks_repo, events)
    sessions = SessionManager(services.sessions_repo, services.tracks_repo, events)
    engine = RecommendationEngine(
        services.tracks_repo, services.profiles, services.settings_repo, services.cache
    )
    autoplay = AutoplayService(engine, queue, services.analytics_repo)
    music = _GatedMusic(services.tracks_repo, tmp_path)
    voice = FakeVoiceGateway()
    history = FakeHistoryGateway()
    analytics = FakeAnalyticsRecorder()
    bot = FakeBot()
    refill_calls: list[dict] = []

    class _TrackingAutoplay(AutoplayService):
        async def refill(self, owner, seed_track_id, count=1):
            refill_calls.append(
                {"owner": owner.topic(), "seed": seed_track_id, "count": count}
            )
            return await super().refill(owner, seed_track_id, count)

    tracking = _TrackingAutoplay(engine, queue, services.analytics_repo)
    controller = PlaybackController(
        queue=queue,
        autoplay=tracking,
        music=music,
        voice=voice,
        sessions=sessions,
        events=events,
        analytics=analytics,
        history=history,
        autoplay_enabled=None,
        default_autoplay=True,
    )
    bundle = SimpleNamespace(
        services=services,
        events=events,
        queue=queue,
        sessions=sessions,
        controller=controller,
        music=music,
        voice=voice,
        history=history,
        analytics=analytics,
        bot=bot,
        refill_calls=refill_calls,
    )
    try:
        yield bundle
    finally:
        await controller.cleanup()


class TestSkipRaceAndStaleAdvance:
    async def test_skip_racing_pending_natural_advance_plays_once(
        self, controller_bundle, db_setup
    ) -> None:
        """THE production defect: skip pressed while a natural advance is
        mid-download. The skip must NOT advance a second time — the track
        the just-finished advance delivered stays playing, no duplicate
        refill, no restart of the same track."""
        b = controller_bundle
        user = QueueOwner(kind="user", id=202)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user, 202, b.bot, first, 202)
        await b.queue.add(user, second, added_by=202)

        # The natural advance's play of `second` blocks inside the gateway.
        gate = b.music.gate_track(second)
        advance = asyncio.create_task(
            b.controller.next(user, 202, b.bot, manual=False, skip=False)
        )
        await asyncio.sleep(0)  # let the advance reach the gate

        # The user presses Skip while the advance is mid-flight.
        skip = asyncio.create_task(
            b.controller.next(user, 202, b.bot, manual=True, skip=True)
        )
        await asyncio.sleep(0)

        gate.set()
        await asyncio.gather(advance, skip)

        session = await b.sessions.get(user)
        assert session.current_track_id == second
        # The queued track played exactly once — no restart of the same
        # track (the production log showed it playing TWICE).
        assert b.music.playable_requests.count(second) == 1
        # No autoplay refill happened at all (a queued track existed).
        assert b.refill_calls == []

    async def test_duplicate_track_end_mid_advance_dropped(
        self, controller_bundle, db_setup
    ) -> None:
        """A duplicate track_end arriving while the first advance is still
        mid-flight is dropped (its target track already changed)."""
        b = controller_bundle
        user = QueueOwner(kind="user", id=203)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user, 203, b.bot, first, 203)
        await b.queue.add(user, second, added_by=203)

        gate = b.music.gate_track(second)
        first_end = asyncio.create_task(
            b.controller.next(user, 203, b.bot, manual=False, skip=False)
        )
        await asyncio.sleep(0)
        duplicate_end = asyncio.create_task(
            b.controller.next(user, 203, b.bot, manual=False, skip=False)
        )
        await asyncio.sleep(0)

        gate.set()
        await asyncio.gather(first_end, duplicate_end)

        session = await b.sessions.get(user)
        assert session.current_track_id == second
        assert b.music.playable_requests.count(second) == 1

    async def test_skip_after_completed_advance_advances_normally(
        self, controller_bundle, db_setup
    ) -> None:
        """A skip on the CURRENT track (no pending advance) still advances
        exactly once — the guard must not break normal skipping."""
        b = controller_bundle
        user = QueueOwner(kind="user", id=204)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        third = db_setup.track_ids_by_title["Static Bloom"]
        await b.controller.play_now(user, 204, b.bot, first, 204)
        await b.queue.add(user, second, added_by=204)
        await b.queue.add(user, third, added_by=204)

        await b.controller.next(user, 204, b.bot, manual=True, skip=True)
        session = await b.sessions.get(user)
        assert session.current_track_id == second

        await b.controller.next(user, 204, b.bot, manual=True, skip=True)
        session = await b.sessions.get(user)
        assert session.current_track_id == third


class TestAutoplaySemantics:
    async def test_on_with_queue_plays_queued_no_refill(
        self, controller_bundle, db_setup
    ) -> None:
        b = controller_bundle
        user = QueueOwner(kind="user", id=205)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user, 205, b.bot, first, 205)
        await b.sessions.set_autoplay(user, True)
        await b.queue.add(user, second, added_by=205)

        await b.controller.next(user, 205, b.bot, manual=False, skip=False)

        session = await b.sessions.get(user)
        assert session.current_track_id == second
        assert b.refill_calls == []  # queued track served; no recommendation

    async def test_on_empty_queue_refills_once_and_plays(
        self, controller_bundle, db_setup
    ) -> None:
        b = controller_bundle
        user = QueueOwner(kind="user", id=206)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user, 206, b.bot, first, 206)
        await b.sessions.set_autoplay(user, True)

        await b.controller.next(user, 206, b.bot, manual=False, skip=False)

        assert len(b.refill_calls) == 1
        session = await b.sessions.get(user)
        assert session.current_track_id is not None
        assert session.current_track_id != first
        assert session.status == "playing"

    async def test_off_empty_queue_never_requests_recommendation(
        self, controller_bundle, db_setup
    ) -> None:
        b = controller_bundle
        user = QueueOwner(kind="user", id=207)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user, 207, b.bot, first, 207)
        await b.sessions.set_autoplay(user, False)

        await b.controller.next(user, 207, b.bot, manual=False, skip=False)

        assert b.refill_calls == []
        session = await b.sessions.get(user)
        assert session.status == "idle"

    async def test_off_with_queue_preserves_manual_queue_behaviour(
        self, controller_bundle, db_setup
    ) -> None:
        b = controller_bundle
        user = QueueOwner(kind="user", id=208)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user, 208, b.bot, first, 208)
        await b.sessions.set_autoplay(user, False)
        await b.queue.add(user, second, added_by=208)

        await b.controller.next(user, 208, b.bot, manual=False, skip=False)

        session = await b.sessions.get(user)
        assert session.current_track_id == second

    async def test_recommendation_failure_no_infinite_retry_loop(
        self, controller_bundle, db_setup
    ) -> None:
        """A failing recommendation engine must not loop: exactly one
        refill attempt, then the queue-finished state (no repeated
        enqueue of the same failing item)."""
        from app.errors import MusicSourceError

        b = controller_bundle
        user = QueueOwner(kind="user", id=216)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user, 216, b.bot, first, 216)
        await b.sessions.set_autoplay(user, True)

        calls = {"n": 0}

        async def _failing_refill(owner, seed_track_id, count=1):
            calls["n"] += 1
            raise MusicSourceError("engine down")

        b.controller._autoplay.refill = _failing_refill  # type: ignore[method-assign]

        await b.controller.next(user, 216, b.bot, manual=False, skip=False)

        assert calls["n"] == 1, "refill must be attempted exactly once"
        session = await b.sessions.get(user)
        assert session.status == "idle"
        finished = [t for (_c, _m, t) in b.bot.edits]
        assert any("QUEUE FINISHED" in t for t in finished)

    async def test_repeat_one_replays_without_refill(
        self, controller_bundle, db_setup
    ) -> None:
        b = controller_bundle
        user = QueueOwner(kind="user", id=209)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user, 209, b.bot, first, 209)
        await b.sessions.set_autoplay(user, True)
        await b.sessions.set_repeat(user, "one")

        await b.controller.next(user, 209, b.bot, manual=False, skip=False)

        session = await b.sessions.get(user)
        assert session.current_track_id == first
        assert b.refill_calls == []

    async def test_repeat_all_with_autoplay_cycles_queue_not_refill(
        self, controller_bundle, db_setup
    ) -> None:
        """Repeat-all + autoplay ON: the queue follows the repeat mode's
        EXISTING semantics (repeat-all changes the finished-state message
        and keeps manual additions cycling; it does not silently recycle
        played items). A refill is requested only when the queue runs dry
        — the recommendation re-seeds playback. (The second advance here
        is a manual skip: two automatic advances within the 0.9 s
        duplicate-track-end throttle window are dropped by design.)"""
        b = controller_bundle
        user = QueueOwner(kind="user", id=217)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user, 217, b.bot, first, 217)
        await b.sessions.set_autoplay(user, True)
        await b.sessions.set_repeat(user, "all")
        await b.queue.add(user, second, added_by=217)

        # First advance: the queued track serves (no refill yet).
        await b.controller.next(user, 217, b.bot, manual=False, skip=False)
        session = await b.sessions.get(user)
        assert session.current_track_id == second
        assert b.refill_calls == []

        # Queue is dry now: the next advance (manual skip of `second`)
        # refills exactly once through autoplay.
        await b.controller.next(user, 217, b.bot, manual=True, skip=True)
        assert len(b.refill_calls) == 1
        session = await b.sessions.get(user)
        assert session.current_track_id is not None
        assert session.status == "playing"

    async def test_group_isolation_refill_only_for_that_group(
        self, controller_bundle, db_setup
    ) -> None:
        b = controller_bundle
        group_a = QueueOwner(kind="group", id=-100111)
        group_b = QueueOwner(kind="group", id=-100222)
        track = db_setup.track_ids_by_title["Circuit Breaker"]
        await b.controller.play_now(group_a, -100111, b.bot, track, 101)
        await b.controller.play_now(group_b, -100222, b.bot, track, 102)
        await b.sessions.set_autoplay(group_a, True)
        await b.sessions.set_autoplay(group_b, False)

        await b.controller.next(group_a, -100111, b.bot, manual=False, skip=False)

        assert b.refill_calls and all(
            call["owner"] == group_a.topic() for call in b.refill_calls
        )
        # Group B's session untouched.
        session_b = await b.sessions.get(group_b)
        assert session_b.current_track_id == track
        assert session_b.status == "playing"

    async def test_autoplay_setting_persists_through_session_lookup(
        self, controller_bundle, db_setup
    ) -> None:
        b = controller_bundle
        user = QueueOwner(kind="user", id=210)
        await b.sessions.set_autoplay(user, False)
        session = await b.sessions.get(user)
        assert session.autoplay is False
        await b.sessions.set_autoplay(user, True)
        session = await b.sessions.get(user)
        assert session.autoplay is True


class TestShutdownGuards:
    async def test_track_end_after_cleanup_never_advances(
        self, controller_bundle, db_setup
    ) -> None:
        """The production log showed a recommendation served DURING
        shutdown. After cleanup(), track_end events must be ignored."""
        b = controller_bundle
        user = QueueOwner(kind="user", id=211)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user, 211, b.bot, first, 211)
        await b.sessions.set_autoplay(user, True)

        await b.controller.cleanup()
        await b.events.publish("track_end:user:211")

        session = await b.sessions.get(user)
        assert session.current_track_id == first  # unchanged
        assert b.refill_calls == []

    async def test_refill_skipped_when_closing(
        self, controller_bundle, db_setup
    ) -> None:
        b = controller_bundle
        user = QueueOwner(kind="user", id=212)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user, 212, b.bot, first, 212)
        await b.sessions.set_autoplay(user, True)
        b.controller._closing = True  # mid-shutdown simulation

        await b.controller.next(user, 212, b.bot, manual=False, skip=False)

        assert b.refill_calls == []
        session = await b.sessions.get(user)
        assert session.status == "idle"

    async def test_manual_failure_during_shutdown_not_notified(
        self, controller_bundle, db_setup
    ) -> None:
        """_on_track_end failure notifications are suppressed once closing."""
        b = controller_bundle
        user = QueueOwner(kind="user", id=213)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user, 213, b.bot, first, 213)
        messages_before = len(b.bot.messages_sent)
        b.controller._closing = True

        # Simulate the timer callback failing during shutdown.
        await b.controller._on_track_end(
            SimpleNamespace(name="track_end:user:213")
        )

        assert len(b.bot.messages_sent) == messages_before


class TestAutoAdvanceFailureSurfacing:
    async def test_auto_play_failure_sets_idle_and_notifies(
        self, controller_bundle, db_setup, tmp_path
    ) -> None:
        """A failed automatic advance (e.g. download error on the next
        track) must surface the reason and park the session idle — not
        stall silently with a stale Now Playing message."""
        b = controller_bundle
        user = QueueOwner(kind="user", id=214)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user, 214, b.bot, first, 214)
        await b.queue.add(user, second, added_by=214)
        # The next track's media acquisition fails with a categorized error.
        b.music.__class__ = _BotErrorMusic  # type: ignore[misc]
        failing = _BotErrorMusic(b.services.tracks_repo, tmp_path, second)

        async def _get_playable(track):
            return await failing.get_playable_path(track)

        b.controller._music.get_playable_path = _get_playable  # type: ignore[attr-defined]
        # Direct _music patch on the controller instance.
        b.controller._music = failing  # type: ignore[assignment]

        await b.controller.next(user, 214, b.bot, manual=False, skip=False)

        session = await b.sessions.get(user)
        assert session.status == "idle"
        notified = [t for (_c, _m, t) in b.bot.edits] + [
            t for (_c, t, _k) in b.bot.messages_sent
        ]
        assert any("download" in text.lower() for text in notified)

    async def test_manual_failure_still_raises_for_handler(
        self, controller_bundle, db_setup, tmp_path
    ) -> None:
        b = controller_bundle
        user = QueueOwner(kind="user", id=215)
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user, 215, b.bot, first, 215)
        await b.queue.add(user, second, added_by=215)
        failing = _BotErrorMusic(b.services.tracks_repo, tmp_path, second)
        b.controller._music = failing  # type: ignore[assignment]

        with pytest.raises(BotError):
            await b.controller.next(user, 215, b.bot, manual=True, skip=True)


# ======================================================================
# DM→group flow with a call link (end-to-end handler level)
# ======================================================================
class TestDmPlayCallLinkFlow:
    async def test_call_link_reprompts_with_call_explanation(self) -> None:
        """Submitting a t.me/call link during the group-link step keeps the
        selected track and explains the call link (never the old
        'authorized music sources' mismatch)."""
        from app.bot.handlers.dm_play import on_group_link
        from .test_dm_group_play import FakeState, _services as _dm_services
        from .test_dm_group_play import FakeMessage as DmFakeMessage
        from app.voice.group_access import GroupAccessService

        # Real resolution result for a call link (client never touched).
        settings = Settings(
            bot_token="123456789:" + "A" * 33, storage_dir=Path("/tmp/dmcall-storage")
        )
        access = GroupAccessService(settings, None)
        resolution = await access.resolve_target(
            object(), "https://t.me/call/8SkY9x2Qz"
        )

        services = _dm_services(resolve=resolution)
        state = FakeState(
            {
                "dmop_track_id": 12,
                "dmop_created": int(time.time()),
                "dmop_requester": 55,
            }
        )
        message = DmFakeMessage(text="https://t.me/call/8SkY9x2Qz")
        message.from_user = SimpleNamespace(id=55, username="t", first_name="T")
        message.bot = SimpleNamespace(username="testbot")

        await on_group_link(message, services, state)

        # The pending operation's track is NOT lost; still awaiting a link.
        assert state._data["dmop_track_id"] == 12
        assert state._data["dmop_stage"] == "awaiting_link"
        # The prompt carries the call-link explanation.
        text, markup = message.edits[-1]
        assert "Telegram call link" in text
        assert "https://t.me/yourgroup" in text
        # Nothing was played.
        assert services.playback.play_now_calls == []


# ======================================================================
# Audit: every visible group-player button has a handler
# ======================================================================
class TestGroupPanelButtonsAllHandled:
    def test_every_grp_button_callback_has_a_handler(self) -> None:
        """Static audit: each callback emitted by the group player panel
        (controller + keyboard builder) maps to a registered filter in
        groups.py source."""
        groups = importlib.import_module("app.bot.handlers.groups")
        source = inspect.getsource(groups)
        from app.bot.keyboards.group import group_controls_keyboard

        datas = set(
            _datas(
                group_controls_keyboard(
                    paused=False, shuffle=True, repeat_mode="all", volume=100,
                    autoplay=True,
                )
            )
        ) | set(
            _datas(
                group_controls_keyboard(
                    paused=True, shuffle=False, repeat_mode="off", volume=None,
                    autoplay=False,
                )
            )
        )
        # Dynamic payloads with static handlers.
        static_handlers = {
            "grp:pause": 'F.data == "grp:pause"',
            "grp:resume": 'F.data == "grp:resume"',
            "grp:skip": 'F.data == "grp:skip"',
            "grp:stop": 'F.data == "grp:stop"',
            "grp:shuf": 'F.data == "grp:shuf"',
            "grp:rep": 'F.data == "grp:rep"',
            "grp:auto": 'F.data == "grp:auto"',
            "grp:queue": 'F.data == "grp:queue"',
            "grp:vol:dn": 'r"^grp:vol:(dn|up)$"',
            "grp:vol:up": 'r"^grp:vol:(dn|up)$"',
        }
        for data in datas:
            marker = static_handlers.get(data)
            assert marker is not None, f"no known handler marker for {data}"
            assert marker in source, f"handler for {data} missing in groups.py"

"""Round-6 regression locks — the two CRITICAL production bugs + §10–§12.

Production evidence (2026-10-11 10:08–10:17 log):

1. **CRITICAL A — queued track never joins the voice chat.** After a
   restart, ``/play`` produced ``queue.added position=1 size=1`` and
   NOTHING else: no ``queue.popped``, no join, no stream. Root cause:
   ``PlaybackSession.status="playing"`` persisted across restarts while
   the voice session, timers and runtime map died with the old process —
   ``enqueue()`` trusted the ghost status and silently queued behind it.
2. **CRITICAL B — DM "play in group" reports success after a failed
   start.** ``play_now()`` swallowed start failures (notified on the
   group control message, returned ``False``) so the DM screen rendered
   "NOW PLAYING IN THE GROUP" for playback that never started. Same
   ghost-status root cause fed ``was_active``.
3. **Network-outage queue loss.** Tracks 25 and 23 were popped, failed
   to download during the outage, and vanished — no requeue, no record.
4. §10 group command auto-delete, §11 completed download-cache cleanup,
   §12 "Groups With VC" broadcast honesty — new, previously missing.

These tests lock the root-cause fixes, not the symptoms.
"""

from __future__ import annotations

import asyncio
import inspect
import os
from pathlib import Path
from types import SimpleNamespace

import pytest

from app.errors import BotError, TrackNotFoundError
from app.playback.controller import PlaybackController
from app.playback.events import EventBus
from app.playback.queue import QueueManager, QueueOwner
from app.playback.session import SessionManager

from .conftest import build_services
from .test_playback_controller import (
    FakeAnalyticsRecorder,
    FakeBot,
    FakeHistoryGateway,
    FakeMusicGateway,
    FakeVoiceGateway,
)

# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
_GROUP = QueueOwner(kind="group", id=-100999)
_GROUP2 = QueueOwner(kind="group", id=-100888)
_USER = QueueOwner(kind="user", id=101)


class _RepoStub:
    """Minimal PlaybackSessionRepository duck-type for oracle tests."""

    def __init__(self) -> None:
        self.rows: dict[str, dict] = {}

    async def get_or_create(self, kind: str, id_: int):
        key = f"{kind}:{id_}"
        if key not in self.rows:
            self.rows[key] = {
                "id": len(self.rows) + 1,
                "session_type": "group" if kind == "group" else "personal",
                "user_id": id_ if kind == "user" else None,
                "group_id": id_ if kind == "group" else None,
                "status": "idle",
                "current_track_id": None,
                "position_seconds": 0,
            }
        return SimpleNamespace(**self.rows[key])

    async def update_for_owner(self, kind: str, id_: int, **fields):
        key = f"{kind}:{id_}"
        if key not in self.rows:
            return None
        self.rows[key].update(fields)
        return SimpleNamespace(**self.rows[key])

    async def update(self, session_id: int, **fields):
        for row in self.rows.values():
            if row["id"] == session_id:
                row.update(fields)
                return SimpleNamespace(**row)
        return None

    async def active_sessions(self):
        return [
            SimpleNamespace(**row)
            for row in self.rows.values()
            if row["status"] in ("playing", "paused")
        ]

    async def set_now_playing(self, kind, id_, track_id, queue_item_id,
                              message_id, chat_id):
        await self.get_or_create(kind, id_)
        # Update the STORE first, then snapshot — the manager keeps the
        # returned namespace as its authoritative session view.
        self.rows[f"{kind}:{id_}"].update(
            status="playing", current_track_id=track_id
        )
        return SimpleNamespace(**self.rows[f"{kind}:{id_}"])


class _NoEventBus:
    """EventBus stand-in: publish is a no-op (oracle tests need no events)."""

    async def publish(self, *args, **kwargs):  # pragma: no cover - unused
        return None


def _mk_manager(repo=None) -> SessionManager:
    return SessionManager(repo or _RepoStub(), None, _NoEventBus())


@pytest.fixture
async def controller_bundle(db_setup, mk_sessions, tmp_path):
    """Real queue/session/autoplay + fake gateways (clone of the r5 suite)."""
    from app.recommendation.engine import RecommendationEngine
    from app.playback.autoplay import AutoplayService

    services = build_services(mk_sessions)
    events = EventBus()
    queue = QueueManager(services.queue_repo, services.tracks_repo, events)
    sessions = SessionManager(services.sessions_repo, services.tracks_repo, events)
    engine = RecommendationEngine(
        services.tracks_repo, services.profiles, services.settings_repo, services.cache
    )
    autoplay = AutoplayService(engine, queue, services.analytics_repo)
    music = FakeMusicGateway(services.tracks_repo, tmp_path)
    voice = FakeVoiceGateway()
    bot = FakeBot()
    controller = PlaybackController(
        queue=queue,
        autoplay=autoplay,
        music=music,
        voice=voice,
        sessions=sessions,
        events=events,
        analytics=FakeAnalyticsRecorder(),
        history=FakeHistoryGateway(),
        autoplay_enabled=None,
        default_autoplay=True,
    )
    bundle = SimpleNamespace(
        services=services,
        queue=queue,
        sessions=sessions,
        controller=controller,
        voice=voice,
        bot=bot,
    )
    try:
        yield bundle
    finally:
        await controller.cleanup()


@pytest.fixture
def group_owner() -> QueueOwner:
    return QueueOwner(kind="group", id=-100999)


@pytest.fixture
def user_owner() -> QueueOwner:
    return QueueOwner(kind="user", id=101)


# ----------------------------------------------------------------------
# A. Liveness oracle (CRITICAL A root cause)
# ----------------------------------------------------------------------
class TestLivenessOracle:
    async def test_stale_playing_without_runtime_is_not_active(self) -> None:
        """A persisted 'playing' from a previous process is a ghost."""
        repo = _RepoStub()
        await repo.get_or_create("group", -100999)
        await repo.update_for_owner("group", -100999, status="playing")

        manager = _mk_manager(repo)
        assert await manager.is_genuinely_active(_GROUP) is False
        # The ghost was reconciled to idle (honest state, honest /np).
        assert repo.rows["group:-100999"]["status"] == "idle"

    async def test_stale_paused_without_runtime_is_not_active(self) -> None:
        repo = _RepoStub()
        await repo.get_or_create("group", -100999)
        await repo.update_for_owner("group", -100999, status="paused")

        manager = _mk_manager(repo)
        assert await manager.is_genuinely_active(_GROUP) is False
        assert repo.rows["group:-100999"]["status"] == "idle"

    async def test_idle_session_is_not_active(self) -> None:
        manager = _mk_manager()
        assert await manager.is_genuinely_active(_GROUP) is False

    async def test_live_playing_is_active(self) -> None:
        """A session established by playback in THIS process is genuine."""
        repo = _RepoStub()
        manager = _mk_manager(repo)
        await manager.set_now_playing(_GROUP, 7, None, None, None)
        assert await manager.is_genuinely_active(_GROUP) is True

    async def test_in_process_paused_is_active(self) -> None:
        repo = _RepoStub()
        manager = _mk_manager(repo)
        await manager.set_now_playing(_GROUP, 7, None, None, None)
        await manager.update_status(_GROUP, "paused", position_seconds=30)
        assert await manager.is_genuinely_active(_GROUP) is True

    async def test_probe_failure_returns_false(self) -> None:
        class _BrokenRepo(_RepoStub):
            async def get_or_create(self, kind, id_):
                raise RuntimeError("db down")

        manager = _mk_manager(_BrokenRepo())
        assert await manager.is_genuinely_active(_GROUP) is False


# ----------------------------------------------------------------------
# B. Startup reconciliation sweep
# ----------------------------------------------------------------------
class TestStartupReconciliation:
    async def test_parks_every_active_session(self) -> None:
        repo = _RepoStub()
        await repo.get_or_create("group", -100999)
        await repo.update_for_owner("group", -100999, status="playing")
        await repo.get_or_create("user", 101)
        await repo.update_for_owner("user", 101, status="paused")
        await repo.get_or_create("group", -100888)  # idle — untouched

        manager = _mk_manager(repo)
        reconciled = await manager.reconcile_startup_states()

        assert reconciled == 2
        assert repo.rows["group:-100999"]["status"] == "idle"
        assert repo.rows["user:101"]["status"] == "idle"

    async def test_lookup_failure_returns_zero(self) -> None:
        class _BrokenRepo(_RepoStub):
            async def active_sessions(self):
                raise RuntimeError("db down")

        manager = _mk_manager(_BrokenRepo())
        assert await manager.reconcile_startup_states() == 0

    async def test_write_failure_is_best_effort(self) -> None:
        repo = _RepoStub()
        await repo.get_or_create("group", -100999)
        await repo.update_for_owner("group", -100999, status="playing")
        await repo.get_or_create("group", -100888)
        await repo.update_for_owner("group", -100888, status="playing")

        original_update = repo.update

        async def _failing_update(session_id, **fields):
            row = repo.rows.get("group:-100999")
            if row is not None and row["id"] == session_id:
                raise RuntimeError("locked")
            return await original_update(session_id, **fields)

        repo.update = _failing_update
        manager = _mk_manager(repo)
        reconciled = await manager.reconcile_startup_states()
        # One row failed, the other still reconciled.
        assert reconciled == 1
        assert repo.rows["group:-100888"]["status"] == "idle"


# ----------------------------------------------------------------------
# C. Controller honest gate + queue recovery (uses the real bundle)
# ----------------------------------------------------------------------
class TestControllerHonestGate:
    async def test_enqueue_starts_after_ghost_restart(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        """CRITICAL A: a stale 'playing' session must not swallow /play."""
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]

        # Simulate the ghost: persisted status playing, but THIS process
        # has never touched the session (no runtime entry was created).
        await b.services.sessions_repo.update_for_owner(
            "group", group_owner.id, status="playing", current_track_id=track_id
        )

        size = await b.controller.enqueue(group_owner, -100999, b.bot, track_id, 101)

        # The track STARTED (popped + streamed), not silently queued.
        assert size == 0
        assert len(b.voice.played) == 1
        session = await b.sessions.get(group_owner)
        assert session.status == "playing"  # genuinely, in this process

    async def test_enqueue_failure_requeues_and_raises(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        """Network-outage policy: no silent track loss on failed START."""
        b = controller_bundle
        b.voice.enabled = False
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]

        with pytest.raises(BotError):
            await b.controller.enqueue(group_owner, -100999, b.bot, track_id, 101)

        items = await b.queue.get_queue(group_owner)
        assert [item.track_id for item in items] == [track_id]
        assert items[0].position == 1
        # No ghost 'playing' state from the failed start.
        session = await b.sessions.get(group_owner)
        assert session.status != "playing"

    async def test_auto_advance_failure_requeues_notifies_and_parks(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        """Natural track-end into a dead network: keep the track, tell the
        group, park idle — never a silent stall or a lost request."""
        b = controller_bundle
        first = db_setup.track_ids_by_title["Circuit Breaker"]
        second = db_setup.track_ids_by_title["Neon Sunrise"]

        await b.controller.play_now(group_owner, -100999, b.bot, first, 101)
        await b.queue.add(group_owner, second, added_by=101)
        # The network dies between the two tracks.
        b.voice.enabled = False

        await b.controller.next(group_owner, -100999, b.bot, manual=False)

        items = await b.queue.get_queue(group_owner)
        assert [item.track_id for item in items] == [second]
        session = await b.sessions.get(group_owner)
        assert session.status == "idle"
        # The group was told why (auto path notifies through the bot).
        assert any(
            "voice engine" in text.lower()
            for _, text, _ in b.bot.messages_sent
        ), "auto-advance failure must surface the reason"

    async def test_manual_skip_failure_requeues_and_raises(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        b = controller_bundle
        first = db_setup.track_ids_by_title["Circuit Breaker"]
        second = db_setup.track_ids_by_title["Static Bloom"]

        await b.controller.play_now(group_owner, -100999, b.bot, first, 101)
        await b.queue.add(group_owner, second, added_by=101)
        b.voice.enabled = False

        with pytest.raises(BotError):
            await b.controller.next(group_owner, -100999, b.bot,
                                    manual=True, skip=True)

        items = await b.queue.get_queue(group_owner)
        assert [item.track_id for item in items] == [second]

    async def test_is_active_wrapper_delegates(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]

        assert await b.controller.is_active(group_owner) is False
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
        assert await b.controller.is_active(group_owner) is True

    async def test_protected_track_ids_reflects_live_playback(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]

        assert b.controller.protected_track_ids() == set()
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
        assert b.controller.protected_track_ids() == {track_id}
        await b.controller.stop(group_owner, b.bot)
        assert b.controller.protected_track_ids() == set()

    async def test_repeat_one_auto_failure_parks_and_notifies(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        """Repeat-one replay hitting a dead network parks honestly."""
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
        await b.controller.set_repeat(group_owner, "one")
        b.voice.enabled = False

        await b.controller.next(group_owner, -100999, b.bot, manual=False)

        session = await b.sessions.get(group_owner)
        assert session.status == "idle"
        assert any(
            "voice engine" in text.lower()
            for _, text, _ in b.bot.messages_sent
        )


# ----------------------------------------------------------------------
# D. QueueManager.requeue_front
# ----------------------------------------------------------------------
class TestRequeueFront:
    async def test_restores_at_head_without_duplicates(
        self, controller_bundle, group_owner, db_setup
    ) -> None:
        b = controller_bundle
        a = db_setup.track_ids_by_title["Neon Sunrise"]
        c = db_setup.track_ids_by_title["Static Bloom"]
        await b.queue.add(group_owner, a, added_by=101)
        await b.queue.add(group_owner, c, added_by=101)

        popped = await b.queue.pop_next(group_owner)
        assert popped is not None and popped.track_id == a
        await b.queue.requeue_front(group_owner, a, added_by=101)

        items = await b.queue.get_queue(group_owner)
        assert [item.track_id for item in items] == [a, c]
        # Front-insert semantics match the existing add(front=True) path:
        # ordering is the contract (position gaps are pre-existing behaviour
        # for every front insert — remove() leaves them too).
        assert items[0].position == 1
        assert items[0].position < items[1].position

    async def test_missing_track_is_logged_not_raised(
        self, controller_bundle, group_owner
    ) -> None:
        b = controller_bundle
        await b.queue.requeue_front(group_owner, 999999)  # no such track
        items = await b.queue.get_queue(group_owner)
        assert items == []

    async def test_unknown_track_add_still_raises(
        self, controller_bundle, group_owner
    ) -> None:
        """_ensure_track contract unchanged for the normal add() path."""
        b = controller_bundle
        with pytest.raises(TrackNotFoundError):
            await b.queue.add(group_owner, 999999, added_by=1)


# ----------------------------------------------------------------------
# E. Handler-side honest probes (groups + dm_play source wiring)
# ----------------------------------------------------------------------
class TestHandlerProbes:
    async def test_groups_session_is_active_uses_probe(self) -> None:
        from app.bot.handlers.groups import _session_is_active

        services = SimpleNamespace(
            playback=SimpleNamespace(
                is_active=self_async_true,
                now_playing=self_async_raising,
            )
        )
        assert await _session_is_active(services, _GROUP) is True

    async def test_groups_session_is_active_probe_failure_is_false(self) -> None:
        from app.bot.handlers.groups import _session_is_active

        services = SimpleNamespace(playback=SimpleNamespace(is_active=self_async_raising))
        assert await _session_is_active(services, _GROUP) is False

    async def test_groups_session_is_active_falls_back_to_status(self) -> None:
        """Fakes without the probe keep the legacy payload contract."""
        from app.bot.handlers.groups import _session_is_active

        async def _now_playing(owner):
            return {"status": "playing"}

        services = SimpleNamespace(
            playback=SimpleNamespace(now_playing=_now_playing)
        )
        assert await _session_is_active(services, _GROUP) is True

    def test_dm_play_uses_the_liveness_probe(self) -> None:
        """Source-level lock: _execute_play consults is_active before
        deciding queued-vs-start (the false 'NOW PLAYING' root cause)."""
        from app.bot.handlers import dm_play

        source = inspect.getsource(dm_play._execute_play)
        assert "is_active" in source
        assert "was_active" in source

    def test_groups_enqueue_uses_the_liveness_probe(self) -> None:
        from app.bot.handlers import groups

        source = inspect.getsource(groups._enqueue)
        assert "_session_is_active" in source


async def self_async_true(owner):  # pragma: no cover - helper
    return True


async def self_async_raising(owner):  # pragma: no cover - helper
    raise RuntimeError("probe failed")


async def _async_return(value):  # pragma: no cover - helper
    return value


# ----------------------------------------------------------------------
# F. Application wiring (source locks)
# ----------------------------------------------------------------------
class TestApplicationWiring:
    def test_startup_reconciliation_is_called(self) -> None:
        from app import application

        source = inspect.getsource(application.Application._bootstrap)
        assert "reconcile_after_restart" in source

    def test_vc_filter_passed_to_target_selector(self) -> None:
        from app import application

        source = inspect.getsource(application.Application._bootstrap)
        assert "vc_filter=" in source

    def test_cleanup_loop_enqueues_downloads_retention(self) -> None:
        from app import application

        source = inspect.getsource(application.Application._cleanup_loop)
        assert "cleanup_downloads" in source


# ----------------------------------------------------------------------
# G. Download retry backoff + jitter (§13)
# ----------------------------------------------------------------------
class _RetryFakeResponse:
    """Duck-typed aiohttp response whose GET raises on cue."""

    def __init__(self, status: int = 200, body: bytes = b"abc",
                 headers: dict | None = None) -> None:
        self.status = status
        self.body = body
        self.headers = headers or {}

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc_info):
        return False

    async def text(self) -> str:
        return ""

    @property
    def content(self):
        return _FakeContent(self.body)


class _FakeContent:
    def __init__(self, body: bytes) -> None:
        self._body = body

    async def read(self, n: int = -1):
        data, self._body = self._body, b""
        return data

    async def iter_chunked(self, chunk_size: int):
        data, self._body = self._body, b""
        if data:
            yield data


class _RaisingGet:
    """http.get that raises a ClientError the first N times."""

    def __init__(self, failures: int, responses: list) -> None:
        self.failures = failures
        self.responses = list(responses)
        self.calls = 0

    def get(self, url: str, **kwargs):
        self.calls += 1
        if self.calls <= self.failures:
            import aiohttp

            raise aiohttp.ClientConnectionError("connection reset")
        return self.responses.pop(0)


class TestDownloadRetryBackoff:
    def _timeout(self):
        import aiohttp

        return aiohttp.ClientTimeout(total=5)

    async def test_backoff_between_attempts_with_jitter(
        self, tmp_path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.music.sources import url_resolver

        sleeps: list[float] = []
        monkeypatch.setattr(asyncio, "sleep", _recording_sleep(sleeps))
        monkeypatch.setattr(
            "app.music.sources.url_resolver.random.random", lambda: 0.5
        )
        # follow_redirects_safely probes once per attempt; the real GET
        # fails on attempt 1 and succeeds on attempt 2.
        http = _ScriptedSession(
            probe_responses=[_RetryFakeResponse()],
            failures_on_get=1,
            good_response=_RetryFakeResponse(
                status=200, body=b"xyz",
                headers={"Content-Length": "3"},
            ),
        )
        target = tmp_path / "song.mp3"
        written = await url_resolver.stream_download(
            "https://cdn.example.com/song.mp3", http, self._timeout(),
            target, 1024 * 1024,
        )
        assert written == 3
        assert target.read_bytes() == b"xyz"
        # Exactly ONE jittered backoff (0.5s base × (0.75 + 0.25)).
        assert sleeps == [url_resolver.DOWNLOAD_RETRY_BACKOFF_SECONDS * 1.0]

    async def test_bounded_retry_then_real_error(
        self, tmp_path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.music.sources.url_resolver import (
            DOWNLOAD_RETRY_BACKOFF_SECONDS,
            DownloadError,
            stream_download,
        )

        sleeps: list[float] = []
        monkeypatch.setattr(asyncio, "sleep", _recording_sleep(sleeps))
        http = _ScriptedSession(
            probe_responses=[_RetryFakeResponse()],
            failures_on_get=99,
            good_response=_RetryFakeResponse(),
        )
        target = tmp_path / "dead.mp3"
        with pytest.raises(DownloadError):
            await stream_download(
                "https://cdn.example.com/song.mp3", http, self._timeout(),
                target, 1024 * 1024,
            )
        assert len(sleeps) == 1
        assert sleeps[0] == pytest.approx(
            DOWNLOAD_RETRY_BACKOFF_SECONDS, rel=0.3
        )
        assert not target.exists(), "partial file must be cleaned up"

    async def test_permanent_errors_are_not_retried(
        self, tmp_path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.music.sources.url_resolver import DownloadError, stream_download

        sleeps: list[float] = []
        monkeypatch.setattr(asyncio, "sleep", _recording_sleep(sleeps))
        # HTTP 404 → DownloadError → raise immediately, no retry, no sleep.
        http = _ScriptedSession(
            probe_responses=[_RetryFakeResponse()],
            failures_on_get=0,
            good_response=_RetryFakeResponse(status=404),
        )
        target = tmp_path / "gone.mp3"
        with pytest.raises(DownloadError):
            await stream_download(
                "https://cdn.example.com/song.mp3", http, self._timeout(),
                target, 1024 * 1024,
            )
        assert sleeps == []


class _ScriptedSession:
    """Redirect probe always 200; the payload GET raises or answers."""

    def __init__(self, probe_responses, failures_on_get, good_response) -> None:
        self._probes = list(probe_responses)
        self._probe_count = len(self._probes)
        self._failures = failures_on_get
        self._good = good_response
        self.get_calls = 0

    def get(self, url: str, **kwargs):
        self.get_calls += 1
        if self._failures and self.get_calls > self._probe_count:
            # payload GET — fail the first _failures times
            if self.get_calls <= self._probe_count + self._failures:
                import aiohttp

                raise aiohttp.ClientConnectionError("reset by peer")
            return self._good
        return self._probes.pop(0) if self._probes else self._good


def _recording_sleep(sleeps: list[float]):
    async def _sleep(delay: float) -> None:
        sleeps.append(float(delay))

    return _sleep


# ----------------------------------------------------------------------
# H. Group command auto-delete (§10)
# ----------------------------------------------------------------------
class TestGroupCommandAutoDelete:
    def test_middleware_registered_on_groups_router(self) -> None:
        from app.bot.handlers.groups import _delete_recognized_commands, router

        assert _delete_recognized_commands in router.message.middleware._middlewares

    async def test_enabled_deletes_recognized_group_command(self) -> None:
        from app.bot.handlers.groups import _delete_recognized_commands

        deleted: list[int] = []

        async def _delete() -> None:
            deleted.append(1)

        event = SimpleNamespace(
            text="/play despacito",
            chat=SimpleNamespace(id=-100999, type="supergroup"),
            delete=_delete,
        )
        ran = []
        data = {"services": SimpleNamespace(settings=SimpleNamespace(
            groups_delete_commands=True
        ))}
        await _delete_recognized_commands(
            lambda e, d: _async_append(ran), event, data
        )
        assert deleted == [1]
        assert ran == [1]

    async def test_disabled_never_deletes(self) -> None:
        from app.bot.handlers.groups import _delete_recognized_commands

        deleted: list[int] = []

        async def _delete() -> None:
            deleted.append(1)

        event = SimpleNamespace(
            text="/play x", chat=SimpleNamespace(id=-1, type="supergroup"),
            delete=_delete,
        )
        data = {"services": SimpleNamespace(settings=SimpleNamespace(
            groups_delete_commands=False
        ))}
        ran = []
        await _delete_recognized_commands(
            lambda e, d: _async_append(ran), event, data
        )
        assert deleted == []
        assert ran == [1]

    async def test_dm_messages_are_never_deleted(self) -> None:
        from app.bot.handlers.groups import _delete_recognized_commands

        deleted: list[int] = []

        async def _delete() -> None:
            deleted.append(1)

        event = SimpleNamespace(
            text="/start", chat=SimpleNamespace(id=101, type="private"),
            delete=_delete,
        )
        data = {"services": SimpleNamespace(settings=SimpleNamespace(
            groups_delete_commands=True
        ))}
        await _delete_recognized_commands(
            lambda e, d: _async_return(None), event, data
        )
        assert deleted == []

    async def test_non_command_messages_are_never_deleted(self) -> None:
        from app.bot.handlers.groups import _delete_recognized_commands

        deleted: list[int] = []

        async def _delete() -> None:
            deleted.append(1)

        event = SimpleNamespace(
            text=None,  # e.g. new_chat_members service message
            chat=SimpleNamespace(id=-1, type="supergroup"),
            delete=_delete,
        )
        data = {"services": SimpleNamespace(settings=SimpleNamespace(
            groups_delete_commands=True
        ))}
        await _delete_recognized_commands(
            lambda e, d: _async_return(None), event, data
        )
        assert deleted == []

    async def test_delete_failure_does_not_break_the_command(self) -> None:
        from app.bot.handlers.groups import _delete_recognized_commands

        async def _boom() -> None:
            raise RuntimeError("not enough rights")

        event = SimpleNamespace(
            text="/skip", chat=SimpleNamespace(id=-1, type="group"),
            delete=_boom,
        )
        data = {"services": SimpleNamespace(settings=SimpleNamespace(
            groups_delete_commands=True
        ))}
        ran = []
        await _delete_recognized_commands(
            lambda e, d: _async_append(ran), event, data
        )
        assert ran == [1]

    async def test_addressed_command_still_deleted(self) -> None:
        from app.bot.handlers.groups import _delete_recognized_commands

        deleted: list[int] = []

        async def _delete() -> None:
            deleted.append(1)

        event = SimpleNamespace(
            text="/play@Filvenmusic_bot hello",
            chat=SimpleNamespace(id=-1, type="group"),
            delete=_delete,
        )
        data = {"services": SimpleNamespace(settings=SimpleNamespace(
            groups_delete_commands=True
        ))}
        await _delete_recognized_commands(
            lambda e, d: _async_return(None), event, data
        )
        assert deleted == [1]


async def _async_append(target: list) -> None:
    target.append(1)


# ----------------------------------------------------------------------
# I. Completed download-cache cleanup (§11)
# ----------------------------------------------------------------------
class TestDownloadCacheCleanup:
    def _make_file(self, downloads: Path, name: str, age_seconds: float,
                   size: int = 100) -> Path:
        import time

        downloads.mkdir(parents=True, exist_ok=True)
        path = downloads / name
        path.write_bytes(b"x" * size)
        stamp = time.time() - age_seconds
        os.utime(path, (stamp, stamp))
        return path

    def test_old_removed_recent_and_protected_kept(self, tmp_path) -> None:
        from app.storage import StorageService

        storage = StorageService(tmp_path)
        downloads = tmp_path / "downloads"
        old = self._make_file(downloads, "track-11.mp3", 30 * 3600)
        recent = self._make_file(downloads, "track-12.mp3", 3600)
        protected = self._make_file(downloads, "track-13.mp3", 30 * 3600)

        removed, bytes_ = storage.cleanup_downloads(
            24 * 3600, protect_track_ids={13}
        )
        assert removed == 1
        assert bytes_ == 100
        assert not old.exists()
        assert recent.exists()
        assert protected.exists()

    def test_zero_retention_disables_cleanup(self, tmp_path) -> None:
        from app.storage import StorageService

        storage = StorageService(tmp_path)
        downloads = tmp_path / "downloads"
        ancient = self._make_file(downloads, "track-1.mp3", 365 * 86400)
        removed, bytes_ = storage.cleanup_downloads(0)
        assert (removed, bytes_) == (0, 0)
        assert ancient.exists()

    def test_symlink_never_followed_or_deleted(self, tmp_path) -> None:
        from app.storage import StorageService

        storage = StorageService(tmp_path)
        downloads = tmp_path / "downloads"
        downloads.mkdir(parents=True, exist_ok=True)
        outside = tmp_path / "outside-secret.txt"
        outside.write_text("credentials")
        link = downloads / "track-99.mp3"
        link.symlink_to(outside)
        import time

        stamp = time.time() - 30 * 86400
        os.utime(link, (stamp, stamp), follow_symlinks=False)

        removed, _ = storage.cleanup_downloads(24 * 3600)
        assert removed == 0
        assert link.exists()
        assert outside.exists()

    def test_exact_track_id_prefix_protection(self, tmp_path) -> None:
        """track-1. must not protect track-12.mp3 (prefix collision)."""
        from app.storage import StorageService

        storage = StorageService(tmp_path)
        downloads = tmp_path / "downloads"
        self._make_file(downloads, "track-12.mp3", 30 * 3600)
        removed, _ = storage.cleanup_downloads(
            24 * 3600, protect_track_ids={1}
        )
        assert removed == 1
        assert not (downloads / "track-12.mp3").exists()

    def test_music_uploads_are_never_touched(self, tmp_path) -> None:
        from app.storage import StorageService

        storage = StorageService(tmp_path)
        import time

        upload = storage.music_dir() / "user-song.mp3"
        upload.write_bytes(b"y" * 50)
        stamp = time.time() - 365 * 86400
        os.utime(upload, (stamp, stamp))

        removed, _ = storage.cleanup_downloads(24 * 3600)
        assert removed == 0
        assert upload.exists()

    def test_missing_directory_is_fine(self, tmp_path) -> None:
        from app.storage import StorageService

        storage = StorageService(tmp_path)
        # downloads/ is auto-created by the property; empty is fine.
        removed, bytes_ = storage.cleanup_downloads(3600)
        assert (removed, bytes_) == (0, 0)


# ----------------------------------------------------------------------
# J. Workers cleanup_downloads task (§11 integration)
# ----------------------------------------------------------------------
class TestCleanupDownloadsTask:
    async def test_registered_in_task_registry(self) -> None:
        from app.workers.tasks import TASKS

        assert "cleanup_downloads" in TASKS

    async def test_disabled_when_retention_zero(self, monkeypatch) -> None:
        from app.workers import tasks as worker_tasks

        class _Storage:
            def __init__(self):
                self.calls = []

            async def cleanup_downloads(self, *a, **kw):
                self.calls.append((a, kw))
                return (0, 0)

        storage = _Storage()
        monkeypatch.setattr(
            worker_tasks, "_container",
            SimpleNamespace(
                storage=storage,
                settings=SimpleNamespace(downloads_retention_hours=0),
            ),
        )
        await worker_tasks.cleanup_downloads({})
        assert storage.calls == []

    async def test_uses_retention_and_protects_active_tracks(
        self, monkeypatch
    ) -> None:
        from app.workers import tasks as worker_tasks

        calls = {}

        class _Storage:
            async def cleanup_downloads(self, max_age, *, protect_track_ids=None):
                calls["max_age"] = max_age
                calls["protect"] = protect_track_ids
                return (2, 500)

        def _probe():
            return {7, 9}

        monkeypatch.setattr(
            worker_tasks, "_container",
            SimpleNamespace(
                storage=_Storage(),
                settings=SimpleNamespace(downloads_retention_hours=6),
                playback=SimpleNamespace(protected_track_ids=_probe),
            ),
        )
        await worker_tasks.cleanup_downloads({})
        assert calls["max_age"] == 6 * 3600
        assert calls["protect"] == {7, 9}

    async def test_payload_overrides_settings(self, monkeypatch) -> None:
        from app.workers import tasks as worker_tasks

        calls = {}

        class _Storage:
            async def cleanup_downloads(self, max_age, *, protect_track_ids=None):
                calls["max_age"] = max_age
                return (0, 0)

        monkeypatch.setattr(
            worker_tasks, "_container",
            SimpleNamespace(
                storage=_Storage(),
                settings=SimpleNamespace(downloads_retention_hours=24),
            ),
        )
        await worker_tasks.cleanup_downloads({"retention_hours": 2})
        assert calls["max_age"] == 2 * 3600


# ----------------------------------------------------------------------
# K. Broadcast "Groups With VC" honesty (§12)
# ----------------------------------------------------------------------
class _FakeGroupSource:
    def __init__(self, ids: list[int]) -> None:
        self.ids = ids

    async def broadcast_segment(self, segment, ids=None):
        return list(self.ids)


class _FakeUserSource:
    async def broadcast_segment(self, segment, language=None, ids=None):
        return []


class TestBroadcastVCHonesty:
    async def test_vc_filter_keeps_only_proven_groups(self) -> None:
        from app.broadcast.targets import TargetSelector

        async def _checker(group_id: int) -> bool:
            return group_id == -100111

        selector = TargetSelector(
            _FakeUserSource(), _FakeGroupSource([-100111, -100222]),
            vc_filter=_checker,
        )
        targets = await selector.build("groups_with_vc", {})
        assert targets == [("group", -100111)]

    async def test_unproven_groups_are_excluded(self) -> None:
        from app.broadcast.targets import TargetSelector

        async def _broken(group_id: int) -> bool:
            raise RuntimeError("mtproto down")

        selector = TargetSelector(
            _FakeUserSource(), _FakeGroupSource([-100111]),
            vc_filter=_broken,
        )
        targets = await selector.build("groups_with_vc", {})
        assert targets == []

    async def test_no_filter_degrades_loudly_to_active_groups(self) -> None:
        from app.broadcast.targets import TargetSelector

        selector = TargetSelector(
            _FakeUserSource(), _FakeGroupSource([-100111, -100222])
        )
        targets = await selector.build("groups_with_vc", {})
        assert targets == [("group", -100111), ("group", -100222)]

    async def test_other_group_targets_are_not_filtered(self) -> None:
        from app.broadcast.targets import TargetSelector

        async def _never(group_id: int) -> bool:  # pragma: no cover
            return False

        selector = TargetSelector(
            _FakeUserSource(), _FakeGroupSource([-100111]),
            vc_filter=_never,
        )
        targets = await selector.build("active_groups", {})
        assert targets == [("group", -100111)]

    async def test_confirm_screen_discloses_live_check(self) -> None:
        from app.bot.handlers.admin import broadcast as bc

        source = inspect.getsource(bc._render_confirm)
        assert "checked live" in source
        assert "groups_with_vc" in source

    def test_targets_keyboard_offers_groups_with_vc(self) -> None:
        from app.bot.keyboards.admin import admin_broadcast_targets_keyboard

        keyboard = admin_broadcast_targets_keyboard()
        flat = [btn.callback_data for row in keyboard.inline_keyboard for btn in row]
        assert "adm:bc:target:groups_with_vc" in flat


# ----------------------------------------------------------------------
# L. About button + dashboard action (§16)
# ----------------------------------------------------------------------
class TestAboutExperience:
    def test_default_buttons_include_about(self) -> None:
        from app.database.defaults import DEFAULT_BUTTONS

        about = [b for b in DEFAULT_BUTTONS if b["action"] == "dash:about"]
        assert about and about[0]["position"] == 95

    def test_known_actions_include_about(self) -> None:
        from app.admin.buttons import KNOWN_ACTIONS

        assert "dash:about" in KNOWN_ACTIONS

    def test_dispatcher_has_about_branch(self) -> None:
        from app.bot.handlers import start

        source = inspect.getsource(start.on_dashboard_action)
        assert 'action == "about"' in source

    def test_action_picker_renders_about(self) -> None:
        from app.bot.keyboards.admin import admin_button_action_picker_keyboard

        keyboard = admin_button_action_picker_keyboard()
        flat = [btn.callback_data for row in keyboard.inline_keyboard for btn in row]
        assert "adm:btn:action:dash:about" in flat

    async def test_ensure_defaults_backfills_about_once(
        self, engine, mk_sessions
    ) -> None:
        """Existing pre-About databases gain exactly one About button."""
        from app.database.base import Base
        from app.database.models import BotButton
        from app.database.repositories.settings import BotButtonRepository
        from sqlalchemy import select

        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

        async with mk_sessions() as s:
            s.add(BotButton(label="🎵 Search Music", action="dash:search",
                            button_type="callback", position=10, is_enabled=True))
            await s.commit()

        repo = BotButtonRepository(mk_sessions)
        created = await repo.ensure_defaults()
        assert created == 1

        async with mk_sessions() as s:
            rows = (await s.execute(select(BotButton))).scalars().all()
        actions = {row.action for row in rows}
        assert "dash:about" in actions
        assert "dash:search" in actions  # untouched
        assert len(rows) == 2

        # Idempotent: a second call adds nothing.
        assert await repo.ensure_defaults() == 0

    async def test_ensure_defaults_empty_table_seeds_all(
        self, engine, mk_sessions
    ) -> None:
        from app.database.base import Base
        from app.database.defaults import DEFAULT_BUTTONS
        from app.database.repositories.settings import BotButtonRepository
        from sqlalchemy import select
        from app.database.models import BotButton

        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

        repo = BotButtonRepository(mk_sessions)
        created = await repo.ensure_defaults()
        assert created == len(DEFAULT_BUTTONS)

        async with mk_sessions() as s:
            rows = (await s.execute(select(BotButton))).scalars().all()
        assert any(row.action == "dash:about" for row in rows)


# ----------------------------------------------------------------------
# M. New settings surface (§10/§11 config)
# ----------------------------------------------------------------------
class TestNewSettings:
    def test_defaults(self) -> None:
        from app.config import Settings

        settings = Settings(bot_token="123456789:" + "A" * 33)
        assert settings.groups_delete_commands is False
        assert settings.downloads_retention_hours == 24

    def test_env_parsing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from app.config import load_settings

        monkeypatch.setenv("BOT_TOKEN", "123456789:" + "A" * 33)
        monkeypatch.setenv("GROUPS_DELETE_COMMANDS", "true")
        monkeypatch.setenv("DOWNLOADS_RETENTION_HOURS", "0")
        settings = load_settings(env_file=None)
        assert settings.groups_delete_commands is True
        # 0 is a VALID value (disables cleanup) — not coerced to 24.
        assert settings.downloads_retention_hours == 0

    def test_retention_bounds_validated(self) -> None:
        from app.config import ConfigError as AppConfigError
        from app.config import Settings, validate_settings

        with pytest.raises(AppConfigError):
            validate_settings(Settings(
                bot_token="123456789:" + "A" * 33,
                downloads_retention_hours=-1,
            ))
        with pytest.raises(AppConfigError):
            validate_settings(Settings(
                bot_token="123456789:" + "A" * 33,
                downloads_retention_hours=9000,
            ))


# ----------------------------------------------------------------------
# N. play_now contract change — honest starts everywhere
# ----------------------------------------------------------------------
class TestPlayNowHonestContract:
    async def test_voice_play_failure_raises_specific_bot_error(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        """CRITICAL B root cause: the exact error must reach the caller
        (DM screen / group status message) — never a silent False."""
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]

        class _FailingVoice:
            async def play(self, group_tg_id, path):
                from app.errors import VoiceChatMissingError

                raise VoiceChatMissingError("no active voice chat")

            async def is_voice_enabled(self):
                return True

        b.controller._voice = _FailingVoice()

        with pytest.raises(BotError) as excinfo:
            await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
        assert "voice chat" in excinfo.value.user_message.lower()
        session = await b.sessions.get(group_owner)
        assert session.status != "playing"

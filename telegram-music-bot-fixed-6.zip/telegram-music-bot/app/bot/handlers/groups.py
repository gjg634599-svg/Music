"""Group chat handlers: playback commands, ``grp:`` callbacks and lifecycle sync.

Everything in this module runs in **group/supergroup** chats only (message
handlers are filtered by chat type; callbacks are filtered on the chat of the
message that carries the inline keyboard).

Silent group mode is law:

* the bot only ever responds to explicit commands, inline-button callbacks and
  permission errors on explicit actions — never to plain text;
* the ``my_chat_member`` / ``new_chat_members`` handlers exist purely to keep
  the database in sync when the bot is added to or removed from a group —
  they never send a message;
* track advancement is rendered by the
  :class:`~app.playback.controller.PlaybackController` through the stored
  Now Playing message; these handlers never duplicate that.

Callback data registry (CONTRACTS §8): ``grp:home``, ``grp:queue``, ``grp:np``,
``grp:settings``, ``grp:set:<key>:<value>``, ``grp:pmode:<mode>``,
``grp:djs``, ``grp:dj:<user_id>:<value>``, the ``grp:new`` / ``grp:new:<page>``
browse screens with one-tap ``grp:newq:<track_id>`` queue buttons, and the
group-context ``trk:<id>`` / ``trk:play:<id>`` / ``trk:queue:<id>`` /
``trk:like:<id>`` buttons (Task 3-a owns the same patterns for private chats).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from time import monotonic
from typing import Any

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import CallbackQuery, ChatMemberUpdated, InlineKeyboardMarkup, Message

from app.bot.keyboards.group import (
    GROUP_NEW_PAGE_SIZE,
    MAX_DJ_BUTTONS,
    PERMISSION_MODE_LABELS,
    dj_list_keyboard,
    group_controls_keyboard,
    group_dashboard_keyboard,
    group_new_releases_keyboard,
    group_queue_keyboard,
    group_search_results_keyboard,
    group_settings_keyboard,
    group_track_keyboard,
    permission_mode_keyboard,
)
from app.bot.handlers.search import artist_name
from app.bot.services import ServiceContainer
from app.errors import BotError
from app.logging import get_logger, log_extra
from app.playback.queue import QueueOwner
from app.utils import (
    PayloadBadges,
    escape,
    format_duration,
    is_group,
    now_playing_text,
    queue_total_line,
    repeat_label,
    safe_answer,
    track_line,
    truncate,
    user_link,
)

logger = get_logger(__name__)

router = Router(name="groups")

#: Chat types this router serves.
GROUP_CHAT_TYPES = {"group", "supergroup"}

#: Message-level chat type filter.
GROUP_MESSAGE = F.chat.type.in_(GROUP_CHAT_TYPES)

#: Callback-level chat type filter (chat of the message carrying the buttons).
GROUP_CALLBACK = F.message.chat.type.in_(GROUP_CHAT_TYPES)


@router.message.middleware()
async def _delete_recognized_commands(
    handler: Any, event: Message, data: dict[str, Any]
) -> Any:
    """Best-effort deletion of RECOGNIZED group command messages (§10).

    This is an INNER middleware: it only fires after a command handler in
    this router matched — ordinary messages, DMs and callback queries can
    never reach it, so only genuine ``/play``-style commands (including
    ``/play@BotUsername``) are ever deleted, and only when the
    ``GROUPS_DELETE_COMMANDS`` setting is enabled.

    Deletion failures (bot lacks delete rights, message already gone) are
    suppressed — chat hygiene must never break command processing.
    """
    services = data.get("services")
    settings = getattr(services, "settings", None)
    if settings is not None and getattr(settings, "groups_delete_commands", False):
        text = getattr(event, "text", None)
        chat = getattr(event, "chat", None)
        if (
            isinstance(text, str)
            and text.startswith("/")
            and chat is not None
            and chat.type in GROUP_CHAT_TYPES
        ):
            try:
                await event.delete()
            except Exception:  # noqa: BLE001 — missing rights etc.
                logger.debug(
                    "groups.command_delete_failed",
                    extra=log_extra(chat_id=chat.id),
                )
    return await handler(event, data)

#: How long resolved chat-admin statuses stay cached (seconds).
ADMIN_CACHE_TTL = 300.0

#: Telegram member statuses that count as chat administrators.
_ADMIN_STATUSES = frozenset({"administrator", "creator"})

#: Session statuses that mean "a track is currently active".
_ACTIVE_STATUSES = frozenset({"playing", "paused"})

#: Repeat-mode cycle order and labels.
_REPEAT_ORDER: tuple[str, ...] = ("off", "all", "one")
_REPEAT_LABELS = {"off": "Off", "all": "All", "one": "One"}

#: Number of search results offered in a group.
SEARCH_RESULTS_LIMIT = 8

#: Number of upcoming tracks listed by /queue.
QUEUE_PREVIEW_LIMIT = 8

#: Permission action used for /volume (the permission engine has no dedicated
#: volume action; the generic transport-control action matches its semantics).
VOLUME_ACTION = "play"

# ----------------------------------------------------------------------
# User-facing texts (short by design)
# ----------------------------------------------------------------------
PERMISSION_DENIED = "❌ You don't have permission to control playback."
SETTINGS_ADMIN_ONLY = "❌ Only group admins can change group settings."
DJS_ADMIN_ONLY = "❌ Only group admins can manage DJs."
# NOTE: every string below is sent with parse_mode="HTML" — placeholder
# angle brackets MUST be entity-escaped (&lt;…&gt;). Raw "<song name>" made
# Telegram reject the whole reply with ``can't parse entities: Unsupported
# start tag "song"`` (production log, groups.reply_failed).
USAGE_PLAY = "💡 Usage: /play &lt;song name&gt;"
USAGE_SEARCH = "💡 Usage: /search &lt;song name&gt;"
USAGE_VOLUME = "💡 Usage: /volume &lt;0-200&gt;"
NOT_FOUND_TEXT = "❌ Couldn't find that track."
SKIPPED_TEXT = "⏭️ Skipped."
PAUSED_TEXT = "⏸️ Paused."
RESUMED_TEXT = "▶️ Resumed."
STOPPED_TEXT = "🛑 Stopped. Left the voice chat."
SHUFFLED_TEXT = "🔀 Queue shuffled."
READY_TEXT = (
    "🎵 <b>GROUP MUSIC</b>\n\n"
    "Ready to play music in this group.\n\n"
    "Use /play &lt;song&gt; to start — music plays in the voice chat."
)
SEARCH_HINT_TEXT = (
    "🔎 <b>SEARCH MUSIC</b>\n\n"
    "Send /play &lt;song&gt; to play the top match right away, or "
    "/search &lt;song&gt; to pick from a list.\n\n"
    "No search mode in groups — keep the chat clean."
)
VOICE_HINT_TEXT = "🎙️ Join the voice chat, then use /play"
PERMISSIONS_PICKER_TEXT = (
    "🎛️ <b>PERMISSIONS</b>\n\n"
    "Who can control playback in this group?\n\n"
    "👥 Everyone — all members\n"
    "🛡️ Admins — chat admins only\n"
    "🎤 DJ Mode — admins + DJs"
)
SETTINGS_ADMIN_HINT = "ℹ️ Only group admins can change these settings."
GROUP_HELP_FALLBACK = (
    "🎵 <b>GROUP MUSIC</b>\n\n"
    "/play &lt;song&gt; — play a track in the voice chat\n"
    "/new — browse new releases, tap to queue\n"
    "/queue — show the queue\n"
    "/skip — skip the current track\n"
    "/pause /resume — control playback\n"
    "/stop — stop and leave the voice chat\n"
    "/settings — group music settings"
)


def _searching_text(query: str) -> str:
    """Immediate acknowledgement posted before any provider call.

    Group searches never animate (see the design rules in
    ``app/bot/search_progress.py``) — a single message is posted instantly
    and later edited into the outcome, closing the multi-second dead air
    while sources respond (production: 7–10 s per search).
    """
    return (
        "🔎 <b>Searching…</b>\n\n"
        f"Query: {escape(truncate((query or '').strip(), 80))}"
    )


def _loading_text(track: Any) -> str:
    """Loading acknowledgement while the matched track downloads."""
    artist = escape(_artist_of(track))
    line = f"⬇️ <b>Loading track…</b>\n\n{_title_of(track)}"
    if artist:
        line += f" — {artist}"
    return line

#: ``grp:dj:<user_id>:<value>`` toggle pattern.
_DJ_TOGGLE_RE = re.compile(r"^grp:dj:(-?\d+):([01])$")

#: ``grp:new:<page>`` pagination pattern (note: never matches ``grp:newq:``).
_NEW_PAGE_RE = re.compile(r"^grp:new:(\d+)$")


# ----------------------------------------------------------------------
# Chat-admin resolution (cached 5 minutes)
# ----------------------------------------------------------------------
_ADMIN_CACHE: dict[tuple[int, int], tuple[float, bool]] = {}


async def _resolve_chat_admin(
    bot: Any,
    chat_id: int,
    user_id: int,
    *,
    sender_chat_id: int | None = None,
) -> bool:
    """Whether *user_id* is an administrator of the group *chat_id*.

    Results are cached for :data:`ADMIN_CACHE_TTL` so permission-relevant
    commands cost at most one ``get_chat_member`` call per user per group per
    five minutes. Messages sent on behalf of the chat itself (anonymous group
    admins, ``sender_chat == chat``) always count as admins.
    """
    key = (int(chat_id), int(user_id))
    now = monotonic()
    cached = _ADMIN_CACHE.get(key)
    if cached is not None and (now - cached[0]) < ADMIN_CACHE_TTL:
        return cached[1]

    if sender_chat_id is not None and int(sender_chat_id) == int(chat_id):
        is_admin = True  # anonymous group admin
    else:
        is_admin = False
        try:
            member = await bot.get_chat_member(int(chat_id), int(user_id))
            is_admin = getattr(member, "status", None) in _ADMIN_STATUSES
        except Exception as exc:  # noqa: BLE001 — API hiccup: deny, stay cached
            logger.debug(
                "groups.admin_lookup_failed",
                extra=log_extra(chat_id=chat_id, user_id=user_id, error=str(exc)[:160]),
            )
    _ADMIN_CACHE[key] = (now, bool(is_admin))
    return bool(is_admin)


def _owner(chat_id: int) -> QueueOwner:
    """Queue owner for a group chat."""
    return QueueOwner(kind="group", id=int(chat_id))


@dataclass(slots=True)
class _GroupCtx:
    """Per-update sync context: DB user/group rows plus admin status."""

    user: Any
    group: Any
    user_tg_id: int
    group_tg_id: int
    is_chat_admin: bool


async def _prepare(
    message: Message,
    services: ServiceContainer,
    *,
    need_admin: bool = False,
) -> _GroupCtx:
    """Sync user + group + membership rows for a group command.

    Args:
        message: Group command message.
        services: Service container.
        need_admin: Resolve (and cache) the sender's chat-admin status; needed
            by every permission-gated command.
    """
    user = await services.users.get_or_create(message.from_user)
    group = await services.groups.get_or_create(message.chat)
    user_tg_id = int(getattr(message.from_user, "id", 0) or 0)
    sender_chat = getattr(message, "sender_chat", None)
    is_admin = (
        await _resolve_chat_admin(
            message.bot,
            message.chat.id,
            user_tg_id,
            sender_chat_id=getattr(sender_chat, "id", None),
        )
        if need_admin
        else False
    )
    try:
        await services.groups.sync_member(
            group.id, user.id, user_tg_id, is_admin=is_admin
        )
    except Exception as exc:  # noqa: BLE001 — membership sync is best effort
        logger.warning(
            "groups.member_sync_failed",
            extra=log_extra(group_id=group.id, user_id=user.id, error=str(exc)[:160]),
        )
    return _GroupCtx(
        user=user,
        group=group,
        user_tg_id=user_tg_id,
        group_tg_id=int(message.chat.id),
        is_chat_admin=is_admin,
    )


async def _prepare_callback(
    callback: CallbackQuery,
    services: ServiceContainer,
    *,
    need_admin: bool = False,
) -> _GroupCtx:
    """Sync context for a group callback query (see :func:`_prepare`)."""
    message = callback.message
    chat = getattr(message, "chat", None)
    if chat is None or not is_group(getattr(chat, "type", None)):
        raise BotError("callback is not attached to a group message")
    user = await services.users.get_or_create(callback.from_user)
    group = await services.groups.get_or_create(chat)
    user_tg_id = int(getattr(callback.from_user, "id", 0) or 0)
    is_admin = (
        await _resolve_chat_admin(callback.bot, chat.id, user_tg_id)
        if need_admin
        else False
    )
    try:
        await services.groups.sync_member(
            group.id, user.id, user_tg_id, is_admin=is_admin
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "groups.member_sync_failed",
            extra=log_extra(group_id=group.id, user_id=user.id, error=str(exc)[:160]),
        )
    return _GroupCtx(
        user=user,
        group=group,
        user_tg_id=user_tg_id,
        group_tg_id=int(chat.id),
        is_chat_admin=is_admin,
    )


# ----------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------
async def _say(
    message: Message, text: str, reply_markup: Any = None
) -> Message | None:
    """Reply concisely (HTML); returns the sent message or ``None``."""
    try:
        return await message.reply(
            text,
            parse_mode="HTML",
            reply_markup=reply_markup,
            allow_sending_without_reply=True,
        )
    except Exception as exc:  # noqa: BLE001 — the chat may forbid the bot
        logger.warning(
            "groups.reply_failed",
            extra=log_extra(error=str(exc)[:160]),
        )
        return None


async def _edit(message: Any, text: str, reply_markup: Any = None) -> None:
    """Edit a group message in place (HTML); failures are swallowed.

    Silent group mode: a failed edit never falls back to sending a new
    message — the user simply presses the button again.
    """
    if message is None:
        return
    try:
        await message.edit_text(text, parse_mode="HTML", reply_markup=reply_markup)
    except Exception as exc:  # noqa: BLE001 — old/unreadable messages
        logger.debug(
            "groups.edit_failed",
            extra=log_extra(error=str(exc)[:160]),
        )


async def _edit_or_say(
    message: Message,
    status: Message | None,
    text: str,
    reply_markup: Any = None,
) -> None:
    """Edit the transient *status* message into *text*; fall back to a reply.

    Groups stay low-noise: one status message carries the whole request
    (searching → loading → outcome). When the status message is missing or
    too old to edit, the outcome is sent as a fresh reply instead — the
    user always gets an answer, never a dead end.
    """
    if status is not None:
        try:
            await status.edit_text(text, parse_mode="HTML", reply_markup=reply_markup)
            return
        except Exception as exc:  # noqa: BLE001 — fall back to a fresh reply
            logger.debug(
                "groups.status_edit_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
    await _say(message, text, reply_markup)


async def _allowed(
    services: ServiceContainer,
    group_tg_id: int,
    user_tg_id: int,
    action: str,
    is_chat_admin: bool,
) -> bool:
    """Permission check that never raises (denies on lookup failures)."""
    try:
        return bool(
            await services.permissions.can(
                group_tg_id, user_tg_id, action, is_chat_admin=is_chat_admin
            )
        )
    except Exception as exc:  # noqa: BLE001 — deny on errors
        logger.warning(
            "groups.permission_check_failed",
            extra=log_extra(action=action, error=str(exc)[:160]),
        )
        return False


async def _track_event(
    services: ServiceContainer,
    event_type: str,
    *,
    user_tg_id: int | None = None,
    group_tg_id: int | None = None,
    track_id: int | None = None,
    payload: dict[str, Any] | None = None,
) -> None:
    """Fire-and-forget analytics event (never breaks the handler)."""
    try:
        await services.analytics.track(
            event_type,
            user_id=user_tg_id,
            group_id=group_tg_id,
            track_id=track_id,
            payload=payload or {},
        )
    except Exception:  # noqa: BLE001 — analytics is best effort
        pass


def _artist_of(track: Any) -> str:
    """Best-effort artist name of a track row."""
    artist = getattr(track, "artist", None)
    return str(getattr(artist, "name", None) or "")


def _title_of(track: Any) -> str:
    """Escaped track title (never empty)."""
    return escape(str(getattr(track, "title", "") or "Unknown track"))


async def _help_text(services: ServiceContainer) -> str:
    """Group help text (admin-customizable, safe fallback)."""
    try:
        text = await services.admin.appearance.message("group_help")
        return text or GROUP_HELP_FALLBACK
    except Exception:  # noqa: BLE001 — appearance is optional plumbing
        return GROUP_HELP_FALLBACK


async def _render_new_group(
    services: ServiceContainer, page: int
) -> tuple[str, InlineKeyboardMarkup]:
    """One page of the group ``/new`` browse (one-tap queue buttons).

    Mirrors the private ``/new`` renderer (clamp-then-refetch included) but
    every row button queues the track directly — the group "radio" flow.
    """
    page = max(1, int(page))
    tracks, total = await services.music.new_releases(
        limit=GROUP_NEW_PAGE_SIZE, offset=(page - 1) * GROUP_NEW_PAGE_SIZE
    )
    total_pages = max(1, -(-total // GROUP_NEW_PAGE_SIZE))
    if page > total_pages:
        # Stale keyboard / out-of-range page — jump to the last real page
        # (same guard as the private /new renderer).
        page = total_pages
        tracks, _ = await services.music.new_releases(
            limit=GROUP_NEW_PAGE_SIZE, offset=(page - 1) * GROUP_NEW_PAGE_SIZE
        )
    lines = [f"🆕 <b>NEW RELEASES</b> · {total} tracks", ""]
    if not tracks:
        lines.append("ℹ️ The catalog is empty — upload a track first!")
    else:
        lines.append("Tap a track to add it to the queue.")
        lines.append("")
        for offset, track in enumerate(tracks):
            lines.append(
                track_line(
                    (page - 1) * GROUP_NEW_PAGE_SIZE + offset + 1,
                    str(getattr(track, "title", "") or "Unknown"),
                    artist_name(track),
                )
            )
        if total_pages > 1:
            lines.append("")
            lines.append(f"📄 Page {page} of {total_pages} — freshest first")
    text = "\n".join(lines)
    keyboard = group_new_releases_keyboard(page, total_pages, tracks)
    return text, keyboard


async def _session_is_active(services: ServiceContainer, owner: QueueOwner) -> bool:
    """Honest "is a track really playing/paused right now?" probe.

    Prefers the controller's liveness probe (``is_active``): the persisted
    session status alone is NOT proof — a previous process can have left
    it ``playing`` while the voice session, timers and bookkeeping died
    with that process (production: ``/play`` queued behind a ghost and
    nothing ever joined the voice chat).
    """
    probe = getattr(services.playback, "is_active", None)
    if probe is not None:
        try:
            return bool(await probe(owner))
        except Exception:  # noqa: BLE001 — probe failure must not block /play
            return False
    try:
        payload = await services.playback.now_playing(owner)
        return payload.get("status") in _ACTIVE_STATUSES
    except Exception:  # noqa: BLE001 — treat as idle on lookup failure
        return False


async def _enqueue(
    services: ServiceContainer,
    chat_id: int,
    bot: Any,
    track_id: int,
    user_tg_id: int,
    *,
    status_message: Any = None,
) -> tuple[int, bool]:
    """Enqueue a track and report whether it started immediately.

    Returns ``(waiting_size, was_active)`` — ``was_active`` is True when a
    track was genuinely playing/paused (liveness-probed), i.e. the new
    item was queued behind it instead of starting right away (in which
    case the PlaybackController renders the Now Playing message itself).
    *status_message* (the group "Loading track…" acknowledgement) is
    forwarded as ``edit_message`` so the controller can edit it into the
    Now Playing control — or into the failure text when playback cannot
    start.
    """
    owner = _owner(chat_id)
    was_active = await _session_is_active(services, owner)
    size = await services.playback.enqueue(
        owner, chat_id, bot, track_id, user_tg_id, edit_message=status_message
    )
    return int(size), bool(was_active)


# ----------------------------------------------------------------------
# View renderers (shared by commands and callbacks)
# ----------------------------------------------------------------------
def _np_text(payload: dict[str, Any]) -> str:
    """Now Playing / Paused message body for a group session.

    Thin delegation to the ONE shared renderer — the group control message,
    the personal player and the dashboard Now-Playing screen all share the
    same layout (title, artist, playhead progress bar, state badges,
    queue count).
    """
    track = payload.get("track")
    if track is None:
        return READY_TEXT
    return now_playing_text(
        track,
        position=max(0, int(payload.get("position_seconds") or 0)),
        paused=payload.get("status") == "paused",
        session=PayloadBadges(payload),
        queue_size=int(payload.get("queue_size") or 0),
    )


async def _np_view(
    services: ServiceContainer, owner: QueueOwner
) -> tuple[str, InlineKeyboardMarkup]:
    """(text, keyboard) for the Now Playing view; ready view when idle."""
    try:
        payload = await services.playback.now_playing(owner)
    except Exception as exc:  # noqa: BLE001 — render the ready state
        logger.warning(
            "groups.np_lookup_failed",
            extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
        )
        return READY_TEXT, group_dashboard_keyboard(playing=False)
    if payload.get("track") is None:
        return READY_TEXT, group_dashboard_keyboard(playing=False)
    return _np_text(payload), group_controls_keyboard(
        paused=payload.get("status") == "paused",
        shuffle=bool(payload.get("shuffle")),
        repeat_mode=str(payload.get("repeat_mode") or "off"),
        volume=payload.get("volume") if payload.get("volume") is not None else None,
        autoplay=bool(payload.get("autoplay")),
    )


async def _queue_view(
    services: ServiceContainer, owner: QueueOwner
) -> tuple[str, InlineKeyboardMarkup]:
    """(text, keyboard) for the group queue view.

    Every upcoming entry carries its duration and the member who requested
    it (resolved best-effort from the users table); the footer totals the
    queue time — the "Up next" pattern the established group music bots
    converge on.
    """
    lines = ["🎧 <b>Group Queue</b>", ""]
    try:
        payload = await services.playback.now_playing(owner)
    except Exception:  # noqa: BLE001 — degrade to an empty view
        payload = {}
    track = payload.get("track")
    if track is not None:
        artist = escape(_artist_of(track))
        lines.append(f"▶️ <b>{_title_of(track)}</b>")
        if artist:
            lines.append(f"   🎤 {artist}")
        lines.append("")
    else:
        lines.extend(["ℹ️ Nothing is playing right now.", ""])

    try:
        items = await services.queue.get_queue(owner)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "groups.queue_lookup_failed",
            extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
        )
        items = []

    durations: list[int | None] = []
    requester_ids: set[int] = set()
    for item in items[:QUEUE_PREVIEW_LIMIT]:
        added_by = getattr(item, "added_by", None)
        if isinstance(added_by, int) and added_by > 0:
            requester_ids.add(added_by)
    names: dict[int, str] = {}
    for tg_id in requester_ids:
        try:
            user = await services.users.get(tg_id)
        except Exception:  # noqa: BLE001 — names are cosmetic
            user = None
        if user is not None:
            first = (getattr(user, "first_name", None) or "").strip()
            if first:
                names[tg_id] = first

    if items:
        lines.append("⏭ <b>Up next</b>")
        for index, item in enumerate(items[:QUEUE_PREVIEW_LIMIT], start=1):
            item_track = getattr(item, "track", None)
            title = _title_of(item_track) if item_track is not None else escape(
                f"Track #{getattr(item, 'track_id', '?')}"
            )
            artist = escape(_artist_of(item_track)) if item_track is not None else ""
            duration = (
                int(getattr(item_track, "duration_seconds", 0) or 0)
                if item_track is not None
                else 0
            )
            durations.append(duration or None)
            line = f"{index}. {title}"
            if artist:
                line += f" — {artist}"
            if duration > 0:
                line += f" · {format_duration(duration)}"
            added_by = getattr(item, "added_by", None)
            if isinstance(added_by, int) and added_by > 0:
                line += f"\n   👤 {user_link(added_by, names.get(added_by))}"
            lines.append(line)
        rest = len(items) - QUEUE_PREVIEW_LIMIT
        if rest > 0:
            lines.append(f"… and {rest} more")
        lines.append("")
        lines.append(queue_total_line(durations))
    else:
        lines.append("📋 The queue is empty.")

    session = None
    try:
        session = await services.sessions.get(owner)
    except Exception:  # noqa: BLE001 — cosmetic defaults
        session = None
    return "\n".join(lines), group_queue_keyboard(
        shuffle=bool(getattr(session, "shuffle", False)),
        repeat_mode=str(getattr(session, "repeat_mode", "off") or "off"),
        autoplay=bool(getattr(session, "autoplay", False)),
    )


def _settings_text(settings: Any) -> str:
    """Settings screen body."""
    silent = bool(getattr(settings, "silent_mode", True))
    autoplay = bool(getattr(settings, "autoplay_enabled", True))
    mode = str(getattr(settings, "permission_mode", "everyone") or "everyone")
    mode_label = PERMISSION_MODE_LABELS.get(mode, mode)
    return (
        "⚙️ <b>GROUP SETTINGS</b>\n\n"
        f"🔇 Silent Mode: {'On' if silent else 'Off'}\n"
        f"🤖 Autoplay: {'On' if autoplay else 'Off'}\n"
        f"🎛️ Permissions: {mode_label}\n\n"
        f"{SETTINGS_ADMIN_HINT}"
    )


async def _settings_view(
    services: ServiceContainer, group_tg_id: int
) -> tuple[str, InlineKeyboardMarkup]:
    """(text, keyboard) for the group settings screen."""
    settings = await services.group_settings.get(group_tg_id)
    return _settings_text(settings), group_settings_keyboard(settings)


async def _dj_list_view(
    services: ServiceContainer, group_tg_id: int
) -> tuple[str, InlineKeyboardMarkup]:
    """(text, keyboard) for the DJ management screen."""
    members = await services.permissions.list_members(group_tg_id)
    shown = list(members)[:MAX_DJ_BUTTONS]
    names: dict[int, str] = {}
    for member in shown:
        tg_id = int(getattr(member, "telegram_user_id", 0) or 0)
        if tg_id <= 0:
            continue
        try:
            user_row = await services.users.get(tg_id)
        except Exception:  # noqa: BLE001 — name lookup is cosmetic
            user_row = None
        name = None
        if user_row is not None:
            name = getattr(user_row, "username", None) or getattr(
                user_row, "first_name", None
            )
        if name:
            names[tg_id] = str(name)

    text = (
        "🎤 <b>GROUP DJs</b>\n\n"
        "Tap a member to grant or revoke DJ status (👑 = DJ)."
    )
    if not shown:
        text += "\n\nℹ️ No members synced yet — they appear after people use bot commands here."
    return text, dj_list_keyboard(shown, group_tg_id, names=names)


def _track_page_text(track: Any) -> str:
    """Track page body for the group search flow."""
    lines = ["🎵 <b>TRACK</b>", "", f"<b>{_title_of(track)}</b>"]
    artist = escape(_artist_of(track))
    if artist:
        lines.append(f"🎤 {artist}")
    duration = int(getattr(track, "duration_seconds", 0) or 0)
    if duration > 0:
        lines.append(f"⏱ {format_duration(duration)}")
    return "\n".join(lines)


# ----------------------------------------------------------------------
# /play — search and enqueue the top result
# ----------------------------------------------------------------------
@router.message(Command("play", "p"), GROUP_MESSAGE)
async def cmd_play(
    message: Message, command: CommandObject, services: ServiceContainer
) -> None:
    """Handle ``/play <query>`` — top search result into the group queue.

    ONE status message carries the whole request: it is posted before any
    provider call ("🔎 Searching…"), edited to "⬇️ Loading track…" once a
    match is found, and finally edited into the Now Playing control by the
    PlaybackController (or into the queue confirmation / the failure text).
    Production search+download spans up to ~30 s — the user sees progress at
    every step instead of dead air.
    """
    query = (command.args or "").strip()
    if not query:
        await _say(message, USAGE_PLAY)
        return
    try:
        ctx = await _prepare(message, services, need_admin=True)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "play", ctx.is_chat_admin
    ):
        await _say(message, PERMISSION_DENIED)
        return
    status = await _say(message, _searching_text(query))
    try:
        results = await services.music.search(query, limit=1)
    except BotError as exc:
        await _edit_or_say(message, status, exc.user_message)
        return
    if not results:
        await _edit_or_say(message, status, NOT_FOUND_TEXT)
        return
    track = results[0]
    await _edit_or_say(message, status, _loading_text(track))
    try:
        size, was_active = await _enqueue(
            services,
            message.chat.id,
            message.bot,
            track.id,
            ctx.user_tg_id,
            status_message=status,
        )
    except BotError as exc:
        await _edit_or_say(message, status, exc.user_message)
        return
    await _track_event(
        services,
        "group_play",
        user_tg_id=ctx.user_tg_id,
        group_tg_id=ctx.group_tg_id,
        track_id=int(track.id),
        payload={"query": query[:128], "queued": bool(was_active)},
    )
    if was_active:
        # Queued behind the current track — the status message becomes the
        # confirmation so the chat keeps exactly one message per request.
        await _edit_or_say(
            message,
            status,
            f"➕ Added to queue: {_title_of(track)} — #{size} in queue",
        )
    # else: playback started — the controller edited the status message into
    # the Now Playing control (edit_message passthrough), or into the error
    # text via _notify_error; replying here would only add noise.


# ----------------------------------------------------------------------
# /search — numbered results with trk:<id> buttons
# ----------------------------------------------------------------------
@router.message(Command("search"), GROUP_MESSAGE)
async def cmd_search(
    message: Message, command: CommandObject, services: ServiceContainer
) -> None:
    """Handle ``/search <query>`` — numbered inline results (group context).

    A single acknowledgement message is posted before the providers are
    queried and edited into the results (or the empty/error text) — the
    group chat never sees multi-second dead air, and never more than one
    message per search.
    """
    query = (command.args or "").strip()
    if not query:
        await _say(message, USAGE_SEARCH)
        return
    try:
        await _prepare(message, services)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    status = await _say(message, _searching_text(query))
    try:
        results = await services.music.search(query, limit=SEARCH_RESULTS_LIMIT)
    except BotError as exc:
        await _edit_or_say(message, status, exc.user_message)
        return
    if not results:
        try:
            no_results = await services.admin.appearance.message("error_no_results")
        except Exception:  # noqa: BLE001
            no_results = "🔎 No results found. Try a different query."
        await _edit_or_say(
            message, status, no_results or "🔎 No results found. Try a different query."
        )
        return
    text = (
        f"🔎 <b>Results</b> — {escape(truncate(query, 64))}\n\n"
        "Tap a track to see its options."
    )
    await _edit_or_say(
        message, status, text, group_search_results_keyboard(results)
    )


# ----------------------------------------------------------------------
# /new — browse fresh releases, tap to queue (radio-style seeding)
# ----------------------------------------------------------------------
@router.message(Command("new"), GROUP_MESSAGE)
async def cmd_new(message: Message, services: ServiceContainer) -> None:
    """Handle ``/new`` — one page of the freshest catalog tracks.

    Browsing is open to every member (the list itself is read-only);
    the one-tap queue buttons behind each row are permission-gated
    in :func:`cb_new_queue`.
    """
    try:
        await _prepare(message, services)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    text, markup = await _render_new_group(services, 1)
    await _say(message, text, markup)
    logger.info(
        "bot.group_new_releases",
        extra=log_extra(
            group_id=int(message.chat.id),
            user_id=int(getattr(message.from_user, "id", 0) or 0),
        ),
    )


# ----------------------------------------------------------------------
# /queue — current + upcoming tracks
# ----------------------------------------------------------------------
@router.message(Command("queue", "q"), GROUP_MESSAGE)
async def cmd_queue(message: Message, services: ServiceContainer) -> None:
    """Handle ``/queue`` — now playing plus the next queued tracks."""
    try:
        await _prepare(message, services)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    text, markup = await _queue_view(services, _owner(message.chat.id))
    await _say(message, text, markup)


# ----------------------------------------------------------------------
# /nowplaying — fresh control message
# ----------------------------------------------------------------------
@router.message(Command("nowplaying", "np"), GROUP_MESSAGE)
async def cmd_nowplaying(message: Message, services: ServiceContainer) -> None:
    """Handle ``/nowplaying`` — send a fresh Now Playing control message.

    The new message replaces the stored control message id so future edits by
    the PlaybackController (pause/skip/advance) land on it.
    """
    try:
        await _prepare(message, services)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    owner = _owner(message.chat.id)
    text, markup = await _np_view(services, owner)
    sent = await _say(message, text, markup)
    if sent is not None:
        try:
            await services.sessions.update(
                owner,
                now_playing_message_id=sent.message_id,
                control_chat_id=message.chat.id,
            )
        except Exception as exc:  # noqa: BLE001 — re-pointing is best effort
            logger.debug(
                "groups.np_repoint_failed",
                extra=log_extra(error=str(exc)[:160]),
            )


# ----------------------------------------------------------------------
# Transport commands
# ----------------------------------------------------------------------
@router.message(Command("skip", "next"), GROUP_MESSAGE)
async def cmd_skip(message: Message, services: ServiceContainer) -> None:
    """Handle ``/skip`` — advance to the next queued track."""
    try:
        ctx = await _prepare(message, services, need_admin=True)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "skip", ctx.is_chat_admin
    ):
        await _say(message, PERMISSION_DENIED)
        return
    try:
        await services.playback.next(
            _owner(message.chat.id),
            message.chat.id,
            message.bot,
            manual=True,
            skip=True,
        )
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    await _say(message, SKIPPED_TEXT)


@router.message(Command("pause"), GROUP_MESSAGE)
async def cmd_pause(message: Message, services: ServiceContainer) -> None:
    """Handle ``/pause`` — pause the voice-chat stream."""
    try:
        ctx = await _prepare(message, services, need_admin=True)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "pause", ctx.is_chat_admin
    ):
        await _say(message, PERMISSION_DENIED)
        return
    try:
        await services.playback.pause(_owner(message.chat.id), message.bot)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    await _say(message, PAUSED_TEXT)


@router.message(Command("resume"), GROUP_MESSAGE)
async def cmd_resume(message: Message, services: ServiceContainer) -> None:
    """Handle ``/resume`` — resume the paused stream."""
    try:
        ctx = await _prepare(message, services, need_admin=True)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "resume", ctx.is_chat_admin
    ):
        await _say(message, PERMISSION_DENIED)
        return
    try:
        await services.playback.resume(
            _owner(message.chat.id), message.chat.id, message.bot
        )
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    await _say(message, RESUMED_TEXT)


@router.message(Command("stop"), GROUP_MESSAGE)
async def cmd_stop(message: Message, services: ServiceContainer) -> None:
    """Handle ``/stop`` — stop playback and leave the voice chat."""
    try:
        ctx = await _prepare(message, services, need_admin=True)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "stop", ctx.is_chat_admin
    ):
        await _say(message, PERMISSION_DENIED)
        return
    try:
        await services.playback.stop(_owner(message.chat.id), message.bot)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    try:
        await services.voice.release(message.chat.id)
    except Exception as exc:  # noqa: BLE001 — already released by the controller
        logger.debug(
            "groups.voice_release_failed",
            extra=log_extra(error=str(exc)[:160]),
        )
    await _say(message, STOPPED_TEXT)


@router.message(Command("shuffle"), GROUP_MESSAGE)
async def cmd_shuffle(message: Message, services: ServiceContainer) -> None:
    """Handle ``/shuffle`` — reshuffle the upcoming queue."""
    try:
        await _prepare(message, services)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    try:
        await services.queue.shuffle(_owner(message.chat.id))
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    await _say(message, SHUFFLED_TEXT)


@router.message(Command("repeat"), GROUP_MESSAGE)
async def cmd_repeat(message: Message, services: ServiceContainer) -> None:
    """Handle ``/repeat`` — cycle off → all → one → off."""
    try:
        await _prepare(message, services)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    owner = _owner(message.chat.id)
    try:
        payload = await services.playback.now_playing(owner)
        current = str(payload.get("repeat_mode") or "off")
    except Exception:  # noqa: BLE001 — default to 'off' on lookup failure
        current = "off"
    if current not in _REPEAT_ORDER:
        current = "off"
    next_mode = _REPEAT_ORDER[(_REPEAT_ORDER.index(current) + 1) % len(_REPEAT_ORDER)]
    try:
        await services.playback.set_repeat(owner, next_mode)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    await _say(message, f"🔁 Repeat: {_REPEAT_LABELS[next_mode]}.")


@router.message(Command("volume"), GROUP_MESSAGE)
async def cmd_volume(
    message: Message, command: CommandObject, services: ServiceContainer
) -> None:
    """Handle ``/volume <0-200>`` — set the group session volume."""
    raw = (command.args or "").strip()
    try:
        volume = int(raw)
    except (TypeError, ValueError):
        volume = -1
    if not 0 <= volume <= 200:
        await _say(message, USAGE_VOLUME)
        return
    try:
        ctx = await _prepare(message, services, need_admin=True)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, VOLUME_ACTION, ctx.is_chat_admin
    ):
        await _say(message, PERMISSION_DENIED)
        return
    try:
        applied = await services.playback.set_volume(
            _owner(message.chat.id), volume
        )
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    await _say(message, f"🔊 Volume: {applied}%")


# ----------------------------------------------------------------------
# /settings and /help
# ----------------------------------------------------------------------
@router.message(Command("settings"), GROUP_MESSAGE)
async def cmd_settings(message: Message, services: ServiceContainer) -> None:
    """Handle ``/settings`` — group settings screen (mutations are admin-only)."""
    try:
        await _prepare(message, services)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    text, markup = await _settings_view(services, message.chat.id)
    await _say(message, text, markup)


@router.message(Command("help"), GROUP_MESSAGE)
async def cmd_help(message: Message, services: ServiceContainer) -> None:
    """Handle ``/help`` — concise group help."""
    try:
        await _prepare(message, services)
    except BotError as exc:
        await _say(message, exc.user_message)
        return
    await _say(message, await _help_text(services))


# ----------------------------------------------------------------------
# grp: callbacks — navigation
# ----------------------------------------------------------------------
@router.callback_query(F.data == "grp:home", GROUP_CALLBACK)
async def cb_home(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Group dashboard: Now Playing + controls, or the ready view."""
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback)
    text, markup = await _np_view(services, _owner(ctx.group_tg_id))
    await _edit(callback.message, text, markup)


@router.callback_query(F.data == "grp:np", GROUP_CALLBACK)
async def cb_np(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Edit the message to the Now Playing view."""
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback)
    text, markup = await _np_view(services, _owner(ctx.group_tg_id))
    await _edit(callback.message, text, markup)


@router.callback_query(F.data == "grp:queue", GROUP_CALLBACK)
async def cb_queue(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Edit the message to the group queue view."""
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback)
    text, markup = await _queue_view(services, _owner(ctx.group_tg_id))
    await _edit(callback.message, text, markup)


@router.callback_query(F.data == "grp:help", GROUP_CALLBACK)
async def cb_help(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Edit the message to the group help text."""
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback)
    await _edit(callback.message, await _help_text(services))


@router.callback_query(F.data == "grp:search", GROUP_CALLBACK)
async def cb_search(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Search hint — no FSM in groups, the /search command is the entry."""
    await safe_answer(callback)
    await _edit(callback.message, SEARCH_HINT_TEXT)


@router.callback_query(F.data == "grp:vc", GROUP_CALLBACK)
async def cb_vc(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Voice-chat hint — the bot never forces a join."""
    await safe_answer(callback, VOICE_HINT_TEXT)


# ----------------------------------------------------------------------
# grp:new / grp:new:<page> — fresh-releases browse (pagination)
# ----------------------------------------------------------------------
@router.callback_query(F.data == "grp:new", GROUP_CALLBACK)
async def cb_new_browse(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``grp:new`` — re-render the browse screen at page 1."""
    text, markup = await _render_new_group(services, 1)
    await safe_answer(callback)
    await _edit(callback.message, text, markup)


@router.callback_query(F.data.regexp(r"^grp:new:\d+$"), GROUP_CALLBACK)
async def cb_new_browse_page(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``grp:new:<page>`` — re-render the browse screen at page N (1-based)."""
    match = _NEW_PAGE_RE.match(str(callback.data or ""))
    page = int(match.group(1)) if match else 1
    text, markup = await _render_new_group(services, max(1, page))
    await safe_answer(callback)
    await _edit(callback.message, text, markup)


@router.callback_query(F.data.startswith("grp:newq:"), GROUP_CALLBACK)
async def cb_new_queue(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``grp:newq:<track_id>`` — one-tap enqueue from the /new browse.

    The permission check mirrors :func:`cb_track_queue` (``play`` action);
    the browse message is never re-rendered here so the list stays usable
    for rapid radio-style seeding of several tracks in a row.
    """
    raw = str(callback.data or "").rsplit(":", 1)[-1]
    if not raw.isdigit():
        await safe_answer(callback, "❌ Invalid track.")
        return
    track_id = int(raw)
    try:
        ctx = await _prepare_callback(callback, services, need_admin=True)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "play", ctx.is_chat_admin
    ):
        await safe_answer(callback, PERMISSION_DENIED, show_alert=True)
        return
    try:
        track = await services.music.get_track(track_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if track is None:
        await safe_answer(callback, NOT_FOUND_TEXT)
        return
    try:
        size, was_active = await _enqueue(
            services, ctx.group_tg_id, callback.bot, track_id, ctx.user_tg_id
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await _track_event(
        services,
        "group_play",
        user_tg_id=ctx.user_tg_id,
        group_tg_id=ctx.group_tg_id,
        track_id=track_id,
        payload={"source": "new_releases", "queued": bool(was_active)},
    )
    if was_active:
        await safe_answer(
            callback, f"➕ Added to queue (#{size})"
        )
    else:
        await safe_answer(callback, "🎵 Now playing")


@router.callback_query(F.data == "grp:settings", GROUP_CALLBACK)
async def cb_settings(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Edit the message to the group settings screen."""
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback)
    text, markup = await _settings_view(services, ctx.group_tg_id)
    await _edit(callback.message, text, markup)


# ----------------------------------------------------------------------
# grp: callbacks — transport (permission-checked)
# ----------------------------------------------------------------------
async def _transport_guard(
    callback: CallbackQuery,
    services: ServiceContainer,
    action: str,
) -> _GroupCtx | None:
    """Shared permission guard for transport callbacks.

    Answers the callback with the denial message and returns ``None`` when the
    pressing user may not perform *action*.
    """
    try:
        ctx = await _prepare_callback(callback, services, need_admin=True)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return None
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, action, ctx.is_chat_admin
    ):
        await safe_answer(callback, PERMISSION_DENIED, show_alert=True)
        return None
    return ctx


@router.callback_query(F.data == "grp:skip", GROUP_CALLBACK)
async def cb_skip(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Skip button — mirrors /skip, then refreshes the message."""
    ctx = await _transport_guard(callback, services, "skip")
    if ctx is None:
        return
    owner = _owner(ctx.group_tg_id)
    try:
        await services.playback.next(
            owner, ctx.group_tg_id, callback.bot, manual=True, skip=True
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, SKIPPED_TEXT)
    text, markup = await _np_view(services, owner)
    await _edit(callback.message, text, markup)


@router.callback_query(F.data == "grp:pause", GROUP_CALLBACK)
async def cb_pause(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Pause button — mirrors /pause, then refreshes the message."""
    ctx = await _transport_guard(callback, services, "pause")
    if ctx is None:
        return
    owner = _owner(ctx.group_tg_id)
    try:
        await services.playback.pause(owner, callback.bot)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, PAUSED_TEXT)
    text, markup = await _np_view(services, owner)
    await _edit(callback.message, text, markup)


@router.callback_query(F.data == "grp:resume", GROUP_CALLBACK)
async def cb_resume(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Resume button — mirrors /resume, then refreshes the message."""
    ctx = await _transport_guard(callback, services, "resume")
    if ctx is None:
        return
    owner = _owner(ctx.group_tg_id)
    try:
        await services.playback.resume(owner, ctx.group_tg_id, callback.bot)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, RESUMED_TEXT)
    text, markup = await _np_view(services, owner)
    await _edit(callback.message, text, markup)


@router.callback_query(F.data == "grp:stop", GROUP_CALLBACK)
async def cb_stop(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Stop button — mirrors /stop (also releases the voice lease)."""
    ctx = await _transport_guard(callback, services, "stop")
    if ctx is None:
        return
    owner = _owner(ctx.group_tg_id)
    try:
        await services.playback.stop(owner, callback.bot)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    try:
        await services.voice.release(ctx.group_tg_id)
    except Exception as exc:  # noqa: BLE001 — controller already released it
        logger.debug(
            "groups.voice_release_failed",
            extra=log_extra(error=str(exc)[:160]),
        )
    await safe_answer(callback, STOPPED_TEXT)
    text, markup = await _np_view(services, owner)  # idle → ready view
    await _edit(callback.message, text, markup)


@router.callback_query(F.data == "grp:shuf", GROUP_CALLBACK)
async def cb_shuf(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Shuffle button — reshuffles and refreshes the queue view."""
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    owner = _owner(ctx.group_tg_id)
    try:
        await services.queue.shuffle(owner)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, SHUFFLED_TEXT)
    text, markup = await _queue_view(services, owner)
    await _edit(callback.message, text, markup)


#: Repeat-mode cycle order for the group repeat button (mirrors np:rep).
_GROUP_REPEAT_CYCLE = {"off": "all", "all": "one", "one": "off"}


@router.callback_query(F.data == "grp:rep", GROUP_CALLBACK)
async def cb_rep(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Repeat button — cycles off → all → one, then refreshes the view.

    Uses the generic "play" permission (a playback-mode toggle, same as
    the transport controls). The button label always shows the mode a
    press will move TO (stateful toggle pattern).
    """
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "play", ctx.is_chat_admin
    ):
        await safe_answer(callback, PERMISSION_DENIED)
        return
    owner = _owner(ctx.group_tg_id)
    session = await services.sessions.get(owner)
    mode = _GROUP_REPEAT_CYCLE.get(session.repeat_mode or "off", "all")
    try:
        await services.playback.set_repeat(owner, mode)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, f"🔁 Repeat: {repeat_label(mode)}")
    text, markup = await _np_view(services, owner)
    await _edit(callback.message, text, markup)


#: Volume step applied per ``grp:vol:dn`` / ``grp:vol:up`` press.
VOLUME_STEP = 25


@router.callback_query(F.data == "grp:auto", GROUP_CALLBACK)
async def cb_autoplay(callback: CallbackQuery, services: ServiceContainer) -> None:
    """🤖 Autoplay ON/OFF button — toggles the group's autoplay setting.

    Toggles the REAL per-group setting the playback controller consults on
    track end (the persisted ``PlaybackSession.autoplay``), then syncs the
    group-settings row (``Group.autoplay_enabled``) so the admin settings
    screen shows the same truth.  Permission model matches the other
    playback-mode toggles (Shuffle / Repeat): the generic "play" action.

    The toggle always reads the ACTUAL session state (never the button
    label), so stale keyboards — an old message still saying "ON" after
    another admin changed it — can never desynchronize the setting.  The
    player message is re-rendered immediately with the new label.
    """
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "play", ctx.is_chat_admin
    ):
        await safe_answer(callback, PERMISSION_DENIED)
        return
    owner = _owner(ctx.group_tg_id)
    session = await services.sessions.get(owner)
    target = not bool(getattr(session, "autoplay", False))
    try:
        await services.playback.set_autoplay(owner, target)
        # Keep the admin settings screen in agreement with the player
        # button (same underlying truth, two surfaces).
        try:
            await services.group_settings.update(
                ctx.group_tg_id, autoplay_enabled=target
            )
        except Exception as exc:  # noqa: BLE001 — cosmetic sync, best effort
            logger.debug(
                "groups.autoplay_settings_sync_failed",
                extra=log_extra(group_id=ctx.group_tg_id, error=str(exc)[:160]),
            )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, f"🤖 Autoplay: {'ON' if target else 'OFF'}")
    text, markup = await _np_view(services, owner)
    await _edit(callback.message, text, markup)


@router.callback_query(F.data.regexp(r"^grp:vol:(dn|up)$"), GROUP_CALLBACK)
async def cb_volume_step(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Volume step buttons — ±25 (clamped 0-200), mirrors ``/volume``.

    Permission model identical to the ``/volume`` command (the generic
    transport-control action). The refresh keeps the message the player
    panel (or queue view) it was pressed from.
    """
    direction = str(callback.data or "").rsplit(":", 1)[-1]
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, VOLUME_ACTION, ctx.is_chat_admin
    ):
        await safe_answer(callback, PERMISSION_DENIED)
        return
    owner = _owner(ctx.group_tg_id)
    session = await services.sessions.get(owner)
    current = int(getattr(session, "volume", 100) or 100)
    target = current - VOLUME_STEP if direction == "dn" else current + VOLUME_STEP
    target = max(0, min(200, target))
    if target == current:
        await safe_answer(callback, f"🔊 Volume: {current}% (limit)")
        return
    try:
        applied = await services.playback.set_volume(owner, target)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, f"🔊 Volume: {applied}%")
    text, markup = await _np_view(services, owner)
    await _edit(callback.message, text, markup)


# ----------------------------------------------------------------------
# grp: callbacks — settings mutations (chat admins only)
# ----------------------------------------------------------------------
@router.callback_query(F.data.startswith("grp:set:"), GROUP_CALLBACK)
async def cb_set_value(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``grp:set:silent:<0|1>`` / ``grp:set:auto:<0|1>`` toggles."""
    parts = (callback.data or "").split(":")
    if (
        len(parts) != 4
        or parts[2] not in {"silent", "auto"}
        or parts[3] not in {"0", "1"}
    ):
        await safe_answer(callback, "❌ Invalid setting.")
        return
    key, value = parts[2], parts[3] == "1"
    field = "silent_mode" if key == "silent" else "autoplay_enabled"
    label = "Silent Mode" if key == "silent" else "Autoplay"

    try:
        ctx = await _prepare_callback(callback, services, need_admin=True)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "settings", ctx.is_chat_admin
    ):
        await safe_answer(callback, SETTINGS_ADMIN_ONLY, show_alert=True)
        return
    try:
        await services.group_settings.update(ctx.group_tg_id, **{field: value})
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    # The autoplay toggle must gate ACTUAL playback (the controller reads
    # the session's autoplay flag on track end) — sync the session so the
    # settings screen and the player button always agree.  Best effort:
    # the settings row stays authoritative even when the session lookup
    # fails (e.g. right after a restart, before any playback).
    if key == "auto":
        try:
            await services.playback.set_autoplay(
                _owner(ctx.group_tg_id), value
            )
        except Exception as exc:  # noqa: BLE001 — cosmetic sync, best effort
            logger.debug(
                "groups.autoplay_session_sync_failed",
                extra=log_extra(group_id=ctx.group_tg_id, error=str(exc)[:160]),
            )
    await safe_answer(callback, f"✅ {label}: {'On' if value else 'Off'}")
    text, markup = await _settings_view(services, ctx.group_tg_id)
    await _edit(callback.message, text, markup)


def _is_picker_screen(message: Any) -> bool:
    """Whether the callback's message currently shows the mode picker."""
    text = getattr(message, "text", None) or ""
    return text.startswith("🎛️ <b>PERMISSIONS</b>")


@router.callback_query(F.data.startswith("grp:pmode:"), GROUP_CALLBACK)
async def cb_perm_mode(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``grp:pmode:<mode>`` — set the permission mode (chat admins only).

    The settings screen's "Permissions" button carries the currently active
    mode; pressing it opens the mode picker. Pressing a *different* mode (from
    the picker) applies it immediately and returns to the settings screen.
    Pressing the already-active mode inside the picker is a no-op refresh.
    """
    mode = (callback.data or "").split(":", 2)[-1]
    if mode not in {"everyone", "admins", "dj"}:
        await safe_answer(callback, "❌ Invalid permission mode.")
        return
    try:
        ctx = await _prepare_callback(callback, services, need_admin=True)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "settings", ctx.is_chat_admin
    ):
        await safe_answer(callback, SETTINGS_ADMIN_ONLY, show_alert=True)
        return

    try:
        settings = await services.group_settings.get(ctx.group_tg_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    current = str(getattr(settings, "permission_mode", "everyone") or "everyone")

    if mode == current and not _is_picker_screen(callback.message):
        # Settings-screen button → open the mode picker.
        await safe_answer(callback)
        await _edit(callback.message, PERMISSIONS_PICKER_TEXT, permission_mode_keyboard())
        return

    if mode == current:
        # Picker press of the already-active mode — refresh the settings view.
        await safe_answer(callback, f"ℹ️ Already active: {mode}.")
    else:
        try:
            await services.group_settings.update(
                ctx.group_tg_id, permission_mode=mode
            )
        except BotError as exc:
            await safe_answer(callback, exc.user_message)
            return
        await safe_answer(callback, f"✅ Permissions: {mode}.")
    text, markup = await _settings_view(services, ctx.group_tg_id)
    await _edit(callback.message, text, markup)


@router.callback_query(F.data == "grp:djs", GROUP_CALLBACK)
async def cb_djs(callback: CallbackQuery, services: ServiceContainer) -> None:
    """DJ management list (chat admins only)."""
    try:
        ctx = await _prepare_callback(callback, services, need_admin=True)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "dj_manage", ctx.is_chat_admin
    ):
        await safe_answer(callback, DJS_ADMIN_ONLY, show_alert=True)
        return
    await safe_answer(callback)
    text, markup = await _dj_list_view(services, ctx.group_tg_id)
    await _edit(callback.message, text, markup)


@router.callback_query(F.data.startswith("grp:dj:"), GROUP_CALLBACK)
async def cb_dj_toggle(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``grp:dj:<user_id>:<0|1>`` — grant or revoke DJ status (admins only)."""
    match = _DJ_TOGGLE_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback, "❌ Invalid action.")
        return
    target_id, value = int(match.group(1)), match.group(2) == "1"
    try:
        ctx = await _prepare_callback(callback, services, need_admin=True)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "dj_manage", ctx.is_chat_admin
    ):
        await safe_answer(callback, DJS_ADMIN_ONLY, show_alert=True)
        return
    try:
        await services.permissions.set_dj(ctx.group_tg_id, target_id, value)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(
        callback, "✅ Promoted to DJ" if value else "✅ Removed DJ status"
    )
    text, markup = await _dj_list_view(services, ctx.group_tg_id)
    await _edit(callback.message, text, markup)


# ----------------------------------------------------------------------
# trk: callbacks (group context only — 3-a owns the private variants)
# ----------------------------------------------------------------------
@router.callback_query(F.data.startswith("trk:play:"), GROUP_CALLBACK)
async def cb_track_play(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``trk:play:<id>`` — enqueue the track, then edit the message."""
    raw = (callback.data or "").split(":")[-1]
    if not raw.isdigit():
        await safe_answer(callback, "❌ Invalid track.")
        return
    track_id = int(raw)
    try:
        ctx = await _prepare_callback(callback, services, need_admin=True)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "play", ctx.is_chat_admin
    ):
        await safe_answer(callback, PERMISSION_DENIED, show_alert=True)
        return
    try:
        track = await services.music.get_track(track_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if track is None:
        await safe_answer(callback, NOT_FOUND_TEXT)
        return
    try:
        size, was_active = await _enqueue(
            services, ctx.group_tg_id, callback.bot, track_id, ctx.user_tg_id
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await _track_event(
        services,
        "group_play",
        user_tg_id=ctx.user_tg_id,
        group_tg_id=ctx.group_tg_id,
        track_id=track_id,
        payload={"source": "track_page", "queued": bool(was_active)},
    )
    if was_active:
        text = f"➕ Added to queue: {_title_of(track)} (#{size})"
        await safe_answer(callback, f"➕ Added to queue (#{size})")
    else:
        text = f"🎵 <b>Playing:</b> {_title_of(track)}"
        await safe_answer(callback, "🎵 Playing")
    # Buttons removed — re-pressing "Play" would duplicate the enqueue.
    await _edit(callback.message, text)


@router.callback_query(F.data.startswith("trk:queue:"), GROUP_CALLBACK)
async def cb_track_queue(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``trk:queue:<id>`` — enqueue the track without leaving the page."""
    raw = (callback.data or "").split(":")[-1]
    if not raw.isdigit():
        await safe_answer(callback, "❌ Invalid track.")
        return
    track_id = int(raw)
    try:
        ctx = await _prepare_callback(callback, services, need_admin=True)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if not await _allowed(
        services, ctx.group_tg_id, ctx.user_tg_id, "play", ctx.is_chat_admin
    ):
        await safe_answer(callback, PERMISSION_DENIED, show_alert=True)
        return
    try:
        track = await services.music.get_track(track_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if track is None:
        await safe_answer(callback, NOT_FOUND_TEXT)
        return
    try:
        size, was_active = await _enqueue(
            services, ctx.group_tg_id, callback.bot, track_id, ctx.user_tg_id
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if was_active:
        await safe_answer(
            callback, f"➕ Added to queue: {truncate(str(getattr(track, 'title', '')), 48)} (#{size})"
        )
    else:
        await safe_answer(callback, "🎵 Now playing")


@router.callback_query(F.data.startswith("trk:like:"), GROUP_CALLBACK)
async def cb_track_like(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``trk:like:<id>`` — toggle the like for the pressing user."""
    raw = (callback.data or "").split(":")[-1]
    if not raw.isdigit():
        await safe_answer(callback, "❌ Invalid track.")
        return
    track_id = int(raw)
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    try:
        liked = await services.library.toggle_like(ctx.user_tg_id, track_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, "❤️ Liked" if liked else "💔 Unliked")


@router.callback_query(F.data.startswith("trk:"), GROUP_CALLBACK)
async def cb_track_page(callback: CallbackQuery, services: ServiceContainer) -> None:
    """``trk:<id>`` — group track page (registered after the trk: actions)."""
    raw = (callback.data or "")[len("trk:"):]
    if not raw.isdigit():
        await safe_answer(callback, "❌ Invalid track.")
        return
    track_id = int(raw)
    try:
        ctx = await _prepare_callback(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    try:
        track = await services.music.get_track(track_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if track is None:
        await safe_answer(callback, NOT_FOUND_TEXT)
        return
    await safe_answer(callback)
    await _edit(
        callback.message, _track_page_text(track), group_track_keyboard(track_id)
    )


# ----------------------------------------------------------------------
# Silent lifecycle sync — NEVER sends messages
# ----------------------------------------------------------------------
@router.my_chat_member()
async def on_bot_membership(
    event: ChatMemberUpdated, services: ServiceContainer
) -> None:
    """Silently sync the DB when the bot is added to / removed from a group.

    Added/promoted → register the group (presence flags refreshed);
    left/kicked → deactivate it. Absolutely no message is ever sent.
    """
    chat = event.chat
    chat_type = getattr(chat, "type", None)
    if chat is None or chat_type not in GROUP_CHAT_TYPES:
        return
    status = getattr(getattr(event, "new_chat_member", None), "status", None)
    try:
        if status in {"left", "kicked"}:
            await services.groups.groups.deactivate(chat.id)
            logger.info(
                "groups.bot_removed",
                extra=log_extra(group_id=chat.id, status=status),
            )
        else:
            # get_or_create refreshes bot_in_chat=True / is_active=True.
            await services.groups.get_or_create(chat)
            logger.info(
                "groups.bot_added",
                extra=log_extra(group_id=chat.id, status=status),
            )
    except Exception as exc:  # noqa: BLE001 — silent sync must never crash
        logger.warning(
            "groups.membership_sync_failed",
            extra=log_extra(group_id=getattr(chat, "id", None), error=str(exc)[:160]),
        )


@router.message(F.new_chat_members)
async def on_new_chat_members(message: Message, services: ServiceContainer) -> None:
    """Silently register the group when the bot itself is added by a member.

    Service message — the silent-group middleware normally drops it; this
    handler exists as a defensive second path and NEVER greets anyone.
    """
    if not is_group(getattr(message.chat, "type", None)):
        return
    bot_id = getattr(message.bot, "id", None)
    added = message.new_chat_members or ()
    if bot_id is None or not any(
        getattr(user, "id", None) == bot_id for user in added
    ):
        return
    try:
        await services.groups.get_or_create(message.chat)
        logger.info(
            "groups.bot_added_via_service_message",
            extra=log_extra(group_id=message.chat.id),
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "groups.membership_sync_failed",
            extra=log_extra(group_id=message.chat.id, error=str(exc)[:160]),
        )


# ----------------------------------------------------------------------
# Registration
# ----------------------------------------------------------------------
def register(parent: Router) -> None:
    """Include this module's router exactly once (idempotent).

    ``app.bot.callbacks.group`` re-exports this very router, so double
    registration through both import paths would duplicate every handler.
    """
    if router not in parent.sub_routers:
        parent.include_router(router)


__all__ = ["register", "router"]

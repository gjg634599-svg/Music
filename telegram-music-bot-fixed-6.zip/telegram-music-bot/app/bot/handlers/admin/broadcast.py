"""Admin broadcast screens: composer flow, control, history and progress.

The composer keeps an in-progress draft dict inside FSM storage::

    {"content_type": str|None, "text": str|None, "caption": str|None,
     "media": [ {"type": ..., "file_id": ...} ], "copy_source": dict|None,
     "buttons": [ {"label": ..., "url": ...} ],
     "target_type": str|None, "target_filter": {}}

Sending creates the campaign through ``services.broadcast.create_draft`` and
immediately starts it (``services.broadcast.start``); the worker delivers.
Every mutation is audited.
"""

from __future__ import annotations

import math
import re
from datetime import datetime
from typing import Any

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message

from app.bot.handlers.admin.states import AdminFSM
from app.bot.keyboards.admin import (
    ALBUM_MAX_ITEMS,
    PAGE_SIZE,
    admin_broadcast_active_keyboard,
    admin_broadcast_album_keyboard,
    admin_broadcast_composer_keyboard,
    admin_broadcast_composer_screen_keyboard,
    admin_broadcast_confirm_keyboard,
    admin_broadcast_history_keyboard,
    admin_broadcast_keyboard,
    admin_broadcast_language_keyboard,
    admin_broadcast_progress_keyboard,
    admin_broadcast_result_keyboard,
    admin_broadcast_targets_keyboard,
)
from app.bot.services import ServiceContainer
from app.broadcast.composer import (
    MAX_BUTTON_LABEL,
    MAX_BUTTONS,
    SINGLE_MEDIA_TYPES,
    BroadcastDraft,
    buttons_to_keyboard,
    from_copy_message,
    from_media_message,
    from_text,
    validate_buttons,
)
from app.broadcast.targets import TARGET_TYPES
from app.errors import BotError, ValidationError
from app.utils.formatting import TELEGRAM_MESSAGE_LIMIT, escape, progress_bar, truncate
from app.utils.telegram import safe_answer, safe_edit
from app.utils.time import utcnow

router = Router(name="admin_broadcast")

_TYPE_RE = re.compile(r"^adm:bc:type:(text|photo|video|audio|document|animation|voice|album|copy)$")
_TARGET_RE = re.compile(r"^adm:bc:target:([a-z_]+)$")
_LANG_RE = re.compile(r"^adm:bc:lang:([a-z]{2,8})$")
_HIST_PAGE_RE = re.compile(r"^adm:bc:hist:(\d+)$")
_CONTROL_RE = re.compile(r"^adm:bc:(\d+):(pause|stop|refresh|retry)$")

#: Telegram caption limit.
_CAPTION_LIMIT = 1024

_CONTENT_LABELS: dict[str, str] = {
    "text": "📝 Text",
    "photo": "🖼️ Photo",
    "video": "🎬 Video",
    "audio": "🎵 Audio",
    "document": "📄 Document",
    "animation": "🎞️ Animation",
    "voice": "🎙️ Voice",
    "album": "🖼️ Album",
    "copy": "📦 Copy Message",
}

_TARGET_LABELS: dict[str, str] = {
    "all_users": "👥 All Users",
    "active_users": "🟢 Active Users",
    "inactive_users": "⚪ Inactive Users",
    "users_by_language": "🌐 Users by Language",
    "users_with_groups": "👥 Users With Groups",
    "specific_users": "🎯 Specific Users",
    "all_groups": "👥 All Groups",
    "active_groups": "🟢 Active Groups",
    "groups_with_vc": "🎙️ Groups With VC",
    "specific_groups": "🎯 Specific Groups",
}

_STATUS_ICONS: dict[str, str] = {"completed": "✅", "cancelled": "⛔", "failed": "❌",
                                 "sending": "📤", "pending": "⏳", "paused": "⏸️", "draft": "📝"}


# ----------------------------------------------------------------------
# Draft helpers
# ----------------------------------------------------------------------
def _fresh_draft() -> dict[str, Any]:
    """A blank composer draft (kept in FSM data)."""
    return {
        "content_type": None,
        "text": None,
        "caption": None,
        "media": [],
        "copy_source": None,
        "buttons": [],
        "target_type": None,
        "target_filter": {},
    }


async def _get_draft(state: FSMContext) -> dict[str, Any]:
    """Load (or create) the composer draft from FSM data."""
    data = await state.get_data()
    draft = data.get("draft")
    if not isinstance(draft, dict):
        draft = _fresh_draft()
    return draft


async def _save_draft(state: FSMContext, draft: dict[str, Any]) -> None:
    """Persist the composer draft into FSM data."""
    await state.update_data(draft=draft)


def _composer_text(draft: dict[str, Any], *, note: str = "") -> str:
    """Render the composer screen text for the current draft."""
    content_type = draft.get("content_type")
    lines = [f"{note}📢 <b>NEW BROADCAST</b>\n"]
    if content_type is None:
        lines.append("Content: — (choose a type)")
    else:
        lines.append(f"Content: {_CONTENT_LABELS.get(content_type, escape(content_type))}")
    text = draft.get("text")
    if text:
        lines.append(f"Text: {escape(truncate(text, 120))}")
    caption = draft.get("caption")
    if caption:
        lines.append(f"Caption: {escape(truncate(caption, 120))}")
    media = draft.get("media") or []
    if content_type == "album":
        lines.append(f"Items: {len(media)}")
    copy_source = draft.get("copy_source")
    if copy_source:
        lines.append(f"Source: chat <code>{copy_source.get('chat_id')}</code>, "
                     f"message(s) {len(copy_source.get('message_ids') or [])}")
    buttons = draft.get("buttons") or []
    lines.append(f"Buttons: {len(buttons)}")
    for button in buttons[:8]:
        lines.append(f"  • {escape(button.get('label', ''))} → {escape(button.get('url', ''))}")
    target = draft.get("target_type")
    lines.append(f"Target: {_TARGET_LABELS.get(target, escape(target or '—'))}")
    return "\n".join(lines)


async def _render_composer(
    callback: CallbackQuery, state: FSMContext, *, note: str = ""
) -> None:
    """Edit the current message into the composer screen."""
    draft = await _get_draft(state)
    await safe_edit(
        callback.message,
        _composer_text(draft, note=note),
        admin_broadcast_composer_screen_keyboard(),
    )


async def _composer_from_message(message: Message, state: FSMContext, *, note: str = "") -> None:
    """Send the composer screen as a new message (FSM completion path)."""
    draft = await _get_draft(state)
    await message.answer(
        _composer_text(draft, note=note),
        reply_markup=admin_broadcast_composer_screen_keyboard(),
        parse_mode="HTML",
    )


async def _render_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    """Edit into the final confirmation screen."""
    draft = await _get_draft(state)
    target = draft.get("target_type") or ""
    note = "The audience is computed on send."
    if target == "groups_with_vc":
        note = (
            "Groups are checked live for an active voice chat at send "
            "time (needs a healthy voice account; without one this "
            "audience falls back to active groups)."
        )
    text = (
        "📢 <b>BROADCAST PREVIEW</b>\n\n"
        f"Target: {_TARGET_LABELS.get(target, escape(target or '—'))}\n"
        f"Content: {_CONTENT_LABELS.get(draft.get('content_type') or '', '—')}\n"
        f"Buttons: {len(draft.get('buttons') or [])}\n\n"
        f"{note}\n\n"
        "<b>Ready to send?</b>"
    )
    await safe_edit(callback.message, text, admin_broadcast_confirm_keyboard())


async def _cancel_from_message(message: Message, state: FSMContext) -> None:
    """Cancel the composer from a text input (clears the FSM draft)."""
    await state.clear()
    await message.answer("ℹ️ Broadcast cancelled.")


def _is_cancel(text: str | None) -> bool:
    """True when the admin typed /cancel."""
    return bool(text) and text.strip().startswith("/cancel")


# ----------------------------------------------------------------------
# Home / list screens
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:bc")
async def broadcast_home(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Broadcast home: campaign counts + active list."""
    counts = await services.broadcast.count_by_status()
    total = sum(value for value in counts.values() if isinstance(value, int))
    active = await services.broadcast.active()
    lines = [f"📢 <b>BROADCAST</b>\n", f"Campaigns: {total}", f"Active: {len(active)}"]
    for broadcast in active:
        icon = _STATUS_ICONS.get(broadcast.status, "•")
        lines.append(f"  #{broadcast.id} — {icon} {broadcast.status} — "
                     f"{broadcast.sent_count}/{broadcast.target_count}")
    await safe_edit(callback.message, "\n".join(lines), admin_broadcast_keyboard())
    await safe_answer(callback)


@router.callback_query(F.data == "adm:bc:act")
async def broadcast_active(callback: CallbackQuery, services: ServiceContainer) -> None:
    """List currently active broadcasts."""
    active = await services.broadcast.active()
    lines = ["⏸️ <b>ACTIVE BROADCASTS</b>\n"]
    if not active:
        lines.append("No active broadcasts.")
    for broadcast in active:
        icon = _STATUS_ICONS.get(broadcast.status, "•")
        lines.append(f"#{broadcast.id} — {icon} {escape(broadcast.status)} — "
                     f"{broadcast.sent_count}/{broadcast.target_count}")
    keyboard = admin_broadcast_active_keyboard([item.id for item in active])
    await safe_edit(callback.message, "\n".join(lines), keyboard)
    await safe_answer(callback)


@router.callback_query(F.data == "adm:bc:hist")
async def broadcast_history(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Broadcast history (first page)."""
    await _render_history(callback, services, 0)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_HIST_PAGE_RE.pattern))
async def broadcast_history_page(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Broadcast history (paginated)."""
    match = _HIST_PAGE_RE.match(callback.data or "")
    page = int(match.group(1)) if match else 0
    await _render_history(callback, services, page)
    await safe_answer(callback)


async def _render_history(
    callback: CallbackQuery, services: ServiceContainer, page: int
) -> None:
    """Render one page of the broadcast history (10 per page)."""
    items = await services.broadcast.history(limit=50)
    total_pages = max(1, math.ceil(len(items) / PAGE_SIZE))
    page = max(0, min(page, total_pages - 1))
    chunk = items[page * PAGE_SIZE : (page + 1) * PAGE_SIZE]
    lines = ["📜 <b>BROADCAST HISTORY</b>\n"]
    if not chunk:
        lines.append("No broadcasts yet.")
    for broadcast in chunk:
        icon = _STATUS_ICONS.get(broadcast.status, "•")
        lines.append(
            f"#{broadcast.id} — {escape(broadcast.target_type)} — {icon} "
            f"{escape(broadcast.status)} — {broadcast.sent_count}/{broadcast.target_count}"
        )
    keyboard = admin_broadcast_history_keyboard(page, total_pages)
    await safe_edit(callback.message, "\n".join(lines), keyboard)


# ----------------------------------------------------------------------
# Composer: content type
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:bc:new")
async def composer_start(callback: CallbackQuery, state: FSMContext) -> None:
    """Start a fresh broadcast draft and show the content-type picker."""
    await state.clear()
    await state.update_data(draft=_fresh_draft())
    text = "📢 <b>NEW BROADCAST</b>\n\nChoose the content type."
    await safe_edit(callback.message, text, admin_broadcast_composer_keyboard())
    await safe_answer(callback)


@router.callback_query(F.data == "adm:bc:new-restore")
async def composer_restore(callback: CallbackQuery, state: FSMContext) -> None:
    """Return to the composer screen without resetting the draft."""
    draft = await _get_draft(state)
    if draft.get("content_type") is None:
        await composer_start(callback, state)
        return
    await _render_composer(callback, state)
    await safe_answer(callback)


@router.callback_query(F.data == "adm:bc:edit")
async def composer_edit(callback: CallbackQuery, state: FSMContext) -> None:
    """Back from the confirm screen to the composer (draft intact)."""
    await _render_composer(callback, state)
    await safe_answer(callback)


@router.callback_query(F.data == "adm:bc:cancel")
async def composer_cancel(
    callback: CallbackQuery, state: FSMContext, services: ServiceContainer
) -> None:
    """Cancel the composer: clear the FSM draft, back to broadcast home."""
    await state.clear()
    await broadcast_home(callback, services)
    await safe_answer(callback, "ℹ️ Broadcast cancelled.")


@router.callback_query(F.data.regexp(_TYPE_RE.pattern))
async def composer_pick_type(
    callback: CallbackQuery, state: FSMContext, services: ServiceContainer
) -> None:
    """Ask for the content of the chosen type (FSM input)."""
    match = _TYPE_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    content_type = match.group(1)
    if content_type == "text":
        await state.set_state(AdminFSM.bc_text)
        prompt = "📝 Send the broadcast text.\n\n/cancel — abort"
    elif content_type == "album":
        await state.set_state(AdminFSM.album_collect)
        prompt = (
            "🎞️ Send the album now — I'll collect up to "
            f"{ALBUM_MAX_ITEMS} items as they arrive, then tap ✅ Done.\n\n/cancel — abort"
        )
    elif content_type == "copy":
        await state.set_state(AdminFSM.bc_copy)
        prompt = "📦 Forward or send the message to copy.\n\n/cancel — abort"
    else:
        await state.update_data(bc_media_type=content_type)
        await state.set_state(AdminFSM.bc_media)
        prompt = f"Send the {content_type} now.\n\n/cancel — abort"
    if callback.message is not None:
        await callback.message.answer(prompt)
    await safe_answer(callback)


# ----------------------------------------------------------------------
# Composer: text input handlers
# ----------------------------------------------------------------------
@router.message(AdminFSM.bc_text, F.text)
async def bc_text_input(message: Message, state: FSMContext) -> None:
    """Capture the broadcast text (HTML preserved)."""
    if _is_cancel(message.text):
        await _cancel_from_message(message, state)
        return
    text = (message.html_text or "").strip()
    if not text:
        await message.answer("❌ Text cannot be empty. Try again or /cancel.")
        return
    if len(text) > TELEGRAM_MESSAGE_LIMIT:
        await message.answer(
            f"❌ Too long ({len(text)} > {TELEGRAM_MESSAGE_LIMIT}). Try again or /cancel."
        )
        return
    draft = await _get_draft(state)
    draft.update({"content_type": "text", "text": text})
    await _save_draft(state, draft)
    await state.set_state(None)
    await _composer_from_message(message, state, note="✅ Text captured.\n\n")


@router.message(AdminFSM.bc_media, F.photo | F.video | F.audio | F.document | F.animation | F.voice)
async def bc_media_input(message: Message, state: FSMContext) -> None:
    """Capture a single media item (+ optional caption) for the broadcast."""
    if _is_cancel(message.caption or message.text):
        await _cancel_from_message(message, state)
        return
    data = await state.get_data()
    requested = str(data.get("bc_media_type") or "")
    detected = from_media_message(message)
    if requested and detected.content_type != requested:
        await message.answer(
            f"❌ That's a {detected.content_type}, but this broadcast needs a {requested}. "
            "Send the right type or /cancel."
        )
        return
    caption = message.html_text if message.caption else None
    if caption and len(caption) > _CAPTION_LIMIT:
        await message.answer(
            "❌ Caption too long (max 1024). Send the media again with a "
            "shorter caption, or /cancel."
        )
        return
    draft = await _get_draft(state)
    draft["content_type"] = detected.content_type
    draft["media"] = detected.media or []
    if caption:
        draft["caption"] = caption
        await _save_draft(state, draft)
        await state.set_state(None)
        await _composer_from_message(message, state, note="✅ Media captured.\n\n")
        return
    await _save_draft(state, draft)
    await state.set_state(AdminFSM.bc_caption)
    await message.answer("Send a caption or /skip.\n\n/cancel — abort")


@router.message(AdminFSM.bc_caption, F.text)
async def bc_caption_input(message: Message, state: FSMContext) -> None:
    """Capture an optional caption (or /skip)."""
    if _is_cancel(message.text):
        await _cancel_from_message(message, state)
        return
    draft = await _get_draft(state)
    if (message.text or "").strip().startswith("/skip"):
        draft["caption"] = None
    else:
        caption = (message.html_text or "").strip()
        if len(caption) > _CAPTION_LIMIT:
            await message.answer("❌ Caption too long (max 1024). Try again, /skip or /cancel.")
            return
        draft["caption"] = caption
    await _save_draft(state, draft)
    await state.set_state(None)
    await _composer_from_message(message, state, note="✅ Content captured.\n\n")


@router.message(AdminFSM.bc_copy)
async def bc_copy_input(message: Message, state: FSMContext) -> None:
    """Capture the message to copy (any content type)."""
    if _is_cancel(message.text):
        await _cancel_from_message(message, state)
        return
    source = from_copy_message(message)
    draft = await _get_draft(state)
    draft["content_type"] = "copy"
    draft["copy_source"] = source.copy_source
    draft["caption"] = source.caption
    await _save_draft(state, draft)
    await state.set_state(None)
    await _composer_from_message(message, state, note="✅ Message captured.\n\n")


@router.message(AdminFSM.album_collect, F.photo | F.video | F.document)
async def album_input(message: Message, state: FSMContext) -> None:
    """Collect album items while a matching media group streams in."""
    if message.animation is not None:
        await message.answer("❌ Albums can't include animations. Send photos/videos/documents.")
        return
    data = await state.get_data()
    draft = await _get_draft(state)
    media = list(draft.get("media") or [])
    group_id = message.media_group_id
    stored_group = data.get("album_group")

    if stored_group is not None and group_id is not None and group_id != stored_group:
        await message.answer("ℹ️ Finish the current album first (tap ✅ Done).")
        return
    if group_id is not None and stored_group is None:
        await state.update_data(album_group=group_id)

    if message.photo:
        item = {"type": "photo", "file_id": message.photo[-1].file_id}
    elif message.video is not None:
        item = {"type": "video", "file_id": message.video.file_id}
    elif message.document is not None:
        item = {"type": "document", "file_id": message.document.file_id}
    else:  # pragma: no cover — filter guarantees one of the three
        await message.answer("❌ Albums may contain photos, videos and documents only.")
        return
    media.append(item)
    draft["media"] = media
    if draft.get("caption") is None and message.caption:
        draft["caption"] = message.html_text
    await _save_draft(state, draft)

    if len(media) >= ALBUM_MAX_ITEMS:
        await _finish_album(message, state)
        return

    status_text = (
        f"📦 Album detected: {len(media)} item(s)\n\n"
        "Tap ✅ Done when the album is complete."
    )
    prompt = data.get("album_prompt")
    if isinstance(prompt, dict):
        try:
            await message.bot.edit_message_text(
                chat_id=prompt["chat_id"],
                message_id=prompt["message_id"],
                text=status_text,
                reply_markup=admin_broadcast_album_keyboard(),
            )
            return
        except Exception:  # noqa: BLE001 — fall through to sending a new prompt
            pass
    sent = await message.answer(status_text, reply_markup=admin_broadcast_album_keyboard())
    await state.update_data(album_prompt={"chat_id": sent.chat.id, "message_id": sent.message_id})


@router.message(AdminFSM.album_collect, F.text)
async def album_text_input(message: Message, state: FSMContext) -> None:
    """Text during album collection — only /cancel is meaningful."""
    if _is_cancel(message.text):
        await _cancel_from_message(message, state)
        return
    await message.answer("❌ Send photos/videos/documents, or tap ✅ Done.")


async def _finish_album(message: Message, state: FSMContext) -> None:
    """Finalize the collected album and show the composer screen."""
    draft = await _get_draft(state)
    if not draft.get("media"):
        await message.answer("ℹ️ No media collected yet.")
        return
    draft["content_type"] = "album"
    await _save_draft(state, draft)
    data = await state.get_data()
    prompt = data.get("album_prompt")
    await state.set_state(None)
    await state.update_data(album_group=None, album_prompt=None)
    note = "✅ Album captured.\n\n"
    if isinstance(prompt, dict):
        try:
            await message.bot.edit_message_text(
                chat_id=prompt["chat_id"],
                message_id=prompt["message_id"],
                text=_composer_text(draft, note=note),
                reply_markup=admin_broadcast_composer_screen_keyboard(),
            )
            return
        except Exception:  # noqa: BLE001 — fall through to a new message
            pass
    await _composer_from_message(message, state, note=note)


@router.callback_query(F.data == "adm:bc:album:done")
async def album_done(callback: CallbackQuery, state: FSMContext) -> None:
    """Admin tapped ✅ Done — finalize the album from the callback path."""
    draft = await _get_draft(state)
    if not draft.get("media"):
        await safe_answer(callback, "ℹ️ No media collected yet.")
        return
    draft["content_type"] = "album"
    await _save_draft(state, draft)
    await state.set_state(None)
    await state.update_data(album_group=None, album_prompt=None)
    await _render_composer(callback, state, note="✅ Album captured.\n\n")
    await safe_answer(callback, "✅ Album captured.")


# ----------------------------------------------------------------------
# Composer: URL buttons
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:bc:btn")
async def bc_button_prompt(callback: CallbackQuery, state: FSMContext) -> None:
    """FSM: broadcast URL-button label."""
    draft = await _get_draft(state)
    if draft.get("content_type") is None:
        await safe_answer(callback, "ℹ️ Add content first.")
        return
    if len(draft.get("buttons") or []) >= MAX_BUTTONS:
        await safe_answer(callback, f"ℹ️ Maximum {MAX_BUTTONS} buttons per broadcast.")
        return
    await state.set_state(AdminFSM.bc_btn_label)
    if callback.message is not None:
        await callback.message.answer(
            "🔗 Send the button label (max 64 chars).\n\n/cancel — abort"
        )
    await safe_answer(callback)


@router.message(AdminFSM.bc_btn_label, F.text)
async def bc_btn_label_input(message: Message, state: FSMContext) -> None:
    """Capture the broadcast button label."""
    if _is_cancel(message.text):
        await _cancel_from_message(message, state)
        return
    label = (message.text or "").strip()
    if not label or len(label) > MAX_BUTTON_LABEL:
        await message.answer(f"❌ Label must be 1–{MAX_BUTTON_LABEL} chars. Try again or /cancel.")
        return
    await state.update_data(bc_btn_label=label)
    await state.set_state(AdminFSM.bc_btn_url)
    await message.answer("🔗 Send the URL (https:// only).\n\n/cancel — abort")


@router.message(AdminFSM.bc_btn_url, F.text)
async def bc_btn_url_input(message: Message, state: FSMContext) -> None:
    """Capture the broadcast button URL, validate and append to the draft."""
    if _is_cancel(message.text):
        await _cancel_from_message(message, state)
        return
    data = await state.get_data()
    label = str(data.get("bc_btn_label") or "")
    url = (message.text or "").strip()
    try:
        validate_buttons([{"label": label or "x", "url": url}])
    except ValidationError:
        await message.answer("❌ Invalid button URL (https:// or tg:// only). Try again or /cancel.")
        return
    draft = await _get_draft(state)
    buttons = list(draft.get("buttons") or [])
    if len(buttons) >= MAX_BUTTONS:
        await state.set_state(None)
        await message.answer(f"ℹ️ Maximum {MAX_BUTTONS} buttons per broadcast.")
        await _composer_from_message(message, state)
        return
    buttons.append({"label": label, "url": url})
    draft["buttons"] = buttons
    await _save_draft(state, draft)
    await state.set_state(None)
    await _composer_from_message(message, state, note="✅ Button added.\n\n")


# ----------------------------------------------------------------------
# Composer: targets
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:bc:targets")
async def bc_targets_screen(callback: CallbackQuery, state: FSMContext) -> None:
    """Audience picker."""
    draft = await _get_draft(state)
    if draft.get("content_type") is None:
        await safe_answer(callback, "ℹ️ Add content first.")
        return
    text = "🎯 <b>CHOOSE TARGET</b>\n\nWho should receive this broadcast?"
    await safe_edit(callback.message, text, admin_broadcast_targets_keyboard())
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_TARGET_RE.pattern))
async def bc_pick_target(callback: CallbackQuery, state: FSMContext) -> None:
    """Store the chosen audience (or ask for ids / language)."""
    match = _TARGET_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    target = match.group(1)
    if target not in TARGET_TYPES:
        await safe_answer(callback, "ℹ️ Unknown target.")
        return
    if target in {"specific_users", "specific_groups"}:
        await state.update_data(bc_target=target)
        await state.set_state(AdminFSM.specific_ids)
        if callback.message is not None:
            await callback.message.answer(
                "Send comma-separated Telegram IDs.\n\nExample: <code>123456789, 987654321</code>"
                "\n\n/cancel — abort",
                parse_mode="HTML",
            )
        await safe_answer(callback)
        return
    if target == "users_by_language":
        text = "🌐 <b>LANGUAGE</b>\n\nChoose the users' language:"
        await safe_edit(callback.message, text, admin_broadcast_language_keyboard())
        await safe_answer(callback)
        return
    draft = await _get_draft(state)
    draft["target_type"] = target
    draft["target_filter"] = {}
    await _save_draft(state, draft)
    await _render_confirm(callback, state)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_LANG_RE.pattern))
async def bc_pick_language(callback: CallbackQuery, state: FSMContext) -> None:
    """Store the language filter and show the confirmation screen."""
    match = _LANG_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    draft = await _get_draft(state)
    draft["target_type"] = "users_by_language"
    draft["target_filter"] = {"language": match.group(1)}
    await _save_draft(state, draft)
    await _render_confirm(callback, state)
    await safe_answer(callback)


@router.message(AdminFSM.specific_ids, F.text)
async def specific_ids_input(message: Message, state: FSMContext) -> None:
    """Capture comma-separated Telegram ids for specific targets."""
    if _is_cancel(message.text):
        await _cancel_from_message(message, state)
        return
    data = await state.get_data()
    target = str(data.get("bc_target") or "")
    raw = (message.text or "").replace(";", ",")
    ids: list[int] = []
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        try:
            ids.append(int(chunk))
        except (TypeError, ValueError):
            await message.answer(
                f"❌ Invalid id: {escape(chunk)}. Send numbers separated by commas, or /cancel."
            )
            return
    if not ids:
        await message.answer("❌ Send at least one Telegram ID, or /cancel.")
        return
    draft = await _get_draft(state)
    draft["target_type"] = target
    draft["target_filter"] = {"ids": ids}
    await _save_draft(state, draft)
    await state.set_state(None)
    await message.answer(
        "🎯 Target saved.\n\n"
        "📢 <b>BROADCAST PREVIEW</b>\n\n"
        f"Target: {_TARGET_LABELS.get(target, escape(target))}\n"
        f"Content: {_CONTENT_LABELS.get(draft.get('content_type') or '', '—')}\n"
        f"Buttons: {len(draft.get('buttons') or [])}\n\n"
        "<b>Ready to send?</b>",
        reply_markup=admin_broadcast_confirm_keyboard(),
        parse_mode="HTML",
    )


# ----------------------------------------------------------------------
# Preview & send
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:bc:preview")
async def bc_preview(callback: CallbackQuery, state: FSMContext) -> None:
    """Send the draft content exactly as recipients would receive it."""
    draft = await _get_draft(state)
    if draft.get("content_type") is None:
        await safe_answer(callback, "ℹ️ Add content first.")
        return
    if callback.message is not None:
        try:
            await _send_preview(callback.message, draft)
        except BotError as exc:
            await safe_answer(callback, exc.user_message, show_alert=True)
            return
    await safe_answer(callback, "👁️ Preview sent below.")


class BroadcastPreviewError(BotError):
    """Raised when a draft cannot be previewed (should not happen)."""

    user_message = "ℹ️ Nothing to preview yet."


async def _send_preview(message: Message, draft: dict[str, Any]) -> None:
    """Render the draft to the admin's chat with real fidelity."""
    try:
        keyboard = buttons_to_keyboard(draft.get("buttons") or None)
    except ValidationError:
        keyboard = None
    content_type = draft.get("content_type")
    caption = draft.get("caption")
    if content_type == "text":
        await message.answer(draft.get("text") or "", reply_markup=keyboard, parse_mode="HTML")
        return
    if content_type in SINGLE_MEDIA_TYPES:
        media = (draft.get("media") or [{}])[0]
        senders = {
            "photo": message.answer_photo,
            "video": message.answer_video,
            "audio": message.answer_audio,
            "document": message.answer_document,
            "animation": message.answer_animation,
            "voice": message.answer_voice,
        }
        sender = senders.get(str(content_type))
        if sender is None:
            raise BroadcastPreviewError()  # pragma: no cover — guarded by content_type check
        await sender(
            media.get("file_id", ""), caption=caption, reply_markup=keyboard, parse_mode="HTML"
        )
        return
    if content_type == "album":
        for index, item in enumerate(draft.get("media") or []):
            item_caption = caption if index == 0 else None
            parse_mode = "HTML" if item_caption else None
            if item.get("type") == "photo":
                await message.answer_photo(
                    item["file_id"], caption=item_caption, parse_mode=parse_mode
                )
            elif item.get("type") == "video":
                await message.answer_video(
                    item["file_id"], caption=item_caption, parse_mode=parse_mode
                )
            else:
                await message.answer_document(
                    item["file_id"], caption=item_caption, parse_mode=parse_mode
                )
        return
    if content_type == "copy":
        source = draft.get("copy_source") or {}
        await message.bot.copy_message(
            chat_id=message.chat.id,
            from_chat_id=source.get("chat_id"),
            message_id=(source.get("message_ids") or [None])[0],
        )
        return
    raise BroadcastPreviewError()


@router.callback_query(F.data == "adm:bc:send")
async def bc_send(callback: CallbackQuery, state: FSMContext, services: ServiceContainer) -> None:
    """Create the campaign, start it and show the progress screen."""
    if not await services.admin.permissions.has(callback.from_user.id, "broadcast"):
        await safe_answer(callback, "❌ You don't have permission to do that.", show_alert=True)
        return
    draft = await _get_draft(state)
    content_type = draft.get("content_type")
    target_type = draft.get("target_type")
    if not content_type or not target_type:
        await safe_answer(callback, "ℹ️ Add content and a target first.", show_alert=True)
        return
    bdraft = _build_broadcast_draft(draft)
    try:
        broadcast = await services.broadcast.create_draft(
            bdraft, target_type, callback.from_user.id, draft.get("target_filter") or None
        )
        await services.broadcast.start(broadcast.id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message, show_alert=True)
        return
    await services.admin.audit.log(
        callback.from_user.id,
        "broadcast.start",
        target_type="broadcast",
        target_id=broadcast.id,
        details={"target_type": target_type, "recipients": broadcast.target_count},
    )
    await state.clear()
    text = (
        f"🚀 Broadcast #{broadcast.id} started.\n\n"
        f"Recipients: {broadcast.target_count}\n\n"
        "The worker delivers — tap 🔄 Refresh for progress."
    )
    await safe_edit(
        callback.message, text, admin_broadcast_progress_keyboard(broadcast.id)
    )
    await safe_answer(callback, "🚀 Started.")


def _build_broadcast_draft(draft: dict[str, Any]) -> BroadcastDraft:
    """Assemble a :class:`BroadcastDraft` from the composer dict."""
    buttons = draft.get("buttons") or None
    content_type = str(draft.get("content_type"))
    if content_type == "text":
        return from_text(draft.get("text") or "", buttons)
    if content_type == "copy":
        return BroadcastDraft(
            content_type="copy", copy_source=draft.get("copy_source"), buttons=buttons
        )
    if content_type == "album":
        return BroadcastDraft(
            content_type="album",
            caption=draft.get("caption"),
            media=list(draft.get("media") or []),
            buttons=buttons,
        )
    return BroadcastDraft(
        content_type=content_type,
        caption=draft.get("caption"),
        media=list(draft.get("media") or []),
        buttons=buttons,
    )


# ----------------------------------------------------------------------
# Campaign control
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(_CONTROL_RE.pattern))
async def broadcast_control(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Pause / stop / refresh / retry one broadcast (all audited)."""
    match = _CONTROL_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    bid, action = int(match.group(1)), match.group(2)
    if action in {"pause", "stop", "retry"} and not await services.admin.permissions.has(
        callback.from_user.id, "broadcast"
    ):
        await safe_answer(callback, "❌ You don't have permission to do that.", show_alert=True)
        return
    try:
        if action == "pause":
            await services.broadcast.pause(bid)
            await services.admin.audit.log(
                callback.from_user.id, "broadcast.pause", target_type="broadcast", target_id=bid
            )
            await safe_answer(callback, "⏸️ Paused.")
        elif action == "stop":
            await services.broadcast.stop(bid)
            await services.admin.audit.log(
                callback.from_user.id, "broadcast.stop", target_type="broadcast", target_id=bid
            )
            await safe_answer(callback, "🛑 Stopped.")
        elif action == "retry":
            requeued = await services.broadcast.retry_failed(bid)
            await services.admin.audit.log(
                callback.from_user.id,
                "broadcast.retry",
                target_type="broadcast",
                target_id=bid,
                details={"requeued": requeued},
            )
            await safe_answer(callback, f"🔁 {requeued} recipient(s) requeued.")
        else:
            await safe_answer(callback)
    except BotError as exc:
        await safe_answer(callback, exc.user_message, show_alert=True)
        return
    await _render_progress(callback, services, bid)


async def _render_progress(
    callback: CallbackQuery, services: ServiceContainer, bid: int
) -> None:
    """Progress/result view of one broadcast (percent bar + counters)."""
    stats = await services.broadcast.stats(bid)
    if not stats:
        await safe_answer(callback, "ℹ️ Broadcast not found.")
        return
    total = int(stats.get("target_count") or 0)
    sent = int(stats.get("sent_count") or 0)
    failed = int(stats.get("failed_count") or 0)
    remaining = int(stats.get("remaining") or 0)
    status = str(stats.get("status") or "draft")
    icon = _STATUS_ICONS.get(status, "•")
    percent = round(sent / total * 100) if total else 0
    lines = [
        f"📢 <b>BROADCAST #{bid}</b>\n",
        f"Status: {icon} {escape(status)}",
        f"{progress_bar(sent, max(total, 1))} {percent}%",
        f"✅ Sent: {sent} | ❌ Failed: {failed} | ⏳ Remaining: {remaining}",
    ]
    speed = _speed_per_minute(stats, sent)
    if speed is not None:
        lines.append(f"Speed: {speed:.0f}/min")
    keyboard: InlineKeyboardMarkup
    if status in {"pending", "sending", "paused"}:
        keyboard = admin_broadcast_progress_keyboard(bid)
    else:
        keyboard = admin_broadcast_result_keyboard(bid)
    await safe_edit(callback.message, "\n".join(lines), keyboard)


def _speed_per_minute(stats: dict[str, Any], sent: int) -> float | None:
    """Delivery speed from ``started_at`` (None before start / on bad data)."""
    started_raw = stats.get("started_at")
    if not started_raw or sent <= 0:
        return None
    try:
        started = datetime.fromisoformat(str(started_raw))
    except ValueError:
        return None
    elapsed = (utcnow() - started).total_seconds()
    if elapsed <= 0:
        return None
    return sent / (elapsed / 60.0)


__all__ = ["router"]

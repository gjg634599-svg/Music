"""The start dashboard, deep links and the dashboard action dispatcher.

This module is the navigation root of the personal bot; it also hosts the
shared screen renderers every personal flow navigates back to:

* :func:`render_dashboard` — the start screen (text, dynamic keyboard, logo),
* :func:`render_group_invite` — the "add me to a group" screen,
* :func:`send_dashboard` — send (photo caption or plain) the dashboard.

Deep links: ``/start track_<id>`` opens the track page directly.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiogram import F, Router
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message

from app.bot.keyboards.common import back_button, edit_screen
from app.bot.keyboards.start import dashboard_keyboard, group_invite_keyboard
from app.bot.handlers.search import (
    enter_search_state,
    render_search_prompt,
    render_track_page,
)
from app.errors import BotError
from app.logging import get_logger, log_extra
from app.utils import display_name, safe_answer

if TYPE_CHECKING:  # pragma: no cover - typing only
    from aiogram import Bot

    from app.bot.services import ServiceContainer

logger = get_logger(__name__)

#: Prefix of the /start deep-link payload that opens a track page.
TRACK_PAYLOAD_PREFIX = "track_"

router = Router(name="start")


# ----------------------------------------------------------------------
# Shared screen renderers
# ----------------------------------------------------------------------
async def render_dashboard(
    services: "ServiceContainer", bot: "Bot", from_user: Any = None
) -> tuple[str, InlineKeyboardMarkup | None, str | None]:
    """Build the dashboard: ``(text, keyboard, logo_file_id)``.

    ``from_user`` feeds the ``{name}`` / ``{username}`` placeholders of the
    admin-customizable start message (missing placeholders stay as-is).
    """
    me = await bot.me()
    bot_username = (me.username or "").lstrip("@")
    name = display_name(from_user) if from_user is not None else ""
    username = (getattr(from_user, "username", None) or "") if from_user is not None else ""
    text = await services.admin.appearance.message(
        "start", name=name, username=username, bot_name=bot_username
    )
    keyboard = await dashboard_keyboard(services, bot_username)
    if not keyboard.inline_keyboard:
        keyboard = None  # no enabled buttons — render without a keyboard
    logo = await services.admin.appearance.logo()
    logo_file_id = getattr(logo, "file_id", None) if logo is not None else None
    return text, keyboard, logo_file_id


async def send_dashboard(
    message: Message, services: "ServiceContainer"
) -> Message | None:
    """Send the dashboard as a photo (with caption) or a plain text message."""
    text, keyboard, logo_file_id = await render_dashboard(
        services, message.bot, message.from_user
    )
    if logo_file_id:
        try:
            return await message.answer_photo(
                logo_file_id, caption=text, parse_mode="HTML", reply_markup=keyboard
            )
        except Exception as exc:  # noqa: BLE001 — broken logo file_id, caption limit
            logger.warning(
                "bot.dashboard_photo_failed", extra=log_extra(error=str(exc)[:160])
            )
    return await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


def render_group_invite(bot_username: str) -> tuple[str, InlineKeyboardMarkup]:
    """The 'add me to a group' instructions screen."""
    username = (bot_username or "").lstrip("@")
    text = (
        "👥 <b>GROUP MODE</b>\n\n"
        "Add me to a group and play music in its voice chat:\n\n"
        "1. Tap the button below\n"
        "2. Choose a group\n"
        "3. Use /play &lt;song&gt; in the group\n\n"
        "I stay silent unless you talk to me with commands."
    )
    return text, group_invite_keyboard(username)


async def _send_track_deep_link(
    message: Message, services: "ServiceContainer", track_id: int
) -> bool:
    """Show a track page for a deep-linked track; False when unavailable."""
    try:
        track = await services.music.get_track(track_id)
    except BotError:
        track = None
    if track is None:
        return False
    text, keyboard = await render_track_page(
        services, message.from_user.id if message.from_user else 0, track
    )
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)
    return True


# ----------------------------------------------------------------------
# /start (with deep-link payloads)
# ----------------------------------------------------------------------
@router.message(CommandStart(), F.chat.type == "private")
async def cmd_start(
    message: Message,
    command: CommandObject,
    services: ServiceContainer,
    state: FSMContext,
) -> None:
    """/start — register the user, then show the dashboard (or deep link)."""
    user = await services.users.get_or_create(message.from_user)
    await state.clear()  # a fresh /start always resets any pending flow
    await services.analytics.track(
        "start", user_id=user.telegram_id, payload={"deep_link": bool(command.args)}
    )
    logger.info("bot.start", extra=log_extra(user_id=user.telegram_id))

    payload = (command.args or "").strip()
    if payload.startswith(TRACK_PAYLOAD_PREFIX):
        try:
            track_id = int(payload[len(TRACK_PAYLOAD_PREFIX):])
        except ValueError:
            track_id = 0
        if track_id > 0 and await _send_track_deep_link(message, services, track_id):
            return
    # Unknown/empty payloads fall through to the regular dashboard.
    await send_dashboard(message, services)


# ----------------------------------------------------------------------
# /group — add-the-bot instructions
# ----------------------------------------------------------------------
@router.message(Command("group"), F.chat.type == "private")
async def cmd_group(message: Message, services: ServiceContainer) -> None:
    """/group — deep-link instructions for adding the bot to a group."""
    me = await message.bot.me()
    text, keyboard = render_group_invite(me.username or "")
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


# ----------------------------------------------------------------------
# dash:<action> — dashboard button dispatcher
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(r"^dash:[a-z]+$"))
async def on_dashboard_action(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Route dynamic dashboard buttons to their screens."""
    action = str(callback.data).split(":", 1)[1]
    message = callback.message

    if action == "search":
        text, keyboard = await render_search_prompt(services)
        await enter_search_state(state)
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "library":
        from app.bot.handlers.library import render_library_home

        text, keyboard = render_library_home()
        await state.update_data(mode=None, playlist_id=None)
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "playlists":
        from app.bot.handlers.playlists import render_playlists_list
        from app.bot.handlers.playlists import _user_db_id

        try:
            user_db_id = await _user_db_id(services, callback.from_user.id)
            text, keyboard = await render_playlists_list(services, user_db_id)
        except BotError as exc:
            await safe_answer(callback, exc.user_message)
            return
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "history":
        from app.bot.handlers.library import _render_recent

        text, keyboard = await _render_recent(services, callback.from_user.id)
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "stats":
        from app.bot.handlers.stats import render_stats_screen

        try:
            text, keyboard = await render_stats_screen(
                services, callback.from_user.id
            )
        except BotError as exc:
            await safe_answer(callback, exc.user_message)
            return
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "settings":
        from app.bot.handlers.library import render_settings

        text, keyboard = await render_settings(services, callback.from_user.id)
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "account":
        from app.bot.handlers.account import render_account_screen

        try:
            text, keyboard = await render_account_screen(
                services, callback.from_user.id
            )
        except BotError as exc:
            await safe_answer(callback, exc.user_message)
            return
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "help":
        text = await services.admin.appearance.message("help")
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[[back_button("nav:home")]]
        )
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "commands":
        text = await services.admin.appearance.message("commands")
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[back_button("nav:home")]])
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "about":
        text = await services.admin.appearance.message("about")
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[back_button("nav:home")]])
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    if action == "group":
        me = await callback.bot.me()
        text, keyboard = render_group_invite(me.username or "")
        await edit_screen(message, text, keyboard)
        await safe_answer(callback)
        return

    # Unknown action (stale button from an older keyboard layout).
    await safe_answer(callback)


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

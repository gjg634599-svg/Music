"""Search in a private DM → play in a group voice chat (full workflow).

The user journey implemented here (every step validated, cancellable and
recoverable):

1. A user opens a track page in a private chat and presses **Play**.
2. The destination chooser appears: their known groups, a "send a group
   link" option and the legacy "play here" (personal audio file) option.
3. Choosing a group or sending a group link resolves the *target group*
   through the configured voice account (Telethon):
   public usernames, ``t.me/<username>`` links and private invite links
   (``t.me/+hash`` / ``joinchat/<hash>`` / ``tg://join``) are supported;
   channels, users, dead links and bans are rejected with actionable
   messages.
4. Prerequisites are verified through MTProto: the group has an ACTIVE
   voice chat, the voice account can access the group (auto-join via the
   documented invite flow when enabled), and the requesting user is a
   member of the group with the ``play`` permission under the group's
   permission model.
5. Only then does playback start — routed to the TARGET GROUP's queue
   and voice session (never the DM chat id), isolated per group, with a
   per-user execution lock preventing duplicate playback from repeated
   clicks.
6. The outcome is confirmed in the DM honestly: success only after the
   controller actually started (or queued behind an active session);
   failures show the reason plus Retry / Cancel.

Back / Cancel / X semantics (distinct by design):

* **Back** returns to the previous logical screen (link prompt → chooser,
  chooser → track page) and never executes anything.
* **Cancel** cancels ONLY this pending operation: the ``dmop_*`` FSM keys
  are popped (search state and other users' operations are untouched) and
  the message is edited to a cancelled state.
* **X** (Close) dismisses the interface only: pending operation cleared,
  playback and unrelated sessions untouched.

Pending-operation state lives in the aiogram FSM data (JSON-serializable,
storage-backend agnostic, naturally isolated per user+chat):

* ``dmop_track_id``   — selected track's database id,
* ``dmop_source`` / ``dmop_source_id`` — original provider identity,
* ``dmop_requester``  — requesting Telegram user id,
* ``dmop_created``    — creation time (unix seconds; TTL-bounded),
* ``dmop_stage``      — ``chooser`` | ``awaiting_link`` | ``executing``,
* ``dmop_search_page``— results page Back returns to.

Operations expire after :data:`DM_OPERATION_TTL` (10 minutes) with a
recovery path; a restart clears in-memory FSM state safely (Redis-backed
deployments keep it, and the TTL still bounds it).
"""

from __future__ import annotations

import asyncio
import time
from typing import TYPE_CHECKING, Any

from aiogram import F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.bot.keyboards.common import edit_screen
from app.bot.handlers.search import artist_name
from app.errors import BotError, TrackNotFoundError, VoiceUnavailableError
from app.logging import get_logger, log_extra
from app.playback.queue import QueueOwner
from app.utils import (
    PayloadBadges,
    escape,
    format_duration,
    now_playing_text,
    queue_total_line,
    safe_answer,
    truncate,
)
from app.voice.group_access import STATUS_MESSAGES as ACCESS_MESSAGES

if TYPE_CHECKING:  # pragma: no cover — typing only
    from app.bot.services import ServiceContainer
    from app.database.models import Track

logger = get_logger(__name__)

router = Router(name="dm_play")

#: How long a pending DM→group operation stays valid (seconds).
DM_OPERATION_TTL = 600

#: Groups offered on the destination chooser.
MAX_PICKER_GROUPS = 6

#: Statuses meaning a group session is already mid-track.
_ACTIVE_STATUSES = frozenset({"playing", "paused"})

#: dmc:<gid>:<action> → permission action (queue view is read-only).
_DMC_ACTIONS: dict[str, str] = {
    "pause": "pause",
    "resume": "resume",
    "next": "skip",
    "stop": "stop",
    "queue": "queue",
    "close": "",  # dismiss-only: no playback permission needed
}


class DmPlayFSM(StatesGroup):
    """States of the DM→group playback conversation."""

    waiting_link = State()


#: Per-user execution locks (double-click / duplicate-message protection).
#: Bounded by active users; entries are dropped after each execution.
_EXECUTION_LOCKS: dict[int, asyncio.Lock] = {}


# ----------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------
def _track_summary(track: "Track") -> str:
    """One-line escaped track summary for DM screens."""
    line = f"🎵 <b>{escape(truncate(track.title, 64))}</b>"
    artist = artist_name(track)
    if artist:
        line += f" — {escape(truncate(artist, 48))}"
    duration = int(getattr(track, "duration_seconds", 0) or 0)
    if duration > 0:
        line += f" · {format_duration(duration)}"
    return line


async def _get_track(
    services: "ServiceContainer", track_id: int
) -> "Track | None":
    try:
        return await services.music.get_track(int(track_id))
    except BotError:
        return None


def _dm_keyboard(rows: list[list[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _chooser_keyboard(
    track_id: int,
    groups: list[Any],
) -> InlineKeyboardMarkup:
    """Destination chooser: known groups + link + personal + navigation."""
    rows: list[list[InlineKeyboardButton]] = []
    for group in groups[:MAX_PICKER_GROUPS]:
        title = str(getattr(group, "title", "") or "Group")
        rows.append(
            [
                InlineKeyboardButton(
                    text=truncate(f"▶️ {title}", 40),
                    callback_data=f"dm:grp:{track_id}:{int(group.telegram_id)}",
                )
            ]
        )
    rows.append(
        [InlineKeyboardButton(text="🔗 Send a group link", callback_data=f"dm:link:{track_id}")]
    )
    rows.append(
        [InlineKeyboardButton(text="🎧 Play here (audio file)", callback_data=f"trk:play:{track_id}")]
    )
    rows.append(
        [
            InlineKeyboardButton(text="🔙 Back", callback_data=f"trk:{track_id}"),
            InlineKeyboardButton(text="❌ Cancel", callback_data="dm:cancel"),
        ]
    )
    return _dm_keyboard(rows)


def _link_prompt_keyboard(track_id: int) -> InlineKeyboardMarkup:
    """The link-input prompt: back to chooser + cancel."""
    return _dm_keyboard(
        [
            [InlineKeyboardButton(text="🔗 Send a group link", callback_data=f"dm:link:{track_id}")],
            [
                InlineKeyboardButton(text="🔙 Back", callback_data=f"dm:back:{track_id}"),
                InlineKeyboardButton(text="❌ Cancel", callback_data="dm:cancel"),
            ],
        ]
    )


def _failure_keyboard(track_id: int, *, offer_back: bool = True) -> InlineKeyboardMarkup:
    """Retry (send another link) + Back + Cancel on failure screens."""
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(text="🔄 Try another group", callback_data=f"dm:link:{track_id}")]
    ]
    if offer_back:
        rows.append(
            [InlineKeyboardButton(text="🔙 Back", callback_data=f"dm:back:{track_id}")]
        )
    rows.append([InlineKeyboardButton(text="❌ Cancel", callback_data="dm:cancel")])
    return _dm_keyboard(rows)


def _success_keyboard(group_tg_id: int) -> InlineKeyboardMarkup:
    """Post-success DM controls for the target group (permission-checked)."""
    gid = int(group_tg_id)
    return _dm_keyboard(
        [
            [
                InlineKeyboardButton(text="⏸️ Pause", callback_data=f"dmc:{gid}:pause"),
                InlineKeyboardButton(text="⏭️ Skip", callback_data=f"dmc:{gid}:next"),
            ],
            [
                InlineKeyboardButton(text="📋 Queue", callback_data=f"dmc:{gid}:queue"),
                InlineKeyboardButton(text="🛑 Stop", callback_data=f"dmc:{gid}:stop"),
            ],
            [InlineKeyboardButton(text="✖️ Close", callback_data="dm:close")],
        ]
    )


async def _store_operation(
    state: FSMContext,
    *,
    track_id: int,
    stage: str,
    services: "ServiceContainer" | None = None,
) -> dict[str, Any]:
    """Write the pending-operation bookkeeping keys (preserving search)."""
    data = await state.get_data()
    updates: dict[str, Any] = {
        "dmop_track_id": int(track_id),
        "dmop_requester": data.get("dmop_requester"),
        "dmop_created": data.get("dmop_created") or int(time.time()),
        "dmop_stage": stage,
    }
    # A NEW Play click starts a fresh operation (own track, fresh clock).
    if data.get("dmop_track_id") != int(track_id):
        updates["dmop_created"] = int(time.time())
    if services is not None:
        track = await _get_track(services, int(track_id))
        if track is not None:
            updates["dmop_source"] = getattr(track, "source", None)
            updates["dmop_source_id"] = str(getattr(track, "source_id", "") or "")
    await state.update_data(**updates)
    return {**data, **updates}


async def _clear_operation(state: FSMContext) -> None:
    """Remove ONLY the dmop_* keys (search state stays untouched)."""
    data = await state.get_data()
    kept = {key: value for key, value in data.items() if not key.startswith("dmop_")}
    if kept != data or await state.get_state() == DmPlayFSM.waiting_link:
        await state.set_data(kept)
    if await state.get_state() == DmPlayFSM.waiting_link:
        await state.set_state(None)


async def _operation_expired(data: dict[str, Any]) -> bool:
    """True when the pending operation outlived its TTL."""
    created = data.get("dmop_created")
    if not isinstance(created, (int, float)) or created <= 0:
        return True
    return (time.time() - float(created)) > DM_OPERATION_TTL


async def _expire_screen(callback: CallbackQuery, state: FSMContext) -> None:
    """Recovery screen for an expired (or missing) pending operation."""
    await _clear_operation(state)
    text = (
        "⌛ <b>THIS REQUEST EXPIRED</b>\n\n"
        "Group-selection requests last 10 minutes. Open the track again and "
        "press <b>Play</b> to start over."
    )
    await edit_screen(callback.message, text, None)
    await safe_answer(callback, "⌛ Request expired — start over with Play")


def _expired_text() -> str:
    return (
        "⌛ <b>THIS REQUEST EXPIRED</b>\n\n"
        "Group-selection requests last 10 minutes. Open the track again and "
        "press <b>Play</b> to start over."
    )


# ----------------------------------------------------------------------
# Screens
# ----------------------------------------------------------------------
async def _render_chooser(
    callback: CallbackQuery,
    services: "ServiceContainer",
    state: FSMContext,
    track_id: int,
) -> None:
    """The destination chooser screen (known groups + link + personal)."""
    track = await _get_track(services, track_id)
    if track is None:
        await safe_answer(callback, TrackNotFoundError().user_message)
        return
    try:
        groups = await services.groups.groups_of_user(callback.from_user.id)
    except Exception as exc:  # noqa: BLE001 — picker is cosmetic
        logger.warning(
            "dm_play.groups_lookup_failed", extra=log_extra(error=str(exc)[:160])
        )
        groups = []
    lines = ["🔊 <b>WHERE SHOULD THIS PLAY?</b>", "", _track_summary(track), ""]
    if groups:
        lines.append("Pick one of your groups below, or send a link to another one:")
    else:
        lines.append("Send me the group link where you want to listen:")
    lines.append("")
    lines.append(
        "🎤 Music plays in the group's <b>voice chat</b> — a group admin may "
        "need to start one first."
    )
    await _store_operation(state, track_id=track.id, stage="chooser", services=services)
    if await state.get_state() == DmPlayFSM.waiting_link:
        await state.set_state(None)
    await edit_screen(callback.message, "\n".join(lines), _chooser_keyboard(track.id, groups))
    await safe_answer(callback)


async def _render_link_prompt(
    message: Any,
    state: FSMContext,
    services: "ServiceContainer",
    track_id: int,
    *,
    note: str | None = None,
) -> None:
    """The 'send me the group link' prompt (enters the waiting_link state)."""
    track = await _get_track(services, track_id)
    if track is None:
        await edit_screen(message, TrackNotFoundError().user_message, None)
        return
    lines = ["🔗 <b>SEND THE GROUP LINK</b>", "", _track_summary(track), ""]
    if note:
        lines.append(note)
        lines.append("")
    lines.append(
        "Send me one of:\n"
        "• a public group link — <code>https://t.me/yourgroup</code>\n"
        "• a group username — <code>@yourgroup</code>\n"
        "• a private invite link — <code>https://t.me/+AbCdEf…</code>"
    )
    await _store_operation(state, track_id=track.id, stage="awaiting_link")
    await state.set_state(DmPlayFSM.waiting_link)
    await edit_screen(message, "\n".join(lines), _link_prompt_keyboard(track.id))


# ----------------------------------------------------------------------
# The heavy lifting: resolve + verify + play
# ----------------------------------------------------------------------
async def _execute_play(
    callback_or_message: Any,
    services: "ServiceContainer",
    state: FSMContext,
    *,
    track_id: int,
    group_tg_id: int,
    group_title: str | None,
    requester: Any,
    bot: Any,
    chat_id: int,
) -> None:
    """Verify every prerequisite, then start playback in the target group.

    Confirmation is honest: the DM screen reports success only after the
    playback controller actually started the session (or queued behind an
    active one); every earlier failure renders its reason + Retry/Cancel.
    """
    message = getattr(callback_or_message, "message", None) or callback_or_message
    requester_id = int(getattr(requester, "id", 0) or 0)

    # 1) The selected track must still exist.
    track = await _get_track(services, track_id)
    if track is None:
        await _clear_operation(state)
        await edit_screen(
            message, f"❌ That track is no longer available.\n\n{_expired_text()}", None
        )
        return

    # 2) The voice engine must be up with a usable account.
    if not getattr(services, "voice", None) or not services.voice.has_accounts():
        await _failure(message, track.id, VoiceUnavailableError().user_message)
        return
    picked = services.voice.pick_client()
    if picked is None:
        await _failure(message, track.id, VoiceUnavailableError().user_message)
        return
    account, client = picked
    access = services.voice.group_access

    # 3) An ACTIVE voice chat must exist in the target group.
    try:
        has_vc = await access.check_voice_chat(client, group_tg_id)
    except Exception as exc:  # noqa: BLE001 — verification must not crash
        logger.warning(
            "dm_play.voice_chat_check_failed",
            extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
        )
        has_vc = None
    if has_vc is False:
        await _failure(message, track.id, ACCESS_MESSAGES["voice_chat_missing"])
        return

    # 4) The voice account must be able to access the group (auto-join when
    #    enabled — the documented private-group invite flow).
    try:
        outcome = await access.ensure_access(
            client, group_tg_id, account_id=int(account.model.id)
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "dm_play.ensure_access_failed",
            extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
        )
        outcome = None
    if outcome is None or not outcome.ok:
        text = (getattr(outcome, "user_message", None)) or ACCESS_MESSAGES.get(
            "group_private", "🎙️ The voice account cannot access this group."
        )
        await _failure(message, track.id, text)
        return

    # 5) The REQUESTING USER must be a member of the target group.
    try:
        membership = await access.check_user_membership(
            client, group_tg_id, requester_id
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "dm_play.user_membership_failed",
            extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
        )
        membership = None
    if membership is None:
        await _failure(message, track.id, ACCESS_MESSAGES["membership_unknown"])
        return
    is_member, is_admin = membership
    if not is_member:
        await _failure(message, track.id, ACCESS_MESSAGES["user_not_member"])
        return

    # 6) The group's permission model must allow this user to start playback.
    allowed = True
    try:
        allowed = bool(
            await services.permissions.can(
                group_tg_id, requester_id, "play", is_chat_admin=is_admin
            )
        )
    except Exception as exc:  # noqa: BLE001 — deny on lookup failure
        logger.warning(
            "dm_play.permission_check_failed",
            extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
        )
        allowed = False
    if not allowed:
        await _failure(
            message, track.id, "❌ You don't have permission to control playback in that group."
        )
        return

    # 7) Register the group + membership (settings, permissions, analytics).
    try:
        group = await services.groups.register_group(
            group_tg_id, group_title, chat_type="supergroup"
        )
        user = await services.users.get_or_create(requester)
        await services.groups.sync_member(
            group.id, user.id, requester_id, is_admin=is_admin
        )
    except Exception as exc:  # noqa: BLE001 — bookkeeping must not block music
        logger.warning(
            "dm_play.group_register_failed",
            extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
        )
        group = None

    # 8) Control message routing: the group when the bot is a member (so
    #    everyone sees Now Playing), otherwise the requester's DM.
    control_chat_id = chat_id  # default: DM
    try:
        await bot.get_chat(group_tg_id)
        control_chat_id = group_tg_id
    except Exception:  # noqa: BLE001 — bot not in the group (or no access)
        control_chat_id = chat_id

    # 9) EXECUTE — queued behind a genuinely-active session, or started
    #    right now. ``was_active`` uses the controller's liveness probe:
    #    a persisted "playing" status left by a previous process is a
    #    ghost (no timer, no voice session in THIS process) and must not
    #    turn the user's request into a silent queue append.
    owner = QueueOwner(kind="group", id=int(group_tg_id))
    title = group_title or (
        str(getattr(group, "title", "") or f"Group {group_tg_id}") if group else f"Group {group_tg_id}"
    )
    try:
        was_active = False
        probe = getattr(services.playback, "is_active", None)
        if probe is not None:
            try:
                was_active = bool(await probe(owner))
            except Exception:  # noqa: BLE001 — probe failure plays now
                was_active = False
        else:
            try:
                payload = await services.playback.now_playing(owner)
                was_active = payload.get("status") in _ACTIVE_STATUSES
            except Exception:  # noqa: BLE001 — treat as idle
                was_active = False
        if was_active:
            position = await services.playback.enqueue(
                owner, control_chat_id, bot, track.id, requester_id
            )
            try:  # cosmetic enrichment — never fails the play outcome
                queue_size = await services.queue.size(owner)
                position_text = f"#{position} of {queue_size}"
            except Exception:  # noqa: BLE001 — older fakes / lookup failures
                position_text = f"#{position}"
            outcome_text = (
                f"✅ <b>ADDED TO THE QUEUE</b>\n\n"
                f"{_track_summary(track)}\n"
                f"📢 Group: <b>{escape(truncate(title, 48))}</b>\n"
                f"➕ Position {position_text} — "
                "a track is already playing there."
            )
            queued = True
        else:
            await services.playback.play_now(
                owner,
                control_chat_id,
                bot,
                track.id,
                requester_id,
            )
            outcome_text = (
                f"▶️ <b>NOW PLAYING IN THE GROUP</b>\n\n"
                f"{_track_summary(track)}\n"
                f"📢 Group: <b>{escape(truncate(title, 48))}</b>\n"
                f"🎙️ Streaming in the voice chat."
            )
            queued = False
    except BotError as exc:
        await _failure(message, track.id, exc.user_message)
        return
    except Exception as exc:  # noqa: BLE001 — unexpected errors stay honest
        logger.error(
            "dm_play.play_failed",
            extra=log_extra(
                track_id=track.id, group_id=group_tg_id, error=str(exc)[:200]
            ),
        )
        await _failure(
            message, track.id, "❌ Couldn't start playback in that group. Please try again."
        )
        return

    # 10) Honest confirmation + DM controls scoped to the target group.
    await _clear_operation(state)
    keyboard = _success_keyboard(group_tg_id)
    if not queued and control_chat_id == chat_id:
        outcome_text += "\n\nℹ️ Controls also live in the group when the bot is added there."
    await edit_screen(message, outcome_text, keyboard)
    logger.info(
        "dm_play.started",
        extra=log_extra(
            track_id=track.id,
            group_id=group_tg_id,
            requester=requester_id,
            queued=queued,
            control_chat=control_chat_id,
        ),
    )


async def _failure(message: Any, track_id: int, text: str) -> None:
    """Render a failure screen with Retry / Back / Cancel."""
    body = f"{text}"
    await edit_screen(message, body, _failure_keyboard(track_id))


# ----------------------------------------------------------------------
# Handlers — destination chooser
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(r"^trk:dest:\d+$"), F.message.chat.type == "private")
async def on_track_destination(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Track page **Play** (private) → destination chooser."""
    track_id = int(str(callback.data).rsplit(":", 1)[1])
    await _render_chooser(callback, services, state, track_id)


@router.callback_query(F.data.regexp(r"^dm:back:\d+$"), F.message.chat.type == "private")
async def on_dm_back(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Back: link prompt → chooser; chooser → track page (never executes)."""
    track_id = int(str(callback.data).rsplit(":", 1)[1])
    data = await state.get_data()
    if data.get("dmop_stage") == "awaiting_link":
        await _render_chooser(callback, services, state, track_id)
        return
    # From the chooser (or a failure screen) → the track page.
    track = await _get_track(services, track_id)
    if track is None:
        await safe_answer(callback, TrackNotFoundError().user_message)
        return
    from app.bot.handlers.search import render_track_page

    page = int(data.get("search_page") or 0)
    text, keyboard = await render_track_page(
        services, callback.from_user.id, track, page=page
    )
    await _clear_operation(state)
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(r"^dm:link:\d+$"), F.message.chat.type == "private")
async def on_dm_link_prompt(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """'Send a group link' (chooser) / 'Try another group' (failure) — the
    link prompt (FSM waiting_link). One handler for both entry points."""
    track_id = int(str(callback.data).rsplit(":", 1)[1])
    await safe_answer(callback)
    await _render_link_prompt(callback.message, state, services, track_id)


@router.callback_query(F.data == "dm:cancel", F.message.chat.type == "private")
async def on_dm_cancel(
    callback: CallbackQuery, state: FSMContext
) -> None:
    """Cancel: clear ONLY this pending operation (search state preserved)."""
    await _clear_operation(state)
    text = (
        "❌ <b>GROUP PLAYBACK CANCELLED</b>\n\n"
        "Nothing was played and no group was joined.\n"
        "Open a track and press Play whenever you want to try again."
    )
    await edit_screen(callback.message, text, None)
    await safe_answer(callback, "❌ Cancelled")


@router.callback_query(F.data == "dm:close", F.message.chat.type == "private")
async def on_dm_close(callback: CallbackQuery, state: FSMContext) -> None:
    """X/Close: dismiss this interface only (playback untouched)."""
    await _clear_operation(state)
    try:
        if callback.message is not None:
            await callback.message.delete()
    except Exception as exc:  # noqa: BLE001 — already deleted / too old
        logger.debug("dm_play.close_failed", extra=log_extra(error=str(exc)[:120]))
        if callback.message is not None:
            await edit_screen(callback.message, "✖️ Closed.", None)
    await safe_answer(callback, "Closed")


# ----------------------------------------------------------------------
# Handlers — link submission (FSM state)
# ----------------------------------------------------------------------
@router.message(
    F.chat.type == "private",
    StateFilter(DmPlayFSM.waiting_link),
    F.text,
)
async def on_group_link(
    message: Message, services: ServiceContainer, state: FSMContext
) -> None:
    """The user sent the group link — resolve, verify and play."""
    data = await state.get_data()
    track_id = data.get("dmop_track_id")
    if not isinstance(track_id, int) or await _operation_expired(data):
        await state.set_state(None)
        await message.answer(_expired_text())
        await _clear_operation(state)
        return

    link = (message.text or "").strip()[:256]
    requester_id = int(message.from_user.id if message.from_user else 0) or int(
        data.get("dmop_requester") or 0
    )
    # Duplicate-submission protection (same user, same pending operation).
    lock = _EXECUTION_LOCKS.setdefault(requester_id, asyncio.Lock())
    if lock.locked():
        await message.answer("⏳ Still working on your previous request…")
        return

    async with lock:
        await state.update_data(dmop_stage="executing", dmop_requester=requester_id)
        await _resolve_and_play(
            message, services, state,
            track_id=int(track_id), link=link,
            requester=message.from_user,
        )
    _EXECUTION_LOCKS.pop(requester_id, None)


@router.message(
    F.chat.type == "private",
    StateFilter(DmPlayFSM.waiting_link),
    Command("cancel"),
)
async def on_group_link_cancel(message: Message, state: FSMContext) -> None:
    """/cancel while waiting for a link — same semantics as the button."""
    await _clear_operation(state)
    await message.answer(
        "❌ <b>GROUP PLAYBACK CANCELLED</b>\n\n"
        "Nothing was played and no group was joined.",
        parse_mode="HTML",
    )


@router.callback_query(F.data.regexp(r"^dm:grp:\d+:-?\d+$"), F.message.chat.type == "private")
async def on_dm_group_pick(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """One of the user's known groups picked from the chooser."""
    parts = str(callback.data).split(":")
    track_id, group_tg_id = int(parts[2]), int(parts[3])
    data = await state.get_data()
    if await _operation_expired(data):
        await _expire_screen(callback, state)
        return

    requester_id = int(callback.from_user.id)
    lock = _EXECUTION_LOCKS.setdefault(requester_id, asyncio.Lock())
    if lock.locked():
        await safe_answer(callback, "⏳ Still working on your previous request…")
        return
    await safe_answer(callback, "🎙️ Starting playback…")
    async with lock:
        await state.update_data(dmop_stage="executing", dmop_requester=requester_id)
        group_title = None
        try:
            group = await services.groups.groups.groups_of_user(requester_id)
            for candidate in group:
                if int(candidate.telegram_id) == group_tg_id:
                    group_title = str(candidate.title or "") or None
                    break
        except Exception:  # noqa: BLE001 — title is cosmetic
            group_title = None
        await _execute_play(
            callback,
            services,
            state,
            track_id=track_id,
            group_tg_id=group_tg_id,
            group_title=group_title,
            requester=callback.from_user,
            bot=callback.bot,
            chat_id=callback.message.chat.id if callback.message else requester_id,
        )
    _EXECUTION_LOCKS.pop(requester_id, None)


async def _resolve_and_play(
    message: Message,
    services: "ServiceContainer",
    state: FSMContext,
    *,
    track_id: int,
    link: str,
    requester: Any,
) -> None:
    """Resolve the submitted link, then run the verified playback flow."""
    if not getattr(services, "voice", None) or not services.voice.has_accounts():
        await _failure(message, track_id, VoiceUnavailableError().user_message)
        return
    picked = services.voice.pick_client()
    if picked is None:
        await _failure(message, track_id, VoiceUnavailableError().user_message)
        return
    account, client = picked
    access = services.voice.group_access

    try:
        resolution = await access.resolve_target(
            client, link, account_id=int(account.model.id), allow_join=True
        )
    except Exception as exc:  # noqa: BLE001 — resolution must not crash the bot
        logger.error(
            "dm_play.resolve_crashed",
            extra=log_extra(error=str(exc)[:200]),
        )
        resolution = None

    if resolution is None or not resolution.ok:
        text = (
            (getattr(resolution, "user_message", None))
            or ACCESS_MESSAGES.get("invalid_link", "⚠️ Invalid group link.")
        )
        note = f"{text}"
        await _render_link_prompt(
            message, state, services, track_id, note=note
        )
        await state.update_data(dmop_stage="awaiting_link")
        return

    # The link resolved (and possibly joined the group) — keep the pending
    # operation's selected track and play in the resolved target group.
    await _execute_play(
        message,
        services,
        state,
        track_id=track_id,
        group_tg_id=int(resolution.group_tg_id or 0),
        group_title=resolution.title,
        requester=requester,
        bot=message.bot,
        chat_id=message.chat.id,
    )
    # Re-enter the link-waiting state only when execution failed and the
    # failure screen offered retry (handled inside _execute_play).


# ----------------------------------------------------------------------
# Handlers — DM group controls (dmc:<gid>:<action>)
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(r"^dmc:-?\d+:[a-z]+$"), F.message.chat.type == "private")
async def on_dm_control(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Playback controls for a group session, operated from the DM.

    Every action is permission-checked against the TARGET GROUP (never
    trusting the callback data as authorization): the pressing user must
    be allowed to perform the mapped action under the group's permission
    model. Stop targets only that group's session.
    """
    parts = str(callback.data).split(":")
    try:
        group_tg_id, action = int(parts[1]), parts[2]
    except (IndexError, ValueError):
        await safe_answer(callback, "❌ Invalid control.")
        return
    if action not in _DMC_ACTIONS:
        await safe_answer(callback, "❌ Invalid control.")
        return
    if action == "close":
        try:
            if callback.message is not None:
                await callback.message.delete()
        except Exception:  # noqa: BLE001
            if callback.message is not None:
                await edit_screen(callback.message, "✖️ Closed.", None)
        await safe_answer(callback, "Closed")
        return

    user_tg_id = int(callback.from_user.id)
    permission_action = _DMC_ACTIONS[action]
    allowed = False
    try:
        allowed = bool(
            await services.permissions.can(
                group_tg_id, user_tg_id, permission_action, is_chat_admin=False
            )
        )
    except Exception as exc:  # noqa: BLE001 — deny on errors
        logger.warning(
            "dm_play.control_permission_failed",
            extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
        )
    if not allowed:
        await safe_answer(
            callback, "❌ You don't have permission to control playback in that group.",
            show_alert=True,
        )
        return

    owner = QueueOwner(kind="group", id=group_tg_id)
    chat_id = callback.message.chat.id if callback.message else user_tg_id
    try:
        if action == "pause":
            await services.playback.pause(owner, callback.bot)
            await safe_answer(callback, "⏸ Paused")
        elif action == "resume":
            await services.playback.resume(owner, chat_id, callback.bot)
            await safe_answer(callback, "▶️ Resumed")
        elif action == "next":
            await services.playback.next(
                owner, chat_id, callback.bot, manual=True, skip=True
            )
            await safe_answer(callback, "⏭ Skipped")
        elif action == "stop":
            await services.playback.stop(owner, callback.bot)
            try:
                await services.voice.release(group_tg_id)
            except Exception as exc:  # noqa: BLE001 — controller released it
                logger.debug(
                    "dm_play.voice_release_failed",
                    extra=log_extra(error=str(exc)[:160]),
                )
            await safe_answer(callback, "🛑 Stopped")
            if callback.message is not None:
                await edit_screen(
                    callback.message, "🛑 <b>PLAYBACK STOPPED</b>", None
                )
            return
        elif action == "queue":
            await _render_group_queue(callback, services, owner)
            return
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return

    # Refresh the DM control screen with the live session state.
    await _render_status(callback, services, owner)


async def _render_status(
    callback: CallbackQuery, services: "ServiceContainer", owner: QueueOwner
) -> None:
    """Live Now-Playing status for the target group, rendered in the DM."""
    try:
        payload = await services.playback.now_playing(owner)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "dm_play.status_failed", extra=log_extra(error=str(exc)[:160])
        )
        payload = {}
    track = payload.get("track")
    if track is None or payload.get("status") not in ("playing", "paused"):
        text = "ℹ️ Nothing is playing in that group right now."
        await edit_screen(callback.message, text, _success_keyboard(owner.id))
        return
    paused = payload.get("status") == "paused"
    header = "⏸ <b>PAUSED</b>" if paused else "🎵 <b>NOW PLAYING IN THE GROUP</b>"
    text = now_playing_text(
        track,
        position=int(payload.get("position_seconds") or 0),
        paused=paused,
        session=PayloadBadges(payload),
        queue_size=int(payload.get("queue_size") or 0),
        header=header,
    )
    keyboard = _success_keyboard(owner.id)
    if paused:
        keyboard = _dm_keyboard(
            [
                [
                    InlineKeyboardButton(text="▶️ Resume", callback_data=f"dmc:{owner.id}:resume"),
                    InlineKeyboardButton(text="⏭️ Skip", callback_data=f"dmc:{owner.id}:next"),
                ],
                [
                    InlineKeyboardButton(text="📋 Queue", callback_data=f"dmc:{owner.id}:queue"),
                    InlineKeyboardButton(text="🛑 Stop", callback_data=f"dmc:{owner.id}:stop"),
                ],
                [InlineKeyboardButton(text="✖️ Close", callback_data="dm:close")],
            ]
        )
    await edit_screen(callback.message, text, keyboard)


async def _render_group_queue(
    callback: CallbackQuery, services: "ServiceContainer", owner: QueueOwner
) -> None:
    """The target group's queue, rendered in the DM (read-only + controls).

    Entries carry durations and the queue footer totals the time — matching
    the in-group queue view.
    """
    try:
        items = await services.queue.get_queue(owner)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "dm_play.queue_failed", extra=log_extra(error=str(exc)[:160])
        )
        items = []
    lines = [f"📋 <b>GROUP QUEUE</b> · {len(items)} upcoming", ""]
    durations: list[int | None] = []
    if not items:
        lines.append("ℹ️ The queue is empty.")
    else:
        lines.append("⏭ <b>Up next</b>")
    for offset, item in enumerate(items[:10], start=1):
        item_track = getattr(item, "track", None)
        if item_track is None:
            item_track = await services.music.get_track(item.track_id)
        title = getattr(item_track, "title", None) or f"Track #{item.track_id}"
        line = f"{offset}. 🎵 <b>{escape(truncate(title, 48))}</b>"
        artist = artist_name(item_track) if item_track is not None else ""
        if artist:
            line += f" — {escape(truncate(artist, 32))}"
        duration = int(getattr(item_track, "duration_seconds", 0) or 0) if item_track is not None else 0
        durations.append(duration or None)
        if duration > 0:
            line += f" · {format_duration(duration)}"
        lines.append(line)
    if len(items) > 10:
        lines.append(f"… and {len(items) - 10} more")
    if durations:
        lines.append("")
        lines.append(queue_total_line(durations))
    keyboard = _dm_keyboard(
        [
            [
                InlineKeyboardButton(text="⏭️ Skip", callback_data=f"dmc:{owner.id}:next"),
                InlineKeyboardButton(text="🛑 Stop", callback_data=f"dmc:{owner.id}:stop"),
            ],
            [InlineKeyboardButton(text="✖️ Close", callback_data="dm:close")],
        ]
    )
    await edit_screen(callback.message, "\n".join(lines), keyboard)
    await safe_answer(callback)


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)


__all__ = [
    "DM_OPERATION_TTL",
    "DmPlayFSM",
    "router",
    "register",
]

"""Playback session runtime state with per-owner duration timers.

Every state change is persisted through
:class:`~app.database.repositories.playback.PlaybackSessionRepository`; the
in-memory :class:`PlaybackSessionData` adds what cannot live in the
database: the running timer task, a monotonic "started at" stamp for
position tracking and a token that guards against stale timer callbacks.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from time import monotonic
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from app.database.repositories.playback import (
    SESSION_STATUSES,
    PlaybackSessionRepository,
)
from app.errors import ValidationError
from app.logging import get_logger, log_extra
from app.playback.events import EventBus
from app.playback.queue import QueueOwner

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models.music import Track
    from app.database.models.playback import PlaybackSession

logger = get_logger(__name__)

#: Allowed repeat modes (mirrors UserPreferences.repeat_mode).
REPEAT_MODES = ("off", "one", "all")


@runtime_checkable
class TrackProvider(Protocol):
    """Duck-typed TrackRepository surface used for payload hydration."""

    async def get_by_id(self, track_id: int) -> Track | None: ...


@dataclass(slots=True)
class PlaybackSessionData:
    """Runtime (non-persisted) state for one playback session."""

    session: PlaybackSession
    timer: asyncio.Task[None] | None = None
    timer_token: int = 0
    #: Monotonic timestamp the current track started playing at.
    started_at: float | None = None
    #: Position seconds accumulated before ``started_at`` (pause support).
    position_base: int = 0
    #: Extra runtime attributes (reserved for future controller state).
    extra: dict[str, Any] = field(default_factory=dict)


class SessionManager:
    """Owns playback sessions: persistence, position tracking and timers.

    One instance per process owns the runtime state: like the ORM identity
    map, the cached session model is authoritative only for this manager.
    All mutations must go through the same instance (the controller does).
    """

    def __init__(
        self,
        sessions: PlaybackSessionRepository,
        tracks: TrackProvider | None = None,
        events: EventBus | None = None,
    ) -> None:
        self._repo = sessions
        self._tracks = tracks
        self._events = events or EventBus()
        self._runtime: dict[str, PlaybackSessionData] = {}

    # ------------------------------------------------------------------
    # Session access
    # ------------------------------------------------------------------
    async def get(self, owner: QueueOwner) -> PlaybackSession:
        """Get (or create) the persisted session for an owner."""
        data = self._runtime.get(owner.topic())
        if data is None:
            data = await self._ensure_runtime(owner)
        return data.session

    async def is_genuinely_active(self, owner: QueueOwner) -> bool:
        """True only when THIS process can prove the session is live.

        A persisted ``playing``/``paused`` status is proof only when the
        runtime entry was established by actual playback in this process
        (a live timer task or a ``started_at`` stamp for *playing*, a
        paused position for *paused*). After a restart the persisted
        status survives while the voice session, the timers and the
        in-process bookkeeping do not — trusting it made ``/play`` silently
        queue behind a ghost session (production: ``queue.added`` with no
        pop, no join, no stream).

        First touch of a persisted-active session with no in-process
        evidence reconciles it to ``idle`` (an interrupted-by-restart
        state is not a playable state).
        """
        data = self._runtime.get(owner.topic())
        if data is None:
            try:
                session = await self.get(owner)
            except Exception:  # noqa: BLE001 — unprovable = not active
                logger.warning(
                    "session.liveness_probe_failed",
                    extra=log_extra(owner=owner.topic()),
                )
                return False
            if session.status not in ("playing", "paused"):
                return False
            logger.info(
                "session.stale_active_reconciled",
                extra=log_extra(
                    owner=owner.topic(),
                    status=session.status,
                    reason="no_runtime_evidence",
                ),
            )
            await self.update_status(owner, "idle")
            return False
        if data.session.status == "paused":
            # Paused in THIS process: a genuine, resumable state.
            return True
        if data.session.status == "playing":
            timer_live = data.timer is not None and not data.timer.done()
            return bool(timer_live or data.started_at is not None)
        return False

    async def reconcile_startup_states(self) -> int:
        """Park every persisted active session to ``idle`` (startup sweep).

        At process start nothing can be playing: the voice sessions, the
        timers and the runtime map are gone. Sessions left ``playing`` or
        ``paused`` by a previous (crashed or restarted) process are ghosts
        — the honest state is ``idle`` so ``/np`` renders READY, ``/play``
        starts immediately instead of queueing behind a ghost, and DM
        "play in group" reports the real outcome.

        Returns the number of sessions reconciled.
        """
        reconciled = 0
        try:
            stale = await self._repo.active_sessions()
        except Exception as exc:  # noqa: BLE001 — startup must not crash
            logger.warning(
                "session.reconcile_lookup_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
            return 0
        for session in stale:
            owner = self._owner_from_session(session)
            if owner is None:
                continue
            # Drop any runtime entry first so update_status cannot
            # resurrect evidence that does not exist.
            data = self._runtime.get(owner.topic())
            if data is not None:
                self._cancel_timer_task(data)
                self._runtime.pop(owner.topic(), None)
            try:
                await self._repo.update(
                    int(session.id), status="idle", position_seconds=0
                )
                reconciled += 1
                logger.info(
                    "session.reconciled_restart",
                    extra=log_extra(
                        owner=owner.topic(),
                        was_status=session.status,
                        track_id=session.current_track_id,
                    ),
                )
            except Exception as exc:  # noqa: BLE001 — best effort per row
                logger.warning(
                    "session.reconcile_write_failed",
                    extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
                )
        if reconciled:
            logger.info(
                "session.startup_reconciled", extra=log_extra(count=reconciled)
            )
        return reconciled

    def active_track_ids(self) -> set[int]:
        """Track ids of sessions this process is actually playing/pausing.

        Used by the download-cache cleanup to protect files that are in
        active use (a cached file older than the retention age must not
        disappear while its track is streaming).
        """
        ids: set[int] = set()
        for data in self._runtime.values():
            if data.session.status in ("playing", "paused") and (
                data.started_at is not None
                or (data.timer is not None and not data.timer.done())
                or data.session.status == "paused"
            ):
                track_id = data.session.current_track_id
                if track_id is not None:
                    ids.add(int(track_id))
        return ids

    async def set_now_playing(
        self,
        owner: QueueOwner,
        track_id: int,
        queue_item_id: int | None,
        message_id: int | None,
        chat_id: int | None,
    ) -> None:
        """Persist the now-playing track and restart position tracking."""
        session = await self._repo.set_now_playing(
            owner.kind,
            owner.id,
            track_id=int(track_id),
            queue_item_id=queue_item_id,
            message_id=message_id,
            chat_id=chat_id,
        )
        data = await self._ensure_runtime(owner)
        data.session = session
        data.position_base = 0
        data.started_at = monotonic()
        logger.info(
            "session.now_playing",
            extra=log_extra(
                owner=owner.topic(),
                track_id=track_id,
                message_id=message_id,
            ),
        )

    async def update_status(
        self,
        owner: QueueOwner,
        status: str,
        position_seconds: int | None = None,
    ) -> PlaybackSession:
        """Update the session status, freezing/resuming position tracking."""
        if status not in SESSION_STATUSES:
            raise ValidationError(f"Invalid playback status: {status!r}")
        data = await self._ensure_runtime(owner)
        if status == "paused":
            frozen = (
                position_seconds
                if position_seconds is not None
                else self._computed_position(data)
            )
            data.position_base = max(0, int(frozen))
            data.started_at = None
            persist_position: int | None = data.position_base
        else:
            if status == "playing" and data.started_at is None:
                data.started_at = monotonic()
            persist_position = (
                position_seconds
                if position_seconds is not None
                else self._computed_position(data)
            )
        data.session.status = status
        session = await self._repo.update_for_owner(
            owner.kind, owner.id, status=status, position_seconds=persist_position
        )
        if session is not None:
            data.session = session
        return data.session

    async def update(self, owner: QueueOwner, **fields: Any) -> PlaybackSession:
        """Update arbitrary whitelisted session fields (see repository)."""
        data = await self._ensure_runtime(owner)
        session = await self._repo.update_for_owner(owner.kind, owner.id, **fields)
        if session is not None:
            data.session = session
        else:
            for key, value in fields.items():
                setattr(data.session, key, value)
        return data.session

    # ------------------------------------------------------------------
    # Preference setters
    # ------------------------------------------------------------------
    async def set_repeat(self, owner: QueueOwner, mode: str) -> str:
        """Set repeat mode: off | one | all."""
        if mode not in REPEAT_MODES:
            raise ValidationError(
                f"repeat mode must be one of {REPEAT_MODES}, got {mode!r}"
            )
        await self.update(owner, repeat_mode=mode)
        return mode

    async def set_shuffle(self, owner: QueueOwner, enabled: bool) -> bool:
        """Enable/disable shuffle preference."""
        await self.update(owner, shuffle=bool(enabled))
        return bool(enabled)

    async def set_autoplay(self, owner: QueueOwner, enabled: bool) -> bool:
        """Enable/disable autoplay for this session."""
        await self.update(owner, autoplay=bool(enabled))
        return bool(enabled)

    async def set_volume(self, owner: QueueOwner, volume: int) -> int:
        """Persist the session volume (0-100, clamped)."""
        clamped = max(0, min(100, int(volume)))
        await self.update(owner, volume=clamped)
        return clamped

    # ------------------------------------------------------------------
    # Timers
    # ------------------------------------------------------------------
    async def start_timer(self, owner: QueueOwner, duration: int) -> None:
        """(Re)start the track-end timer for an owner.

        The timer sleeps ``duration`` seconds and then publishes
        ``track_end:<owner>``. A monotonic token guarantees that only the
        most recently started timer may fire (stale callbacks are ignored).
        """
        data = await self._ensure_runtime(owner)
        self._cancel_timer_task(data)
        data.timer_token += 1
        token = data.timer_token
        delay = float(duration) if duration and duration > 0 else 1.0
        data.timer = asyncio.create_task(
            self._timer_task(owner.topic(), token, delay),
            name=f"track-timer:{owner.topic()}",
        )
        logger.debug(
            "session.timer_started",
            extra=log_extra(owner=owner.topic(), duration=duration, token=token),
        )

    async def cancel_timer(self, owner: QueueOwner) -> None:
        """Cancel the running timer (if any) for an owner."""
        data = self._runtime.get(owner.topic())
        if data is None:
            return
        self._cancel_timer_task(data)

    async def cleanup(self) -> None:
        """Cancel every running timer (shutdown path)."""
        for data in self._runtime.values():
            self._cancel_timer_task(data)
        self._runtime.clear()
        logger.info("session.timers_cancelled")

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------
    async def position_seconds(self, owner: QueueOwner) -> int:
        """Current playback position (runtime tracking, pause-aware)."""
        data = await self._ensure_runtime(owner)
        return self._computed_position(data)

    async def message_payload(self, owner: QueueOwner) -> dict[str, Any]:
        """Everything the Now-Playing message and keyboards need."""
        session = await self.get(owner)
        track: Track | None = None
        if session.current_track_id is not None and self._tracks is not None:
            try:
                track = await self._tracks.get_by_id(int(session.current_track_id))
            except Exception as exc:  # noqa: BLE001 — duck-typed repo
                logger.debug(
                    "session.track_lookup_failed",
                    extra=log_extra(track_id=session.current_track_id, error=str(exc)[:160]),
                )
        return {
            "track": track,
            "position_seconds": await self.position_seconds(owner),
            "status": session.status,
            "repeat_mode": session.repeat_mode,
            "shuffle": session.shuffle,
            "autoplay": session.autoplay,
            "volume": session.volume,
            "now_playing_message_id": session.now_playing_message_id,
            "control_chat_id": session.control_chat_id,
            "queue_item_id": session.current_queue_item_id,
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    @staticmethod
    def _owner_from_session(session: PlaybackSession) -> QueueOwner | None:
        """Rebuild the owner from a session row (or None when unusable)."""
        kind = getattr(session, "session_type", None)
        if kind == "group":
            group_id = getattr(session, "group_id", None)
            if group_id:
                return QueueOwner(kind="group", id=int(group_id))
        elif kind == "personal":
            user_id = getattr(session, "user_id", None)
            if user_id:
                return QueueOwner(kind="user", id=int(user_id))
        return None

    async def _ensure_runtime(self, owner: QueueOwner) -> PlaybackSessionData:
        """Return the runtime entry for an owner, creating it if needed."""
        data = self._runtime.get(owner.topic())
        if data is not None:
            return data
        session = await self._repo.get_or_create(owner.kind, owner.id)
        data = PlaybackSessionData(
            session=session,
            position_base=int(session.position_seconds or 0),
            started_at=None,
        )
        self._runtime[owner.topic()] = data
        return data

    @staticmethod
    def _computed_position(data: PlaybackSessionData) -> int:
        if data.started_at is None:
            return max(0, int(data.position_base))
        elapsed = monotonic() - data.started_at
        return max(0, int(data.position_base + elapsed))

    @staticmethod
    def _cancel_timer_task(data: PlaybackSessionData) -> None:
        data.timer_token += 1
        task = data.timer
        data.timer = None
        if task is not None and not task.done():
            task.cancel()

    async def _timer_task(self, topic: str, token: int, delay: float) -> None:
        """Sleep, then publish ``track_end`` if still the current timer."""
        try:
            await asyncio.sleep(max(0.0, delay))
        except asyncio.CancelledError:
            raise
        data = self._runtime.get(topic)
        if data is None or data.timer_token != token:
            return  # superseded by a newer timer or cancel
        data.timer = None
        logger.info("session.track_end", extra=log_extra(owner=topic))
        try:
            await self._events.publish(f"track_end:{topic}")
        except Exception as exc:  # noqa: BLE001 — bus isolates failures
            logger.error(
                "session.track_end_publish_failed",
                extra=log_extra(owner=topic, error=str(exc)[:160]),
            )


__all__ = ["PlaybackSessionData", "SessionManager", "TrackProvider"]

"""Playback controller — the heart of the music bot.

Orchestrates the queue, session timers, autoplay, history and analytics for
both playback modes:

* **Personal** (private chat): the audio file is sent to the chat and an
  editable "Now Playing" control message carries the inline keyboard. A
  duration timer publishes ``track_end`` which auto-advances the queue.
* **Group** (voice chat): audio is played through the voice gateway; the
  same session timer drives auto-advance, and the control message is the
  single group Now Playing message.

Cross-task services (music, voice, history, analytics, settings) are
consumed through the local :class:`MusicGateway` / :class:`VoiceGateway` /
:class:`HistoryGateway` / :class:`AnalyticsRecorder` protocols so this
module never imports another task's implementation.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from time import monotonic
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from aiogram.types import FSInputFile
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.errors import (
    BotError,
    NothingPlayingError,
    PlaybackError,
    QueueEmptyError,
    TrackNotFoundError,
    ValidationError,
    VoiceError,
    VoiceUnavailableError,
)
from app.logging import get_logger, log_extra
from app.playback.events import Event, EventBus
from app.playback.queue import QueueManager, QueueOwner
from app.playback.session import SessionManager
from app.utils import now_playing_text, repeat_label

if TYPE_CHECKING:  # pragma: no cover - typing only
    from pathlib import Path

    from app.database.models.music import Track
    from app.playback.autoplay import AutoplayService

logger = get_logger(__name__)

#: Repeat modes accepted by :meth:`PlaybackController.set_repeat`.
REPEAT_MODES = ("off", "one", "all")

#: Minimum seconds between two automatic advances for one owner (guards
#: against duplicate ``track_end`` events firing from two timers).
AUTO_ADVANCE_THROTTLE_SECONDS = 0.9

QUEUE_FINISHED_TEXT = (
    "📋 <b>QUEUE FINISHED</b>\n\n"
    "Add more tracks, or turn on 🤖 autoplay to keep the music going."
)
QUEUE_FINISHED_REPEAT_TEXT = (
    "🔁 <b>QUEUE FINISHED</b>\n\n"
    "Repeat-all is on — send more tracks and I'll keep going."
)
STOPPED_TEXT = (
    "⏹ <b>PLAYBACK STOPPED</b>\n\n"
    "Your queue is kept — add a track to start again."
)


# ----------------------------------------------------------------------
# Cross-task protocols (duck typing — see CONTRACTS.md section 9)
# ----------------------------------------------------------------------
@runtime_checkable
class MusicGateway(Protocol):
    """What the controller needs from Task 2-a's MusicService."""

    async def get_track(self, track_id: int) -> Track | None: ...

    async def get_playable_path(self, track: Track) -> Path: ...

    async def ensure_audio_file_id(self, track: Track, bot: Any) -> str | None: ...


@runtime_checkable
class VoiceGateway(Protocol):
    """What the controller needs from Task 2-c's VoiceManager."""

    async def play(self, group_tg_id: int, path: Path) -> None: ...

    async def pause(self, group_tg_id: int) -> None: ...

    async def resume(self, group_tg_id: int) -> None: ...

    async def stop(self, group_tg_id: int) -> None: ...

    async def release(self, group_tg_id: int) -> None: ...

    async def set_volume(self, group_tg_id: int, volume: int) -> None: ...

    async def is_voice_enabled(self) -> bool: ...


@runtime_checkable
class HistoryGateway(Protocol):
    """What the controller needs from Task 2-e's HistoryService."""

    async def record(
        self,
        user_tg_id: int | None,
        track_id: int,
        *,
        context: str,
        group_id: int | None = None,
        completed: bool = False,
        skipped: bool = False,
        duration_played: int = 0,
    ) -> None: ...


@runtime_checkable
class AnalyticsRecorder(Protocol):
    """What the controller needs from Task 2-e's AnalyticsRepository."""

    async def track(
        self,
        event_type: str,
        user_id: int | None = None,
        group_id: int | None = None,
        track_id: int | None = None,
        payload: dict | None = None,
    ) -> None: ...


def _artist_name(track: Any) -> str:
    """Best-effort artist name (detached ORM instances may fail to lazy-load)."""
    try:
        artist = track.artist
    except Exception:  # noqa: BLE001 — DetachedInstanceError etc.
        return ""
    return getattr(artist, "name", None) or ""


class PlaybackController:
    """Unified playback control for personal and group sessions."""

    def __init__(
        self,
        queue: QueueManager,
        autoplay: AutoplayService,
        music: MusicGateway,
        voice: VoiceGateway,
        sessions: SessionManager,
        events: EventBus,
        analytics: AnalyticsRecorder,
        history: HistoryGateway,
        autoplay_enabled: Callable[[], Awaitable[bool]] | None = None,
        *,
        default_autoplay: bool = True,
    ) -> None:
        self._queue = queue
        self._autoplay = autoplay
        self._music = music
        self._voice = voice
        self._sessions = sessions
        self._events = events
        self._analytics = analytics
        self._history = history
        self._autoplay_enabled = autoplay_enabled
        self._default_autoplay = bool(default_autoplay)

        # Runtime wiring state (owner topic -> value).
        self._ctx: dict[str, tuple[int, Any]] = {}
        self._current_user: dict[str, int | None] = {}
        self._pending_queue_item: dict[str, int | None] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._last_auto_advance: dict[str, float] = {}
        #: Set once :meth:`cleanup` runs (shutdown): no further automatic
        #: advances, refills or auto-advance failure notifications — a
        #: shutdown must not schedule NEW background playback work.
        self._closing = False

        # Auto-advance on track_end (personal timers and group timers).
        self._events.subscribe("track_end", self._on_track_end)

    # ==================================================================
    # Personal + group: start playing a specific track
    # ==================================================================
    async def play_now(
        self,
        owner: QueueOwner,
        chat_id: int,
        bot: Any,
        track_id: int,
        user_tg_id: int,
        *,
        edit_message: Any = None,
    ) -> None:
        """Start playing ``track_id`` for the owner right now."""
        topic = owner.topic()
        self._remember(owner, chat_id, bot)

        track = await self._music.get_track(int(track_id))
        if track is None:
            raise TrackNotFoundError(f"track {track_id} not found")
        if not getattr(track, "is_playable", True):
            raise PlaybackError(f"track {track_id} is not playable")

        self._current_user[topic] = int(user_tg_id) if user_tg_id else None
        queue_item_id = self._pending_queue_item.pop(topic, None)

        if owner.kind == "group":
            message_id = await self._start_group(
                owner, chat_id, bot, track, edit_message=edit_message
            )
        else:
            message_id = await self._start_personal(
                owner, chat_id, bot, track, edit_message=edit_message
            )

        await self._sessions.set_now_playing(
            owner, track.id, queue_item_id, message_id, chat_id
        )

        duration = int(getattr(track, "duration_seconds", 0) or 0)
        await self._sessions.start_timer(owner, duration if duration > 0 else 1)

        is_group = owner.kind == "group"
        if self._current_user.get(topic):
            try:
                await self._history.record(
                    self._current_user[topic],
                    track.id,
                    context="group" if is_group else "personal",
                    group_id=owner.id if is_group else None,
                )
            except Exception as exc:  # noqa: BLE001 — history is best effort
                logger.warning(
                    "playback.history_failed",
                    extra=log_extra(owner=topic, error=str(exc)[:160]),
                )

        await self._track_event(
            "group_play" if is_group else "track_play",
            owner,
            track.id,
            user_id=self._current_user.get(topic),
            payload={"source": getattr(track, "source", None)},
        )
        await self._events.publish(
            f"track_start:{topic}",
            track_id=track.id,
            owner_kind=owner.kind,
            owner_id=owner.id,
        )
        logger.info(
            "playback.started",
            extra=log_extra(
                owner=topic,
                track_id=track.id,
                duration=duration,
                mode=owner.kind,
            ),
        )

    async def _start_personal(
        self,
        owner: QueueOwner,
        chat_id: int,
        bot: Any,
        track: Track,
        *,
        edit_message: Any = None,
    ) -> int | None:
        """Personal mode: send the audio file, then the control message."""
        if bot is None:
            raise PlaybackError("no bot instance available for personal playback")

        artist_name = _artist_name(track)
        if track.audio_file_id:
            await bot.send_audio(chat_id, audio=track.audio_file_id)
        else:
            path = await self._music.get_playable_path(track)
            await bot.send_audio(
                chat_id,
                audio=FSInputFile(str(path)),
                title=(track.title or "")[:64] or None,
                performer=(artist_name or "")[:64] or None,
                duration=int(track.duration_seconds or 0) or None,
            )
            # Cache the Telegram file_id for fast re-sends (best effort).
            try:
                await self._music.ensure_audio_file_id(track, bot)
            except Exception as exc:  # noqa: BLE001 — cache must not break playback
                logger.debug(
                    "playback.file_id_cache_failed",
                    extra=log_extra(track_id=track.id, error=str(exc)[:160]),
                )

        session = await self._sessions.get(owner)
        text = now_playing_text(
            track, position=0, paused=False, session=session,
            queue_size=await self._queue.size(owner),
        )
        message_id = await self._upsert_control(
            owner, chat_id, bot, text,
            self._player_keyboard(
                paused=False, group=False,
                shuffle=bool(getattr(session, "shuffle", False)),
                repeat_mode=str(getattr(session, "repeat_mode", "off") or "off"),
                autoplay=bool(getattr(session, "autoplay", False)),
            ),
            edit_message=edit_message,
        )
        return message_id

    async def _start_group(
        self,
        owner: QueueOwner,
        chat_id: int,
        bot: Any,
        track: Track,
        *,
        edit_message: Any = None,
    ) -> int | None:
        """Group mode: play through the voice gateway, then control message.

        Raises :class:`BotError` (with its ``user_message``) when playback
        cannot start — voice engine unavailable, download/stream failure,
        join failure. Callers surface the error on their own message
        surface (the group status message, the DM screen, the control
        message for automatic advances): a queue entry, a resolved URL or
        an attempted join is never proof of playback.
        """
        if not await self._voice_enabled():
            raise VoiceUnavailableError("voice engine is not configured")
        try:
            path = await self._music.get_playable_path(track)
            await self._voice.play(owner.id, path)
        except BotError as exc:
            logger.warning(
                "playback.group_play_failed",
                extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
            )
            raise

        session = await self._sessions.get(owner)
        text = now_playing_text(
            track, position=0, paused=False, session=session,
            queue_size=await self._queue.size(owner),
        )
        message_id = await self._upsert_control(
            owner, chat_id, bot, text,
            self._player_keyboard(
                paused=False, group=True,
                shuffle=bool(getattr(session, "shuffle", False)),
                repeat_mode=str(getattr(session, "repeat_mode", "off") or "off"),
                volume=int(getattr(session, "volume", 100) or 100),
                autoplay=bool(getattr(session, "autoplay", False)),
            ),
            edit_message=edit_message,
        )
        return message_id

    # ==================================================================
    # Queue advancement
    # ==================================================================
    async def next(
        self,
        owner: QueueOwner,
        chat_id: int,
        bot: Any,
        *,
        manual: bool = True,
        skip: bool = False,
    ) -> None:
        """Advance to the next queued track (or autoplay/finish).

        **Stale-advance guard (skip racing a pending natural advance):**
        the session's current track is captured BEFORE acquiring the
        per-owner lock.  When another advance (natural track-end or an
        earlier skip) delivered a NEW track while this call waited on the
        lock, the captured and post-lock tracks differ — this call is stale
        (the track the user acted on is already gone) and returns without
        advancing a second time.  Without the guard, a skip pressed while a
        natural advance was mid-download used to wait for the lock and then
        advance AGAIN — replaying a duplicate recommendation and restarting
        the just-started track (observed in production: the same track
        played twice back-to-back).
        """
        topic = owner.topic()
        try:
            pre_lock_track = (
                await self._sessions.get(owner)
            ).current_track_id
        except Exception:  # noqa: BLE001 — session lookups must not block skips
            pre_lock_track = None
        async with self._lock(topic):
            try:
                post_lock_track = (
                    await self._sessions.get(owner)
                ).current_track_id
            except Exception:  # noqa: BLE001
                post_lock_track = None
            if (
                pre_lock_track is not None
                and post_lock_track is not None
                and pre_lock_track != post_lock_track
            ):
                logger.info(
                    "playback.stale_advance_dropped",
                    extra=log_extra(
                        owner=topic,
                        was_track=pre_lock_track,
                        now_track=post_lock_track,
                        manual=manual,
                    ),
                )
                return
            await self._advance(owner, chat_id, bot, manual=manual, skip=skip)

    async def _advance(
        self,
        owner: QueueOwner,
        chat_id: int,
        bot: Any,
        *,
        manual: bool,
        skip: bool,
    ) -> None:
        topic = owner.topic()
        is_group = owner.kind == "group"

        if not manual:
            # Throttle duplicate track_end events (personal + voice timers).
            last = self._last_auto_advance.get(topic)
            now = monotonic()
            if last is not None and (now - last) < AUTO_ADVANCE_THROTTLE_SECONDS:
                logger.debug(
                    "playback.duplicate_track_end",
                    extra=log_extra(owner=topic),
                )
                return
            self._last_auto_advance[topic] = now

        session = await self._sessions.get(owner)
        current_track_id = session.current_track_id
        current_user = self._current_user.get(topic)

        # 1. Record the skip for the outgoing track.
        if current_track_id is not None and skip:
            position = await self._sessions.position_seconds(owner)
            if current_user:
                try:
                    await self._history.record(
                        current_user,
                        current_track_id,
                        context="group" if is_group else "personal",
                        group_id=owner.id if is_group else None,
                        skipped=True,
                        duration_played=position,
                    )
                except Exception as exc:  # noqa: BLE001
                    logger.warning(
                        "playback.skip_history_failed",
                        extra=log_extra(owner=topic, error=str(exc)[:160]),
                    )
            await self._track_event(
                "track_skip", owner, current_track_id, user_id=current_user
            )
        await self._sessions.cancel_timer(owner)

        # 2. Repeat-one replays the current track immediately.
        if current_track_id is not None and session.repeat_mode == "one":
            self._pending_queue_item[topic] = session.current_queue_item_id
            try:
                await self.play_now(
                    owner, chat_id, bot, current_track_id, current_user or 0
                )
            except BotError as exc:
                if manual:
                    raise
                # Automatic repeat replay failed: park idle and report —
                # the current track stays current (no requeue needed).
                logger.warning(
                    "playback.auto_advance_failed",
                    extra=log_extra(
                        owner=topic, track_id=current_track_id, error=str(exc)[:160]
                    ),
                )
                await self._sessions.update_status(owner, "idle")
                await self._notify_error(bot, owner, chat_id, exc.user_message)
            finally:
                self._pending_queue_item.pop(topic, None)
            return

        # 3. Pop the next queued item.
        item = await self._queue.pop_next(owner)

        # 4. Queue ran dry — try autoplay before giving up.
        if item is None and current_track_id is not None:
            autoplay_on = bool(session.autoplay) and await self._autoplay_allowed()
            if autoplay_on and not self._closing:
                try:
                    added = await self._autoplay.refill(
                        owner, current_track_id, count=1
                    )
                except Exception as exc:  # noqa: BLE001 — autoplay is best effort
                    logger.warning(
                        "playback.autoplay_failed",
                        extra=log_extra(owner=topic, error=str(exc)[:160]),
                    )
                    added = 0
                if added:
                    item = await self._queue.pop_next(owner)

        # 5. Nothing left to play.
        if item is None:
            await self._sessions.update_status(owner, "idle")
            if current_track_id is None and manual:
                raise QueueEmptyError()
            await self._notify_finished(
                owner, chat_id, bot, repeat_mode=session.repeat_mode
            )
            await self._events.publish(f"queue_empty:{topic}")
            return

        # 6. Play the next item.
        requester = item.added_by or current_user
        self._current_user[topic] = requester
        self._pending_queue_item[topic] = item.id
        try:
            await self.play_now(owner, chat_id, bot, item.track_id, requester or 0)
        except BotError as exc:
            # The track failed to START: restore it to the queue head so
            # it is neither silently lost (network outage production case:
            # popped tracks 25 and 23 vanished) nor duplicated.
            await self._queue.requeue_front(
                owner, item.track_id, added_by=item.added_by
            )
            if manual:
                raise  # manual paths surface errors through their handlers
            # Automatic advance failed (download/stream): report it on the
            # control message instead of silently stalling the session —
            # then park the session idle so the state is honest.
            logger.warning(
                "playback.auto_advance_failed",
                extra=log_extra(owner=topic, track_id=item.track_id, error=str(exc)[:160]),
            )
            await self._sessions.update_status(owner, "idle")
            await self._notify_error(bot, owner, chat_id, exc.user_message)
            return
        finally:
            self._pending_queue_item.pop(topic, None)

    # ==================================================================
    # Transport controls
    # ==================================================================
    async def pause(self, owner: QueueOwner, bot: Any) -> None:
        """Pause playback (timer stops so autoplay will not advance)."""
        session = await self._sessions.get(owner)
        if session.current_track_id is None:
            raise NothingPlayingError()
        if session.status == "paused":
            return
        if session.status != "playing":
            raise NothingPlayingError("playback is not active")

        position = await self._sessions.position_seconds(owner)
        if owner.kind == "group":
            await self._voice.pause(owner.id)  # VoiceError propagates

        await self._sessions.cancel_timer(owner)
        await self._sessions.update_status(owner, "paused", position_seconds=position)
        payload = await self._sessions.message_payload(owner)
        await self._edit_control(
            bot,
            owner,
            now_playing_text(
                payload.get("track"),
                position=position,
                paused=True,
                session=session,
                queue_size=await self._queue.size(owner),
            ),
            self._player_keyboard(
                paused=True, group=owner.kind == "group",
                shuffle=bool(getattr(session, "shuffle", False)),
                repeat_mode=str(getattr(session, "repeat_mode", "off") or "off"),
                volume=int(getattr(session, "volume", 100) or 100),
                autoplay=bool(getattr(session, "autoplay", False)),
            ),
        )
        await self._track_event("track_pause", owner, session.current_track_id)
        logger.info(
            "playback.paused",
            extra=log_extra(owner=owner.topic(), position=position),
        )

    async def resume(self, owner: QueueOwner, chat_id: int, bot: Any) -> None:
        """Resume paused playback with the remaining time."""
        session = await self._sessions.get(owner)
        if session.current_track_id is None:
            raise NothingPlayingError()
        if session.status != "paused":
            return

        payload = await self._sessions.message_payload(owner)
        track = payload.get("track")
        if track is None and session.current_track_id is not None:
            track = await self._music.get_track(int(session.current_track_id))
        if track is None:
            raise TrackNotFoundError("current track is no longer available")

        duration = int(getattr(track, "duration_seconds", 0) or 0)
        position = int(payload.get("position_seconds") or 0)
        remaining = max(1, duration - position) if duration > 0 else 1

        if owner.kind == "group":
            await self._voice.resume(owner.id)  # VoiceError propagates

        await self._sessions.update_status(owner, "playing")
        await self._sessions.start_timer(owner, remaining)
        await self._edit_control(
            bot,
            owner,
            now_playing_text(
                track,
                position=position,
                paused=False,
                session=session,
                queue_size=await self._queue.size(owner),
            ),
            self._player_keyboard(
                paused=False, group=owner.kind == "group",
                shuffle=bool(getattr(session, "shuffle", False)),
                repeat_mode=str(getattr(session, "repeat_mode", "off") or "off"),
                volume=int(getattr(session, "volume", 100) or 100),
                autoplay=bool(getattr(session, "autoplay", False)),
            ),
        )
        await self._track_event("track_resume", owner, track.id)
        logger.info(
            "playback.resumed",
            extra=log_extra(owner=owner.topic(), remaining=remaining),
        )

    async def stop(self, owner: QueueOwner, bot: Any) -> None:
        """Stop playback (queue is kept) and park the session in idle."""
        await self._sessions.cancel_timer(owner)
        if owner.kind == "group":
            for label, call in (
                ("stop", lambda: self._voice.stop(owner.id)),
                ("release", lambda: self._voice.release(owner.id)),
            ):
                try:
                    await call()
                except VoiceError as exc:
                    logger.warning(
                        "playback.group_stop_failed",
                        extra=log_extra(owner=owner.topic(), step=label, error=str(exc)[:160]),
                    )
        await self._sessions.update(
            owner,
            status="idle",
            current_track_id=None,
            current_queue_item_id=None,
            position_seconds=0,
        )
        await self._edit_control(bot, owner, STOPPED_TEXT, None)
        self._current_user.pop(owner.topic(), None)
        logger.info("playback.stopped", extra=log_extra(owner=owner.topic()))

    # ==================================================================
    # Enqueue
    # ==================================================================
    async def enqueue(
        self,
        owner: QueueOwner,
        chat_id: int,
        bot: Any,
        track_id: int,
        user_tg_id: int,
        *,
        edit_message: Any = None,
    ) -> int:
        """Add a track to the queue; starts playback when idle.

        Returns the number of tracks now waiting in the queue. When the
        queue is idle and playback starts immediately, *edit_message* (a
        transient status message such as the group "⬇️ Loading track…"
        acknowledgement) is edited into the Now Playing control — one
        message carries the whole request instead of a silent multi-second
        gap followed by a second message.

        The idle gate is the honest liveness probe
        (:meth:`SessionManager.is_genuinely_active`): a session left
        "playing" by a previous process is a ghost — this process has no
        timer, no voice session and no bookkeeping for it, so the new
        track starts immediately instead of queueing behind nothing
        (production: ``queue.added`` with no pop/join/stream).

        When the just-popped track fails to START (download/stream/join
        error) it is requeued at the head — a failed start is not a
        played track, and silently discarding it lost user requests
        during network outages. The ``BotError`` then propagates so the
        calling handler surfaces the reason on its status message.
        """
        self._remember(owner, chat_id, bot)

        track = await self._music.get_track(int(track_id))
        if track is None:
            raise TrackNotFoundError(f"track {track_id} not found")
        if not getattr(track, "is_playable", True):
            raise PlaybackError(f"track {track_id} is not playable")

        size = await self._queue.add(owner, track.id, added_by=int(user_tg_id))
        await self._track_event(
            "queue_add",
            owner,
            track.id,
            user_id=int(user_tg_id),
            payload={"size": size},
        )

        if not await self._sessions.is_genuinely_active(owner):
            item = await self._queue.pop_next(owner)
            if item is not None:
                requester = item.added_by or int(user_tg_id)
                self._pending_queue_item[owner.topic()] = item.id
                try:
                    await self.play_now(
                        owner, chat_id, bot, item.track_id, requester,
                        edit_message=edit_message,
                    )
                except BotError:
                    # The track never started: restore it to the queue
                    # head (no silent loss) and let the caller surface
                    # the exact reason on its status message.
                    await self._queue.requeue_front(
                        owner, item.track_id, added_by=item.added_by
                    )
                    raise
                finally:
                    self._pending_queue_item.pop(owner.topic(), None)
                size = await self._queue.size(owner)
        return size

    # ==================================================================
    # Introspection + preferences
    # ==================================================================
    async def now_playing(self, owner: QueueOwner) -> dict[str, Any]:
        """Payload describing the current playback state (for keyboards)."""
        payload = await self._sessions.message_payload(owner)
        payload["queue_size"] = await self._queue.size(owner)
        payload["owner_kind"] = owner.kind
        payload["owner_id"] = owner.id
        return payload

    async def is_active(self, owner: QueueOwner) -> bool:
        """Honest activity probe (liveness, not the persisted status).

        Used by enqueue-side gates (group ``/play``, DM "play in group")
        to decide whether a new track queues behind real playback or
        starts right away. See :meth:`SessionManager.is_genuinely_active`.
        """
        return await self._sessions.is_genuinely_active(owner)

    async def reconcile_after_restart(self) -> int:
        """Park ghost sessions left active by a previous process.

        Called once during application startup; see
        :meth:`SessionManager.reconcile_startup_states`.
        """
        return await self._sessions.reconcile_startup_states()

    def protected_track_ids(self) -> set[int]:
        """Track ids whose cached files must survive download cleanup."""
        return self._sessions.active_track_ids()

    async def set_repeat(self, owner: QueueOwner, mode: str) -> str:
        """Set repeat mode: off | one | all."""
        if mode not in REPEAT_MODES:
            raise ValidationError(
                f"repeat mode must be one of {REPEAT_MODES}, got {mode!r}"
            )
        await self._sessions.set_repeat(owner, mode)
        logger.info("playback.repeat_set", extra=log_extra(owner=owner.topic(), mode=mode))
        return mode

    async def set_shuffle(self, owner: QueueOwner, enabled: bool) -> bool:
        """Toggle shuffle; enabling it reshuffles the upcoming queue."""
        enabled = bool(enabled)
        await self._sessions.set_shuffle(owner, enabled)
        if enabled:
            size = await self._queue.size(owner)
            if size > 1:
                await self._queue.shuffle(owner)
        logger.info(
            "playback.shuffle_set",
            extra=log_extra(owner=owner.topic(), enabled=enabled),
        )
        return enabled

    async def set_autoplay(self, owner: QueueOwner, enabled: bool) -> bool:
        """Toggle autoplay for this session (owner-level override)."""
        enabled = bool(enabled)
        await self._sessions.set_autoplay(owner, enabled)
        logger.info(
            "playback.autoplay_set",
            extra=log_extra(owner=owner.topic(), enabled=enabled),
        )
        return enabled

    async def set_volume(self, owner: QueueOwner, volume: int) -> int:
        """Persist volume (0-100); groups additionally set it on the voice engine."""
        clamped = await self._sessions.set_volume(owner, int(volume))
        if owner.kind == "group":
            try:
                await self._voice.set_volume(owner.id, clamped)
            except VoiceError as exc:
                logger.warning(
                    "playback.volume_failed",
                    extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
                )
        logger.info(
            "playback.volume_set",
            extra=log_extra(owner=owner.topic(), volume=clamped),
        )
        return clamped

    async def cleanup(self) -> None:
        """Cancel all session timers and stop automatic advancement.

        Sets the closing flag first so in-flight advances stop BEFORE any
        recommendation refill or auto-advance failure notification — a
        shutdown must never schedule NEW background playback work (the
        production log showed a recommendation being served mid-shutdown).
        """
        self._closing = True
        await self._sessions.cleanup()

    # ==================================================================
    # Event handling
    # ==================================================================
    async def _on_track_end(self, event: Event) -> None:
        """Auto-advance on ``track_end:<kind>:<id>`` events."""
        if self._closing:
            logger.debug(
                "playback.track_end_ignored_closing",
                extra=log_extra(name=event.name),
            )
            return
        try:
            _, kind, raw_id = event.name.split(":", 2)
            owner = QueueOwner(kind=kind, id=int(raw_id))
        except (ValueError, IndexError, ValidationError):
            logger.debug("playback.bad_track_end", extra=log_extra(name=event.name))
            return

        chat_id, bot = self._ctx.get(owner.topic(), (0, None))
        if bot is None:
            if owner.kind == "user":
                # No bot reference (process restarted) — the user can tap
                # "next" manually; we cannot send audio without a bot.
                logger.info(
                    "playback.auto_advance_skipped",
                    extra=log_extra(owner=owner.topic(), reason="no_bot"),
                )
                return
            # Groups can continue through the voice engine without editing.
        try:
            await self.next(owner, chat_id, bot, manual=False, skip=False)
        except Exception as exc:  # noqa: BLE001 — timers must never crash
            logger.error(
                "playback.auto_advance_failed",
                extra=log_extra(owner=owner.topic(), error=str(exc)[:200]),
            )
            if not self._closing:
                try:
                    await self._sessions.update_status(owner, "idle")
                    await self._notify_error(
                        bot,
                        owner,
                        chat_id,
                        "⚠️ Playback stopped — the next track failed to start.",
                    )
                except Exception:  # noqa: BLE001 — shutdown-time best effort
                    pass

    # ==================================================================
    # Message helpers
    # ==================================================================
    async def _upsert_control(
        self,
        owner: QueueOwner,
        chat_id: int,
        bot: Any,
        text: str,
        keyboard: Any,
        *,
        edit_message: Any = None,
    ) -> int | None:
        """Edit the control message in place, or send a fresh one.

        Priority: explicit ``edit_message`` → stored control message →
        new message. Returns the control message id (or None).
        """
        if edit_message is not None and hasattr(edit_message, "edit_text"):
            try:
                await edit_message.edit_text(
                    text, parse_mode="HTML", reply_markup=keyboard
                )
                message_id = getattr(edit_message, "message_id", None)
                if message_id:
                    return int(message_id)
            except Exception as exc:  # noqa: BLE001 — editing is best effort
                logger.debug(
                    "playback.control_edit_failed",
                    extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
                )

        session = await self._sessions.get(owner)
        if (
            bot is not None
            and session.control_chat_id
            and session.now_playing_message_id
        ):
            try:
                await bot.edit_message_text(
                    text,
                    chat_id=session.control_chat_id,
                    message_id=session.now_playing_message_id,
                    parse_mode="HTML",
                    reply_markup=keyboard,
                )
                return int(session.now_playing_message_id)
            except Exception as exc:  # noqa: BLE001
                logger.debug(
                    "playback.control_edit_failed",
                    extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
                )

        if bot is not None:
            try:
                message = await bot.send_message(
                    chat_id, text, parse_mode="HTML", reply_markup=keyboard
                )
                message_id = getattr(message, "message_id", None)
                if message_id:
                    return int(message_id)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "playback.control_send_failed",
                    extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
                )
        return None

    async def _edit_control(
        self, bot: Any, owner: QueueOwner, text: str, keyboard: Any = None
    ) -> None:
        """Edit the stored control message; every failure is swallowed."""
        if bot is None:
            return
        session = await self._sessions.get(owner)
        if not session.control_chat_id or not session.now_playing_message_id:
            return
        try:
            await bot.edit_message_text(
                text,
                chat_id=session.control_chat_id,
                message_id=session.now_playing_message_id,
                parse_mode="HTML",
                reply_markup=keyboard,
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "playback.control_edit_failed",
                extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
            )

    async def _notify_error(
        self,
        bot: Any,
        owner: QueueOwner,
        chat_id: int,
        text: str,
        *,
        edit_message: Any = None,
    ) -> None:
        """Surface a playback error through the control message.

        When a transient *edit_message* is available (the group status
        message that already told the user "Searching… → Loading track…"),
        it becomes the error surface: one message tells the whole story and
        the chat gets no extra noise. Otherwise the stored control message
        is edited and a fresh notification is sent as before.
        """
        if edit_message is not None and hasattr(edit_message, "edit_text"):
            try:
                await edit_message.edit_text(text, parse_mode="HTML")
                return
            except Exception as exc:  # noqa: BLE001 — fall through to control message
                logger.debug(
                    "playback.error_edit_failed",
                    extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
                )
        await self._edit_control(bot, owner, text, None)
        if bot is None or not chat_id:
            return
        try:
            await bot.send_message(chat_id, text, parse_mode="HTML")
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "playback.error_notify_failed",
                extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
            )

    async def _notify_finished(
        self,
        owner: QueueOwner,
        chat_id: int,
        bot: Any,
        *,
        repeat_mode: str,
    ) -> None:
        """Show the queue-finished state on the control message."""
        text = QUEUE_FINISHED_REPEAT_TEXT if repeat_mode == "all" else QUEUE_FINISHED_TEXT
        await self._edit_control(bot, owner, text, None)
        if bot is None or not chat_id:
            return
        session = await self._sessions.get(owner)
        if session.control_chat_id and session.now_playing_message_id:
            return  # already edited above
        try:
            await bot.send_message(chat_id, text, parse_mode="HTML")
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "playback.finish_notify_failed",
                extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
            )

    # ==================================================================
    # Rendering
    # ==================================================================
    def _now_playing_text(
        self,
        track: Track | None,
        *,
        position: int,
        paused: bool,
        session: Any,
        queue_size: int,
    ) -> str:
        """Render the Now Playing / Paused message body (HTML).

        Thin delegation to the ONE shared renderer
        (:func:`app.utils.now_playing_text`) — the personal player, the
        group control message and the dashboard screen used to keep three
        drifting copies of this layout.
        """
        return now_playing_text(
            track,
            position=position,
            paused=paused,
            session=session,
            queue_size=queue_size,
        )

    @staticmethod
    def _player_keyboard(
        *,
        paused: bool,
        group: bool = False,
        shuffle: bool = False,
        repeat_mode: str = "off",
        volume: int | None = None,
        autoplay: bool = False,
    ) -> Any:
        """Inline keyboard for the Now Playing control message.

        Personal sessions use the ``np:`` namespace (user-scoped handlers);
        GROUP sessions must use the ``grp:`` namespace — those callbacks are
        resolved against the message's own group chat and permission-checked
        per group. Emitting ``np:`` buttons on a group control message used
        to route Pause/Skip to the *pressing user's personal* session — a
        wrong-target button bug — and is regression-locked in tests.

        Buttons are STATEFUL (shuffle / repeat / autoplay show their current
        mode on the label — the pattern leading music bots converge on), and
        the group panel carries volume steps (``grp:vol:dn|up``) plus the
        dedicated 🤖 Autoplay ON/OFF toggle (``grp:auto``).

        **Layout (mobile-first, no clipped labels):** transport actions pair
        in two-button rows; the three stateful toggles (Shuffle / Repeat /
        Autoplay) take FULL-WIDTH rows so their labels never truncate on
        narrow screens (production screenshots showed "Shuffle: Of…" and
        "Repeat: Of…" clipped in two-column rows).
        """
        builder = InlineKeyboardBuilder()
        if group:
            builder.button(
                text="▶️ Resume" if paused else "⏸️ Pause",
                callback_data="grp:resume" if paused else "grp:pause",
            )
            builder.button(text="⏭️ Skip", callback_data="grp:skip")
            builder.button(
                text=(f"🔉 Vol − {max(0, (volume if isinstance(volume, int) else 100) - 25)}"),
                callback_data="grp:vol:dn",
            )
            builder.button(
                text=(f"🔊 Vol + {min(200, (volume if isinstance(volume, int) else 100) + 25)}"),
                callback_data="grp:vol:up",
            )
            builder.button(
                text=f"🔀 Shuffle: {'On' if shuffle else 'Off'}",
                callback_data="grp:shuf",
            )
            builder.button(
                text=f"🔁 Repeat: {repeat_label(repeat_mode)}",
                callback_data="grp:rep",
            )
            builder.button(text="📋 Queue", callback_data="grp:queue")
            builder.button(text="🛑 Stop", callback_data="grp:stop")
            builder.button(
                text=f"🤖 Autoplay: {'ON' if autoplay else 'OFF'}",
                callback_data="grp:auto",
            )
            builder.adjust(2, 2, 1, 1, 2, 1)
            return builder.as_markup()
        builder.button(
            text="▶️ Resume" if paused else "⏸ Pause",
            callback_data="np:resume" if paused else "np:pause",
        )
        builder.button(text="⏭ Next", callback_data="np:next")
        builder.button(text="⏮ Prev", callback_data="np:prev")
        builder.button(text="❤️ Like", callback_data="np:like")
        builder.button(
            text=f"🔀 Shuffle: {'On' if shuffle else 'Off'}",
            callback_data="np:shuf",
        )
        builder.button(
            text=f"🔁 Repeat: {repeat_label(repeat_mode)}",
            callback_data="np:rep",
        )
        builder.button(text="📋 Queue", callback_data="np:queue")
        builder.button(text="✖️ Close", callback_data="np:close")
        builder.adjust(2, 2, 1, 1, 2)
        return builder.as_markup()

    # ==================================================================
    # Small helpers
    # ==================================================================
    def _remember(self, owner: QueueOwner, chat_id: int, bot: Any) -> None:
        """Store the bot + chat context used by timer-driven auto-advance."""
        if chat_id and bot is not None:
            self._ctx[owner.topic()] = (int(chat_id), bot)

    def _lock(self, topic: str) -> asyncio.Lock:
        """Per-owner lock serializing advance operations."""
        lock = self._locks.get(topic)
        if lock is None:
            lock = asyncio.Lock()
            self._locks[topic] = lock
        return lock

    async def _autoplay_allowed(self) -> bool:
        """Global autoplay flag (injected callable) with a config default."""
        if self._autoplay_enabled is None:
            return self._default_autoplay
        try:
            return bool(await self._autoplay_enabled())
        except Exception as exc:  # noqa: BLE001 — flag failures fall back
            logger.warning(
                "playback.autoplay_check_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
            return self._default_autoplay

    async def _voice_enabled(self) -> bool:
        """Duck-typed check whether the voice engine is configured."""
        check = getattr(self._voice, "is_voice_enabled", None)
        if check is None:
            return True
        try:
            return bool(await check())
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "playback.voice_check_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
            return False

    async def _track_event(
        self,
        event_type: str,
        owner: QueueOwner,
        track_id: int | None,
        *,
        user_id: int | None = None,
        payload: dict | None = None,
    ) -> None:
        """Record an analytics event (best effort)."""
        try:
            await self._analytics.track(
                event_type,
                user_id=user_id,
                group_id=owner.id if owner.kind == "group" else None,
                track_id=track_id,
                payload=payload or {},
            )
        except Exception as exc:  # noqa: BLE001 — analytics must not break playback
            logger.debug(
                "playback.analytics_failed",
                extra=log_extra(event=event_type, error=str(exc)[:160]),
            )


__all__ = [
    "AnalyticsRecorder",
    "HistoryGateway",
    "MusicGateway",
    "PlaybackController",
    "VoiceGateway",
]

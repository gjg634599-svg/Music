"""Default seeded content for bot_messages / bot_settings / bot_buttons.

Everything an admin can customize at runtime lives in the database; these
constants are inserted once at first startup (idempotent) so a fresh
installation works out of the box.
"""

from __future__ import annotations

from typing import Any

# ----------------------------------------------------------------------
# Message templates. Placeholders: {name} {username} {bot_name}
# ----------------------------------------------------------------------
DEFAULT_MESSAGES: dict[str, str] = {
    "start": (
        "🎵 <b>MUSIC BOT</b>\n\n"
        "Your personal Telegram music assistant.\n"
        "Search • Play • Discover\n\n"
        "👋 Hi {name}! Quick start:\n"
        "1️⃣ Send me a song or artist name\n"
        "2️⃣ Tap a result to see its options\n"
        "3️⃣ Press ▶️ Play — here, or in a group voice chat\n\n"
        "🎧 I remember what you like and keep the music going."
    ),
    "help": (
        "ℹ️ <b>HOW IT WORKS</b>\n\n"
        "🎵 <b>Personal mode</b> — chat with me directly:\n"
        "• Send a song/artist name to search\n"
        "• Send an audio file to add it to your library\n"
        "• Send a link from a supported source\n\n"
        "👥 <b>Group mode</b> — add me to a group:\n"
        "• /play &lt;song&gt; — play in the voice chat\n"
        "• /new — browse new releases, tap to queue\n"
        "• /queue, /skip, /pause, /resume, /stop\n\n"
        "🤖 <b>Autoplay</b> — when your queue runs dry I keep "
        "the music going based on what you like."
    ),
    "about": "🎵 MUSIC BOT\nA Telegram-native music platform.\nPersonal library • Autoplay • Group voice chats.",
    "commands": (
        "📜 <b>COMMANDS</b>\n\n"
        "<b>Personal</b>\n"
        "/start — dashboard\n"
        "/search — search music\n"
        "/playlists — your playlists\n"
        "/liked — liked songs\n"
        "/new — new releases\n"
        "/history — recently played\n"
        "/mystats — your listening stats\n"
        "/settings — preferences\n"
        "/commands — this list\n"
        "/group — add me to a group\n"
        "/help — help\n\n"
        "<b>Group</b>\n"
        "/play &lt;song&gt; (or /p) • /search • /new\n"
        "/queue (or /q) • /nowplaying (or /np)\n"
        "/skip (or /next) • /pause • /resume\n"
        "/stop • /shuffle • /repeat\n"
        "/volume &lt;0-200&gt; • /settings • /help\n\n"
        "💡 The ▶ Pause / Skip / Shuffle / Repeat buttons live right on "
        "the Now Playing message — no command needed."
    ),
    "group_help": (
        "🎵 <b>GROUP MUSIC</b>\n\n"
        "/play &lt;song&gt; (or /p) — play a track in the voice chat\n"
        "/new — browse new releases, tap to queue\n"
        "/queue (or /q) — show the queue\n"
        "/skip (or /next) — skip the current track\n"
        "/pause /resume — control playback\n"
        "/stop — stop and leave the voice chat\n"
        "/settings — group music settings\n\n"
        "💡 The ▶ Pause / Skip / Shuffle / Repeat / Volume buttons live on "
        "the Now Playing message."
    ),
    "error_generic": "❌ Something went wrong. Please try again.",
    "error_track_unavailable": (
        "❌ Couldn't play this track.\n\nThe requested track is currently unavailable."
    ),
    "error_voice_missing": (
        "🎙️ No active voice chat found.\n\nStart a group voice chat first, then use /play."
    ),
    "error_no_results": (
        "🔎 No results found.\n\n"
        "Try a different spelling, fewer words, or an artist name — "
        "then tap Search Again."
    ),
    "empty_queue": (
        "📋 The queue is empty.\n\n"
        "Search for a song and press Play — I'll keep the music going "
        "with autoplay."
    ),
    "maintenance": "🚧 <b>MUSIC BOT IS UNDER MAINTENANCE</b>\n\nPlease try again later.",
    "added_to_library": "✅ Added to your library.",
    "track_added": "➕ Added to queue: {title}",
    "download_ready": "⬇️ Here's your track:",
    "search_prompt": (
        "🔎 <b>SEARCH MUSIC</b>\n\n"
        "Send me the song or artist name.\n\n"
        "💡 Try a title, an artist, or a few words you remember."
    ),
    "search_slow": (
        "🥹 Babby, I'm trying hard!\n\n"
        "Some music sources are taking longer than usual."
    ),
}

# ----------------------------------------------------------------------
# Bot settings (JSON values).
# ----------------------------------------------------------------------
DEFAULT_SETTINGS: dict[str, Any] = {
    "recommendation_weights": {
        "track_similarity": 1.0,
        "artist_similarity": 1.5,
        "genre_similarity": 1.2,
        "user_preference": 2.0,
        "popularity": 0.6,
        "playlist_context": 0.8,
        "recently_played_penalty": 2.5,
        "skipped_track_penalty": 1.8,
        "same_track_penalty": 6.0,
    },
    "recommendation_options": {
        "candidate_limit": 200,
        "min_score": 0.1,
    },
    "autoplay": {
        "enabled": True,
        "count": 1,
    },
    "broadcast": {
        "rate_per_second": 25,
        "worker_concurrency": 2,
        "max_retries": 3,
    },
    "maintenance": {
        "enabled": False,
        "groups_continue": False,
    },
    "features": {
        "mention_mode": False,
        "url_processing": True,
    },
}

# ----------------------------------------------------------------------
# Start-screen buttons. action keys map to internal callback actions.
# Known callback actions: dash:search, dash:np, dash:queue, dash:library,
# dash:playlists, dash:history, dash:stats, dash:settings, dash:account,
# dash:help, dash:commands
# ----------------------------------------------------------------------
DEFAULT_BUTTONS: list[dict[str, Any]] = [
    {"label": "🎵 Search Music", "action": "dash:search", "button_type": "callback", "position": 10},
    {"label": "🎧 Now Playing", "action": "dash:np", "button_type": "callback", "position": 15},
    {"label": "📋 Queue", "action": "dash:queue", "button_type": "callback", "position": 25},
    {"label": "❤️ My Library", "action": "dash:library", "button_type": "callback", "position": 30},
    {"label": "🎼 Playlists", "action": "dash:playlists", "button_type": "callback", "position": 35},
    {"label": "🕘 History", "action": "dash:history", "button_type": "callback", "position": 40},
    {"label": "📊 My Stats", "action": "dash:stats", "button_type": "callback", "position": 45},
    {"label": "👤 My Account", "action": "dash:account", "button_type": "callback", "position": 50},
    {"label": "⚙️ Settings", "action": "dash:settings", "button_type": "callback", "position": 60},
    {"label": "➕ Add Me to Group", "action": "add_group", "button_type": "add_group", "position": 70},
    {"label": "ℹ️ Help", "action": "dash:help", "button_type": "callback", "position": 80},
    {"label": "📜 Commands", "action": "dash:commands", "button_type": "callback", "position": 90},
    {"label": "ℹ️ About", "action": "dash:about", "button_type": "callback", "position": 95},
]

SETTING_DESCRIPTIONS: dict[str, str] = {
    "recommendation_weights": "Recommendation engine scoring weights",
    "recommendation_options": "Recommendation engine options",
    "autoplay": "Autoplay defaults",
    "broadcast": "Broadcast engine limits",
    "maintenance": "Global maintenance mode",
    "features": "Feature flags",
}

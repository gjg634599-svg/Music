"""Music service — the facade every handler/worker talks to.

Covers the whole lifecycle of a track inside the bot: multi-source search
(with catalog persistence), URL resolution (authorized sources + direct
audio files), upload registration, playable-path acquisition (downloading
on demand), Telegram ``file_id`` caching and similarity search.

Error taxonomy (see ``app.errors``): ``ValidationError`` from URL SSRF
checks, ``UnauthorizedSourceError`` for known DRM sources,
``UnsupportedUrlError`` for anything unresolvable, ``DownloadError`` /
``FileTooLargeError`` during media acquisition.
"""

from __future__ import annotations

import asyncio
import hashlib
import uuid
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlparse

import aiohttp
from sqlalchemy.orm.exc import DetachedInstanceError

from app.cache.redis import CacheProtocol
from app.config import Settings
from app.database.models.music import Track
from app.database.repositories.music import TrackRepository
from app.errors import (
    BotError,
    DownloadError,
    InvalidAudioError,
    MusicSourceError,
    UnsupportedUrlError,
)
from app.logging import get_logger, log_extra
from app.music.metadata import MetadataService
from app.music.models import AudioMetadata, TrackResult
from app.music.resolver import TrackResolver
from app.music.search import SearchAggregator
from app.music.sources.base import MusicSource
from app.music.sources.url_resolver import (
    raise_for_unsupported_host,
    resolve_direct_audio,
    stream_download,
)
from app.playback.events import EventBus
from app.security.validation import sanitize_filename, validate_url
from app.storage import StorageService

logger = get_logger(__name__)

#: Read chunk size when hashing uploaded files.
_HASH_CHUNK = 1024 * 1024

#: Maximum number of characters of a query stored in analytics payloads.
_ANALYTICS_QUERY_LIMIT = 128

#: Hard cap on stored stream URLs (matches the ORM column size).
_MAX_URL = 1024


def _is_legacy_duplicate(track: Track) -> bool:
    """Whether *track* is a legacy ``source='local'`` duplicate row.

    Rows created by an older ``LocalSource`` carry ``source='local'``, no
    media of their own (no file, no stream URL, no cached Telegram file
    id) and a numeric ``source_id`` equal to the primary key of the row
    they duplicated. They are still playable (through the legacy healing
    in :meth:`MusicService.get_playable_path`) but should not be listed
    twice in catalog browsing.
    """
    if (track.source or "") != "local":
        return False
    if track.file_path or track.stream_url or track.audio_file_id:
        return False
    sid = str(track.source_id or "")
    if not sid.isdigit() or not sid:
        return False
    return int(sid) != int(track.id)


class AnalyticsTracker(Protocol):
    """Duck-typed analytics repository (owned by the users/groups task)."""

    async def track(
        self,
        event_type: str,
        user_id: int | None = None,
        group_id: int | None = None,
        track_id: int | None = None,
        payload: dict[str, Any] | None = None,
    ) -> None: ...  # pragma: no cover — protocol shape only


class MusicService:
    """High-level music operations (search / resolve / upload / fetch)."""

    def __init__(
        self,
        sources: list[MusicSource],
        aggregator: SearchAggregator,
        resolver: TrackResolver,
        tracks: TrackRepository,
        metadata: MetadataService,
        storage: StorageService,
        cache: CacheProtocol,
        events: EventBus,
        analytics: AnalyticsTracker | None = None,
        settings: Settings | None = None,
        http: aiohttp.ClientSession | None = None,
    ) -> None:
        self._sources = sources
        self._aggregator = aggregator
        self._resolver = resolver
        self._tracks = tracks
        self._metadata = metadata
        self._storage = storage
        self._cache = cache
        self._events = events
        self._analytics = analytics
        # settings/http may also be borrowed from the first source when the
        # composition root does not pass them explicitly.
        self._settings = settings or (sources[0].settings if sources else None)
        self._http = http or (sources[0].http if sources else None)
        # Per-track download mutexes: guarantee at most one in-flight download
        # per track id and make concurrent requests reuse the first result.
        self._download_locks: dict[int, asyncio.Lock] = {}

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------
    async def search(
        self,
        query: str,
        limit: int = 10,
        *,
        on_progress: "Callable[[str, str, int], None] | None" = None,
    ) -> list[Track]:
        """Aggregate a multi-source search and persist every result.

        Returns catalog rows (already upserted by the resolver), best
        matches first. Individual resolve failures are logged and skipped
        so one bad source result cannot fail the whole search.
        ``on_progress`` (optional) is forwarded to the aggregator and is
        invoked as ``on_progress(source_name, status, count)``.
        """
        results = await self._aggregator.search(query, limit=limit, on_progress=on_progress)
        tracks: list[Track] = []
        for result in results:
            try:
                tracks.append(await self._resolver.resolve(result))
            except Exception as exc:  # noqa: BLE001 — isolate single-result errors
                logger.warning(
                    "music.service.resolve_failed",
                    extra=log_extra(
                        source=result.source, source_id=result.source_id[:64],
                        error=str(exc)[:200],
                    ),
                )
        await self._track_analytics(
            "search", payload={"query": query[:_ANALYTICS_QUERY_LIMIT], "results": len(tracks)}
        )
        logger.info(
            "music.service.search",
            extra=log_extra(query=query[:_ANALYTICS_QUERY_LIMIT], resolved=len(tracks)),
        )
        return tracks

    async def get_track(self, track_id: int) -> Track | None:
        """Fetch a catalog track by id."""
        return await self._tracks.get(track_id)

    async def new_releases(
        self, *, limit: int = 10, offset: int = 0
    ) -> tuple[list[Track], int]:
        """Browse the newest playable tracks (``created_at`` DESC).

        Returns ``(tracks, total)`` where *total* is the number of playable
        catalog tracks (for pagination math). Browsing never contacts
        external sources — it reads the local catalog only.

        Legacy duplicate rows (``source='local'``, no media of their own,
        ``source_id`` pointing at the row they duplicated) are filtered in
        Python — they duplicate another catalog entry's title and would
        show the same song twice. They remain playable through the
        legacy-healing path in :meth:`get_playable_path`.
        """
        limit = max(1, min(int(limit), 100))
        offset = max(0, int(offset))
        rows = await self._tracks.recent(limit=limit, offset=offset)
        tracks = [row for row in rows if not _is_legacy_duplicate(row)]
        total = await self._tracks.count_playable()
        logger.info(
            "music.service.new_releases",
            extra=log_extra(
                limit=limit, offset=offset, total=total,
                legacy_filtered=len(rows) - len(tracks),
            ),
        )
        return tracks, total

    # ------------------------------------------------------------------
    # URL resolution
    # ------------------------------------------------------------------
    async def resolve_url(self, url: str) -> Track:
        """Resolve a user-submitted URL into a catalog track.

        Order: SSRF validation (``ValidationError`` bubbles up so handlers
        can map it), known-unsupported host check (Spotify/YouTube/...
        raise ``UnauthorizedSourceError``), authorized source resolvers
        (Jamendo / Audius permalinks), direct audio file download, and
        finally ``UnsupportedUrlError``.
        """
        url = (url or "").strip()
        safe_url = await asyncio.to_thread(validate_url, url)
        raise_for_unsupported_host(safe_url)

        for source in self._sources:
            if not source.is_configured():
                continue
            try:
                result = await source.resolve_url(safe_url)
            except MusicSourceError as exc:
                logger.warning(
                    "music.service.url_source_failed",
                    extra=log_extra(source=source.name, error=str(exc)[:200]),
                )
                continue
            if result is not None:
                track = await self._resolver.resolve(result)
                await self._publish_registered(track, context="url")
                return track

        direct = await self._resolve_direct(safe_url)
        if direct is not None:
            track = await self._resolver.resolve(direct)
            await self._publish_registered(track, context="url")
            return track

        host = urlparse(safe_url).hostname or safe_url
        raise UnsupportedUrlError(f"No handler for URL from {host}")

    # ------------------------------------------------------------------
    # Uploads
    # ------------------------------------------------------------------
    async def register_upload(
        self,
        tg_user_id: int,
        file_path: str,
        file_name: str,
        meta: AudioMetadata | None = None,
    ) -> Track:
        """Register a user-uploaded audio file into the catalog.

        The file is moved into the storage ``music/`` directory under a
        sanitized unique name, metadata is probed (ffprobe) with the
        caller-provided ``meta`` taking precedence, and missing
        title/artist fields are filled from the ``"Artist - Title.ext"``
        filename pattern. The source id is the SHA-256 of the file bytes
        (first 32 hex chars) so re-uploading the same file dedupes.
        """
        source = Path(file_path)
        if not source.is_file():
            raise DownloadError(f"Uploaded file missing: {source}")

        safe_name = sanitize_filename(file_name or source.name)
        stored = self._storage.save(f"music/{self._storage.unique_name(safe_name)}", source)
        relative = str(stored.relative_to(self._storage.root))

        probed = await self._probe_metadata(stored)
        if meta is None and not probed.duration_seconds:
            # Neither caller tags nor probeable content — reject politely.
            self._storage.delete(f"music/{stored.name}")
            raise InvalidAudioError(f"Unrecognized audio content: {safe_name}")
        title, artist, album, genre, language, tempo = self._merge_meta(
            meta or AudioMetadata(), probed, safe_name
        )
        duration = (meta.duration_seconds if meta else 0) or probed.duration_seconds or 0
        if not title:
            title = Path(safe_name).stem.strip()[:256] or "Unknown upload"

        digest = await self._hash_file(stored)
        result = TrackResult(
            title=title,
            artist=artist,
            album=album,
            duration_seconds=duration,
            source="upload",
            source_id=digest[:32],
            stream_url=None,
            artwork_url=None,
            genre=genre,
            language=language,
            tempo=tempo,
            extra={
                "file_path": relative,
                "uploaded_by": str(tg_user_id),
                "original_name": safe_name,
            },
        )
        track = await self._resolver.resolve(result)
        await self._publish_registered(track, context="upload")
        await self._track_analytics(
            "upload", user_id=tg_user_id, track_id=track.id, payload={"source": "upload"}
        )
        logger.info(
            "music.service.upload_registered",
            extra=log_extra(track_id=track.id, user=str(tg_user_id), path=relative),
        )
        return track

    # ------------------------------------------------------------------
    # Playable files
    # ------------------------------------------------------------------
    async def get_playable_path(self, track: Track) -> Path:
        """Return an ABSOLUTE local path to the track's audio, downloading if needed.

        Resolution order:

        1. Existing local file (storage-relative ``file_path`` or a legacy
           absolute path) — validated for existence, non-zero size and a
           recognizable audio header.
        2. ``track.stream_url`` (e.g. Jamendo direct-audio URLs captured at
           search time).
        3. The owning source's ``get_stream()`` endpoint (e.g. Audius)
           when no URL is stored — this is what connects Audius search
           results (``stream_url=None`` by design) to actual playback.
        4. One re-resolution retry when a *stored* URL fails to download
           (signed/expiring CDN links) before giving up.

        Downloads are serialized per track id, written to a unique temporary
        file and atomically renamed into place, so concurrent requests can
        never observe a half-written file. The returned path is always an
        absolute :class:`~pathlib.Path` (the playback layer and py-tgcalls
        require a real filesystem path, not a storage-relative string).

        Raises:
            DownloadError: No local file, no resolvable stream URL, or the
                download failed (including after the re-resolution retry).
            FileTooLargeError: The remote file exceeds the size cap.
            InvalidAudioError: The downloaded content is empty or not
                recognizable audio (HTML error pages, images, ...).
        """
        cached = self._existing_local_path(track)
        if cached is not None:
            return cached

        if self._settings is None or self._http is None:
            raise MusicSourceError("MusicService has no HTTP session configured")

        lock = self._download_locks.setdefault(int(track.id), asyncio.Lock())
        async with lock:
            # Re-check after acquiring: a concurrent caller may have finished
            # the very same download while we were waiting on the lock.
            cached = self._existing_local_path(track)
            if cached is not None:
                return cached

            url = track.stream_url
            if not url:
                url = await self._resolve_fresh_stream_url(track)
            if not url:
                # A local-source answer may have just healed ``file_path``
                # onto this row (the ``is_local`` branch persists it and
                # returns None) — re-check the local fast path BEFORE
                # failing, otherwise a resolvable local answer would be
                # reported as an unresolvable track.
                healed = self._existing_local_path(track)
                if healed is not None:
                    return healed
                raise DownloadError(
                    f"Track {track.id} has neither a local file nor a resolvable "
                    f"stream URL (source={track.source!r})"
                )

            try:
                target = await self._download_to_cache(track, url)
            except BotError as first_error:
                # Stored (and freshly resolved) stream URLs can expire —
                # ask the owning source for a new one and retry exactly once.
                fresh = await self._resolve_fresh_stream_url(track)
                if not fresh or fresh == url:
                    raise
                logger.warning(
                    "music.service.stream_expired_retry",
                    extra=log_extra(
                        track_id=track.id,
                        source=track.source,
                        error=str(first_error)[:160],
                    ),
                )
                url = fresh
                target = await self._download_to_cache(track, url)

            relative = str(target.relative_to(self._storage.root))
            track.file_path = relative
            try:
                await self._tracks.update(track.id, file_path=relative)
            except Exception as exc:  # noqa: BLE001 — bookkeeping must not break playback
                logger.warning(
                    "music.service.file_path_write_failed",
                    extra=log_extra(track_id=track.id, error=str(exc)[:160]),
                )
            logger.info(
                "music.service.downloaded",
                extra=log_extra(track_id=track.id, path=relative),
            )
            return target

    async def resolve_stream_url(self, track: Track) -> str | None:
        """Return a playable stream URL for *track*, resolving via ``get_stream()``.

        Public wrapper around the source-backed resolution used before
        playback: returns the stored ``stream_url`` when present, otherwise
        asks the owning configured source (Audius / Jamendo / local) for a
        fresh one and persists it on the catalog row. ``None`` when the
        track cannot produce any remote stream (local-file tracks).
        """
        if track.stream_url:
            return track.stream_url
        return await self._resolve_fresh_stream_url(track)

    async def _resolve_fresh_stream_url(self, track: Track) -> str | None:
        """Ask the owning source for a stream URL; persist and return it.

        Sources like Audius intentionally map search results with
        ``stream_url=None`` (their search payload carries no media URL) —
        the playable URL only exists behind ``get_stream(source_id)``.
        This is the bridge that connects those providers to playback.

        Resolution order:

        1. The track's **own** provider adapter (matched by
           ``track.source``), using its provider-specific
           ``track.source_id`` (never the database primary key).
        2. Legacy duplicate healing — old ``source='local'`` rows whose
           ``source_id`` points at the original catalog row are resolved
           through the ORIGINAL row's provider, and the result is
           persisted on both rows so the duplicate self-heals.
        """
        url = await self._resolve_provider_stream(
            track, track.source, str(track.source_id or "")
        )
        if url is not None:
            return url
        return await self._resolve_legacy_duplicate(track)

    async def _resolve_provider_stream(
        self, track: Track, source_name: str, source_id: str
    ) -> str | None:
        """Resolve a stream via the provider adapter named *source_name*.

        ``track`` is the row any resolved URL / local file is persisted on;
        ``source_name`` / ``source_id`` select the adapter and the
        provider-specific id it is asked (they belong to the track's true
        provider, which for legacy duplicates is the ORIGINAL row's).
        """
        for source in self._sources:
            if source.name != source_name or not source.is_configured():
                continue
            try:
                info = await source.get_stream(source_id)
            except MusicSourceError as exc:
                logger.warning(
                    "music.service.stream_resolve_failed",
                    extra=log_extra(
                        track_id=track.id,
                        source=source_name,
                        error=str(exc)[:160],
                    ),
                )
                return None
            if info is None:
                return None
            if info.is_local:
                # Local sources may answer with a storage-relative file path.
                if self._storage.exists(info.url_or_path):
                    await self._persist_file_path(
                        track, info.url_or_path, source="local-stream"
                    )
                    return None  # the caller's local-file fast path now hits
                return None
            url = str(info.url_or_path)
            if not url:
                return None
            track.stream_url = url[:_MAX_URL]
            try:
                await self._tracks.update(track.id, stream_url=url[:_MAX_URL])
            except Exception as exc:  # noqa: BLE001 — persistence is best-effort
                logger.warning(
                    "music.service.stream_url_write_failed",
                    extra=log_extra(track_id=track.id, error=str(exc)[:160]),
                )
            logger.info(
                "music.service.stream_resolved",
                extra=log_extra(
                    track_id=track.id,
                    source=source_name,
                    host=(urlparse(url).hostname or "")[:128],
                ),
            )
            return url
        return None

    async def _resolve_legacy_duplicate(self, track: Track) -> str | None:
        """Resolve a legacy ``source='local'`` duplicate via its original.

        Rows created by an older ``LocalSource`` carry ``source='local'``
        and a ``source_id`` equal to the PRIMARY KEY of the row they
        duplicated. When the local adapter could not produce anything,
        follow that pointer: resolve the original row through ITS provider
        adapter and persist the result on **both** rows, so the duplicate
        becomes directly playable after the first successful resolution
        (self-healing legacy data without a destructive migration).

        Returns the resolved remote URL (``None`` when this row is not a
        legacy duplicate or the original cannot be resolved either — the
        original's local file is copied onto the duplicate instead, which
        the caller picks up through its local-file re-check).
        """
        if (track.source or "") != "local":
            return None
        sid = str(track.source_id or "")
        if not sid.isdigit() or int(sid) == int(track.id):
            return None
        try:
            original = await self._tracks.get(int(sid))
        except Exception as exc:  # noqa: BLE001 — original lookup is best-effort
            logger.debug(
                "music.service.legacy_lookup_failed",
                extra=log_extra(track_id=track.id, error=str(exc)[:160]),
            )
            return None
        if original is None or original.id == track.id:
            return None
        if (original.source or "local") == "local":
            return None  # original is itself a plain local row

        url = await self._resolve_provider_stream(
            original, original.source, str(original.source_id or "")
        )
        if url is not None:
            # Self-heal the duplicate row so its next playback is direct.
            track.stream_url = url[:_MAX_URL]
            try:
                await self._tracks.update(track.id, stream_url=url[:_MAX_URL])
            except Exception as exc:  # noqa: BLE001 — best-effort healing
                logger.warning(
                    "music.service.legacy_heal_failed",
                    extra=log_extra(track_id=track.id, error=str(exc)[:160]),
                )
            logger.info(
                "music.service.legacy_duplicate_healed",
                extra=log_extra(
                    track_id=track.id, original_id=original.id, source=original.source
                ),
            )
            return url

        # Original resolves remotely only later / not at all — but if it
        # already HAS a local file, the duplicate can play it right now.
        if original.file_path and self._storage.exists(original.file_path):
            await self._persist_file_path(
                track, original.file_path, source="legacy-local"
            )
            logger.info(
                "music.service.legacy_duplicate_healed",
                extra=log_extra(
                    track_id=track.id, original_id=original.id, source="local-file"
                ),
            )
        return None

    async def _persist_file_path(
        self, track: Track, relative: str, *, source: str
    ) -> None:
        """Best-effort persistence of a resolved local file path."""
        track.file_path = relative
        try:
            await self._tracks.update(track.id, file_path=relative)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "music.service.file_path_write_failed",
                extra=log_extra(track_id=track.id, error=str(exc)[:160]),
            )

    def _existing_local_path(self, track: Track) -> Path | None:
        """Validated local file for *track* (``None`` when unusable).

        A file is usable when it exists, has a non-zero size and starts with
        a recognizable audio header. Broken/empty cached files are logged
        and treated as "needs re-download" instead of failing playback with
        a cryptic py-tgcalls/Telegram error later.
        """
        if not track.file_path:
            return None
        candidate: Path | None = None
        if self._storage.exists(track.file_path):
            try:
                candidate = self._storage.resolve(track.file_path)
            except Exception:  # noqa: BLE001 — treat as unusable
                candidate = None
        if candidate is None:
            absolute = Path(track.file_path)
            if absolute.is_absolute() and absolute.is_file():
                candidate = absolute  # legacy / externally-managed path
        if candidate is None:
            return None
        try:
            _validate_audio_file(candidate)
        except InvalidAudioError as exc:
            logger.warning(
                "music.service.local_file_invalid",
                extra=log_extra(
                    track_id=track.id, path=candidate.name, error=str(exc)[:160]
                ),
            )
            return None
        return candidate

    async def _download_to_cache(self, track: Track, url: str) -> Path:
        """Download *url* into the downloads cache and return the absolute path.

        The payload is streamed into a unique temporary file and atomically
        renamed into the final ``downloads/track-<id><ext>`` name, so:

        * concurrent downloads of the same track never interleave writes;
        * readers only ever see complete files (old or new);
        * a failed/invalid download never replaces a previously good file.
        """
        assert self._settings is not None and self._http is not None
        try:
            safe_url = await asyncio.to_thread(validate_url, url)
        except Exception as exc:  # noqa: BLE001 — ValidationError / UnsupportedUrlError
            raise DownloadError(f"Stream URL rejected: {exc}") from exc

        extension = Path(urlparse(safe_url).path).suffix.lower()
        if not extension or len(extension) > 6:
            extension = ".mp3"
        final = self._storage.downloads_dir() / sanitize_filename(
            f"track-{track.id}{extension}"
        )
        # A previously cached, still-valid file short-circuits the download.
        try:
            _validate_audio_file(final)
            return final
        except InvalidAudioError:
            pass

        temp = final.with_name(f".{final.name}.{uuid.uuid4().hex[:12]}.part")
        timeout = aiohttp.ClientTimeout(total=max(60, self._settings.http_timeout * 3))
        # Voice-chat streaming cap: this file is played LOCALLY through
        # ffmpeg/PyTgCalls and never re-uploaded through the Bot API, so the
        # relevant bound is disk usage (VOICE_MAX_AUDIO_SIZE_MB, default
        # 200 MB) — not Telegram's 50 MB upload limit. Long DJ mixes
        # (45+ MiB) used to abort group playback here with a misleading
        # "Telegram upload limit" error.
        voice_cap_mb = getattr(self._settings, "voice_max_audio_size_mb", None)
        if isinstance(voice_cap_mb, int) and voice_cap_mb > 0:
            max_bytes = voice_cap_mb * 1024 * 1024
        else:  # duck-typed settings without the voice cap
            max_bytes = self._settings.max_audio_size_mb * 1024 * 1024
        try:
            await stream_download(
                safe_url, self._http, timeout, temp, max_bytes, streaming=True
            )
            # Content validation BEFORE the atomic rename: empty payloads or
            # non-audio bodies (HTML error pages served with HTTP 200, ...
            # images) must never reach the voice pipeline.
            _validate_audio_file(temp)
            temp.replace(final)
        finally:
            # Remove the partial file whatever happened (after a successful
            # rename this is a no-op — the name no longer exists).
            try:
                temp.unlink(missing_ok=True)
            except OSError:  # pragma: no cover — best effort
                pass
        return final

    async def ensure_audio_file_id(
        self,
        track: Track,
        bot: Any = None,
        sent_message: Any = None,
    ) -> str | None:
        """Return the cached Telegram ``file_id`` for *track*, if known.

        Telegram has **no** server-side "upload without sending" API, so a
        file_id can only be captured from a message that was *actually
        sent* to some chat. This method therefore:

        1. returns ``track.audio_file_id`` immediately when cached;
        2. otherwise, when the caller passes ``sent_message`` (a
           ``aiogram.types.Message`` that was just sent by the playback
           layer and carries ``.audio``), records
           ``sent_message.audio.file_id`` via the track repository and
           returns it;
        3. otherwise returns ``None`` — the caller should send the audio
           (its own UX decision, e.g. personal playback already sends the
           file) and call this method again with the sent message.

        ``bot`` is accepted for signature compatibility with the service
        contract but intentionally never used to send anything — this
        method must never spam any chat.
        """
        if track.audio_file_id:
            return track.audio_file_id
        audio = getattr(sent_message, "audio", None) if sent_message is not None else None
        file_id = getattr(audio, "file_id", None) if audio is not None else None
        if not file_id:
            return None
        updated = await self._tracks.update(track.id, audio_file_id=str(file_id))
        track.audio_file_id = str(file_id)
        logger.info(
            "music.service.file_id_cached",
            extra=log_extra(track_id=track.id),
        )
        return updated.audio_file_id if updated is not None else str(file_id)

    # ------------------------------------------------------------------
    # Similarity
    # ------------------------------------------------------------------
    async def find_similar(self, track: Track, limit: int = 20) -> list[Track]:
        """Find tracks similar to *track* (autoplay / recommendations feed).

        Strategy in order: same artist, shared genres, popular tracks,
        random tracks. The seed track itself is always excluded.
        """
        limit = max(1, min(int(limit), 50))
        results: list[Track] = []
        seen: set[int] = {track.id}

        if track.artist_id is not None:
            for candidate in await self._tracks.by_artist(track.artist_id, limit=limit):
                if candidate.id not in seen:
                    results.append(candidate)
                    seen.add(candidate.id)

        if len(results) < limit:
            genre_ids = self._track_genre_ids(track)
            if genre_ids:
                for candidate in await self._tracks.by_genres(genre_ids, limit=limit):
                    if candidate.id not in seen:
                        results.append(candidate)
                        seen.add(candidate.id)

        if len(results) < limit:
            for candidate in await self._tracks.popular(limit=limit):
                if candidate.id not in seen:
                    results.append(candidate)
                    seen.add(candidate.id)

        if len(results) < limit:
            for candidate in await self._tracks.random(limit, list(seen)):
                if candidate.id not in seen:
                    results.append(candidate)
                    seen.add(candidate.id)

        return results[:limit]

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _resolve_direct(self, url: str) -> TrackResult | None:
        """Try to treat the URL as a direct audio file (``None`` ⇒ not audio).

        ``UnsupportedUrlError`` means "not a direct audio URL" and is
        swallowed; download / size errors propagate to the caller.
        """
        if self._http is None or self._settings is None:
            return None
        try:
            return await resolve_direct_audio(url, self._settings, self._http, self._storage)
        except UnsupportedUrlError:
            return None

    async def _probe_metadata(self, path: Path) -> AudioMetadata:
        """Probe tags, returning empty metadata when probing fails."""
        try:
            return await self._metadata.extract(path)
        except Exception as exc:  # noqa: BLE001 — probing is best-effort here
            logger.warning(
                "music.service.probe_failed",
                extra=log_extra(path=str(path), error=str(exc)[:200]),
            )
            return AudioMetadata()

    @staticmethod
    def _merge_meta(
        provided: AudioMetadata | None,
        probed: AudioMetadata,
        file_name: str,
    ) -> tuple[str | None, str | None, str | None, str | None, str | None, int | None]:
        """Merge metadata layers: provided > probed > filename pattern."""
        provided = provided or AudioMetadata()
        file_artist, file_title = _artist_title_from_filename(file_name)
        title = provided.title or probed.title or file_title
        artist = provided.artist or probed.artist or file_artist
        album = provided.album or probed.album
        genre = provided.genre or probed.genre
        language = provided.language or probed.language
        tempo = provided.tempo if provided.tempo is not None else probed.tempo
        return title, artist, album, genre, language, tempo

    async def _hash_file(self, path: Path) -> str:
        """SHA-256 of a file's bytes (streamed inside a worker thread)."""
        return await asyncio.to_thread(_hash_file_sync, path)

    async def _track_analytics(
        self,
        event_type: str,
        user_id: int | None = None,
        group_id: int | None = None,
        track_id: int | None = None,
        payload: dict[str, Any] | None = None,
    ) -> None:
        """Fire-and-forget analytics via the injected (duck-typed) repo."""
        if self._analytics is None:
            return
        try:
            await self._analytics.track(
                event_type,
                user_id=user_id,
                group_id=group_id,
                track_id=track_id,
                payload=payload,
            )
        except Exception as exc:  # noqa: BLE001 — analytics must never break UX
            logger.warning(
                "music.service.analytics_failed",
                extra=log_extra(event=event_type, error=str(exc)[:160]),
            )

    async def _publish_registered(self, track: Track, *, context: str) -> None:
        """Publish a ``music.track_registered`` event for workers/listeners."""
        try:
            await self._events.publish(
                "music.track_registered",
                track_id=track.id,
                source=track.source,
                context=context,
            )
        except Exception as exc:  # noqa: BLE001 — events must never break flow
            logger.warning(
                "music.service.event_failed", extra=log_extra(error=str(exc)[:160])
            )

    @staticmethod
    def _track_genre_ids(track: Track) -> list[int]:
        """Genre ids of *track*, tolerating detached ORM instances."""
        try:
            return [genre.id for genre in (track.genres or [])]
        except DetachedInstanceError:
            return []


def _artist_title_from_filename(file_name: str) -> tuple[str | None, str | None]:
    """Parse the ``"Artist - Title"`` filename convention."""
    stem = Path(file_name).stem.strip()
    if not stem:
        return None, None
    if " - " in stem:
        artist, _, title = stem.partition(" - ")
        artist = artist.strip()
        title = title.strip()
        if artist and title:
            return artist[:256], title[:256]
    return None, stem[:256]


def _hash_file_sync(path: Path) -> str:
    """Blocking SHA-256 over a file (called via ``asyncio.to_thread``)."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(_HASH_CHUNK)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


#: Magic-byte signatures of the audio containers/codecs the pipeline accepts.
#: Kept deliberately dependency-free (no ffprobe round-trip per download):
#: every format FFmpeg can ingest for voice playback that a provider may
#: realistically serve is covered by one of these headers.
def _recognized_audio_header(head: bytes) -> bool:
    """True when *head* (first bytes of a file) looks like audio."""
    if len(head) < 4:
        return False
    # ID3v2-tagged MP3 (most common for music downloads).
    if head.startswith(b"ID3"):
        return True
    # MPEG audio frame sync (raw MP3 / ADTS AAC): 11 set bits + layer bits.
    if head[0] == 0xFF and (head[1] & 0xE0) == 0xE0:
        return True
    # Ogg container (Vorbis / Opus).
    if head.startswith(b"OggS"):
        return True
    # FLAC native container.
    if head.startswith(b"fLaC"):
        return True
    # RIFF WAVE.
    if head.startswith(b"RIFF") and head[8:12] == b"WAVE":
        return True
    # ISO base media (M4A / MP4 audio).
    if head[4:8] == b"ftyp":
        return True
    # Windows Media Audio.
    if head.startswith(b"\x30\x26\xb2\x75"):
        return True
    # MIDI (rare but valid audio).
    if head.startswith(b"MThd"):
        return True
    # APE / Monkey's Audio.
    if head.startswith(b"MAC "):
        return True
    return False


def _validate_audio_file(path: Path) -> None:
    """Raise :class:`InvalidAudioError` unless *path* is plausibly playable audio.

    Checks (cheap, blocking, no external processes):

    * the file exists and is readable;
    * it has a non-zero size;
    * its header matches a known audio container/codec signature.

    HTML/XML error bodies, JSON payloads, images and empty files all fail
    here — long before they can reach Telegram upload or py-tgcalls.
    """
    try:
        size = path.stat().st_size
    except OSError as exc:
        raise InvalidAudioError(f"Audio file is not accessible: {path.name}") from exc
    if size <= 0:
        raise InvalidAudioError(f"Audio file is empty: {path.name}")
    try:
        with path.open("rb") as handle:
            head = handle.read(16)
    except OSError as exc:
        raise InvalidAudioError(f"Audio file is not readable: {path.name}") from exc
    if not _recognized_audio_header(head):
        preview = head[:8].hex()
        raise InvalidAudioError(
            f"Downloaded content is not recognizable audio (header 0x{preview}): {path.name}"
        )


__all__ = ["AnalyticsTracker", "MusicService"]

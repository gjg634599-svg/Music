"""Direct-URL resolution and the "known unsupported hosts" registry.

Two responsibilities:

1. **Known unsupported hosts** — Spotify, YouTube, SoundCloud, Deezer and
   Apple Music links cannot be played by any authorized source (DRM and/or
   terms of service). When a user submits such a link we raise
   :class:`~app.errors.UnauthorizedSourceError` with a polite explanation
   (its ``user_message`` is already user-facing).
2. **Direct audio files** — ``https://example.com/song.mp3`` style URLs are
   validated (SSRF checks!), downloaded with a size cap and returned as a
   ``TrackResult`` ready to be resolved into the catalog.
"""

from __future__ import annotations

import asyncio
import hashlib
import random
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urljoin, urlparse

import aiohttp

from app.config import Settings
from app.errors import (
    DownloadError,
    FileTooLargeError,
    UnauthorizedSourceError,
    UnsupportedUrlError,
)
from app.logging import get_logger, log_extra
from app.music.models import TrackResult
from app.music.normalizer import clean_title
from app.security.validation import is_direct_audio_url, validate_url
from app.storage import StorageService

logger = get_logger(__name__)

#: Hosts we know we cannot play, with a short human explanation used in
#: logs (users see the ``UnauthorizedSourceError.user_message`` instead).
KNOWN_UNSUPPORTED_HOSTS: dict[str, str] = {
    "spotify.com": "Spotify streams are DRM-protected and cannot be played by bots.",
    "youtube.com": "YouTube content requires formats the bot is not authorized to handle.",
    "music.youtube.com": "YouTube Music content is not available for bot playback.",
    "soundcloud.com": "SoundCloud terms of service do not permit bot playback.",
    "deezer.com": "Deezer streams are DRM-protected and cannot be played by bots.",
    "apple.com/music": "Apple Music streams are DRM-protected and cannot be played by bots.",
}

#: Closely related hosts mapped onto an entry above.
_HOST_ALIASES: dict[str, str] = {
    "open.spotify.com": "spotify.com",
    "play.spotify.com": "spotify.com",
    "youtu.be": "youtube.com",
    "m.youtube.com": "youtube.com",
    "music.apple.com": "apple.com/music",
    "itunes.apple.com": "apple.com/music",
}

#: Download chunk size for streamed downloads.
_CHUNK_SIZE = 64 * 1024

#: Base delay before the single download retry (jittered ±25%). Bounded
#: retry policy: one backoff, one retry, then a real error — never a loop.
DOWNLOAD_RETRY_BACKOFF_SECONDS = 0.5


def unsupported_host_reason(url: str) -> str | None:
    """Return the explanation string when *url* is a known-unsupported host.

    Matches exact hosts and subdomains; ``apple.com`` additionally requires
    a ``/music`` path prefix (so a plain apple.com landing page is not
    flagged).
    """
    try:
        parsed = urlparse((url or "").strip())
    except ValueError:
        return None
    host = (parsed.hostname or "").lower()
    if not host:
        return None
    alias = _HOST_ALIASES.get(host)
    if alias is not None:
        return KNOWN_UNSUPPORTED_HOSTS[alias]

    path = parsed.path or ""
    for key, explanation in KNOWN_UNSUPPORTED_HOSTS.items():
        if "/" in key:
            host_part, path_prefix = key.split("/", 1)
            if host == host_part or host.endswith(f".{host_part}"):
                if path.startswith(f"/{path_prefix}"):
                    return explanation
        elif host == key or host.endswith(f".{key}"):
            return explanation
    return None


def raise_for_unsupported_host(url: str) -> None:
    """Raise :class:`UnauthorizedSourceError` when the host is unsupported.

    The error's ``user_message`` (already defined in ``app.errors``) is a
    polite Telegram-facing message; the technical explanation travels in
    the exception message for structured logs.
    """
    reason = unsupported_host_reason(url)
    if reason is not None:
        raise UnauthorizedSourceError(reason)


async def follow_redirects_safely(
    url: str,
    http: aiohttp.ClientSession,
    timeout: aiohttp.ClientTimeout,
    *,
    max_redirects: int = 5,
) -> str:
    """Manually resolve redirects, re-validating EVERY destination (SSRF).

    Automatic redirect following would let a public "redirector" URL bounce
    the request to loopback / private-network targets, bypassing the
    ``validate_url`` checks performed on the original URL. Here every hop
    is resolved explicitly and validated **fresh** with the same SSRF
    rules (scheme allow-list, credentials check, private-address DNS
    resolution) before the next request is made.

    Returns the final (validated) URL to actually download from.
    """
    current = url
    for _ in range(max(0, max_redirects) + 1):
        async with http.get(current, timeout=timeout, allow_redirects=False) as resp:
            if resp.status not in (301, 302, 303, 307, 308):
                return current
            location = resp.headers.get("Location")
            if not location:
                raise DownloadError("Redirect response without a Location header")
            next_url = urljoin(current, location)
            current = await asyncio.to_thread(validate_url, next_url)
    raise DownloadError(f"Exceeded {max_redirects} redirects")


async def resolve_direct_audio(
    url: str,
    settings: Settings,
    http: aiohttp.ClientSession,
    storage: StorageService,
) -> TrackResult:
    """Turn a direct audio file URL into a :class:`TrackResult`.

    The URL is validated (SSRF protection via ``validate_url`` — private
    addresses and non-http(s) schemes are rejected) and must point at a
    recognizable audio extension. The file is then downloaded with a hard
    size cap of ``settings.max_audio_size_mb`` so playback never depends on
    the remote host again.

    Raises:
        ValidationError: Propagated from ``validate_url`` (private host,
            unresolvable host, ...).
        UnsupportedUrlError: Not a direct audio file URL.
        DownloadError: Network failure after one retry, or non-200 response.
        FileTooLargeError: File exceeds the configured size cap.
    """
    safe_url = await asyncio.to_thread(validate_url, (url or "").strip())
    if not is_direct_audio_url(safe_url):
        raise UnsupportedUrlError(f"Not a direct audio URL: {safe_url[:200]}")

    parsed = urlparse(safe_url)
    filename = PurePosixPath(unquote(parsed.path)).name or "audio"
    stem = Path(filename).stem or "audio"
    extension = Path(filename).suffix.lower() or ".mp3"

    digest = hashlib.sha256(safe_url.encode("utf-8")).hexdigest()
    relative = f"downloads/url-{digest[:16]}{extension}"
    target = storage.resolve(relative)
    if target.exists():
        size = target.stat().st_size
        logger.info("music.url.cache_hit", extra=log_extra(path=relative, size=size))
    else:
        timeout = aiohttp.ClientTimeout(total=settings.http_timeout)
        max_bytes = settings.max_audio_size_mb * 1024 * 1024
        size = await stream_download(safe_url, http, timeout, target, max_bytes)
    return TrackResult(
        title=(clean_title(stem) or stem)[:256],
        artist=None,
        album=None,
        duration_seconds=0,
        source="url",
        source_id=digest[:32],
        stream_url=safe_url,
        extra={"file_path": relative, "size": size},
    )


async def stream_download(
    url: str,
    http: aiohttp.ClientSession,
    timeout: aiohttp.ClientTimeout,
    target: Path,
    max_bytes: int,
    *,
    streaming: bool = False,
) -> int:
    """Stream *url* to *target* enforcing a size cap; returns bytes written.

    Retries once on client errors (the partial file is removed between
    attempts; the retry waits a short jittered backoff so a blip in
    connectivity is not hammered a second time in the same instant —
    production showed DNS/resets where an immediate retry just hit the
    same dead network). Redirects are followed (Audius stream endpoints
    answer with a 302 to the media file).  *streaming* marks voice-chat
    playback downloads — size-limit failures then carry the actionable
    voice-cap message instead of the generic upload-limit wording.

    The retry count is BOUNDED (one retry, then a real error): no
    infinite loops, no unbounded memory (streaming write), and permanent
    errors (non-200, oversize) are never retried.
    """
    last_error: Exception | None = None
    for attempt in (1, 2):
        try:
            return await _stream_once(
                url, http, timeout, target, max_bytes, streaming=streaming
            )
        except (DownloadError, FileTooLargeError):
            raise
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            last_error = exc
            _remove_quietly(target)
            if attempt == 1:
                backoff = DOWNLOAD_RETRY_BACKOFF_SECONDS * (
                    0.75 + random.random() * 0.5  # ±25% jitter
                )
                logger.warning(
                    "music.url.download_retry",
                    extra=log_extra(
                        host=urlparse(url).hostname or "",
                        attempt=attempt,
                        backoff_ms=int(backoff * 1000),
                    ),
                )
                await asyncio.sleep(backoff)
    raise DownloadError(
        f"Download failed for {urlparse(url).hostname}: {last_error}"
    ) from last_error


async def _stream_once(
    url: str,
    http: aiohttp.ClientSession,
    timeout: aiohttp.ClientTimeout,
    target: Path,
    max_bytes: int,
    *,
    streaming: bool = False,
) -> int:
    """Single streaming download attempt with Content-Length pre-check.

    Redirects are followed **manually** via
    :func:`follow_redirects_safely` — every destination is re-validated
    (SSRF) before the request is made, so automatic redirects can never
    bounce the download into a private network.
    """
    limit_mb = max(1, max_bytes // (1024 * 1024))
    final_url = await follow_redirects_safely(url, http, timeout)
    written = 0
    target.parent.mkdir(parents=True, exist_ok=True)
    async with http.get(final_url, timeout=timeout, allow_redirects=False) as resp:
        if resp.status != 200:
            body = await resp.text()
            raise DownloadError(
                f"HTTP {resp.status} while downloading: {body[:120]}"
            )
        content_length = resp.headers.get("Content-Length")
        if content_length:
            try:
                if int(content_length) > max_bytes:
                    raise FileTooLargeError.with_limit_mb(
                        limit_mb, streaming=streaming
                    )
            except ValueError:
                pass  # malformed header — the streaming cap still protects us
        try:
            with target.open("wb") as handle:
                async for chunk in resp.content.iter_chunked(_CHUNK_SIZE):
                    written += len(chunk)
                    if written > max_bytes:
                        raise FileTooLargeError.with_limit_mb(
                            limit_mb, streaming=streaming
                        )
                    handle.write(chunk)
        except FileTooLargeError:
            _remove_quietly(target)
            raise
    logger.info(
        "music.url.downloaded",
        extra=log_extra(host=urlparse(url).hostname or "", size=written),
    )
    return written


def _remove_quietly(path: Path) -> None:
    """Best-effort removal of a partial download."""
    try:
        if path.exists():
            path.unlink()
    except OSError:  # pragma: no cover - best effort
        pass


__all__ = [
    "KNOWN_UNSUPPORTED_HOSTS",
    "follow_redirects_safely",
    "raise_for_unsupported_host",
    "resolve_direct_audio",
    "stream_download",
    "unsupported_host_reason",
]

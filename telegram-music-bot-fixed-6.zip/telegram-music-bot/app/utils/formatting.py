"""Formatting helpers for Telegram messages."""

from __future__ import annotations

import html
from typing import Any

TELEGRAM_MESSAGE_LIMIT = 4096


def format_duration(seconds: int | float | None) -> str:
    """Format seconds as m:ss or h:mm:ss."""
    if seconds is None:
        return "0:00"
    seconds = max(0, int(seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


def progress_bar(position: int, duration: int, width: int = 16) -> str:
    """Render a Telegram progress bar with a playhead marker.

    ``▬▬▬▬▬●──────────`` — the filled run grows with ``position / duration``
    and the ``●`` playhead marks the exact spot (established pattern in
    leading Telegram music bots and chat-player UIs).
    """
    if duration <= 0:
        return "─" * max(4, width)
    ratio = min(1.0, max(0.0, position / duration))
    usable = max(4, width) - 1  # one slot is always the playhead
    filled = round(ratio * usable)
    return "▬" * filled + "●" + "─" * (usable - filled)


def np_progress_lines(position: int, duration: int) -> list[str]:
    """The two progress lines of a Now Playing block (bar + timecodes).

    ``1:23 / 3:45`` sits under the bar; unknown durations render nothing
    (an empty list) so callers can ``lines.extend(...)`` unconditionally.
    The displayed position is clamped to the duration (transient overshoots
    from timer jitter never render impossible timecodes).
    """
    if duration <= 0:
        return []
    position = min(max(0, int(position)), int(duration))
    return [
        progress_bar(position, duration),
        f"{format_duration(position)} / {format_duration(duration)}",
    ]


def human_count(value: int) -> str:
    """12345 -> '12.3K'."""
    if value < 1000:
        return str(value)
    if value < 1_000_000:
        return f"{value / 1000:.1f}K".replace(".0K", "K")
    return f"{value / 1_000_000:.1f}M".replace(".0M", "M")


#: Human labels for repeat modes (buttons and status lines).
REPEAT_LABELS: dict[str, str] = {"off": "Off", "all": "All", "one": "One"}


def repeat_label(mode: str | None) -> str:
    """Human repeat-mode label (unknown values pass through politely)."""
    text = (mode or "off").strip() or "off"
    return REPEAT_LABELS.get(text, text.title())


def _track_artist(track: Any) -> str:
    """Best-effort artist name of a track-like object (never raises)."""
    try:
        artist = getattr(track, "artist", None)
    except Exception:  # noqa: BLE001 — DetachedInstanceError and friends
        return ""
    return (getattr(artist, "name", None) or "") if artist is not None else ""


def now_playing_text(
    track: Any,
    *,
    position: int = 0,
    paused: bool = False,
    session: Any = None,
    queue_size: int = 0,
    requester: str | None = None,
    header: str | None = None,
) -> str:
    """Render the shared Now Playing / Paused message body (HTML).

    One renderer for the personal player, the group control message and
    the dashboard Now-Playing screen (they used to drift apart):

    ``🎵 NOW PLAYING`` / ``⏸ PAUSED`` header, title, artist, playhead
    progress bar, active-mode badges, optional requester attribution and
    the queue count. ``requester`` must be pre-escaped HTML (e.g. a
    ``tg://user`` mention built by the caller). ``header`` overrides the
    default header line (e.g. the DM control screen's "NOW PLAYING IN THE
    GROUP").
    """
    if track is None:
        return "ℹ️ Nothing is playing right now."
    title = escape(getattr(track, "title", "") or "Unknown track")
    artist = escape(_track_artist(track))
    duration = int(getattr(track, "duration_seconds", 0) or 0)

    default_header = "⏸ <b>PAUSED</b>" if paused else "🎵 <b>NOW PLAYING</b>"
    lines = [header or default_header, ""]
    lines.append(f"<b>{title}</b>")
    if artist:
        lines.append(f"🎤 {artist}")
    lines.append("")
    lines.extend(np_progress_lines(max(0, int(position)), duration))

    badges: list[str] = []
    if bool(getattr(session, "shuffle", False)):
        badges.append("🔀 Shuffle")
    repeat_mode = str(getattr(session, "repeat_mode", "off") or "off")
    if repeat_mode != "off":
        badges.append(f"🔁 Repeat: {repeat_label(repeat_mode)}")
    if bool(getattr(session, "autoplay", False)):
        badges.append("🤖 Autoplay")
    if badges:
        lines.append("")
        lines.append(" · ".join(badges))
    if requester:
        lines.append(f"👤 Requested by {requester}")
    lines.append(f"📋 {max(0, int(queue_size))} in queue")
    return "\n".join(lines)


def queue_total_line(
    durations: list[int | None], *, remaining_of_current: int | None = None
) -> str:
    """The queue-length summary line: ``📋 5 in queue · ≈ 18 min``.

    ``durations`` are the upcoming tracks' seconds — one entry per queued
    track (``None``/0 entries count toward the queue length but add no
    time); ``remaining_of_current`` optionally adds the rest of the playing
    track to the total.
    """
    total = sum(int(d) for d in durations if d and int(d) > 0)
    if remaining_of_current and int(remaining_of_current) > 0:
        total += int(remaining_of_current)
    count = len(durations)
    text = f"📋 {count} in queue"
    if total > 0:
        minutes = max(1, round(total / 60))
        if minutes >= 60:
            hours, rest = divmod(minutes, 60)
            text += f" · ≈ {hours}h {rest}m"
        else:
            text += f" · ≈ {minutes} min"
    return text


class PayloadBadges:
    """Duck-typed session view over a now-playing payload dict.

    Lets :func:`now_playing_text` read the shuffle / repeat / autoplay
    badges straight from a payload dict (personal handler, group views,
    DM control screens) without copying it into a session object.
    """

    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = payload

    @property
    def shuffle(self) -> bool:
        return bool(self._payload.get("shuffle"))

    @property
    def repeat_mode(self) -> str:
        return str(self._payload.get("repeat_mode") or "off")

    @property
    def autoplay(self) -> bool:
        return bool(self._payload.get("autoplay"))


def user_link(tg_id: int | None, name: str | None) -> str:
    """Pre-escaped HTML mention for a queue requester (``None`` → empty).

    Uses the deep ``tg://user?id=`` form so the label is the caller's
    best-known name even when the bot cannot resolve the profile.
    """
    tg_id = int(tg_id or 0)
    label = escape((name or "").strip() or "Member")
    if tg_id > 0:
        return f'<a href="tg://user?id={tg_id}">{label}</a>'
    return label


def escape(text: str | None) -> str:
    """HTML-escape user content for Telegram HTML parse mode."""
    return html.escape(text or "", quote=False)


#: Human labels for track source providers (search results / track pages).
PROVIDER_LABELS: dict[str, str] = {
    "audius": "Audius",
    "jamendo": "Jamendo",
    "local": "Local",
    "upload": "Upload",
    "url": "Link",
}


def provider_label(source: str | None) -> str:
    """Human provider name (unknown providers pass through politely)."""
    text = (source or "").strip()
    if not text:
        return ""
    return PROVIDER_LABELS.get(text, text[:12].title())


def track_line(
    index: int,
    title: str,
    artist: str | None,
    duration: int | None = None,
    source: str | None = None,
) -> str:
    """A numbered search-result line.

    ``1. 🎵 <b>Title</b>
        Artist · 3:45 · Audius`` — the second line only carries the parts
    that are actually known (artist / duration / provider).
    """
    line = f"{index}. 🎵 <b>{escape(title)}</b>"
    details: list[str] = []
    if artist:
        details.append(escape(artist))
    if duration and int(duration) > 0:
        details.append(format_duration(int(duration)))
    label = provider_label(source)
    if label:
        details.append(escape(label))
    if details:
        line += "\n   " + " · ".join(details)
    return line


def truncate(text: str, limit: int = 4000) -> str:
    """Ensure the text fits in a Telegram message."""
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def chunk_text(text: str, limit: int = TELEGRAM_MESSAGE_LIMIT) -> list[str]:
    """Split long text into Telegram-sized chunks."""
    text = text.strip()
    if len(text) <= limit:
        return [text]
    chunks: list[str] = []
    while text:
        cut = text.rfind("\n", 0, limit)
        if cut <= 0:
            cut = limit
        chunks.append(text[:cut])
        text = text[cut:].lstrip("\n")
    return chunks


def status_icon(condition: bool) -> str:
    return "🟢" if condition else "🔴"


def warning_icon(condition: bool) -> str:
    return "🟡" if condition else "🟢"


def kv(key: str, value: Any) -> str:
    """Render a 'Key: value' line with escaped value."""
    return f"<b>{escape(key)}:</b> {escape(str(value))}"

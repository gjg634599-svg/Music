"""Application bootstrap and lifecycle.

Builds the full dependency graph (settings → database → caches →
repositories → services → bot → workers → voice engine), runs startup
validation, starts the requested roles (bot / worker / all) and performs a
graceful shutdown on SIGINT/SIGTERM.

Layered architecture (see CONTRACTS.md):

    Bot control plane  →  Music platform  →  Voice engine  →  Infrastructure
"""

from __future__ import annotations

import asyncio
import contextlib
import signal
import sys
from typing import Any

import aiohttp

from app.config import Role, Settings, load_settings
from app.logging import get_logger, log_extra, setup_logging

logger = get_logger(__name__)


class ApplicationError(Exception):
    """Raised when the application cannot start."""


class Application:
    """Owns every subsystem and the process lifecycle."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._services: Any = None
        self._bot: Any = None
        self._dispatcher: Any = None
        self._http: aiohttp.ClientSession | None = None
        self._redis_client: Any = None
        self._background: list[asyncio.Task[None]] = []
        self._health_runner: Any = None
        self._shutdown = asyncio.Event()
        self._started = False

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    @classmethod
    def create(cls, role: Role = Role.ALL, *, settings: Settings | None = None) -> "Application":
        try:
            resolved = settings or load_settings()
        except Exception as exc:  # noqa: BLE001 — surface a clean error
            raise ApplicationError(str(exc)) from exc
        application = cls(resolved)
        application.role = role
        return application

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def run(self) -> None:
        """Start everything for the configured role and block until shutdown."""
        self._install_signal_handlers()

        services = await self._bootstrap()
        self._services = services
        self._bot = services.bot_or_raise()

        self._print_banner(services)

        # --- Role-specific background services --------------------------
        if self.role in (Role.WORKER, Role.ALL):
            self._background.append(
                asyncio.create_task(
                    services.workers.run(self.settings.broadcast.worker_concurrency),
                    name="worker-pool",
                )
            )
            self._background.append(
                asyncio.create_task(
                    services.broadcast_worker.run_forever(), name="broadcast-worker"
                )
            )
            self._background.append(
                asyncio.create_task(self._voice_health_loop(services), name="voice-health")
            )
            self._background.append(
                asyncio.create_task(self._voice_idle_loop(services), name="voice-idle")
            )
            self._background.append(
                asyncio.create_task(self._cleanup_loop(services), name="cleanup")
            )

        # Health endpoint (bot + all roles; useful in every deployment).
        await self._start_health_server(services)

        self._started = True
        logger.info(
            "app.started",
            extra=log_extra(role=self.role.value, pid=sys.argv[0][:40] or "-"),
        )

        try:
            if self.role in (Role.BOT, Role.ALL):
                await self._dispatcher.start_polling(
                    self._bot, handle_signals=False, allowed_updates=self._dispatcher.resolve_used_update_types()
                )
            else:  # worker-only process: block until shutdown
                await self._shutdown.wait()
        finally:
            await self.shutdown()

    async def shutdown(self) -> None:
        """Graceful shutdown: stop accepting work, flush, close resources."""
        if not self._started and self._services is None:
            return
        logger.info("app.shutdown_begin")
        self._shutdown.set()

        # Stop accepting updates.
        if self._dispatcher is not None:
            with contextlib.suppress(Exception):
                await self._dispatcher.stop_polling()

        # Cancel background loops.
        for task in self._background:
            task.cancel()
        if self._background:
            await asyncio.gather(*self._background, return_exceptions=True)
        self._background.clear()

        services = self._services
        if services is not None:
            # Playback: cancel timers, leave voice chats safely.
            with contextlib.suppress(Exception):
                await services.playback.cleanup()
            # Voice engine: leave VCs, disconnect accounts.
            with contextlib.suppress(Exception):
                await services.voice.shutdown()
            # Broadcast worker: stop mid-flight sends gracefully.
            with contextlib.suppress(Exception):
                await services.broadcast_worker.stop()
            # Job workers.
            with contextlib.suppress(Exception):
                await services.workers.stop()

        # Health server.
        if self._health_runner is not None:
            with contextlib.suppress(Exception):
                await self._health_runner.cleanup()
            self._health_runner = None

        # Connections.
        if self._http is not None:
            with contextlib.suppress(Exception):
                await self._http.close()
        if self._redis_client is not None:
            with contextlib.suppress(Exception):
                await self._redis_client.aclose()
        if services is not None:
            with contextlib.suppress(Exception):
                await services.cache.close()
            with contextlib.suppress(Exception):
                await services.db.dispose()
        logger.info("app.shutdown_complete")

    # ------------------------------------------------------------------
    # Bootstrap
    # ------------------------------------------------------------------
    async def _bootstrap(self) -> Any:
        """Build the entire dependency graph and run startup validation."""
        from app.bot.bot import attach_services, build_bot, create_dispatcher
        from app.bot.services import ServiceContainer
        from app.cache.redis import CacheProtocol, LockManager, RateLimiter, create_cache
        from app.database.engine import Database
        from app.playback.events import EventBus
        from app.storage import StorageService, create_storage

        settings = self.settings
        setup_logging(settings.log_level, settings.log_format)

        # --- Infrastructure ---------------------------------------------
        database = Database(settings.database_url)
        if settings.database_url.startswith("sqlite"):
            await database.create_all()  # demo mode
        else:
            healthy = await database.ping()
            if not healthy:
                raise ApplicationError("Database is unreachable — check DATABASE_URL.")
        cache: CacheProtocol = create_cache(settings.redis_url)
        if settings.redis_url:
            try:
                import redis.asyncio as aioredis

                self._redis_client = aioredis.from_url(settings.redis_url)
            except Exception as exc:  # noqa: BLE001
                logger.warning("app.redis_client_failed", extra={"error": str(exc)[:120]})
                self._redis_client = None
        limiter = RateLimiter(cache)
        locks = LockManager(cache, ttl=60)
        events = EventBus()
        storage: StorageService = create_storage(settings)
        self._http = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=settings.http_timeout)
        )

        await self._verify_requirements(database, cache)

        # --- Repositories -------------------------------------------------
        from app.database.repositories import (
            admin as admin_repos,
            analytics as analytics_repos,
            broadcast as broadcast_repos,
            groups as group_repos,
            library as library_repos,
            music as music_repos,
            playback as playback_repos,
            playlists as playlist_repos,
            settings as settings_repos,
            users as user_repos,
            voice as voice_repos,
        )

        sessions = database.sessionmaker()
        users_repo = user_repos.UserRepository(sessions)
        prefs_repo = user_repos.UserPreferenceRepository(sessions)
        search_history_repo = user_repos.SearchHistoryRepository(sessions)
        liked_repo = library_repos.LikedTrackRepository(sessions)
        history_repo = library_repos.ListeningHistoryRepository(sessions)
        playlists_repo = playlist_repos.PlaylistRepository(sessions)
        tracks_repo = music_repos.TrackRepository(sessions)
        artists_repo = music_repos.ArtistRepository(sessions)
        albums_repo = music_repos.AlbumRepository(sessions)
        genres_repo = music_repos.GenreRepository(sessions)
        groups_repo = group_repos.GroupRepository(sessions)
        members_repo = group_repos.GroupMemberRepository(sessions)
        group_settings_repo = group_repos.GroupSettingsRepository(sessions)
        queue_repo = playback_repos.QueueRepository(sessions)
        playback_session_repo = playback_repos.PlaybackSessionRepository(sessions)
        broadcast_repo = broadcast_repos.BroadcastRepository(sessions)
        voice_repo = voice_repos.VoiceRepository(sessions)
        bot_settings_repo = settings_repos.BotSettingsRepository(sessions)
        messages_repo = settings_repos.BotMessageRepository(sessions)
        assets_repo = settings_repos.BotAssetRepository(sessions)
        buttons_repo = settings_repos.BotButtonRepository(sessions)
        admin_repo = admin_repos.AdminRepository(sessions)
        audit_repo = admin_repos.AdminAuditLogRepository(sessions)
        analytics_repo = analytics_repos.AnalyticsRepository(sessions)

        # Seed dynamic configuration (idempotent).
        await bot_settings_repo.ensure_defaults()
        await buttons_repo.ensure_defaults()

        # --- Music platform ----------------------------------------------
        from app.music.metadata import MetadataService
        from app.music.resolver import TrackResolver
        from app.music.search import SearchAggregator
        from app.music.service import MusicService
        from app.music.sources import build_sources

        metadata_service = MetadataService(settings)
        sources = build_sources(settings, self._http, sessions)
        aggregator = SearchAggregator(sources, cache)
        resolver = TrackResolver(tracks_repo, artists_repo, albums_repo, genres_repo)
        music_service = MusicService(
            sources, aggregator, resolver, tracks_repo, metadata_service,
            storage, cache, events, analytics_repo,
        )

        from app.audio.ffmpeg import FFmpegToolkit
        from app.audio.processor import AudioProcessor

        ffmpeg = FFmpegToolkit(settings)
        audio_processor = AudioProcessor(
            settings, ffmpeg, storage, cache,
            stream_resolver=music_service.resolve_stream_url,
        )

        # --- Users & groups ------------------------------------------------
        from app.groups.permissions import GroupPermissions
        from app.groups.service import GroupService
        from app.groups.settings import GroupSettingsService
        from app.users.history import HistoryService
        from app.users.library import LibraryService
        from app.users.playlists import PlaylistService
        from app.users.service import UserService
        from app.users.stats import UserStatsService

        user_service = UserService(
            users_repo, prefs_repo, members_repo, groups_repo,
            history=history_repo, queue=queue_repo, likes=liked_repo,
            playlists=playlists_repo,
        )
        library_service = LibraryService(
            liked_repo, tracks_repo, users_repo, history_repo
        )
        history_service = HistoryService(
            history_repo, users_repo, search_history_repo, analytics_repo
        )
        stats_service = UserStatsService(
            history_repo, liked_repo, tracks_repo, artists_repo, users_repo
        )
        playlist_service = PlaylistService(playlists_repo)
        group_service = GroupService(
            groups_repo, members_repo, queue=queue_repo,
            sessions=playback_session_repo, tracks=tracks_repo,
        )
        group_settings_service = GroupSettingsService(group_settings_repo)
        group_permissions = GroupPermissions(group_settings_repo, members_repo)

        # --- Admin services -------------------------------------------------
        from app.admin.appearance import AppearanceService
        from app.admin.audit import AuditService
        from app.admin.buttons import ButtonService
        from app.admin.permissions import PermissionService
        from app.admin.service import AdminService
        from app.admin.settings import SettingsService
        from app.admin.statistics import StatisticsService

        permission_service = PermissionService(admin_repo, settings.admin_ids)
        appearance_service = AppearanceService(messages_repo, assets_repo, buttons_repo)
        button_service = ButtonService(buttons_repo)
        settings_service = SettingsService(bot_settings_repo)
        statistics_service = StatisticsService(
            users_repo, groups_repo, tracks_repo, analytics_repo,
            broadcast_repo, voice_repo, cache, settings_service,
        )
        audit_service = AuditService(audit_repo)
        admin_service = AdminService(
            permission_service, appearance_service, button_service,
            settings_service, statistics_service, audit_service,
        )

        # --- Recommendation engine ------------------------------------------
        from app.recommendation.engine import RecommendationEngine
        from app.recommendation.profile import ProfileBuilder

        profile_builder = ProfileBuilder(history_repo, liked_repo, tracks=tracks_repo)
        recommendation_engine = RecommendationEngine(
            tracks_repo, profile_builder, bot_settings_repo, cache
        )

        # --- Playback --------------------------------------------------------
        from app.playback.autoplay import AutoplayService
        from app.playback.controller import PlaybackController
        from app.playback.queue import QueueManager
        from app.playback.session import SessionManager

        queue_manager = QueueManager(queue_repo, tracks_repo, events)
        session_manager = SessionManager(playback_session_repo, tracks_repo, events)

        async def autoplay_flag() -> bool:
            try:
                return await settings_service.autoplay_enabled()
            except Exception:  # noqa: BLE001 — fall back to static config
                return settings.autoplay_enabled

        autoplay_service = AutoplayService(
            recommendation_engine, queue_manager, analytics_repo,
            default_enabled=settings.autoplay_enabled, enabled_check=autoplay_flag,
        )

        # --- Voice engine -----------------------------------------------------
        from app.security.encryption import get_cipher
        from app.voice.login import VoiceLoginService
        from app.voice.manager import VoiceManager

        cipher = get_cipher(settings.voice.encryption_key)
        voice_manager = VoiceManager(
            voice_repo, settings, cipher, cache, locks, events
        )
        voice_login = VoiceLoginService(
            settings, sessions, cipher, on_account_saved=voice_manager.reload_accounts
        )

        playback_controller = PlaybackController(
            queue_manager, autoplay_service, music_service, voice_manager,
            session_manager, events, analytics_repo, history_service,
            autoplay_enabled=autoplay_flag,
            default_autoplay=settings.autoplay_enabled,
        )

        # --- Broadcast --------------------------------------------------------
        from app.broadcast.rate_limit import TelegramRateLimiter
        from app.broadcast.service import BroadcastService
        from app.broadcast.targets import TargetSelector
        from app.broadcast.worker import BroadcastWorker
        from app.workers.manager import WorkerManager

        # Bot first (broadcast worker delivers through it).
        bot = build_bot(settings.bot_token)
        self._bot = bot

        # Voice private-group auto-joining: the *bot* account creates a
        # DEDICATED invite link for the group (Bot API createChatInviteLink —
        # requires bot admin rights with the "invite users via link"
        # permission) and the MTProto voice account imports it when not yet
        # a member.  A dedicated link is used instead of
        # ``exportChatInviteLink`` because exporting returns (and may rotate)
        # the group's PRIMARY link — replacing a link the group's owner may
        # have published elsewhere.  ``createChatInviteLink`` never touches
        # the primary link; failures (bot not admin, missing "invite users
        # via link" right, invalid chat id, API errors) degrade to ``None``
        # and the membership layer maps them to its actionable messages.
        # The returned link itself is never logged.
        async def _create_group_invite_link(chat_id: int) -> str | None:
            try:
                result = await bot.create_chat_invite_link(
                    chat_id, name="Music bot voice account"
                )
            except Exception as exc:  # noqa: BLE001 — provider must not raise
                logger.warning(
                    "voice.invite_create_failed",
                    extra=log_extra(chat_id=chat_id, error=str(exc)[:200]),
                )
                return None
            link = str(getattr(result, "invite_link", "") or "").strip()
            if not link:
                logger.warning(
                    "voice.invite_create_invalid",
                    extra=log_extra(chat_id=chat_id),
                )
                return None
            return link

        voice_manager.set_invite_provider(_create_group_invite_link)

        async def _group_has_live_voice_chat(group_tg_id: int) -> bool:
            """Live voice-chat probe for the 'Groups With VC' broadcast segment.

            Returns False when the state cannot be verified (no healthy
            voice account / MTProto error) so the audience only ever keeps
            groups whose voice chat is PROVEN active at send time — never a
            label's implication.
            """
            try:
                picked = voice_manager.pick_client()
                if picked is None:
                    return False
                account, client = picked
                return bool(
                    await voice_manager.group_access.check_voice_chat(
                        client, int(group_tg_id)
                    )
                )
            except Exception:  # noqa: BLE001 — unprovable = excluded
                return False

        target_selector = TargetSelector(
            users_repo, groups_repo, vc_filter=_group_has_live_voice_chat
        )
        broadcast_limiter = TelegramRateLimiter(
            settings.broadcast.rate_per_second
        )
        broadcast_worker = BroadcastWorker(
            bot, broadcast_repo, broadcast_limiter, settings, events
        )
        broadcast_service = BroadcastService(
            broadcast_repo, target_selector, broadcast_worker
        )

        # --- Workers -----------------------------------------------------------
        worker_manager = WorkerManager(cache, locks, redis=self._redis_client)
        from app.workers import tasks as worker_tasks

        container = ServiceContainer(
            settings=settings,
            db=database,
            cache=cache,
            limiter=limiter,
            locks=locks,
            storage=storage,
            events=events,
            music=music_service,
            audio=audio_processor,
            users=user_service,
            library=library_service,
            history=history_service,
            playlists=playlist_service,
            stats=stats_service,
            groups=group_service,
            group_settings=group_settings_service,
            permissions=group_permissions,
            queue=queue_manager,
            sessions=session_manager,
            playback=playback_controller,
            autoplay=autoplay_service,
            recommendations=recommendation_engine,
            voice=voice_manager,
            voice_login=voice_login,
            admin=admin_service,
            broadcast=broadcast_service,
            broadcast_worker=broadcast_worker,
            analytics=analytics_repo,
            workers=worker_manager,
            bot=bot,
        )
        worker_tasks.bind(container)
        for job_type, handler in list(worker_tasks.TASKS.items()):
            worker_manager.register(job_type, handler)

        # --- Dispatcher -----------------------------------------------------
        fsm_storage: Any = None
        if self._redis_client is not None:
            with contextlib.suppress(Exception):
                from aiogram.fsm.storage.redis import RedisStorage

                fsm_storage = RedisStorage(redis=self._redis_client, key_builder=None)
        dispatcher = create_dispatcher(fsm_storage)
        attach_services(dispatcher, container)
        self._dispatcher = dispatcher

        # --- Voice engine start (after container exists) ---------------------
        await voice_manager.start()
        if settings.voice_enabled and not voice_manager.has_accounts():
            logger.warning(
                "voice.no_accounts",
                extra=log_extra(
                    hint="Admin panel → Voice Engine → Add Account (login wizard), "
                    "or scripts/add_voice_account.py on the server",
                ),
            )

        # --- Ghost-session reconciliation (restart honesty) -------------------
        # Nothing can be playing at process start: the voice sessions,
        # timers and runtime map died with the previous process. Sessions
        # left "playing"/"paused" in the database made /play queue behind
        # a ghost (production: queue.added with no pop/join/stream) and
        # /np render a phantom Now Playing. Park them idle, honestly.
        try:
            reconciled = await playback_controller.reconcile_after_restart()
            if reconciled:
                logger.info(
                    "app.sessions_reconciled",
                    extra=log_extra(count=reconciled),
                )
        except Exception as exc:  # noqa: BLE001 — startup must not crash
            logger.warning(
                "app.session_reconcile_failed",
                extra=log_extra(error=str(exc)[:160]),
            )

        from app.bot.commands import register_bot_commands

        with contextlib.suppress(Exception):
            await register_bot_commands(bot)

        return container

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    async def _verify_requirements(self, database: Any, cache: Any) -> None:
        """Fail fast (or warn) when infrastructure is missing."""
        problems: list[str] = []
        if not await database.ping():
            problems.append("database")
        if not await cache.ping():
            problems.append("cache")
        if problems:
            raise ApplicationError(f"Unreachable infrastructure: {', '.join(problems)}")

    async def _voice_health_loop(self, services: Any) -> None:
        interval = max(30, services.settings.voice.health_check_interval)
        while True:
            await asyncio.sleep(interval)
            if not await services.voice.is_voice_enabled():
                continue
            with contextlib.suppress(Exception):
                await services.voice.run_health_checks()

    async def _voice_idle_loop(self, services: Any) -> None:
        """Periodically release group voice sessions idle past their timeout.

        The per-group timeout comes from GroupSettings.idle_timeout_minutes
        (admins can change it via /settings); the global default lives in
        ``settings.voice.idle_timeout_minutes``.
        """

        async def group_timeout(group_tg_id: int) -> float:
            settings_row = await services.group_settings.get(group_tg_id)
            return float(getattr(settings_row, "idle_timeout_minutes", 0) or 0) or float(
                services.settings.voice.idle_timeout_minutes or 5
            )

        while True:
            await asyncio.sleep(60)
            if not await services.voice.is_voice_enabled():
                continue
            with contextlib.suppress(Exception):
                released = await services.voice.release_idle_sessions(
                    resolver=group_timeout
                )
                if released:
                    logger.info(
                        "app.voice_idle_released",
                        extra=log_extra(groups=",".join(map(str, released))),
                    )

    async def _cleanup_loop(self, services: Any) -> None:
        while True:
            await asyncio.sleep(3600)
            with contextlib.suppress(Exception):
                services.storage.cleanup_tmp(max_age_seconds=7200)
            with contextlib.suppress(Exception):
                await services.workers.enqueue(
                    __import__("app.workers.jobs", fromlist=["make_job"]).make_job(
                        "cleanup_tmp", {}
                    )
                )
            # Completed download-cache retention (§11): expire cached
            # provider downloads older than DOWNLOADS_RETENTION_HOURS
            # (default 24h; 0 disables), protecting files whose tracks
            # are genuinely playing right now. Runs through the SAME
            # worker task as tmp cleanup — no competing loop.
            with contextlib.suppress(Exception):
                await services.workers.enqueue(
                    __import__("app.workers.jobs", fromlist=["make_job"]).make_job(
                        "cleanup_downloads", {}
                    )
                )

    async def _start_health_server(self, services: Any) -> None:
        port = self.settings.health_port
        if not port:
            return
        try:
            from aiohttp import web

            async def health_handler(request: web.Request) -> web.Response:
                db_ok = await services.db.ping()
                cache_ok = await services.cache.ping()
                workers_ok = services.workers._tasks is not None and any(
                    not task.done() for task in services.workers._tasks
                ) or self.role == Role.BOT
                # Voice engine readiness — status counts only, never secrets.
                # "no accounts" and "accounts disconnected" stay distinct.
                try:
                    voice_status = await services.voice.status()
                    if not await services.voice.is_voice_enabled():
                        voice = "disabled"
                    elif voice_status.total_accounts == 0:
                        voice = "no_accounts"
                    elif voice_status.healthy_accounts == 0:
                        voice = "accounts_offline"
                    else:
                        voice = (
                            "degraded"
                            if voice_status.healthy_accounts < voice_status.total_accounts
                            else "ready"
                        )
                except Exception:  # noqa: BLE001 — health must never crash
                    voice = "unknown"
                payload = {
                    "status": "ok" if db_ok and cache_ok else "degraded",
                    "database": "ok" if db_ok else "down",
                    "redis": "ok" if cache_ok else "down",
                    "workers": "ok" if workers_ok else "down",
                    "voice": voice,
                    "role": self.role.value,
                }
                return web.json_response(
                    payload, status=200 if payload["status"] == "ok" else 503
                )

            app = web.Application()
            app.router.add_get("/health", health_handler)
            self._health_runner = web.AppRunner(app)
            await self._health_runner.setup()
            site = web.TCPSite(self._health_runner, "0.0.0.0", port)
            await site.start()
            logger.info("app.health_server", extra=log_extra(port=port))
        except Exception as exc:  # noqa: BLE001 — health endpoint is optional
            logger.warning("app.health_server_failed", extra={"error": str(exc)[:120]})

    def _print_banner(self, services: Any) -> None:
        """Startup banner — component status, never any secret."""
        import shutil

        from app.config import Role

        ffmpeg_ok = bool(
            shutil.which(self.settings.ffmpeg_path)
            or shutil.which("ffmpeg")
        )
        voice_state = (
            "disabled"
            if not self.settings.voice_enabled
            else ("ready" if services.voice.has_accounts() else "no accounts")
        )
        print("🎵 Music Bot")
        print("─" * 34)
        print(f"Bot API        {'🟢' if self._bot else '🔴'}")
        print(f"Role           {self.role.value}")
        print(f"Database       {'🟢' if self.settings.database_url.startswith('sqlite') else '🟢 pg'}")
        print(f"Redis/Cache    {'🟢 redis' if self.settings.redis_url else '🟡 memory'}")
        print(f"FFmpeg         {'🟢' if ffmpeg_ok else '🔴'}")
        print(f"Workers        {'🟢' if self.role in (Role.WORKER, Role.ALL) else '⚪ bot-only'}")
        print(f"Voice Engine   {'🟢' if voice_state == 'ready' else ('🟡 ' + voice_state)}")
        print(f"Admins         {len(self.settings.admin_ids) or '—'}")
        print("─" * 34)
        print("Starting…", flush=True)

    def _install_signal_handlers(self) -> None:
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            with contextlib.suppress(NotImplementedError):
                loop.add_signal_handler(sig, self._request_shutdown)

    def _request_shutdown(self) -> None:
        """Signal handler: initiate exactly one orderly shutdown."""
        if self._shutdown.is_set():
            return  # second Ctrl+C must not duplicate stop work
        self._shutdown.set()
        asyncio.create_task(self._trigger_stop(), name="shutdown-trigger")

    async def _trigger_stop(self) -> None:
        """Stop polling and wake the worker-only loop."""
        if self._dispatcher is not None:
            with contextlib.suppress(Exception):
                await self._dispatcher.stop_polling()

"""Storage abstraction: local storage now, S3-compatible later."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import BinaryIO

from app.config import Settings
from app.errors import ValidationError
from app.logging import get_logger
from app.security.validation import sanitize_filename

logger = get_logger(__name__)


class StorageService:
    """File storage under the configured storage directory.

    All paths are sandboxed inside the storage root — path traversal is
    impossible because user-supplied names are sanitized.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    # -- low-level API ---------------------------------------------------
    def resolve(self, relative: str) -> Path:
        """Safely resolve a storage-relative path."""
        candidate = (self.root / relative).resolve()
        if not candidate.is_relative_to(self.root):
            raise ValidationError("Invalid storage path")
        return candidate

    def save(self, relative: str, source: Path | BinaryIO | bytes) -> Path:
        """Save a file (from path, file object or bytes) into storage."""
        target = self.resolve(relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(source, bytes):
            target.write_bytes(source)
        elif isinstance(source, Path):
            shutil.copyfile(source, target)
        else:
            with target.open("wb") as handle:
                shutil.copyfileobj(source, handle)
        logger.info("storage.saved", extra={"path": relative})
        return target

    def get(self, relative: str) -> Path | None:
        path = self.resolve(relative)
        return path if path.exists() else None

    def exists(self, relative: str) -> bool:
        try:
            return self.resolve(relative).exists()
        except ValidationError:
            return False

    def delete(self, relative: str) -> bool:
        path = self.resolve(relative)
        if path.exists():
            path.unlink()
            return True
        return False

    def size(self, relative: str) -> int:
        return self.resolve(relative).stat().st_size

    # -- domain helpers --------------------------------------------------
    def music_dir(self) -> Path:
        path = self.root / "music"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def tmp_dir(self) -> Path:
        path = self.root / "tmp"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def downloads_dir(self) -> Path:
        path = self.root / "downloads"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def artwork_dir(self) -> Path:
        path = self.root / "artwork"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def unique_name(self, original_name: str, *, prefix: str = "") -> str:
        """A sanitized, unique filename inside the tmp dir."""
        import time
        import uuid

        safe = sanitize_filename(original_name)
        stamp = f"{int(time.time() * 1000)}-{uuid.uuid4().hex[:8]}"
        return f"{prefix}{stamp}-{safe}"

    def cleanup_tmp(self, max_age_seconds: int = 3600) -> int:
        """Remove stale files from the tmp directory; return removed count."""
        import time

        removed = 0
        cutoff = time.time() - max_age_seconds
        for path in self.tmp_dir().iterdir():
            try:
                if path.is_file() and path.stat().st_mtime < cutoff:
                    path.unlink()
                    removed += 1
            except OSError:  # pragma: no cover - best effort
                continue
        if removed:
            logger.info("storage.tmp_cleaned", extra={"removed": removed})
        return removed

    def cleanup_downloads(
        self,
        max_age_seconds: int,
        *,
        protect_track_ids: set[int] | None = None,
    ) -> tuple[int, int]:
        """Remove EXPIRED files from the completed-download cache.

        This is the retention policy for ``storage/downloads`` — the cache
        of fully downloaded provider tracks (``track-<id>.<ext>``). The tmp
        sweeper only ever covered partial/intermediate files, so completed
        caches used to accumulate forever.

        Safety rules:

        * only regular files directly inside ``downloads/`` are touched —
          symlinks are skipped (never followed out of the cache), and the
          permanent ``music/`` uploads, sessions, databases and config live
          outside this directory and are never scanned;
        * files belonging to *protect_track_ids* (tracks this process is
          genuinely playing/pausing) survive regardless of age;
        * files newer than *max_age_seconds* survive (recently downloaded
          or in active rotation);
        * a missing directory is fine (nothing cached yet);
        * per-file failures are logged and skipped — cleanup is best
          effort and must never raise into the worker.

        Returns ``(removed_count, removed_bytes)``.
        """
        import time

        if max_age_seconds <= 0:
            return 0, 0
        protect = protect_track_ids or set()
        downloads = self.downloads_dir()
        if not downloads.exists():
            return 0, 0
        cutoff = time.time() - max_age_seconds
        removed = 0
        removed_bytes = 0
        try:
            entries = list(downloads.iterdir())
        except OSError as exc:  # pragma: no cover - best effort
            logger.warning("storage.downloads_scan_failed", extra={"error": str(exc)[:160]})
            return 0, 0
        for path in entries:
            try:
                if path.is_symlink() or not path.is_file():
                    continue  # never follow links; dirs are not ours
                name = path.name
                if any(name.startswith(f"track-{tid}.") for tid in protect):
                    continue  # in active use
                stat = path.stat()
                if stat.st_mtime >= cutoff:
                    continue  # within retention
                size = stat.st_size
                path.unlink()
                removed += 1
                removed_bytes += size
            except OSError as exc:  # pragma: no cover - best effort
                logger.warning(
                    "storage.downloads_remove_failed",
                    extra={"path": path.name, "error": str(exc)[:160]},
                )
                continue
        if removed:
            logger.info(
                "storage.downloads_cleaned",
                extra={"removed": removed, "bytes": removed_bytes},
            )
        return removed, removed_bytes


def create_storage(settings: Settings) -> StorageService:
    return StorageService(settings.storage_dir)

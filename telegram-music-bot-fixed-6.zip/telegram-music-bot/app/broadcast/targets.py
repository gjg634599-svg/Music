"""Audience selection for broadcast campaigns.

Translates a human-facing ``target_type`` (e.g. ``active_users``) into a
concrete list of ``(chat_type, chat_id)`` pairs by querying the user and
group repositories through narrow, duck-typed segment methods:

* ``users_repo.broadcast_segment(segment, language=None, ids=None) -> list[int]``
  with segments: ``all`` | ``active`` | ``inactive`` | ``by_language`` |
  ``with_groups`` | ``specific``.
* ``groups_repo.broadcast_segment(segment, ids=None) -> list[int]``
  with segments: ``all`` | ``active`` | ``specific``.

The repositories themselves are responsible for excluding blocked/inactive
users from user segments (Task 2-e implements ``UserRepository`` /
``GroupRepository``); this module only maps and validates the segment input.
"""

from __future__ import annotations

from typing import Awaitable, Callable, Protocol

from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Valid target types (see the Broadcast.target_type column docstring).
USER_TARGET_TYPES: frozenset[str] = frozenset(
    {
        "all_users",
        "active_users",
        "inactive_users",
        "users_by_language",
        "users_with_groups",
        "specific_users",
    }
)
GROUP_TARGET_TYPES: frozenset[str] = frozenset(
    {
        "all_groups",
        "active_groups",
        "groups_with_vc",  # alias of active_groups — Group has no VC flag
        "specific_groups",
    }
)
TARGET_TYPES: frozenset[str] = USER_TARGET_TYPES | GROUP_TARGET_TYPES

#: user-segment mapping (target_type → repository segment)
_USER_SEGMENTS: dict[str, str] = {
    "all_users": "all",
    "active_users": "active",
    "inactive_users": "inactive",
    "users_by_language": "by_language",
    "users_with_groups": "with_groups",
    "specific_users": "specific",
}

#: group-segment mapping (target_type → repository segment)
_GROUP_SEGMENTS: dict[str, str] = {
    "all_groups": "all",
    "active_groups": "active",
    # NOTE: the Group model carries no voice-chat flag, so "groups with a
    # voice chat" degrades to "active groups" (bot present & active).
    "groups_with_vc": "active",
    "specific_groups": "specific",
}


class UserSegmentSource(Protocol):
    """User repository segment interface (implemented by UserRepository)."""

    async def broadcast_segment(
        self,
        segment: str,
        language: str | None = None,
        ids: list[int] | None = None,
    ) -> list[int]:
        """Telegram ids for a user segment.

        Segments: all | active | inactive | by_language | with_groups | specific.
        Implementations always exclude blocked (``is_blocked``) users;
        activity filtering is expressed through the segment choice
        (``active`` = seen within 30 days).
        """
        ...


class GroupSegmentSource(Protocol):
    """Group repository segment interface (implemented by GroupRepository)."""

    async def broadcast_segment(
        self,
        segment: str,
        ids: list[int] | None = None,
    ) -> list[int]:
        """Telegram ids for a group segment (all | active | specific)."""
        ...


class TargetSelector:
    """Builds broadcast target lists from audience descriptors."""

    def __init__(
        self,
        users: UserSegmentSource,
        groups: GroupSegmentSource,
        *,
        vc_filter: Callable[[int], Awaitable[bool]] | None = None,
    ) -> None:
        self._users = users
        self._groups = groups
        #: Optional live voice-chat probe used ONLY by the
        #: ``groups_with_vc`` segment: when provided, each candidate group
        #: is actually checked (MTProto) at send time — the label never
        #: implies voice-chat presence that was not queried. Without a
        #: probe the segment degrades to "active groups" (logged).
        self._vc_filter = vc_filter

    async def build(
        self, target_type: str, filter_data: dict | None
    ) -> list[tuple[str, int]]:
        """Resolve a target type into ``(chat_type, chat_id)`` pairs.

        ``chat_type`` is ``user`` or ``group``. Raises :class:`ValidationError`
        for unknown target types or malformed filter data.
        """
        target_type = (target_type or "").strip()
        if target_type not in TARGET_TYPES:
            raise ValidationError(
                f"Unknown broadcast target type: {target_type or '(empty)'}"
            )
        filter_data = filter_data or {}

        if target_type in USER_TARGET_TYPES:
            ids = await self._user_ids(target_type, filter_data)
            chat_type = "user"
        else:
            ids = await self._group_ids(target_type, filter_data)
            chat_type = "group"

        # Dedupe while preserving order (same chat may appear twice when
        # admins pass overlapping explicit id lists).
        seen: set[int] = set()
        targets: list[tuple[str, int]] = []
        for chat_id in ids:
            if chat_id in seen:
                continue
            seen.add(chat_id)
            targets.append((chat_type, int(chat_id)))

        logger.info(
            "broadcast.targets_built",
            extra=log_extra(target_type=target_type, count=len(targets)),
        )
        return targets

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _user_ids(self, target_type: str, filter_data: dict) -> list[int]:
        segment = _USER_SEGMENTS[target_type]
        language: str | None = None
        ids: list[int] | None = None
        if segment == "by_language":
            language = str(filter_data.get("language") or "").strip()
            if not language:
                raise ValidationError("A language code is required for this target type")
            if len(language) > 8:
                raise ValidationError("Language code is too long")
        elif segment == "specific":
            ids = _parse_id_list(filter_data, "ids")
        return await self._users.broadcast_segment(segment, language=language, ids=ids)

    async def _group_ids(self, target_type: str, filter_data: dict) -> list[int]:
        segment = _GROUP_SEGMENTS[target_type]
        ids: list[int] | None = None
        if segment == "specific":
            ids = _parse_id_list(filter_data, "ids")
        group_ids = await self._groups.broadcast_segment(segment, ids=ids)
        if target_type == "groups_with_vc":
            if self._vc_filter is None:
                # No live probe available: the documented degradation —
                # keep the active-groups audience, loudly.
                logger.warning(
                    "broadcast.vc_filter_unavailable",
                    extra=log_extra(fallback="active_groups", count=len(group_ids)),
                )
                return group_ids
            checked: list[int] = []
            for group_id in group_ids:
                try:
                    proven = await self._vc_filter(int(group_id))
                except Exception:  # noqa: BLE001 — unprovable = excluded
                    proven = False
                if proven:
                    checked.append(int(group_id))
            dropped = len(group_ids) - len(checked)
            if dropped:
                logger.info(
                    "broadcast.vc_filtered",
                    extra=log_extra(kept=len(checked), dropped=dropped),
                )
            return checked
        return group_ids


def _parse_id_list(filter_data: dict, key: str = "ids") -> list[int]:
    """Extract a non-empty list of integer Telegram ids from filter data."""
    raw = filter_data.get(key)
    if raw is None or isinstance(raw, str) and not raw.strip():
        raise ValidationError("A list of Telegram ids is required for this target type")
    if isinstance(raw, str):
        raw = [chunk.strip() for chunk in raw.replace(";", ",").split(",") if chunk.strip()]
    if not isinstance(raw, (list, tuple)) or not raw:
        raise ValidationError("A list of Telegram ids is required for this target type")
    ids: list[int] = []
    for item in raw:
        try:
            value = int(str(item).strip())
        except (TypeError, ValueError) as exc:
            raise ValidationError(f"Invalid Telegram id: {item!r}") from exc
        ids.append(value)
    return ids


__all__ = [
    "TargetSelector",
    "UserSegmentSource",
    "GroupSegmentSource",
    "USER_TARGET_TYPES",
    "GROUP_TARGET_TYPES",
    "TARGET_TYPES",
]

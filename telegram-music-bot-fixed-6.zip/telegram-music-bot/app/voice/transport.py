"""Voice transports — protocol + native py-tgcalls implementation.

py-tgcalls is an optional runtime dependency: the guarded import below keeps
this module (and everything depending on it) importable without the package,
exposing :data:`PYTGCALLS_AVAILABLE` for feature detection. All methods raise
:class:`app.errors.VoiceError` subclasses with user-safe messages; raw library
exceptions are classified and logged in full, never leaked to users.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from app.errors import VoiceChatMissingError, VoiceError, VoiceUnavailableError
from app.logging import get_logger, log_extra

try:  # py-tgcalls is optional at runtime (see requirements.txt)
    from pytgcalls import PyTgCalls
    from pytgcalls.types import GroupCallConfig, MediaStream

    PYTGCALLS_AVAILABLE = True
except Exception:  # noqa: BLE001 — any import-time failure means "unavailable"
    PYTGCALLS_AVAILABLE = False

logger = get_logger(__name__)

#: Substrings of library errors meaning "there is no voice chat to join".
#: ``NoActiveGroupCall`` renders as "No active group call" in py-tgcalls 2.x.
_CHAT_MISSING_MARKERS = (
    "VOICE_CHAT_INVALID",
    "chat not found",
    "GROUPCALLS_FORBIDDEN",
    "GroupCallNotFound",
    "no active group call",
)

#: Substrings meaning the userbot session is no longer authorized.
_AUTH_MARKERS = ("AUTH", "authorization")

#: Max characters of a raw error embedded in an internal VoiceError message.
_MESSAGE_LIMIT = 200


def _classify_play_error(exc: Exception) -> VoiceError:
    """Map a raw pytgcalls exception to a typed :class:`VoiceError`."""
    message = str(exc)
    lowered = message.lower()
    if any(marker.lower() in lowered for marker in _CHAT_MISSING_MARKERS):
        return VoiceChatMissingError("Voice chat is not available in this group")
    if any(marker in message or marker in lowered for marker in _AUTH_MARKERS):
        return VoiceError("re-authentication required for the voice account")
    return VoiceError(message[:_MESSAGE_LIMIT] or type(exc).__name__)


@runtime_checkable
class VoiceTransport(Protocol):
    """What the voice engine needs from a group-call transport."""

    async def join(self, group_tg_id: int) -> None: ...
    async def play(
        self, group_tg_id: int, path: Path, *args: Any, **kwargs: Any
    ) -> None: ...
    async def pause(self, group_tg_id: int) -> None: ...
    async def resume(self, group_tg_id: int) -> None: ...
    async def set_volume(self, group_tg_id: int, volume: int) -> None: ...
    async def leave(self, group_tg_id: int) -> None: ...
    async def is_connected(self, group_tg_id: int) -> bool: ...


class NativeTransport:
    """py-tgcalls backed transport (one instance per userbot account).

    The library joins the group call lazily on the first ``play()`` — ``join``
    only validates readiness, matching how py-tgcalls manages connections.
    """

    def __init__(self, client: Any) -> None:
        self._client = client
        self._calls: Any = None
        self._started = False
        self._joined: set[int] = set()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def ensure_started(self) -> None:
        """Create and start the PyTgCalls app exactly once."""
        if self._started:
            return
        if not PYTGCALLS_AVAILABLE:
            raise VoiceUnavailableError("py-tgcalls is not installed on the server")
        calls = PyTgCalls(self._client)
        try:
            await calls.start()
        except Exception as exc:  # noqa: BLE001 — classify library errors
            logger.error(
                "voice.transport.start_failed",
                extra=log_extra(error=str(exc)[:300]),
            )
            raise VoiceError(f"Voice transport failed to start: {str(exc)[:_MESSAGE_LIMIT]}") from exc
        self._calls = calls
        self._started = True
        logger.info("voice.transport.started")

    def _require_calls(self) -> Any:
        """Return the started PyTgCalls app or raise."""
        if not PYTGCALLS_AVAILABLE:
            raise VoiceUnavailableError("py-tgcalls is not installed on the server")
        if self._calls is None:
            raise VoiceUnavailableError("Voice transport is not started")
        return self._calls

    # ------------------------------------------------------------------
    # VoiceTransport implementation
    # ------------------------------------------------------------------
    async def join(self, group_tg_id: int) -> None:
        """Validate readiness only — the actual join happens lazily on ``play``.

        Deliberately a no-op (never raises): pytgcalls establishes the group
        call inside ``play()``; problems surface there with proper
        classification. Here we only coerce/validate the group id and log.
        """
        group_tg_id = int(group_tg_id)
        ready = PYTGCALLS_AVAILABLE and self._started
        logger.debug(
            "voice.transport.join_ready" if ready else "voice.transport.join_deferred",
            extra=log_extra(group_id=group_tg_id, ready=ready),
        )

    async def play(
        self, group_tg_id: int, path: Path, *args: Any, **kwargs: Any
    ) -> None:
        """Start streaming ``path`` into the group voice chat.

        py-tgcalls 2.x API notes (verified against 2.3.3):

        * ``MediaStream`` takes NO ``loop`` kwarg (regression: passing
          ``loop=False`` raised ``TypeError: got an unexpected keyword
          argument 'loop'`` and killed every playback attempt — the
          production ``voice.transport.play_failed`` log).
        * ``GroupCallConfig(auto_start=False)`` keeps the honest contract:
          when the group has no live voice chat we get a clean
          ``NoActiveGroupCall`` (classified as
          :class:`VoiceChatMissingError`) instead of the userbot silently
          trying to *create* a call it may lack admin rights for.
        """
        calls = self._require_calls()
        try:
            await calls.play(
                group_tg_id,
                MediaStream(str(path)),
                GroupCallConfig(auto_start=False),
            )
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "voice.transport.play_failed",
                extra=log_extra(group_id=group_tg_id, path=Path(path).name, error=str(exc)[:400]),
            )
            raise _classify_play_error(exc) from exc
        self._joined.add(group_tg_id)
        logger.info(
            "voice.transport.play",
            extra=log_extra(group_id=group_tg_id, path=Path(path).name),
        )

    async def pause(self, group_tg_id: int) -> None:
        """Pause the outgoing stream."""
        calls = self._require_calls()
        try:
            await calls.pause(group_tg_id)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "voice.transport.pause_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:300]),
            )
            raise VoiceError(f"Pause failed: {str(exc)[:_MESSAGE_LIMIT]}") from exc
        logger.info("voice.transport.paused", extra=log_extra(group_id=group_tg_id))

    async def resume(self, group_tg_id: int) -> None:
        """Resume the paused stream."""
        calls = self._require_calls()
        try:
            await calls.resume(group_tg_id)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "voice.transport.resume_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:300]),
            )
            raise VoiceError(f"Resume failed: {str(exc)[:_MESSAGE_LIMIT]}") from exc
        logger.info("voice.transport.resumed", extra=log_extra(group_id=group_tg_id))

    async def set_volume(self, group_tg_id: int, volume: int) -> None:
        """Best-effort volume adjust (optional API, name differs per build).

        py-tgcalls 2.x exposes ``change_volume_call``; some builds also
        provide ``set_volume``. Both are tried, neither is ever fatal.
        """
        calls = self._require_calls()
        group_tg_id = int(group_tg_id)
        try:
            if hasattr(calls, "set_volume"):
                await calls.set_volume(group_tg_id, int(volume))
            else:
                await calls.change_volume_call(group_tg_id, int(volume))
            logger.debug(
                "voice.transport.volume",
                extra=log_extra(group_id=group_tg_id, volume=int(volume)),
            )
        except Exception as exc:  # noqa: BLE001 — optional API, never fatal
            logger.debug(
                "voice.transport.volume_unavailable",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:200]),
            )

    async def leave(self, group_tg_id: int) -> None:
        """Leave the group call (always discards the joined marker)."""
        self._joined.discard(group_tg_id)
        calls = self._calls
        if calls is None:
            return
        try:
            await calls.leave_call(group_tg_id)
            logger.info("voice.transport.left", extra=log_extra(group_id=group_tg_id))
        except Exception as exc:  # noqa: BLE001 — leaving is best-effort
            logger.debug(
                "voice.transport.leave_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:200]),
            )

    async def is_connected(self, group_tg_id: int) -> bool:
        """True when this transport is streaming in the group (joined set)."""
        return int(group_tg_id) in self._joined


__all__ = ["PYTGCALLS_AVAILABLE", "NativeTransport", "VoiceTransport"]

"""VoiceManager — the voice engine facade.

Owns the account pool, group session leases, health monitoring and failover.
Playback flow:

    manager.play(group_id, path)
        → acquire(group_id)            # pick least-loaded account, create lease
        → VoiceSessionRuntime.start_playback(path)
            → NativeTransport.play(...)  # py-tgcalls joins + streams
            → duration timer → ``track_end:group:<id>``   # queue auto-advance

Failures mid-playback surface through ``FailoverController.handle_failure``,
which publishes ``voice_failure:<group_id>``; the manager's subscription
releases the broken lease and re-acquires on a healthy account.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from app.audio.ffmpeg import FFmpegToolkit
from app.errors import (
    VoiceAccountOfflineError,
    VoiceGroupAccessError,
    VoiceNotJoinedError,
    VoiceError,
)
from app.logging import get_logger, log_extra
from app.playback.events import Event, EventBus
from app.voice.account import VoiceAccountClient
from app.voice.assignment import AssignmentStrategy
from app.voice.failover import FailoverController
from app.voice.group_access import GroupAccessService
from app.voice.health import HealthMonitor
from app.voice.session import VoiceSessionRuntime

if TYPE_CHECKING:
    from app.cache.redis import CacheProtocol, LockManager
    from app.config import Settings
    from app.database.models.voice import VoiceAccount, VoiceSession
    from app.database.repositories.voice import VoiceRepository
    from app.security.encryption import SessionCipher

logger = get_logger(__name__)


@dataclass(slots=True)
class VoiceAccountSummary:
    """One line of the engine status report (no secrets)."""

    label: str
    account_id: int
    status: str
    active_sessions: int
    max_sessions: int


@dataclass(slots=True)
class VoiceEngineStatus:
    """Snapshot of the voice engine for the admin panel."""

    accounts: list[VoiceAccountSummary] = field(default_factory=list)
    total_accounts: int = 0
    healthy_accounts: int = 0
    active_sessions: int = 0


class VoiceManager:
    """Facade over accounts, sessions, health checks and failover."""

    def __init__(
        self,
        repo: VoiceRepository,
        settings: Settings,
        cipher: SessionCipher | None,
        cache: CacheProtocol,
        locks: LockManager,
        events: EventBus,
        assignment: AssignmentStrategy | None = None,
    ) -> None:
        self._repo = repo
        self._settings = settings
        self._cipher = cipher
        self._cache = cache
        self._locks = locks
        self._events = events
        self._assignment = assignment or AssignmentStrategy()

        self._accounts: dict[int, VoiceAccountClient] = {}
        self._sessions: dict[int, VoiceSessionRuntime] = {}
        self._group_locks: dict[int, asyncio.Lock] = {}
        self._health = HealthMonitor(settings, repo)
        self._failover = FailoverController(lambda: self, repo, locks, events)
        self._ffmpeg: FFmpegToolkit | None = None
        self._started = False
        self._subscribed = False
        # Private-group membership verification + automatic invite joining.
        # The invite provider (bot-backed ``create_chat_invite_link``) is
        # attached later by the composition root via ``set_invite_provider``.
        self._group_access = GroupAccessService(settings, None)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def start(self) -> None:
        """Load and connect the account pool (no-op when voice is disabled)."""
        self._started = True
        if not self._settings.voice_enabled:
            logger.warning("voice.disabled_no_credentials")
            return
        await self._load_accounts()
        self._subscribe_events()
        logger.info(
            "voice.manager.started",
            extra=log_extra(accounts=len(self._accounts)),
        )

    async def _load_accounts(self) -> None:
        """Connect every enabled account; failures degrade, never crash."""
        try:
            rows = await self._repo.list_accounts()
        except Exception as exc:  # noqa: BLE001 — DB outage must not kill startup
            logger.error(
                "voice.accounts_load_failed", extra=log_extra(error=str(exc)[:200])
            )
            return
        for row in rows:
            if row.status == "disabled":
                logger.info(
                    "voice.account_skipped_disabled",
                    extra=log_extra(account_id=row.id, label=row.label),
                )
                continue
            client = VoiceAccountClient(row, self._settings, self._cipher)
            try:
                await client.connect()
            except Exception as exc:  # noqa: BLE001 — one bad account ≠ dead engine
                message = str(exc)
                status = "auth_required" if "auth" in message.lower() else "offline"
                logger.warning(
                    "voice.account_start_failed",
                    extra=log_extra(
                        account_id=row.id,
                        label=row.label,
                        status=status,
                        error=message[:200],
                    ),
                )
                try:
                    await self._repo.set_status(row.id, status, error=message[:200])
                except Exception as exc2:  # noqa: BLE001
                    logger.warning(
                        "voice.account_status_write_failed",
                        extra=log_extra(account_id=row.id, error=str(exc2)[:160]),
                    )
                self._accounts[int(row.id)] = client
                continue
            try:
                await self._repo.set_status(row.id, "healthy")
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "voice.account_status_write_failed",
                    extra=log_extra(account_id=row.id, error=str(exc)[:160]),
                )
            row.status = "healthy"
            self._accounts[int(row.id)] = client

    def _subscribe_events(self) -> None:
        """Subscribe to failover events exactly once."""
        if self._subscribed:
            return
        self._events.subscribe("voice_failure", self._on_voice_failure)
        self._subscribed = True

    async def shutdown(self) -> None:
        """Release every session and disconnect every account."""
        for group_id, runtime in list(self._sessions.items()):
            try:
                await runtime.leave()
            except Exception as exc:  # noqa: BLE001 — shutdown is best-effort
                logger.warning(
                    "voice.shutdown.session_leave_failed",
                    extra=log_extra(session_id=runtime.session_id, error=str(exc)[:160]),
                )
            try:
                await self._repo.release_assignment_for_group(group_id)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "voice.shutdown.assignment_release_failed",
                    extra=log_extra(group_id=group_id, error=str(exc)[:160]),
                )
        self._sessions.clear()
        for client in list(self._accounts.values()):
            try:
                await client.disconnect()
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "voice.shutdown.disconnect_failed",
                    extra=log_extra(account_id=client.model.id, error=str(exc)[:160]),
                )
        self._accounts.clear()
        self._started = False
        if self._subscribed:
            self._events.unsubscribe("voice_failure", self._on_voice_failure)
            self._subscribed = False
        logger.info("voice.manager.stopped")

    async def reload_accounts(self) -> None:
        """Reload the account pool (admin "reconnect" action).

        Live sessions are released first — their runtimes hold references to
        the old (possibly dead) clients. Callers can immediately re-acquire.
        """
        if not self._settings.voice_enabled:
            logger.warning("voice.reload_disabled")
            return
        for group_id in list(self._sessions):
            await self.release(group_id)
        for client in list(self._accounts.values()):
            try:
                await client.disconnect()
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "voice.reload_disconnect_failed",
                    extra=log_extra(account_id=client.model.id, error=str(exc)[:160]),
                )
        self._accounts.clear()
        await self._load_accounts()
        logger.info(
            "voice.accounts_reloaded", extra=log_extra(accounts=len(self._accounts))
        )

    # ------------------------------------------------------------------
    # Session leases
    # ------------------------------------------------------------------
    def set_invite_provider(self, provider: "Callable[[int], Awaitable[str | None]] | None") -> None:
        """Attach the bot-backed invite-link provider used for auto-joining.

        The provider is expected to call the Bot API's
        ``create_chat_invite_link`` for the given chat id — i.e. the *bot*
        account must be a group admin with the "invite users via link"
        permission — and return the created (dedicated, non-primary) link.
        Passing ``None`` disables invite-link joining (membership
        must then be arranged manually) while membership *checks* stay on.
        """
        self._group_access.set_invite_provider(provider)
        logger.info(
            "voice.manager.invite_provider_set"
            if provider is not None
            else "voice.manager.invite_provider_cleared"
        )

    @property
    def group_access(self) -> GroupAccessService:
        """The group-access service (membership checks / auto-join state)."""
        return self._group_access

    def pick_client(self) -> tuple[VoiceAccountClient, Any] | None:
        """The best available account and its raw MTProto client.

        Used by the DM→group playback workflow to resolve group links and
        verify prerequisites (voice-chat existence, user membership)
        through a *connected* user account. Preference order: the account
        already serving the target group (not known here), then the
        assignment strategy's pick among accounts exposing a raw client.
        Returns ``None`` when no usable client exists (voice disabled or
        every account offline) — callers surface an actionable error.
        """
        candidates = [
            account
            for account in self._accounts.values()
            if getattr(account, "raw_client", None) is not None
        ]
        if not candidates:
            return None
        account = self._assignment.select(candidates) or candidates[0]
        client = getattr(account, "raw_client", None)
        if client is None:  # pragma: no cover — filtered above
            return None
        return account, client

    async def acquire(self, group_tg_id: int) -> VoiceSessionRuntime | None:
        """Lease a voice session for a group; ``None`` when no account fits."""
        group_tg_id = int(group_tg_id)
        async with self._group_lock(group_tg_id):
            existing = self._sessions.get(group_tg_id)
            if existing is not None:
                return existing

            account = self._assignment.select(list(self._accounts.values()))
            if account is None:
                logger.warning(
                    "voice.acquire_no_account", extra=log_extra(group_id=group_tg_id)
                )
                return None
            try:
                session_model = await self._repo.create_session(
                    group_tg_id, int(account.model.id)
                )
            except Exception as exc:  # noqa: BLE001 — treat as "unavailable"
                logger.error(
                    "voice.acquire_session_create_failed",
                    extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
                )
                return None
            try:
                await self._repo.record_assignment(
                    int(account.model.id), group_tg_id, session_model.id
                )
            except Exception as exc:  # noqa: BLE001 — audit trail is best-effort
                logger.warning(
                    "voice.acquire_assignment_failed",
                    extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
                )

            runtime = VoiceSessionRuntime(
                self._repo,
                session_model,
                account,
                self._events,
                duration_probe=self._probe_duration,
                heartbeat_interval=float(
                    self._settings.voice.health_check_interval or 0
                )
                or None,
            )
            self._sessions[group_tg_id] = runtime
            account.active_sessions += 1
            try:
                await self._repo.update_session(session_model.id, status="joining")
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "voice.acquire_status_write_failed",
                    extra=log_extra(session_id=session_model.id, error=str(exc)[:160]),
                )
            logger.info(
                "voice.acquired",
                extra=log_extra(
                    group_id=group_tg_id,
                    session_id=session_model.id,
                    account_id=account.model.id,
                    account_sessions=account.active_sessions,
                ),
            )
            return runtime

    async def release(self, group_tg_id: int) -> None:
        """Release the group's lease (account stays connected for reuse)."""
        group_tg_id = int(group_tg_id)
        runtime = self._sessions.pop(group_tg_id, None)
        if runtime is None:
            return
        account_id = int(runtime.account.model.id)
        try:
            await runtime.leave()
        except Exception as exc:  # noqa: BLE001 — release is best-effort
            logger.warning(
                "voice.release_leave_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
            )
        account = self._accounts.get(account_id)
        if account is not None:
            account.active_sessions = max(0, account.active_sessions - 1)
        try:
            await self._repo.release_assignment_for_group(group_tg_id)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "voice.release_assignment_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
            )
        logger.info(
            "voice.released",
            extra=log_extra(group_id=group_tg_id, account_id=account_id),
        )

    # ------------------------------------------------------------------
    # Playback control
    # ------------------------------------------------------------------
    async def play(self, group_tg_id: int, path: Path, *, duration: int | None = None) -> None:
        """Stream ``path`` into the group, acquiring a session if needed.

        For private groups the serving voice account's *group membership* is
        verified first (and, when ``voice.auto_join_enabled`` is on and the
        bot has invite-export rights, automatically joined via an invite
        link) — only then does the actual voice-chat connection happen.
        """
        runtime = self._sessions.get(int(group_tg_id)) or await self.acquire(group_tg_id)
        if runtime is None:
            raise VoiceAccountOfflineError(
                f"No voice account available for group {group_tg_id}"
            )
        await self._ensure_group_access(int(group_tg_id), runtime.account)
        await runtime.start_playback(Path(path), duration=duration)

    async def _ensure_group_access(
        self, group_tg_id: int, account: VoiceAccountClient
    ) -> None:
        """Guarantee the account can access the group before playback.

        Membership is verified through MTProto; when the account is not a
        member and automatic joining is enabled, the bot exports an invite
        link and the account imports it (:class:`GroupAccessService`). Any
        failure raises :class:`VoiceGroupAccessError` with an actionable,
        user-safe message (never a raw library error).
        """
        # ``getattr`` (not attribute access): the account pool contract only
        # guarantees ``transport``/``model`` — stub accounts in tests and
        # half-connected clients may not expose the raw MTProto client. No
        # client ⇒ no membership check possible; the transport layer will
        # surface a precise error of its own in that case.
        client = getattr(account, "raw_client", None)
        if client is None:
            logger.debug(
                "voice.group_access.skipped_no_client",
                extra=log_extra(
                    group_id=group_tg_id,
                    account_id=int(account.model.id),
                ),
            )
            return
        try:
            outcome = await self._group_access.ensure_access(
                client, group_tg_id, account_id=int(account.model.id)
            )
        except Exception as exc:  # noqa: BLE001 — classify unexpected failures
            logger.error(
                "voice.group_access.unexpected_error",
                extra=log_extra(
                    group_id=group_tg_id,
                    account_id=int(account.model.id),
                    error=str(exc)[:200],
                ),
            )
            raise VoiceGroupAccessError(
                f"Group access check failed for group {group_tg_id}"
            ) from exc
        if not outcome.ok:
            logger.warning(
                "voice.group_access.denied",
                extra=log_extra(
                    group_id=group_tg_id,
                    account_id=int(account.model.id),
                    status=outcome.status,
                    detail=outcome.detail[:200],
                ),
            )
            raise VoiceGroupAccessError(
                f"Group access failed ({outcome.status}): {outcome.detail[:160]}",
                user_message=outcome.user_message,
            )
        if outcome.joined:
            try:
                await self._events.publish(
                    "voice:group_joined", group_id=group_tg_id
                )
            except Exception as exc:  # noqa: BLE001 — events must not break flow
                logger.debug(
                    "voice.group_access.event_failed",
                    extra=log_extra(error=str(exc)[:160]),
                )

    async def pause(self, group_tg_id: int) -> None:
        """Pause the group's stream."""
        await self._require_runtime(group_tg_id).pause()

    async def resume(self, group_tg_id: int) -> None:
        """Resume the group's stream."""
        await self._require_runtime(group_tg_id).resume()

    async def stop_stream(self, group_tg_id: int) -> None:
        """Stop the audio but stay in the voice chat."""
        await self._require_runtime(group_tg_id).stop_playback()

    async def stop(self, group_tg_id: int) -> None:
        """Alias of :meth:`stop_stream` (VoiceGateway compatibility)."""
        await self.stop_stream(group_tg_id)

    async def set_volume(self, group_tg_id: int, volume: int) -> None:
        """Adjust the outgoing stream volume for the group."""
        runtime = self._require_runtime(group_tg_id)
        transport = runtime.account.transport
        if transport is None:
            raise VoiceError("Voice account has no active transport")
        await transport.set_volume(int(group_tg_id), int(volume))

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------
    async def status(self) -> VoiceEngineStatus:
        """Engine snapshot for the admin panel (never includes secrets)."""
        summaries = [
            VoiceAccountSummary(
                label=account.label,
                account_id=account_id,
                status=str(account.model.status or "offline"),
                active_sessions=account.active_sessions,
                max_sessions=account.max_sessions,
            )
            for account_id, account in sorted(self._accounts.items())
        ]
        return VoiceEngineStatus(
            accounts=summaries,
            total_accounts=len(summaries),
            healthy_accounts=sum(1 for item in summaries if item.status == "healthy"),
            active_sessions=sum(item.active_sessions for item in summaries),
        )

    async def list_active_sessions(self) -> list[VoiceSession]:
        """All live group sessions (DB view)."""
        try:
            return await self._repo.active_sessions()
        except Exception as exc:  # noqa: BLE001 — introspection must not raise
            logger.error(
                "voice.list_sessions_failed", extra=log_extra(error=str(exc)[:160])
            )
            return []

    async def check_account_group_access(
        self, account_id: int, group_tg_id: int
    ) -> dict[str, Any] | None:
        """Check one account's access to a group (admin UI).

        Returns ``None`` when the account is unknown/not loaded. The result
        dict is safe for display: it contains only the membership state,
        auto-join configuration and cooldown info — never links, hashes,
        phone numbers or session data.
        """
        account = self._accounts.get(int(account_id))
        if account is None:
            return None
        client = getattr(account, "raw_client", None)
        if client is None:
            return {
                "account_id": int(account_id),
                "label": account.label,
                "group_id": int(group_tg_id),
                "membership": "offline",
                "auto_join_enabled": self._group_access.auto_join_enabled,
                "cooldown_seconds": 0,
            }
        membership = await self._group_access.check_membership(
            client, group_tg_id, account_id=int(account_id)
        )
        state = {
            True: "member",
            False: "not_member",
            None: "unknown",
        }[membership]
        return {
            "account_id": int(account_id),
            "label": account.label,
            "group_id": int(group_tg_id),
            "membership": state,
            "auto_join_enabled": self._group_access.auto_join_enabled,
            "cooldown_seconds": round(
                self._group_access.cooldown_remaining(group_tg_id)
            ),
        }

    async def account_info(self, account_id: int) -> dict[str, Any] | None:
        """Detailed info for one account (admin UI); ``None`` when unknown."""
        client = self._accounts.get(int(account_id))
        if client is None:
            return None
        try:
            health_rows = await self._repo.latest_health(int(account_id), limit=5)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "voice.account_info_health_failed",
                extra=log_extra(account_id=account_id, error=str(exc)[:160]),
            )
            health_rows = []
        return {
            "account_id": int(client.model.id),
            "label": client.label,
            "status": str(client.model.status or "offline"),
            "telegram_id": client.telegram_id,
            "username": client.username,
            "active_sessions": client.active_sessions,
            "max_sessions": client.max_sessions,
            "last_health_check_at": (
                client.model.last_health_check_at.isoformat()
                if client.model.last_health_check_at
                else None
            ),
            "recent_health": [
                {
                    "status": row.status,
                    "latency_ms": row.latency_ms,
                    "error": row.error,
                    "checked_at": (
                        row.checked_at.isoformat() if row.checked_at else None
                    ),
                }
                for row in health_rows
            ],
        }

    async def run_health_checks(self) -> dict[int, str]:
        """Check every account and refresh in-memory status summaries."""
        results = await self._health.run_checks(list(self._accounts.values()))
        for account_id, status in results.items():
            client = self._accounts.get(account_id)
            if client is not None:
                client.model.status = status
        if results:
            try:
                await self._cache.set(
                    "voice:health",
                    {str(key): value for key, value in results.items()},
                    ttl=self._settings.voice.health_check_interval or 60,
                )
            except Exception as exc:  # noqa: BLE001 — cache is optional
                logger.debug(
                    "voice.health_cache_failed", extra=log_extra(error=str(exc)[:160])
                )
        return results

    # ------------------------------------------------------------------
    # Idle-timeout release
    # ------------------------------------------------------------------
    async def release_idle_sessions(
        self,
        timeout_minutes: float | None = None,
        *,
        resolver: "Callable[[int], Awaitable[float]] | None" = None,
    ) -> list[int]:
        """Release voice sessions idle for longer than the timeout.

        A session counts as idle when it is NOT actively playing (paused,
        joining, or stalled) and no user interaction (pause/resume/stop/play)
        happened within the idle window. Sessions mid-track are never
        released. The timeout resolves per group via ``resolver`` (e.g.
        group settings) when provided, else ``timeout_minutes``, else the
        global ``settings.voice.idle_timeout_minutes``.

        Returns the list of released group ids.
        """
        if not self._sessions:
            return []
        default_timeout = timeout_minutes or self._settings.voice.idle_timeout_minutes or 5.0
        released: list[int] = []
        for group_id, runtime in list(self._sessions.items()):
            try:
                threshold_minutes = (
                    float(await resolver(group_id))
                    if resolver is not None
                    else default_timeout
                )
            except Exception as exc:  # noqa: BLE001 — fall back to the default
                logger.debug(
                    "voice.idle_resolver_failed",
                    extra=log_extra(group_id=group_id, error=str(exc)[:120]),
                )
                threshold_minutes = default_timeout
            threshold_seconds = max(0.0, threshold_minutes * 60.0)
            if runtime.status == "playing":
                continue  # never interrupt live playback
            if runtime.idle_seconds < threshold_seconds:
                continue
            logger.info(
                "voice.idle_released",
                extra=log_extra(
                    group_id=group_id,
                    idle_seconds=round(runtime.idle_seconds),
                    timeout_minutes=round(threshold_minutes, 1),
                ),
            )
            await self.release(group_id)
            released.append(group_id)
            try:
                await self._events.publish(
                    "voice:idle_released", group_id=group_id
                )
            except Exception as exc:  # noqa: BLE001 — event bus must not break release
                logger.debug(
                    "voice.idle_event_failed", extra=log_extra(error=str(exc)[:120])
                )
        return released

    # ------------------------------------------------------------------
    # Feature flags
    # ------------------------------------------------------------------
    async def is_voice_enabled(self) -> bool:
        """True when the voice engine is configured (api id/hash + key).

        Awaitable per CONTRACTS.md section 4 — the playback controller awaits
        this through the VoiceGateway protocol.
        """
        return bool(self._settings.voice_enabled)

    def has_accounts(self) -> bool:
        """True when the pool holds at least one configured account."""
        return bool(self._accounts)

    @property
    def failover(self) -> FailoverController:
        """The failover controller (for wiring / admin actions)."""
        return self._failover

    # ------------------------------------------------------------------
    # Event handling
    # ------------------------------------------------------------------
    async def _on_voice_failure(self, event: Event) -> None:
        """Handle ``voice_failure:<group_id>`` — release + re-acquire.

        Event handlers must never raise; every failure is logged instead.
        """
        group_id = event.data.get("group_id")
        if group_id is None:
            return
        try:
            await self.release(int(group_id))
            runtime = await self.acquire(int(group_id))
            if runtime is not None:
                await self._events.publish("voice:reassigned", group_id=int(group_id))
        except Exception as exc:  # noqa: BLE001 — never raise from handlers
            logger.error(
                "voice.failure_reassign_failed",
                extra=log_extra(group_id=group_id, error=str(exc)[:200]),
            )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    def _group_lock(self, group_id: int) -> asyncio.Lock:
        """Per-group mutex making session acquisition single-flight."""
        return self._group_locks.setdefault(int(group_id), asyncio.Lock())

    def _require_runtime(self, group_tg_id: int) -> VoiceSessionRuntime:
        """Return the group's runtime or raise :class:`VoiceNotJoinedError`."""
        runtime = self._sessions.get(int(group_tg_id))
        if runtime is None:
            raise VoiceNotJoinedError(f"No active voice session for group {group_tg_id}")
        return runtime

    def _get_ffmpeg(self) -> FFmpegToolkit:
        """Lazily built ffprobe toolkit for duration probing."""
        if self._ffmpeg is None:
            self._ffmpeg = FFmpegToolkit(self._settings)
        return self._ffmpeg

    async def _probe_duration(self, path: Path) -> int:
        """Best-effort track duration (0 disables the auto-advance timer)."""
        try:
            meta = await self._get_ffmpeg().extract_metadata(path)
            return int(meta.duration_seconds or 0)
        except Exception as exc:  # noqa: BLE001 — degraded playback, not an error
            logger.warning(
                "voice.play_duration_probe_failed",
                extra=log_extra(path=Path(path).name, error=str(exc)[:160]),
            )
            return 0


__all__ = ["VoiceAccountSummary", "VoiceEngineStatus", "VoiceManager"]

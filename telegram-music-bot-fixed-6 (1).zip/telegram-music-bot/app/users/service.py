"""User lifecycle service: registration, account summary, group memberships."""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Protocol

from app.database.models import User
from app.database.repositories.groups import GroupMemberRepository, GroupRepository
from app.database.repositories.library import LikedTrackRepository, ListeningHistoryRepository
from app.database.repositories.playlists import PlaylistRepository
from app.database.repositories.users import UserPreferenceRepository, UserRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)


class QueueSizeLike(Protocol):
    """Duck-typed queue dependency (``QueueRepository`` from Task 2-b).

    A ``QueueManager`` exposing ``size(owner)`` is also accepted — see
    :func:`_queue_size`.
    """

    async def size(self, owner_type: str, owner_id: int) -> int: ...


@dataclass(frozen=True, slots=True)
class _OwnerRef:
    """Minimal ``QueueOwner`` duck used with QueueManager-style queues."""

    kind: str
    id: int

    def topic(self) -> str:
        return f"{self.kind}:{self.id}"


async def _maybe_await(value: Any) -> Any:
    """Await coroutine-like results; pass plain values through."""
    if inspect.isawaitable(value):
        return await value
    return value


async def _queue_size(queue: Any, owner_type: str, owner_id: int) -> int:
    """Best-effort queue size lookup that never raises.

    Accepts a repository exposing ``size(owner_type, owner_id)`` or a manager
    exposing ``size(owner)`` (QueueOwner duck).
    """
    if queue is None:
        return 0
    try:
        return int(await _maybe_await(queue.size(owner_type, owner_id)))
    except TypeError:
        pass  # fall through to the QueueManager-style call
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "users.queue_size_failed", extra=log_extra(error=str(exc)[:200])
        )
        return 0
    try:
        return int(await _maybe_await(queue.size(_OwnerRef(owner_type, owner_id))))
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "users.queue_size_failed", extra=log_extra(error=str(exc)[:200])
        )
        return 0


class UserService:
    """High-level user operations (CONTRACTS §6).

    Primary dependencies are injected positionally; optional repositories
    enrich :meth:`account_summary` and :meth:`my_groups` when available.
    """

    def __init__(
        self,
        users: UserRepository,
        prefs: UserPreferenceRepository,
        members: GroupMemberRepository,
        groups: GroupRepository,
        *,
        history: ListeningHistoryRepository | None = None,
        queue: QueueSizeLike | None = None,
        likes: LikedTrackRepository | None = None,
        playlists: PlaylistRepository | None = None,
    ) -> None:
        self.users = users
        self.prefs = prefs
        self.members = members
        self.groups = groups
        self.history = history
        self.queue = queue
        self.likes = likes
        self.playlists = playlists

    async def get_or_create(self, message_from: Any) -> User:
        """Register/refresh a user from an aiogram ``message.from_user``-like object.

        The object is duck-typed (``id``, ``username``, ``first_name``,
        ``language_code``); ``last_seen_at`` is refreshed and the default
        preferences row is guaranteed to exist.
        """
        if message_from is None:
            raise ValidationError(
                "message_from is required", user_message="❌ This message has no sender."
            )
        tg_id = getattr(message_from, "id", None)
        if not isinstance(tg_id, int) or tg_id == 0:
            raise ValidationError(
                "message_from.id must be a Telegram user id",
                user_message="❌ This message has no sender.",
            )
        username = getattr(message_from, "username", None)
        first_name = getattr(message_from, "first_name", None)
        user = await self.users.get_or_create(tg_id, username=username, first_name=first_name)
        language_code = getattr(message_from, "language_code", None)
        if language_code and language_code != user.language:
            user = await self.users.update_profile(tg_id, language=language_code) or user
        return user

    async def get(self, tg_id: int) -> User | None:
        """Fetch a user (with preferences) or None."""
        return await self.users.get_by_telegram_id(tg_id)

    async def account_summary(self, tg_id: int) -> dict[str, Any]:
        """Aggregated account numbers for the profile screen.

        Returns ``{"user": User, "plays": int, "likes": int, "playlists": int,
        "groups": int}``. Counts served by non-injected repositories fall back
        to zero (plays falls back to the denormalized ``user.play_count``).
        """
        user = await self.users.get_by_telegram_id(tg_id)
        if user is None:
            raise ValidationError(
                f"Unknown user {tg_id}", user_message="ℹ️ Please press /start to begin."
            )
        if self.history is not None:
            plays = await self.history.count_for_user(user.id)
        else:
            plays = int(user.play_count or 0)
        likes = await self.likes.count(user.id) if self.likes is not None else 0
        playlists = (
            await self.playlists.count_for_user(user.id) if self.playlists is not None else 0
        )
        groups = await self.groups.groups_of_user(tg_id)
        return {
            "user": user,
            "plays": plays,
            "likes": likes,
            "playlists": playlists,
            "groups": len(groups),
        }

    async def my_groups(self, tg_id: int) -> list[dict[str, Any]]:
        """Groups the user belongs to: ``{"group", "settings", "queue_size"}``.

        Group status flags (bot active / voice active) are computed by the bot
        layer; the queue size is served by the injected queue dependency.
        """
        entries: list[dict[str, Any]] = []
        for group in await self.groups.groups_of_user(tg_id):
            settings = group.settings
            if settings is None:  # legacy row without settings — heal it
                group = await self.groups.get_or_create(
                    group.telegram_id, group.title, type=group.type
                )
                settings = group.settings
            entries.append(
                {
                    "group": group,
                    "settings": settings,
                    "queue_size": await _queue_size(self.queue, "group", group.telegram_id),
                }
            )
        return entries

    async def set_blocked(self, tg_id: int, blocked: bool) -> bool:
        """Block/unblock a user. True when a row was updated."""
        updated = await self.users.set_blocked(tg_id, blocked)
        logger.info(
            "users.blocked_changed",
            extra=log_extra(tg_id=tg_id, blocked=bool(blocked)),
        )
        return updated


__all__ = ["UserService"]

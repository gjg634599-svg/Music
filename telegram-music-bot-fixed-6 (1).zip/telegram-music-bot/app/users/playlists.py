"""Playlist management and one-shot playlist queueing.

``user_db_id`` arguments are database ``users.id`` values — resolve them via
``UserService.get_or_create(...).id`` in the bot layer.
"""

from __future__ import annotations

import html
import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol, Sequence

from app.database.models import Playlist, Track
from app.database.repositories.playlists import PlaylistRepository
from app.errors import PermissionDeniedError, ValidationError
from app.logging import get_logger, log_extra
from app.music.normalizer import normalize_text
from app.utils.formatting import escape, format_duration

if TYPE_CHECKING:  # cross-task types (Task 2-b) — annotations only
    from app.playback.queue import QueueManager, QueueOwner

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Import: parse + result types
# ---------------------------------------------------------------------------
#: Maximum parsed track lines accepted by :meth:`PlaylistService.import_text`.
MAX_IMPORT_LINES = 50

#: Fallback playlist title when the pasted text has no recognizable header.
IMPORT_FALLBACK_TITLE = "Imported Playlist"

#: Export header: ``📋 <b>Title</b> · playlist export``.
_HEADER_RE = re.compile(r"^\s*📋\s*<b>(?P<title>.*?)</b>", re.IGNORECASE)

#: Standalone description line: ``<i>description</i>``.
_DESCRIPTION_RE = re.compile(r"^\s*<i>(?P<description>.*?)</i>\s*$", re.IGNORECASE)

#: Numbered track line: ``1. rest`` or ``1) rest``.
_NUMBERED_RE = re.compile(r"^\s*(?P<number>\d+)[.)]\s+(?P<rest>.+?)\s*$")

#: Trailing duration: ``<i>(3:45)</i>``.
_DURATION_RE = re.compile(r"\s*<i>\((?P<duration>[0-9:]+)\)</i>\s*$")

#: Export footer line: ``⏱️ Total ... · N tracks``.
_FOOTER_RE = re.compile(r"^\s*⏱")

#: Title/artist separators: em dash, en dash or `` - `` (spaced hyphen).
_ARTIST_SPLIT_RE = re.compile(r"\s+[—–]\s+|\s+-\s+")

#: The only tags :meth:`PlaylistService.export_text` ever emits.
_TAG_RE = re.compile(r"</?[biu]>")


@dataclass(slots=True)
class ImportLine:
    """One parsed track line from an import text."""

    number: int
    title: str
    artist: str | None = None
    duration: str | None = None


@dataclass(slots=True)
class ImportResult:
    """Outcome of :meth:`PlaylistService.import_text`."""

    playlist: Playlist
    matched: list[Any] = field(default_factory=list)
    unmatched: list[ImportLine] = field(default_factory=list)


class ImportSearch(Protocol):
    """Callable resolving a query into candidate tracks (best first).

    :meth:`app.music.service.MusicService.search` satisfies this protocol;
    tests inject fakes backed by the seeded catalog.
    """

    async def __call__(self, query: str, limit: int = 5) -> Sequence[Any]: ...  # pragma: no cover


def _clean_fragment(fragment: str) -> str:
    """Reverse of :func:`app.utils.formatting.escape`: strip tags, unescape."""
    return html.unescape(_TAG_RE.sub("", fragment)).strip()


def parse_export_text(text: str) -> tuple[str, str | None, list[ImportLine]]:
    """Parse an exported playlist (or a plain numbered list) back to parts.

    Recognizes the exact format produced by
    :meth:`PlaylistService.export_text` (header, optional description,
    numbered ``Title — Artist <i>(m:ss)</i>`` lines, footer) and the looser
    plain-list form users paste manually (``1. Artist - Title`` with or
    without artist/duration). Returns ``(title, description, lines)`` —
    the title is empty when no header was found.
    """
    title = ""
    description: str | None = None
    lines: list[ImportLine] = []
    seen_tracks = False
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        if not seen_tracks:
            header = _HEADER_RE.match(line)
            if header is not None:
                title = _clean_fragment(header.group("title"))
                continue
            desc = _DESCRIPTION_RE.match(line)
            if desc is not None and desc.group("description").strip():
                description = _clean_fragment(desc.group("description"))
                continue
        if _FOOTER_RE.match(line):
            continue
        numbered = _NUMBERED_RE.match(line)
        if numbered is None:
            continue  # free text — skipped
        seen_tracks = True
        rest = numbered.group("rest")
        duration: str | None = None
        duration_match = _DURATION_RE.search(rest)
        if duration_match is not None:
            duration = duration_match.group("duration")
            rest = rest[: duration_match.start()].rstrip()
        rest = _clean_fragment(rest)
        if not rest:
            continue
        artist: str | None = None
        title_part = rest
        split = _ARTIST_SPLIT_RE.split(rest, maxsplit=1)
        if len(split) == 2 and split[0].strip() and split[1].strip():
            title_part, artist = split[0].strip(), split[1].strip()
        lines.append(
            ImportLine(
                number=int(numbered.group("number")),
                title=title_part[:256],
                artist=(artist[:256] if artist else None),
                duration=duration,
            )
        )
    return title, description, lines[:MAX_IMPORT_LINES]


def _track_artist_name(candidate: Any) -> str:
    """Artist name of a catalog track, tolerating detached ORM rows."""
    try:
        artist = getattr(candidate, "artist", None)
        return (artist.name or "") if artist is not None else ""
    except Exception:  # noqa: BLE001 — detached rows must never crash import
        return ""


def _match_score(line: ImportLine, candidate: Any) -> int:
    """Similarity of a parsed line to a search candidate (0 = no match)."""
    title_a = normalize_text(line.title)
    title_b = normalize_text(str(getattr(candidate, "title", "") or ""))
    if not title_a or not title_b:
        return 0
    score = 0
    if title_a == title_b:
        score += 3
    elif title_a in title_b or title_b in title_a:
        score += 2
    artist_a = normalize_text(line.artist or "")
    if artist_a:
        artist_b = normalize_text(_track_artist_name(candidate))
        if artist_a and artist_a == artist_b:
            score += 2
        elif artist_a and (artist_a in artist_b or artist_b in artist_a):
            score += 1
    return score


def _best_match(line: ImportLine, candidates: Sequence[Any]) -> Any | None:
    """Highest-scoring candidate above zero, else ``None``."""
    best: Any = None
    best_score = 0
    for candidate in candidates:
        score = _match_score(line, candidate)
        if score > best_score:
            best, best_score = candidate, score
    return best


class PlaylistService:
    """CRUD + queueing for user playlists (CONTRACTS §6)."""

    def __init__(self, playlists: PlaylistRepository) -> None:
        self.playlists = playlists

    async def create(
        self, user_db_id: int, title: str, description: str | None = None
    ) -> Playlist:
        """Create a playlist owned by the user."""
        return await self.playlists.create(user_db_id, title, description)

    async def my_playlists(self, user_db_id: int) -> list[Playlist]:
        """All playlists of the user (items eager-loaded for counts)."""
        return await self.playlists.list_for_user(user_db_id)

    async def get(self, playlist_id: int) -> Playlist | None:
        """Fetch a playlist with ordered items (tracks eager-loaded)."""
        return await self.playlists.get(playlist_id)

    async def rename(
        self, playlist_id: int, user_db_id: int, title: str
    ) -> Playlist | None:
        """Rename an owned playlist.

        Raises:
            PermissionDeniedError: when the playlist belongs to someone else.
        """
        existing = await self.playlists.get(playlist_id)
        if existing is None:
            return None
        if existing.user_id != user_db_id:
            raise PermissionDeniedError(
                f"User #{user_db_id} cannot rename playlist #{playlist_id}",
                user_message="❌ You can only edit your own playlists.",
            )
        return await self.playlists.rename(playlist_id, user_db_id, title)

    async def delete(self, playlist_id: int, user_db_id: int) -> bool:
        """Delete an owned playlist (items cascade).

        Raises:
            PermissionDeniedError: when the playlist belongs to someone else.
        """
        existing = await self.playlists.get(playlist_id)
        if existing is None:
            return False
        if existing.user_id != user_db_id:
            raise PermissionDeniedError(
                f"User #{user_db_id} cannot delete playlist #{playlist_id}",
                user_message="❌ You can only delete your own playlists.",
            )
        return await self.playlists.delete(playlist_id, user_db_id)

    async def add_track(
        self, playlist_id: int, track_id: int, added_by: int | None = None
    ) -> bool:
        """Append a track (deduplicated). False when already present."""
        return await self.playlists.add_track(playlist_id, track_id, added_by=added_by)

    async def remove_track(self, playlist_id: int, track_id: int) -> bool:
        """Remove a track. True when a row was removed."""
        return await self.playlists.remove_track(playlist_id, track_id)

    async def tracks(self, playlist_id: int) -> list[Track]:
        """Ordered tracks of a playlist (empty when the playlist is unknown)."""
        playlist = await self.playlists.get(playlist_id)
        if playlist is None:
            return []
        return [item.track for item in playlist.items if item.track is not None]

    async def track_ids(self, playlist_id: int) -> list[int]:
        """Ordered track ids of a playlist."""
        return await self.playlists.track_ids(playlist_id)

    async def export_text(self, playlist_id: int, user_db_id: int) -> str:
        """Render an owned playlist as a shareable, forwardable HTML message.

        The export is a standalone text message (no keyboard) so the user can
        forward it to any chat. Content is HTML-escaped; long playlists are
        truncated to the Telegram message limit.

        Raises:
            ValidationError: when the playlist does not exist or is empty.
            PermissionDeniedError: when the playlist belongs to someone else.
        """
        playlist = await self.playlists.get(playlist_id)
        if playlist is None:
            raise ValidationError(
                f"Playlist #{playlist_id} not found", user_message="❌ Playlist not found."
            )
        if playlist.user_id != user_db_id:
            raise PermissionDeniedError(
                f"User #{user_db_id} cannot export playlist #{playlist_id}",
                user_message="❌ You can only export your own playlists.",
            )
        tracks = [item.track for item in playlist.items if item.track is not None]
        if not tracks:
            raise ValidationError(
                f"Playlist #{playlist_id} is empty", user_message="📋 This playlist is empty."
            )

        total_seconds = sum(t.duration_seconds or 0 for t in tracks)
        lines = [
            f"📋 <b>{escape(playlist.title)}</b> · playlist export",
        ]
        if playlist.description:
            lines.append(f"<i>{escape(playlist.description)}</i>")
        lines.append("")
        for index, track in enumerate(tracks, start=1):
            line = f"{index}. {escape(track.title)}"
            artist = ""
            try:
                artist = (track.artist.name or "") if track.artist is not None else ""
            except Exception:  # noqa: BLE001 — detached rows must never crash us
                artist = ""
            if artist:
                line += f" — {escape(artist)}"
            if track.duration_seconds:
                line += f" <i>({format_duration(track.duration_seconds)})</i>"
            lines.append(line)
        lines.append("")
        lines.append(
            f"⏱️ Total {format_duration(total_seconds)} · {len(tracks)} tracks"
        )
        text = "\n".join(lines)
        if len(text) > 4000:
            # keep the footer visible when truncating a very long export
            keep = 4000 - len(lines[-1]) - 1
            text = text[:keep].rsplit("\n", 1)[0] + "\n…\n" + lines[-1]
        logger.info(
            "playlists.exported",
            extra=log_extra(playlist_id=playlist_id, tracks=len(tracks)),
        )
        return text

    async def import_text(
        self, user_db_id: int, text: str, search: ImportSearch
    ) -> ImportResult:
        """Build a new playlist from an export text (or plain numbered list).

        The inverse of :meth:`export_text`: every parsed line is resolved
        through the injected *search* callable (the music platform's
        multi-source search), the best match is added to a freshly created
        playlist and lines without a plausible match are reported back.
        The playlist is only created when at least one line matched, so a
        failed import leaves no empty shell behind.

        Args:
            user_db_id: Owner of the new playlist.
            text: Forwarded/pasted export or numbered track list.
            search: Async callable ``(query, limit) -> candidates``.

        Returns:
            :class:`ImportResult` with the playlist and per-line outcomes.

        Raises:
            ValidationError: when no track lines could be parsed or nothing
                matched (no playlist is created in either case).
        """
        title, description, lines = parse_export_text(text)
        if not lines:
            raise ValidationError(
                "No track lines found in import text",
                user_message=(
                    "❌ I couldn't find any tracks in that text.\n"
                    "Send me a playlist export or a numbered list like\n"
                    "<code>1. Title — Artist</code>"
                ),
            )

        matched: dict[int, Any] = {}
        unmatched: list[ImportLine] = []
        for line in lines:
            query = f"{line.title} {line.artist}".strip() if line.artist else line.title
            try:
                candidates = list(await search(query, limit=5))
            except Exception as exc:  # noqa: BLE001 — one query failing must not kill the import
                logger.warning(
                    "playlists.import_search_failed",
                    extra=log_extra(error=str(exc)[:160]),
                )
                unmatched.append(line)
                continue
            best = _best_match(line, candidates)
            if best is None:
                unmatched.append(line)
                continue
            matched[int(best.id)] = best

        if not matched:
            raise ValidationError(
                "No imported line matched the catalog",
                user_message="😔 None of these tracks matched — try a different list.",
            )

        playlist = await self.playlists.create(
            user_db_id,
            title[:128] if title else IMPORT_FALLBACK_TITLE,
            description,
        )
        result = ImportResult(playlist=playlist)
        for track in matched.values():
            await self.playlists.add_track(playlist.id, int(track.id))
            result.matched.append(track)
        result.unmatched = unmatched
        logger.info(
            "playlists.imported",
            extra=log_extra(
                playlist_id=playlist.id,
                matched=len(result.matched),
                unmatched=len(unmatched),
            ),
        )
        return result

    async def queue_playlist(
        self,
        owner: QueueOwner,
        playlist_id: int,
        queue: QueueManager,
    ) -> int:
        """Enqueue every track of a playlist in order via ``queue.add``.

        Returns the number of tracks added. Errors from the queue (e.g. queue
        full) propagate to the caller after partial adds.
        """
        playlist = await self.playlists.get(playlist_id)
        if playlist is None:
            raise ValidationError(
                f"Playlist #{playlist_id} not found", user_message="❌ Playlist not found."
            )
        ids = await self.playlists.track_ids(playlist_id)
        if not ids:
            raise ValidationError(
                f"Playlist #{playlist_id} is empty", user_message="📋 This playlist is empty."
            )
        added_by = owner.id if getattr(owner, "kind", "") == "user" else None
        added = 0
        for track_id in ids:
            await queue.add(owner, track_id, added_by)
            added += 1
        logger.info(
            "playlists.queued",
            extra=log_extra(playlist_id=playlist_id, tracks=added),
        )
        return added


__all__ = [
    "IMPORT_FALLBACK_TITLE",
    "ImportLine",
    "ImportResult",
    "MAX_IMPORT_LINES",
    "PlaylistService",
    "parse_export_text",
]

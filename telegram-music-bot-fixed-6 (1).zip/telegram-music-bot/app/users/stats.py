"""Personal listening statistics — the data behind ``/mystats``.

:class:`UserStatsService` aggregates one user's listening history, likes and
artist play counts into a :class:`UserStats` value object and renders it as
the Telegram HTML message shown by the ``/mystats`` command and the
``dash:stats`` dashboard action.

Design notes:

* The service talks to repositories through their public methods only
  (``ListeningHistoryRepository`` aggregations, ``LikedTrackRepository``
  counts, ``TrackRepository``/``ArtistRepository`` lookups, and
  ``UserRepository`` for tg-id resolution) — no SQL leaks into this layer.
* Every aggregation degrades gracefully: a user with no history at all gets
  a friendly empty state, never an exception.
* Output is HTML with every dynamic value escaped (the handler passes
  ``parse_mode="HTML"``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from html import escape
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from app.errors import ValidationError
from app.logging import get_logger, log_extra

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models.music import Artist, Track

logger = get_logger(__name__)

#: Top tracks listed in the message.
TOP_TRACKS_LIMIT = 5

#: Top artists listed in the message.
TOP_ARTISTS_LIMIT = 3

#: History rows backing the "recently played" count.
RECENT_LIMIT = 50

#: Cap for the unique-track count (matches the repo's history cap).
UNIQUE_TRACKS_LIMIT = 1000


@runtime_checkable
class _StatsUserRepo(Protocol):
    async def get_by_telegram_id(self, tg_id: int) -> Any: ...


@runtime_checkable
class _StatsHistoryRepo(Protocol):
    async def count_for_user(self, user_db_id: int) -> int: ...

    async def play_counts(self, user_db_id: int, limit: int = 200) -> dict[int, int]: ...

    async def artist_play_counts(self, user_db_id: int) -> dict[int, int]: ...

    async def listening_seconds(self, user_db_id: int) -> int: ...

    async def recent(self, user_db_id: int, limit: int = 20) -> list[Any]: ...


@runtime_checkable
class _StatsLikedRepo(Protocol):
    async def count(self, user_db_id: int) -> int: ...


@runtime_checkable
class _StatsTrackRepo(Protocol):
    async def get_by_id(self, track_id: int) -> "Track | None": ...


@runtime_checkable
class _StatsArtistRepo(Protocol):
    async def get_by_ids(self, artist_ids: list[int]) -> list["Artist"]: ...


@dataclass(slots=True)
class UserStats:
    """Aggregated listening facts for one user."""

    tg_user_id: int = 0
    total_plays: int = 0
    unique_tracks: int = 0
    liked_count: int = 0
    listening_seconds: int = 0
    recent_tracks: int = 0
    #: (track model, play count) — most played first.
    top_tracks: list[tuple["Track", int]] = field(default_factory=list)
    #: (artist id, play count) — names are resolved at render time.
    top_artists: list[tuple[int, int]] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        """True when the user has no listening signal at all."""
        return self.total_plays == 0 and self.liked_count == 0

    @property
    def listening_time_label(self) -> str:
        """Human ``1h 23m`` / ``4m 05s`` label for the listening time."""
        seconds = max(0, int(self.listening_seconds))
        hours, rem = divmod(seconds, 3600)
        minutes, secs = divmod(rem, 60)
        if hours:
            return f"{hours}h {minutes:02d}m"
        if minutes:
            return f"{minutes}m {secs:02d}s"
        return f"{secs}s"


class UserStatsService:
    """Build and render :class:`UserStats` for the ``/mystats`` screen."""

    def __init__(
        self,
        history_repo: _StatsHistoryRepo,
        liked_repo: _StatsLikedRepo,
        tracks_repo: _StatsTrackRepo,
        artists_repo: _StatsArtistRepo,
        users_repo: _StatsUserRepo,
    ) -> None:
        self._history = history_repo
        self._liked = liked_repo
        self._tracks = tracks_repo
        self._artists = artists_repo
        self._users = users_repo

    # ------------------------------------------------------------------
    # Aggregation
    # ------------------------------------------------------------------
    async def build(self, tg_user_id: int) -> UserStats:
        """Aggregate one user's listening stats (tg id in, stats out)."""
        tg_user_id = int(tg_user_id)
        user = await self._users.get_by_telegram_id(tg_user_id)
        if user is None:
            raise ValidationError(f"Unknown user: {tg_user_id}")
        user_db_id = int(user.id)

        stats = UserStats(tg_user_id=tg_user_id)

        # Every aggregation is independent — one failing query must never
        # take the whole screen down.
        stats.total_plays = await self._safe(
            self._history.count_for_user(user_db_id), 0
        )
        stats.listening_seconds = await self._safe(
            self._history.listening_seconds(user_db_id), 0
        )
        stats.liked_count = await self._safe(self._liked.count(user_db_id), 0)
        recent_rows = await self._safe(
            self._history.recent(user_db_id, limit=RECENT_LIMIT), []
        )
        stats.recent_tracks = len(recent_rows or [])

        play_counts: dict[int, int] = await self._safe(
            self._history.play_counts(user_db_id, limit=UNIQUE_TRACKS_LIMIT), {}
        )
        stats.unique_tracks = len(play_counts)
        if not play_counts and recent_rows:
            # play_counts aggregation failed — derive a best-effort count
            # from the recent-history rows instead.
            stats.unique_tracks = len(
                {row.track_id for row in recent_rows if getattr(row, "track_id", None)}
            )

        stats.top_tracks = await self._top_tracks(play_counts)
        artist_counts: dict[int, int] = await self._safe(
            self._history.artist_play_counts(user_db_id), {}
        )
        stats.top_artists = self._top_artists(artist_counts)

        return stats

    async def _top_tracks(self, play_counts: dict[int, int]) -> list[tuple["Track", int]]:
        """Hydrate the most-played tracks (missing tracks skipped)."""
        if not play_counts:
            return []
        ordered = sorted(play_counts.items(), key=lambda kv: (-kv[1], kv[0]))
        hydrated: list[tuple["Track", int]] = []
        for track_id, plays in ordered[:TOP_TRACKS_LIMIT]:
            track = await self._safe(self._tracks.get_by_id(int(track_id)), None)
            if track is not None:
                hydrated.append((track, int(plays)))
        return hydrated

    def _top_artists(self, artist_counts: dict[int, int]) -> list[tuple[int, int]]:
        """Order artist play counts, most played first (ids only)."""
        ordered = sorted(artist_counts.items(), key=lambda kv: (-kv[1], kv[0]))
        return [(int(a), int(c)) for a, c in ordered[:TOP_ARTISTS_LIMIT]]

    @staticmethod
    async def _safe(awaitable: Any, fallback: Any) -> Any:
        """Await a repo call, converting failures into the fallback."""
        try:
            return await awaitable
        except Exception as exc:  # noqa: BLE001 — stats must never 500
            logger.warning(
                "user_stats.aggregation_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
            return fallback

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------
    async def render(self, tg_user_id: int) -> str:
        """Build the /mystats HTML message for one Telegram user."""
        stats = await self.build(tg_user_id)
        artist_names = await self._artist_names(
            [artist_id for artist_id, _ in stats.top_artists]
        )
        return self.format(stats, artist_names)

    def format(
        self,
        stats: UserStats,
        artist_names: dict[int, str] | None = None,
    ) -> str:
        """Render a :class:`UserStats` into HTML (pure, no awaits)."""
        artist_names = artist_names or {}
        lines: list[str] = ["📊 <b>MY LISTENING STATS</b>", ""]

        if stats.is_empty:
            lines.append("ℹ️ Nothing here yet — play or like a track and")
            lines.append("your stats will appear.")
            return "\n".join(lines)

        lines.append(
            f"🎧 <b>{stats.total_plays}</b> plays · "
            f"<b>{stats.unique_tracks}</b> unique tracks"
        )
        lines.append(
            f"❤️ <b>{stats.liked_count}</b> liked · "
            f"⏱️ <b>{escape(stats.listening_time_label)}</b> listened"
        )

        if stats.top_tracks:
            lines.append("")
            lines.append("<b>Top tracks</b>")
            for rank, (track, plays) in enumerate(stats.top_tracks, start=1):
                title = escape(str(getattr(track, "title", "") or "Unknown"))
                artist = _track_artist_label(track)
                suffix = f" · {artist}" if artist else ""
                lines.append(f"{rank}. {title}{suffix} — {plays}×")

        if stats.top_artists:
            lines.append("")
            lines.append("<b>Top artists</b>")
            for rank, (artist_id, plays) in enumerate(stats.top_artists, start=1):
                name = escape(artist_names.get(artist_id) or "Unknown artist")
                lines.append(f"{rank}. {name} — {plays}×")

        return "\n".join(lines)

    async def _artist_names(self, artist_ids: list[int]) -> dict[int, str]:
        """Resolve artist ids to display names (best effort)."""
        if not artist_ids:
            return {}
        artists = await self._safe(self._artists.get_by_ids(list(artist_ids)), [])
        return {
            int(a.id): str(getattr(a, "name", "") or "")
            for a in artists or []
            if getattr(a, "id", None) is not None
        }


def _track_artist_label(track: Any) -> str:
    """Best-effort artist name for a track row (detached-safe)."""
    try:
        artist = getattr(track, "artist", None)
    except Exception:  # noqa: BLE001 — DetachedInstanceError and friends
        return ""
    if artist is None:
        return ""
    name = getattr(artist, "name", None) or ""
    return escape(str(name))


__all__ = [
    "TOP_ARTISTS_LIMIT",
    "TOP_TRACKS_LIMIT",
    "UNIQUE_TRACKS_LIMIT",
    "UserStats",
    "UserStatsService",
]

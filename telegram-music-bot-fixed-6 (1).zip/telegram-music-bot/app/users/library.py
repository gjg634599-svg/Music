"""Personal music library: likes and recently played tracks.

All public methods key on the *Telegram* user id; the service resolves the DB
user row through the injected :class:`UserRepository`.
"""

from __future__ import annotations

from typing import Protocol

from app.database.models import Track
from app.database.repositories.library import LikedTrackRepository, ListeningHistoryRepository
from app.database.repositories.users import UserRepository
from app.errors import TrackNotFoundError, ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)


class TrackLookupLike(Protocol):
    """Duck-typed subset of ``TrackRepository`` (Task 2-a)."""

    async def get_by_id(self, track_id: int) -> Track | None: ...


class LibraryService:
    """Likes and recents (CONTRACTS §6)."""

    def __init__(
        self,
        liked: LikedTrackRepository,
        tracks: TrackLookupLike,
        users: UserRepository,
        history: ListeningHistoryRepository | None = None,
    ) -> None:
        self.liked = liked
        self.tracks = tracks
        self.users = users
        self.history = history

    async def toggle_like(self, user_tg_id: int, track_id: int) -> bool:
        """Toggle the like state of a track. True when it is now liked.

        Raises:
            ValidationError: when the user is unknown to the bot.
            TrackNotFoundError: when the track does not exist.
        """
        user = await self.users.get_by_telegram_id(user_tg_id)
        if user is None:
            raise ValidationError(
                f"Unknown user {user_tg_id}", user_message="ℹ️ Please press /start to begin."
            )
        track = await self.tracks.get_by_id(track_id)
        if track is None:
            raise TrackNotFoundError(f"Track #{track_id} not found")
        liked_now = await self.liked.toggle(user.id, track_id)
        logger.info(
            "library.toggle_like",
            extra=log_extra(tg_id=user_tg_id, track_id=track_id, liked=liked_now),
        )
        return liked_now

    async def is_liked(self, user_tg_id: int, track_id: int) -> bool:
        """Whether a track is liked (False for unknown users)."""
        user = await self.users.get_by_telegram_id(user_tg_id)
        if user is None:
            return False
        return await self.liked.is_liked(user.id, track_id)

    async def liked_tracks(self, user_tg_id: int, limit: int = 50) -> list[Track]:
        """Liked tracks, newest first (empty for unknown users)."""
        user = await self.users.get_by_telegram_id(user_tg_id)
        if user is None:
            return []
        return await self.liked.list_tracks(user.id, limit=limit)

    async def liked_track_ids(self, user_tg_id: int) -> set[int]:
        """Set of liked track ids (empty for unknown users)."""
        user = await self.users.get_by_telegram_id(user_tg_id)
        if user is None:
            return set()
        return await self.liked.liked_track_ids(user.id)

    async def recent_tracks(self, user_tg_id: int, limit: int = 10) -> list[Track]:
        """Distinct recently played tracks, newest first."""
        if self.history is None:
            logger.warning("library.history_missing")
            return []
        user = await self.users.get_by_telegram_id(user_tg_id)
        if user is None:
            return []
        return await self.history.recent_tracks(user.id, limit=limit)


__all__ = ["LibraryService"]

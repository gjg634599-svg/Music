"""Listening and search history service.

Methods key on the *Telegram* user id; the DB user row is resolved here.
History rows for unknown users are skipped with a warning (never raise).
"""

from __future__ import annotations

from app.database.models import ListeningHistory, SearchHistory
from app.database.repositories.analytics import AnalyticsRepository
from app.database.repositories.library import ListeningHistoryRepository
from app.database.repositories.users import SearchHistoryRepository, UserRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)


class HistoryService:
    """Records plays and searches (CONTRACTS §6)."""

    def __init__(
        self,
        history: ListeningHistoryRepository,
        users: UserRepository,
        search_history: SearchHistoryRepository,
        analytics: AnalyticsRepository,
    ) -> None:
        # Attribute names differ from method names (``history`` / ``search_history``)
        # so the repository dependencies never shadow the public methods.
        self.history_repo = history
        self.users = users
        self.search_history_repo = search_history
        self.analytics = analytics

    async def record(
        self,
        user_tg_id: int,
        track_id: int,
        *,
        context: str = "personal",
        group_id: int | None = None,
        completed: bool = False,
        skipped: bool = False,
        duration_played: int = 0,
    ) -> None:
        """Record one listening event for a Telegram user.

        Unknown users are skipped with a warning log (history must never break
        playback).
        """
        if not isinstance(track_id, int) or track_id <= 0:
            raise ValidationError("track_id must be a positive integer")
        user = await self.users.get_by_telegram_id(user_tg_id)
        if user is None:
            logger.warning(
                "history.unknown_user",
                extra=log_extra(tg_id=user_tg_id, track_id=track_id),
            )
            return
        await self.history_repo.record(
            user.id,
            track_id,
            group_id=group_id,
            context=context,
            completed=completed,
            skipped=skipped,
            duration_played=duration_played,
        )

    async def history(self, user_tg_id: int, limit: int = 20) -> list[ListeningHistory]:
        """Newest listening events (track attached); empty for unknown users."""
        user = await self.users.get_by_telegram_id(user_tg_id)
        if user is None:
            return []
        return await self.history_repo.recent(user.id, limit=limit)

    async def search_history(self, user_tg_id: int, limit: int = 10) -> list[SearchHistory]:
        """Newest search queries; empty for unknown users."""
        user = await self.users.get_by_telegram_id(user_tg_id)
        if user is None:
            return []
        return await self.search_history_repo.recent(user.id, limit=limit)

    async def record_search(
        self, user_tg_id: int, query: str, results_count: int
    ) -> None:
        """Persist a search query and emit the ``search`` analytics event."""
        user = await self.users.get_by_telegram_id(user_tg_id)
        if user is None:
            logger.warning(
                "history.unknown_user_search", extra=log_extra(tg_id=user_tg_id)
            )
            return
        await self.search_history_repo.add(user.id, query, results_count)
        await self.analytics.track(
            "search",
            user_id=user_tg_id,
            payload={"query": str(query)[:128], "results": int(results_count)},
        )
        logger.info(
            "history.search_recorded",
            extra=log_extra(tg_id=user_tg_id, results=results_count),
        )


__all__ = ["HistoryService"]

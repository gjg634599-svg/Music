"""Multi-source search aggregation with caching, timeouts and progress.

The :class:`SearchAggregator` fans a query out to every configured source
concurrently, tolerates individual source failures (each source error is
logged and skipped), applies an **explicit per-source timeout** as well as a
configurable **overall search timeout** (returning partial results when the
overall budget is exhausted), merges results in source priority order,
dedupes them by their normalized ``(title, artist)`` key and caches the
outcome for 5 minutes via the shared cache.

Progress reporting: callers may pass ``on_progress`` (a callable invoked as
``on_progress(source_name, status, count)`` with status ``"done"`` /
``"timeout"`` / ``"error"``) to build provider-aware UI. Callbacks are
invoked synchronously on the event loop and must never block.

Cache format: a JSON string of ``TrackResult.to_dict()`` payloads — this
works for both the in-memory cache and Redis without pickle compatibility
constraints between processes.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
from collections.abc import Callable

from app.cache.redis import CacheProtocol
from app.errors import MusicSourceError
from app.logging import get_logger, log_extra
from app.music.models import TrackResult
from app.music.normalizer import normalized_key
from app.music.sources.base import MusicSource

logger = get_logger(__name__)

#: Search result cache TTL (seconds).
SEARCH_CACHE_TTL = 300

#: Upper bound for a single search page.
MAX_LIMIT = 50

#: Default per-source timeout (seconds) — a slow provider can no longer
#: stall the whole search (production showed ~13 s "Bang bang" searches).
DEFAULT_PER_SOURCE_TIMEOUT = 8.0

#: Default overall search timeout (seconds) — after this budget partial
#: results are returned and stragglers are cancelled.
DEFAULT_OVERALL_TIMEOUT = 12.0

#: Progress callback signature: (source_name, status, result_count).
ProgressCallback = Callable[[str, str, int], None]


class SearchAggregator:
    """Fan-out search across all sources with dedupe, timeouts and caching."""

    def __init__(
        self,
        sources: list[MusicSource],
        cache: CacheProtocol,
        *,
        per_source_timeout: float = DEFAULT_PER_SOURCE_TIMEOUT,
        overall_timeout: float = DEFAULT_OVERALL_TIMEOUT,
    ) -> None:
        self._sources = sources
        self._cache = cache
        self._per_source_timeout = max(1.0, float(per_source_timeout))
        # An explicitly small overall timeout is honoured: the search then
        # returns partial results once the budget is exhausted (stragglers
        # are cancelled) instead of waiting for every per-source timeout.
        self._overall_timeout = max(1.0, float(overall_timeout))

    async def search(
        self,
        query: str,
        limit: int = 10,
        *,
        on_progress: ProgressCallback | None = None,
    ) -> list[TrackResult]:
        """Search every configured source and return merged results.

        Args:
            query: Free-text user query.
            limit: Maximum number of results after dedupe.
            on_progress: Optional sync callback per source state change.

        Returns:
            Deduplicated results ordered by source priority (local first),
            then by each source's own ranking. Never raises for source
            failures — failing or timed-out sources are logged, reported
            via ``on_progress`` and skipped; usable partial results are
            returned as soon as the overall timeout expires.
        """
        query = (query or "").strip()
        limit = max(1, min(int(limit), MAX_LIMIT))
        if not query:
            return []

        key = f"search:{hashlib.sha1(query.encode('utf-8')).hexdigest()}:{limit}"
        cached = await self._cache_get(key)
        if cached is not None:
            logger.info(
                "music.search.cache_hit",
                extra=log_extra(query=query[:128], count=len(cached)),
            )
            if on_progress is not None:
                self._emit_progress(on_progress, "cache", "done", len(cached))
            return cached

        active = [source for source in self._sources if source.is_configured()]
        batches: dict[str, list[TrackResult]] = {}
        partial = False

        if active:
            tasks = [
                asyncio.create_task(
                    self._search_source_timed(source, query, limit, batches, on_progress)
                )
                for source in active
            ]
            try:
                async with asyncio.timeout(self._overall_timeout):
                    await asyncio.gather(*tasks)
            except TimeoutError:
                # Overall budget exhausted — return what already arrived.
                partial = True
                for task in tasks:
                    task.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
                logger.warning(
                    "music.search.overall_timeout",
                    extra=log_extra(
                        query=query[:128],
                        sources=len(active),
                        completed=len(batches),
                    ),
                )

        merged: list[TrackResult] = []
        seen: set[str] = set()
        for source in active:  # preserve source priority order
            for result in batches.get(source.name, []):
                dedupe_key = normalized_key(result.title, result.artist)
                if dedupe_key in seen:
                    continue
                seen.add(dedupe_key)
                merged.append(result)
                if len(merged) >= limit:
                    break
            if len(merged) >= limit:
                break

        await self._cache_set(key, merged)
        logger.info(
            "music.search.completed",
            extra=log_extra(
                query=query[:128],
                sources=len(active),
                found=len(merged),
                partial=partial,
            ),
        )
        return merged

    # ------------------------------------------------------------------
    # Per-source wrapper: bounded time, progress reporting
    # ------------------------------------------------------------------
    async def _search_source_timed(
        self,
        source: MusicSource,
        query: str,
        limit: int,
        batches: dict[str, list[TrackResult]],
        on_progress: ProgressCallback | None,
    ) -> None:
        """Run one source inside a timeout; record its batch + progress."""
        try:
            results, status = await asyncio.wait_for(
                self._search_source(source, query, limit),
                timeout=self._per_source_timeout,
            )
        except TimeoutError:
            logger.warning(
                "music.search.source_timeout",
                extra=log_extra(source=source.name, timeout=self._per_source_timeout),
            )
            self._emit_progress(on_progress, source.name, "timeout", 0)
            return
        except asyncio.CancelledError:
            # Overall timeout cancelled us mid-flight — no result, no callback.
            raise
        batches[source.name] = results
        self._emit_progress(on_progress, source.name, status, len(results))

    async def _search_source(
        self, source: MusicSource, query: str, limit: int
    ) -> tuple[list[TrackResult], str]:
        try:
            results = await source.search(query, limit=limit)
            return [r for r in results if isinstance(r, TrackResult)], "done"
        except MusicSourceError as exc:
            logger.warning(
                "music.search.source_failed",
                extra=log_extra(source=source.name, error=str(exc)[:200]),
            )
            return [], "error"
        except asyncio.TimeoutError:
            logger.warning(
                "music.search.source_timeout",
                extra=log_extra(source=source.name),
            )
            return [], "timeout"
        except Exception as exc:  # noqa: BLE001 — isolation by design
            logger.error(
                "music.search.source_crashed",
                extra=log_extra(source=source.name, error=str(exc)[:200]),
            )
            return [], "error"

    @staticmethod
    def _emit_progress(
        on_progress: ProgressCallback | None, name: str, status: str, count: int
    ) -> None:
        """Invoke a progress callback, never letting it break the search."""
        if on_progress is None:
            return
        try:
            on_progress(name, status, count)
        except Exception as exc:  # noqa: BLE001 — UI callbacks must not break search
            logger.debug(
                "music.search.progress_callback_failed",
                extra=log_extra(error=str(exc)[:120]),
            )

    # ------------------------------------------------------------------
    # Cache helpers (cache outages must not break search)
    # ------------------------------------------------------------------
    async def _cache_get(self, key: str) -> list[TrackResult] | None:
        try:
            raw = await self._cache.get(key)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "music.search.cache_read_failed", extra=log_extra(error=str(exc)[:160])
            )
            return None
        if raw is None:
            return None
        try:
            if isinstance(raw, str):
                payload = json.loads(raw)
                return [TrackResult.from_dict(item) for item in payload]
            if isinstance(raw, list):  # in-memory cache storing objects directly
                return [item for item in raw if isinstance(item, TrackResult)]
        except (json.JSONDecodeError, TypeError, ValueError) as exc:
            logger.warning(
                "music.search.cache_corrupt", extra=log_extra(error=str(exc)[:160])
            )
        return None

    async def _cache_set(self, key: str, results: list[TrackResult]) -> None:
        try:
            payload = json.dumps([result.to_dict() for result in results])
            await self._cache.set(key, payload, ttl=SEARCH_CACHE_TTL)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "music.search.cache_write_failed", extra=log_extra(error=str(exc)[:160])
            )


__all__ = [
    "DEFAULT_OVERALL_TIMEOUT",
    "DEFAULT_PER_SOURCE_TIMEOUT",
    "SEARCH_CACHE_TTL",
    "ProgressCallback",
    "SearchAggregator",
]

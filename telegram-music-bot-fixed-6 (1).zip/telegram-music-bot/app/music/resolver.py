"""Resolve source results into the normalized catalog (artist/album/genre/track).

:class:`TrackResolver` turns a transport-level
:class:`~app.music.models.TrackResult` into a persisted
:class:`~app.database.models.music.Track`, upserting the surrounding
entities on the way:

1. **Artist** — upserted by normalized name.
2. **Album** — upserted by normalized title + artist (when provided).
3. **Genres** — ``result.genre`` is split on ``/`` and ``,`` and each part
   is upserted and associated with the track (and its artist).
4. **Track** — get-or-create by ``(source, source_id)``; existing rows are
   refreshed with any non-empty fields from the result.

The returned ORM ``Track`` is detached but fully loaded (artist, album,
genres), safe to render directly in handlers.
"""

from __future__ import annotations

import re

from app.database.models.music import Track
from app.database.repositories.music import (
    AlbumRepository,
    ArtistRepository,
    GenreRepository,
    TrackRepository,
)
from app.logging import get_logger, log_extra
from app.music.models import TrackResult
from app.music.normalizer import clean_title

logger = get_logger(__name__)

#: Genre separators inside the ``TrackResult.genre`` string.
_GENRE_SPLIT_RE = re.compile(r"[/,]")

#: Hard truncation limits matching ORM column sizes.
_MAX_URL = 1024
_MAX_ID = 128


class TrackResolver:
    """Persists :class:`TrackResult` objects as catalog rows."""

    def __init__(
        self,
        tracks: TrackRepository,
        artists: ArtistRepository,
        albums: AlbumRepository,
        genres: GenreRepository,
    ) -> None:
        self._tracks = tracks
        self._artists = artists
        self._albums = albums
        self._genres = genres

    async def resolve(self, result: TrackResult) -> Track:
        """Upsert *result* into the catalog and return the ORM track.

        The ``(source, source_id)`` pair is the identity: resolving the
        same source track twice updates the existing row instead of
        creating a duplicate. Empty/None result fields never erase
        already-stored values (except ``is_playable`` which is always
        set back to ``True``).
        """
        title = (result.title or "Unknown").strip()[:256] or "Unknown"
        title = clean_title(title) or title

        artist_id: int | None = None
        if result.artist and result.artist.strip():
            artist = await self._artists.get_or_create(result.artist.strip()[:256])
            artist_id = artist.id

        album_id: int | None = None
        if result.album and result.album.strip():
            album = await self._albums.get_or_create(
                result.album.strip()[:256],
                artist_id=artist_id,
                artwork_url=(result.artwork_url or None),
                source=result.source[:32],
            )
            album_id = album.id

        genre_ids = await self._upsert_genres(result.genre)
        if artist_id is not None and genre_ids:
            await self._genres.associate_artist(artist_id, genre_ids)

        existing = await self._tracks.get_by_source(result.source, result.source_id)
        if existing is None:
            track = await self._tracks.create(
                title=title,
                artist_id=artist_id,
                album_id=album_id,
                duration_seconds=max(0, int(result.duration_seconds or 0)),
                language=(result.language or None),
                mood=(result.mood or None),
                tempo=result.tempo,
                popularity=max(0, int(result.popularity or 0)),
                isrc=(result.isrc or None),
                source=result.source[:32],
                source_id=str(result.source_id)[:_MAX_ID],
                stream_url=result.stream_url,
                artwork_url=result.artwork_url,
                file_path=(result.extra or {}).get("file_path"),
                uploaded_by=(result.extra or {}).get("uploaded_by"),
                is_playable=True,
            )
            created = True
        else:
            updates: dict[str, object] = {"is_playable": True}
            if title and title != existing.title:
                updates["title"] = title
            if artist_id is not None:
                updates["artist_id"] = artist_id
            if album_id is not None:
                updates["album_id"] = album_id
            if result.duration_seconds:
                updates["duration_seconds"] = max(0, int(result.duration_seconds))
            if result.language:
                updates["language"] = result.language[:8]
            if result.mood:
                updates["mood"] = result.mood[:32]
            if result.tempo is not None:
                updates["tempo"] = int(result.tempo)
            if result.popularity:
                updates["popularity"] = max(0, int(result.popularity))
            if result.isrc:
                updates["isrc"] = result.isrc[:32]
            if result.stream_url:
                updates["stream_url"] = result.stream_url[:_MAX_URL]
            if result.artwork_url:
                updates["artwork_url"] = result.artwork_url[:_MAX_URL]
            file_path = (result.extra or {}).get("file_path")
            if file_path:
                updates["file_path"] = str(file_path)[:512]
            track = await self._tracks.update(existing.id, **updates) or existing
            created = False

        if genre_ids:
            await self._genres.associate_track(track.id, genre_ids)
            # Re-fetch so the returned object reflects the fresh associations
            # (its genres collection was loaded before they existed).
            track = await self._tracks.get(track.id) or track

        logger.info(
            "music.resolver.resolved",
            extra=log_extra(
                track_id=track.id,
                source=result.source,
                created=created,
                genres=len(genre_ids),
            ),
        )
        return track

    # ------------------------------------------------------------------
    # Genre handling
    # ------------------------------------------------------------------
    async def _upsert_genres(self, genre: str | None) -> list[int]:
        """Split a genre string and upsert every part; returns genre ids."""
        if not genre:
            return []
        names: list[str] = []
        for part in _GENRE_SPLIT_RE.split(str(genre)):
            name = part.strip()[:64]
            if name and name.casefold() not in {n.casefold() for n in names}:
                names.append(name)
        ids: list[int] = []
        for name in names[:8]:  # sane cap on associations per track
            genre_row = await self._genres.get_or_create(name)
            ids.append(genre_row.id)
        return ids


__all__ = ["TrackResolver"]

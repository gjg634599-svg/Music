"""Audio metadata extraction via ffprobe.

Wraps ``ffprobe -print_format json -show_format`` through
``asyncio.create_subprocess_exec`` (never a blocking call) and maps the
JSON format/tags block into :class:`~app.music.models.AudioMetadata`.

A custom ``probe`` callable can be injected for tests: it receives the
file path as ``str`` and returns (or awaits) the parsed ffprobe JSON dict.
"""

from __future__ import annotations

import asyncio
import inspect
import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

from app.config import Settings
from app.errors import InvalidAudioError
from app.logging import get_logger, log_extra
from app.music.models import AudioMetadata

logger = get_logger(__name__)

#: Type of the injectable probe callable: takes a path, returns (or awaits)
#: the parsed ffprobe JSON dict.
ProbeCallable = Callable[[str], Any]

#: Hard wall-clock limit for one ffprobe run.
_PROBE_TIMEOUT_BUDGET = 30.0


class MetadataService:
    """Extract ID3/Vorbis-style tags from audio files."""

    def __init__(
        self,
        settings: Settings,
        probe: ProbeCallable | None = None,
    ) -> None:
        """Initialize the service.

        Args:
            settings: Application settings (``ffprobe_path`` used by the
                default implementation).
            probe: Optional replacement probe — a callable taking the file
                path (``str``) and returning the ffprobe JSON dict, either
                directly or as an awaitable. Used in tests to avoid
                spawning real processes.
        """
        self._settings = settings
        self._probe = probe

    async def extract(self, file_path: str | Path) -> AudioMetadata:
        """Probe *file_path* and return its tags.

        Raises:
            InvalidAudioError: The file is missing, not audio, or the
                probe failed / returned garbage.
        """
        path = Path(file_path)
        if not path.is_file():
            raise InvalidAudioError(f"Audio file not found: {path}")

        probe = self._probe or self._ffprobe_default
        try:
            result = probe(str(path))
            if inspect.isawaitable(result):
                result = await result
        except InvalidAudioError:
            raise
        except Exception as exc:  # noqa: BLE001 — injected probes may fail freely
            raise InvalidAudioError(f"Probe failed: {exc}") from exc

        if not isinstance(result, dict):
            raise InvalidAudioError("Probe returned an unexpected payload")
        metadata = self._parse(result)
        logger.info(
            "music.metadata.extracted",
            extra=log_extra(
                title=bool(metadata.title),
                artist=bool(metadata.artist),
                duration=metadata.duration_seconds,
            ),
        )
        return metadata

    # ------------------------------------------------------------------
    # Default ffprobe implementation
    # ------------------------------------------------------------------
    async def _ffprobe_default(self, path: str) -> dict[str, Any]:
        """Run ``ffprobe -print_format json -show_format`` asynchronously."""
        proc = await asyncio.create_subprocess_exec(
            self._settings.ffprobe_path,
            "-v",
            "error",
            "-print_format",
            "json",
            "-show_format",
            path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=_PROBE_TIMEOUT_BUDGET
            )
        except asyncio.TimeoutError as exc:
            proc.kill()
            raise InvalidAudioError(f"ffprobe timed out on {path}") from exc
        if proc.returncode != 0:
            detail = (stderr or b"").decode("utf-8", "replace")[:200]
            raise InvalidAudioError(f"ffprobe failed ({proc.returncode}): {detail}")
        try:
            return json.loads(stdout.decode("utf-8", "replace") or "{}")
        except json.JSONDecodeError as exc:
            raise InvalidAudioError("ffprobe produced invalid JSON") from exc

    # ------------------------------------------------------------------
    # Mapping
    # ------------------------------------------------------------------
    @staticmethod
    def _parse(payload: dict[str, Any]) -> AudioMetadata:
        """Map an ffprobe JSON document to :class:`AudioMetadata`."""
        fmt = payload.get("format") if isinstance(payload.get("format"), dict) else {}
        raw_tags = fmt.get("tags") if isinstance(fmt.get("tags"), dict) else {}
        tags = {str(k).lower(): v for k, v in raw_tags.items()}

        def tag(*names: str) -> str | None:
            for name in names:
                value = tags.get(name.lower()) or tags.get(f"tag:{name.lower()}")
                if value is not None:
                    text = str(value).strip()
                    if text:
                        return text
            return None

        duration = 0
        try:
            duration = int(round(float(fmt.get("duration", 0) or 0)))
        except (TypeError, ValueError):
            duration = 0

        tempo = None
        tempo_raw = tag("bpm", "tbpm", "tempo")
        if tempo_raw:
            try:
                tempo = int(round(float(tempo_raw)))
            except (TypeError, ValueError):
                tempo = None

        return AudioMetadata(
            title=tag("title"),
            artist=tag("artist", "artist_performer", "album_artist"),
            album=tag("album", "album_name"),
            duration_seconds=duration,
            genre=tag("genre"),
            language=tag("language", "lang"),
            tempo=tempo,
        )


__all__ = ["MetadataService"]

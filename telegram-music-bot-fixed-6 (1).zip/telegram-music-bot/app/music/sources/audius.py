"""Audius music source (public API, https://docs.audius.org/api).

Audius is a decentralized music streaming platform with an open API. There
is no API key — instead, clients must first ask ``https://api.audius.co``
for a list of *discovery provider* hosts and then talk to one of them.

Flow implemented here:

1. ``GET https://api.audius.co`` → ``{"data": ["https://host", ...]}``;
   a random host is picked and cached in memory for the lifetime of the
   source (with ``https://audius-discovery-1.altego.net`` as fallback).
2. ``GET {host}/v1/tracks/search?query=...&app_name=...`` → search.
3. ``GET {host}/v1/tracks/{id}?app_name=...`` → single track.
4. ``GET {host}/v1/resolve?url=...&app_name=...`` → resolve
   ``https://audius.co/<artist>/<track-slug>`` permalinks.
5. ``GET {host}/v1/tracks/{id}/stream?app_name=...`` → 302 redirect to the
   audio file; the URL is returned as the stream info and followed by the
   downloader.
"""

from __future__ import annotations

import asyncio
import random
import re
from typing import Any
from urllib.parse import urlparse

import aiohttp

from app.config import Settings
from app.errors import MusicSourceError
from app.logging import get_logger, log_extra
from app.music.models import StreamInfo, TrackResult
from app.music.sources.base import HttpStatusError, MusicSource

logger = get_logger(__name__)

_DISCOVERY_URL = "https://api.audius.co"
_FALLBACK_HOST = "https://audius-discovery-1.altego.net"
_APP_NAME = "MusicBot"

#: Hostnames whose URLs we attempt to resolve via /v1/resolve.
_KNOWN_HOSTS = frozenset(
    {"audius.co", "www.audius.co", "audius.com", "www.audius.com"}
)

#: Shape of an id inside a discovery-provider resource URL (for the case
#: where /v1/resolve answers with a URL instead of an id object).
_RESOURCE_URL_RE = re.compile(r"/v1/tracks/([A-Za-z0-9]+)")


class AudiusSource(MusicSource):
    """Audius public API (no credentials required)."""

    name = "audius"

    def __init__(self, settings: Settings, http: aiohttp.ClientSession) -> None:
        super().__init__(settings, http)
        self._host: str | None = None
        self._host_lock = asyncio.Lock()

    def is_configured(self) -> bool:
        """The Audius API is public — always configured."""
        return True

    # ------------------------------------------------------------------
    # Discovery host management
    # ------------------------------------------------------------------
    async def _discover_host(self) -> str:
        """Return a cached discovery host, discovering one if needed."""
        if self._host:
            return self._host
        async with self._host_lock:
            if self._host:
                return self._host
            try:
                payload = await self._get_json(_DISCOVERY_URL)
                hosts = payload.get("data") if isinstance(payload, dict) else None
                if isinstance(hosts, list) and hosts:
                    chosen = str(random.choice(list(hosts))).rstrip("/")  # noqa: S311
                    if chosen.startswith("https://"):
                        self._host = chosen
                        return self._host
            except MusicSourceError as exc:
                logger.warning(
                    "music.audius.discovery_failed",
                    extra=log_extra(error=str(exc)[:160]),
                )
            self._host = _FALLBACK_HOST
            return self._host

    async def _reset_host(self) -> str:
        """Forget the cached host (it failed) and pick a new one."""
        self._host = None
        return await self._discover_host()

    async def _request(
        self, path: str, params: dict[str, str], *, allow_404: bool = False
    ) -> Any:
        """GET ``{host}{path}`` with failover to a fresh discovery host.

        HTTP status errors (bad ids, gone tracks) are not retried against
        another host; only network-level failures trigger the failover.
        """
        host = await self._discover_host()
        try:
            return await self._get_json(f"{host}{path}", params, allow_404=allow_404)
        except HttpStatusError:
            raise
        except MusicSourceError:
            logger.warning(
                "music.audius.host_failover", extra=log_extra(host=host)
            )
            host = await self._reset_host()
            return await self._get_json(f"{host}{path}", params, allow_404=allow_404)

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------
    async def search(self, query: str, limit: int = 10) -> list[TrackResult]:
        """Search tracks by query via the discovery provider."""
        query = (query or "").strip()
        if not query:
            return []
        payload = await self._request(
            "/v1/tracks/search",
            {"query": query, "app_name": _APP_NAME, "limit": str(max(1, min(int(limit), 100)))},
        )
        items = self._data_list(payload)
        mapped = [t for t in (self._map(item) for item in items) if t is not None]
        logger.info(
            "music.audius.search", extra=log_extra(query=query[:128], found=len(mapped))
        )
        return mapped

    async def get_track(self, source_id: str) -> TrackResult | None:
        """Fetch a single track by its Audius id."""
        if not source_id:
            return None
        payload = await self._request(
            f"/v1/tracks/{source_id}", {"app_name": _APP_NAME}, allow_404=True
        )
        track = self._unwrap_track(payload)
        return self._map(track) if track else None

    # ------------------------------------------------------------------
    # URL resolution & streaming
    # ------------------------------------------------------------------
    async def resolve_url(self, url: str) -> TrackResult | None:
        """Resolve an ``https://audius.co/...`` permalink via /v1/resolve."""
        if not self._is_audius_url(url):
            return None
        payload = await self._request(
            "/v1/resolve",
            {"url": (url or "").strip(), "app_name": _APP_NAME},
            allow_404=True,
        )
        if payload is None:
            return None
        data = payload.get("data") if isinstance(payload, dict) else None

        # Shape 1: {"data": {"track_id": "..."}}
        if isinstance(data, dict):
            track_id = data.get("track_id")
            if track_id:
                return await self.get_track(str(track_id))
            # Shape 2: {"data": {<full track object>}}
            if "id" in data and "title" in data:
                return self._map(data)
            # Other resource types (users, playlists) are not tracks.
            return None

        # Shape 3: {"data": "https://host/v1/tracks/<id>..."}
        if isinstance(data, str):
            match = _RESOURCE_URL_RE.search(data)
            if match:
                return await self.get_track(match.group(1))
        return None

    async def get_stream(self, source_id: str) -> StreamInfo | None:
        """Stream endpoint; Audius answers with a 302 to the media file."""
        if not source_id:
            return None
        host = await self._discover_host()
        url = f"{host}/v1/tracks/{source_id}/stream?app_name={_APP_NAME}"
        return StreamInfo(url_or_path=url, is_local=False)

    @staticmethod
    def _is_audius_url(url: str) -> bool:
        """True when the URL points at an Audius content host."""
        try:
            parsed = urlparse((url or "").strip())
        except ValueError:
            return False
        return (parsed.hostname or "").lower() in _KNOWN_HOSTS

    # ------------------------------------------------------------------
    # Payload helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _data_list(payload: Any) -> list[dict[str, Any]]:
        """Extract the ``data`` list from an Audius response."""
        if isinstance(payload, dict):
            data = payload.get("data")
            if isinstance(data, list):
                return [item for item in data if isinstance(item, dict)]
        return []

    @staticmethod
    def _unwrap_track(payload: Any) -> dict[str, Any] | None:
        """Accept both ``{track}`` and ``{"data": {track}}`` response shapes."""
        if isinstance(payload, dict):
            if "id" in payload:
                return payload
            data = payload.get("data")
            if isinstance(data, dict) and "id" in data:
                return data
        return None

    def _map(self, track: dict[str, Any]) -> TrackResult | None:
        """Map an Audius track object to :class:`TrackResult`."""
        track_id = track.get("id")
        title = track.get("title")
        if track_id is None or not title:
            return None
        if track.get("is_delete"):
            return None

        artwork = track.get("artwork")
        artwork_url = None
        if isinstance(artwork, dict):
            for size in ("1000x1000", "480x480", "150x150"):
                url = artwork.get(size)
                if url:
                    artwork_url = str(url)
                    break

        play_count = _to_int(track.get("play_count"), default=0) or 0
        genre = _clean(track.get("genre"))
        return TrackResult(
            title=str(title)[:256],
            artist=self._artist_name(track),
            album=None,
            duration_seconds=_to_int(track.get("duration"), default=0) or 0,
            source=self.name,
            source_id=str(track_id)[:128],
            stream_url=None,  # streaming goes through get_stream()
            artwork_url=artwork_url,
            genre=genre,
            language=_clean(track.get("language")),
            mood=_clean(track.get("mood")),
            tempo=_to_int(track.get("bpm")),
            popularity=play_count,
            isrc=_clean(track.get("isrc")),
            extra={
                "handle": self._artist_handle(track),
                "permalink": _clean(track.get("permalink")),
                "release_date": _clean(track.get("release_date")),
            },
        )

    @staticmethod
    def _artist_name(track: dict[str, Any]) -> str | None:
        """Artist display name (``user`` in search, ``artist`` elsewhere)."""
        for key in ("artist", "user"):
            obj = track.get(key)
            if isinstance(obj, dict):
                name = obj.get("name") or obj.get("handle")
                if name:
                    return str(name)[:256]
        return None

    @staticmethod
    def _artist_handle(track: dict[str, Any]) -> str | None:
        """Artist handle, used to build ``audius.co/<handle>/<slug>`` links."""
        for key in ("artist", "user"):
            obj = track.get(key)
            if isinstance(obj, dict) and obj.get("handle"):
                return str(obj["handle"])
        return None


def _clean(value: Any) -> str | None:
    """String-or-None coercion for loosely typed API fields."""
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _to_int(value: Any, default: int | None = None) -> int | None:
    """Int coercion for loosely typed API fields (never raises)."""
    if value is None or isinstance(value, bool):
        return default
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


__all__ = ["AudiusSource"]

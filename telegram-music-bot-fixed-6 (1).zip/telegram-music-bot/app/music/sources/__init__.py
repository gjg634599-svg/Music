"""Music source package: concrete sources and the factory wiring order.

The composition root (application bootstrap) calls :func:`build_sources` to
get the source chain in a fixed priority order: local catalog first, then
Jamendo, then Audius.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import aiohttp

from app.config import Settings
from app.music.sources.audius import AudiusSource
from app.music.sources.base import MusicSource
from app.music.sources.jamendo import JamendoSource
from app.music.sources.local import LocalSource

if TYPE_CHECKING:  # pragma: no cover - type-only import
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker


def build_sources(
    settings: Settings,
    http: aiohttp.ClientSession,
    sessions: async_sessionmaker[AsyncSession] | None = None,
) -> list[MusicSource]:
    """Build the music source chain in priority order.

    Order matters: results are merged in this order by the
    :class:`~app.music.search.SearchAggregator`, so the local catalog always
    comes first, followed by Jamendo (when configured) and Audius.

    Args:
        settings: Application settings.
        http: Shared aiohttp session (never created here).
        sessions: Optional shared DB sessionmaker used by the local source;
            when omitted, the local source builds its own engine per
            database URL (cached, so repeated calls stay cheap).
    """
    return [
        LocalSource(settings, http, sessions=sessions),
        JamendoSource(settings, http),
        AudiusSource(settings, http),
    ]


__all__ = [
    "AudiusSource",
    "JamendoSource",
    "LocalSource",
    "MusicSource",
    "build_sources",
]

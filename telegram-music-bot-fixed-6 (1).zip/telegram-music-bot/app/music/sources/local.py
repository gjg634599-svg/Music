"""Local music source backed by the bot's own database catalog.

Searches the ``tracks`` table (title / artist name) through
:class:`TrackRepository` and maps catalog rows to
:class:`app.music.models.TrackResult` objects **preserving each row's
original provider identity** (``source`` / ``source_id`` — e.g. an
Audius track cached earlier remains ``source="audius"`` with its
Audius track id). The database primary key stays available in
``extra["track_id"]`` for UI callbacks. The catalog is always available,
so :meth:`LocalSource.is_configured` always returns ``True``.

Legacy healing: rows created by an older version of this module could
end up as ``source="local"`` with ``source_id`` pointing at *another*
row's primary key and no file/stream of their own ("dead duplicate"
rows). :meth:`search` detects that shape, resolves the referenced
original row and returns *its* result instead, so repeated searches
neither surface unplayable duplicates nor overwrite a remote track's
provider identity.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import aiohttp

from app.config import Settings
from app.database.models.music import Track
from app.database.repositories.music import TrackRepository
from app.logging import get_logger, log_extra
from app.music.models import StreamInfo, TrackResult
from app.music.sources.base import MusicSource

if TYPE_CHECKING:  # pragma: no cover - type-only import (runtime import is lazy)
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

logger = get_logger(__name__)


class LocalSource(MusicSource):
    """The bot's own catalog (uploads + previously resolved tracks)."""

    name = "local"

    def __init__(
        self,
        settings: Settings,
        http: aiohttp.ClientSession,
        sessions: async_sessionmaker[AsyncSession] | None = None,
    ) -> None:
        super().__init__(settings, http)
        if sessions is None:
            sessions = _fallback_sessionmaker(settings)
        self._tracks = TrackRepository(sessions)

    def is_configured(self) -> bool:
        """The local catalog is always available."""
        return True

    async def search(self, query: str, limit: int = 10) -> list[TrackResult]:
        """LIKE-search the catalog on title and artist name.

        Rows keep their original provider identity (``row.source`` /
        ``row.source_id``). Legacy "dead duplicate" rows (``source='local'``,
        no file, no stream, ``source_id`` = another row's primary key) are
        transparently replaced by the referenced original row; rows that can
        never produce audio are skipped.
        """
        query = (query or "").strip()
        if not query:
            return []
        rows = await self._tracks.search_catalog(query, limit=limit)
        results: list[TrackResult] = []
        seen_track_ids: set[int] = set()
        for row in rows:
            row = await self._heal_legacy_row(row)
            if row is None:
                continue
            if row.id in seen_track_ids:
                continue  # dead duplicate + its original in one page
            seen_track_ids.add(row.id)
            results.append(self._to_result(row))
            if len(results) >= limit:
                break
        logger.info(
            "music.local.search",
            extra=log_extra(query=query[:128], found=len(results)),
        )
        return results

    async def get_track(self, source_id: str) -> TrackResult | None:
        """Fetch a catalog track by its numeric id."""
        try:
            track_id = int(source_id)
        except (TypeError, ValueError):
            return None
        row = await self._tracks.get(track_id)
        return self._to_result(row) if row else None

    async def get_stream(self, source_id: str) -> StreamInfo | None:
        """Local files stream straight from disk; remote rows use their URL."""
        try:
            track_id = int(source_id)
        except (TypeError, ValueError):
            return None
        row = await self._tracks.get(track_id)
        if row is None:
            return None
        if row.file_path:
            return StreamInfo(url_or_path=row.file_path, is_local=True)
        if row.stream_url:
            return StreamInfo(url_or_path=row.stream_url, is_local=False)
        return None

    # ------------------------------------------------------------------
    # Mapping
    # ------------------------------------------------------------------
    @staticmethod
    def _to_result(row: Track) -> TrackResult:
        """Map an ORM :class:`~app.database.models.music.Track` to a result.

        Provider identity is **taken from the row** (``row.source`` /
        ``row.source_id``): a catalog row created from an Audius result
        stays an Audius result with its Audius track id, so the resolver
        upserts onto the existing row instead of creating a
        ``source='local'`` duplicate, and playback routes stream
        resolution to the correct provider adapter. The database primary
        key is exposed via ``extra['track_id']`` (never as ``source_id``).
        """
        artist = row.artist.name if row.artist is not None else None
        album = row.album.title if row.album is not None else None
        genres = "/".join(g.name for g in (row.genres or [])) or None
        source = (row.source or "local").strip() or "local"
        source_id = str(row.source_id or "") or str(row.id)
        return TrackResult(
            title=row.title,
            artist=artist,
            album=album,
            duration_seconds=row.duration_seconds or 0,
            source=source,
            source_id=source_id,
            stream_url=row.stream_url,
            artwork_url=row.artwork_url,
            genre=genres,
            language=row.language,
            mood=row.mood,
            tempo=row.tempo,
            popularity=row.popularity or 0,
            isrc=row.isrc,
            extra={
                "track_id": row.id,
                "file_path": row.file_path,
                "uploaded_by": row.uploaded_by,
            },
        )

    # ------------------------------------------------------------------
    # Legacy dead-row healing
    # ------------------------------------------------------------------
    async def _heal_legacy_row(self, row: Track) -> Track | None:
        """Return the row a search result should be built from.

        * A row with a local file or a stream URL is used as-is.
        * A remote-provider row (audius/jamendo/…) is used as-is even
          without a URL — its provider adapter resolves the stream at
          playback time.
        * A ``source='local'`` row with **no** file and **no** URL whose
          ``source_id`` is an integer pointing at a different row is a
          legacy duplicate: the referenced row is returned instead (the
          original keeps its true provider identity).
        * Anything else that can never produce audio is dropped.
        """
        if row.file_path or row.stream_url or row.audio_file_id:
            return row
        if (row.source or "local") != "local":
            return row  # remote provider — resolvable through its adapter
        sid = str(row.source_id or "")
        if not sid.isdigit():
            return None  # unplayable 'local' row without any media
        original_id = int(sid)
        if original_id == row.id:
            return None  # genuine local row that lost its file
        try:
            original = await self._tracks.get(original_id)
        except Exception:  # noqa: BLE001 — treat as gone
            return None
        if original is None:
            return None
        logger.info(
            "music.local.legacy_row_healed",
            extra=log_extra(dead_row_id=row.id, track_id=original.id),
        )
        return original


# ----------------------------------------------------------------------
# Standalone fallback: allow building LocalSource without a shared engine
# ----------------------------------------------------------------------
_FALLBACK_SESSIONMAKERS: dict[str, async_sessionmaker[AsyncSession]] = {}


def _fallback_sessionmaker(settings: Settings) -> async_sessionmaker[AsyncSession]:
    """Create (once per database URL) a sessionmaker for standalone use.

    The normal wiring passes the application's shared ``async_sessionmaker``
    into :class:`LocalSource`. This fallback keeps the source usable when it
    is constructed directly (scripts, tests); engines are cached per URL so
    repeated construction does not leak connection pools.
    """
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine, AsyncSession

    cached = _FALLBACK_SESSIONMAKERS.get(settings.database_url)
    if cached is not None:
        return cached
    engine = create_async_engine(settings.database_url, pool_pre_ping=True)
    sessions = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    _FALLBACK_SESSIONMAKERS[settings.database_url] = sessions
    return sessions


__all__ = ["LocalSource"]

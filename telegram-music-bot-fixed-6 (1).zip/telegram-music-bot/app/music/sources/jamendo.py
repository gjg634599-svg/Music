"""Jamendo music source (https://developer.jamendo.com, API v3.0).

Jamendo is a Creative-Commons music platform with a free developer API.
Requests go to ``https://api.jamendo.com/v3.0/tracks`` with the app's
``client_id``; searches use the ``search`` parameter plus
``include=musicinfo`` so genre tags and BPM come back with each track.

The client id is a public identifier (not a secret) but it is still never
written to logs. When ``JAMENDO_CLIENT_ID`` is not configured the source
degrades gracefully: searches return ``[]``, track lookups return ``None``,
and no errors are raised.
"""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlparse

import aiohttp

from app.config import Settings
from app.errors import MusicSourceError
from app.logging import get_logger, log_extra
from app.music.models import StreamInfo, TrackResult
from app.music.sources.base import MusicSource

logger = get_logger(__name__)

_API_BASE = "https://api.jamendo.com/v3.0"

#: Permalink shapes we can resolve: jamendo.com/track/<id> and
#: licensing.jamendo.com/<locale>/track/<id> (locale like ``en``).
_TRACK_URL_RE = re.compile(r"^/(?:[a-z]{2}/)?track/(\d+)/?", re.IGNORECASE)


class JamendoSource(MusicSource):
    """Jamendo catalog integration (requires ``jamendo_client_id``)."""

    name = "jamendo"

    def is_configured(self) -> bool:
        """Configured only when a Jamendo client id is present."""
        return bool(self.settings.jamendo_client_id)

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------
    async def search(self, query: str, limit: int = 10) -> list[TrackResult]:
        """Full-text search via the ``search`` parameter."""
        query = (query or "").strip()
        if not query or not self.is_configured():
            return []
        params = {
            "client_id": self.settings.jamendo_client_id or "",
            "format": "json",
            "limit": str(max(1, min(int(limit), 200))),
            "search": query,
            "include": "musicinfo",
        }
        payload = await self._get_json(f"{_API_BASE}/tracks", params)
        items = self._results(payload)
        mapped = [t for t in (self._map(item) for item in items) if t is not None]
        logger.info(
            "music.jamendo.search", extra=log_extra(query=query[:128], found=len(mapped))
        )
        return mapped

    async def get_track(self, source_id: str) -> TrackResult | None:
        """Fetch one track by its Jamendo id (``id`` parameter)."""
        if not self.is_configured() or not source_id:
            return None
        params = {
            "client_id": self.settings.jamendo_client_id or "",
            "format": "json",
            "id": str(source_id),
            "include": "musicinfo",
        }
        payload = await self._get_json(f"{_API_BASE}/tracks", params, allow_404=True)
        if payload is None:
            return None
        items = self._results(payload)
        if not items:
            return None
        return self._map(items[0])

    # ------------------------------------------------------------------
    # URL resolution & streaming
    # ------------------------------------------------------------------
    async def resolve_url(self, url: str) -> TrackResult | None:
        """Resolve ``jamendo.com/track/<id>`` and licensing permalinks."""
        source_id = self.extract_track_id(url)
        if source_id is None:
            return None
        return await self.get_track(source_id)

    async def get_stream(self, source_id: str) -> StreamInfo | None:
        """Jamendo stream endpoint (mp3, follows redirects)."""
        if not self.is_configured() or not source_id:
            return None
        url = (
            f"{_API_BASE}/tracks/stream"
            f"?client_id={self.settings.jamendo_client_id}&id={source_id}"
        )
        return StreamInfo(url_or_path=url, is_local=False)

    @staticmethod
    def extract_track_id(url: str) -> str | None:
        """Return the numeric track id from a Jamendo URL, else ``None``."""
        try:
            parsed = urlparse((url or "").strip())
        except ValueError:
            return None
        host = (parsed.hostname or "").lower()
        if not host.endswith(".jamendo.com") and host != "jamendo.com":
            return None
        match = _TRACK_URL_RE.match(parsed.path or "")
        return match.group(1) if match else None

    # ------------------------------------------------------------------
    # Payload helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _results(payload: Any) -> list[dict[str, Any]]:
        """Extract the ``results`` list from a Jamendo response.

        Jamendo answers HTTP 200 even for application-level failures
        (invalid client id, bad parameters), reporting them in
        ``headers.status == "failed"`` — those are surfaced as
        :class:`MusicSourceError` here.
        """
        if isinstance(payload, dict):
            headers = payload.get("headers")
            if isinstance(headers, dict) and str(headers.get("status", "")).lower() == "failed":
                message = (
                    headers.get("error_message")
                    or headers.get("warnings")
                    or "unknown API error"
                )
                raise MusicSourceError(f"jamendo: API error: {str(message)[:200]}")
            results = payload.get("results")
            if isinstance(results, list):
                return [item for item in results if isinstance(item, dict)]
        return []

    def _map(self, item: dict[str, Any]) -> TrackResult | None:
        """Map a Jamendo track object to :class:`TrackResult`."""
        track_id = item.get("id")
        name = item.get("name")
        if track_id is None or not name:
            return None
        musicinfo = item.get("musicinfo")
        musicinfo = musicinfo if isinstance(musicinfo, dict) else {}
        tags = musicinfo.get("tags")
        tags = tags if isinstance(tags, dict) else {}

        genres = [str(g) for g in tags.get("genres") or [] if str(g).strip()]
        genre = "/".join(genres) if genres else None

        tempo = _to_int(musicinfo.get("bpm"))
        popularity = 0
        for key in ("hottt", "popularity", "rating"):
            value = _to_int(item.get(key))
            if value:
                popularity = value
                break

        return TrackResult(
            title=str(name)[:256],
            artist=_clean(item.get("artist_name")),
            album=_clean(item.get("album_name")),
            duration_seconds=_to_int(item.get("duration"), default=0) or 0,
            source=self.name,
            source_id=str(track_id)[:128],
            stream_url=_clean(item.get("audio")),
            artwork_url=_clean(item.get("image")) or _clean(item.get("album_image")),
            genre=genre,
            language=_clean(item.get("language")) or _clean(musicinfo.get("lang")),
            mood=_clean(musicinfo.get("vocalinstrumental")) or _clean(musicinfo.get("speed")),
            tempo=tempo,
            popularity=popularity,
            isrc=_clean(item.get("isrc")),
            extra={"license": _clean(item.get("license_ccurl"))},
        )


def _clean(value: Any) -> str | None:
    """String-or-None coercion for loosely typed API fields."""
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _to_int(value: Any, default: int | None = None) -> int | None:
    """Int coercion for loosely typed API fields (never raises)."""
    if value is None or isinstance(value, bool):
        return default
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


__all__ = ["JamendoSource"]

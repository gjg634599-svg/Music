"""Abstract music source contract shared by all providers.

A *music source* is anything that can turn a text query into a list of
:class:`app.music.models.TrackResult` objects, fetch a single track by its
source id, resolve a permalink URL, and produce a playable stream URL.

Concrete implementations live next to this module (``local``, ``jamendo``,
``audius``). They must never create their own ``aiohttp.ClientSession`` —
the session is injected by the composition root.
"""

from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from typing import Any
from urllib.parse import urlparse

import aiohttp

from app.config import Settings
from app.errors import MusicSourceError
from app.logging import get_logger, log_extra
from app.music.models import StreamInfo, TrackResult

logger = get_logger(__name__)

#: How many attempts a GET makes before failing (1 try + 1 retry).
_HTTP_ATTEMPTS = 2


class HttpStatusError(MusicSourceError):
    """The upstream API answered with an HTTP error status.

    Distinguished from network failures so callers can decide not to
    retry / fail over to another host (e.g. a 404 will not heal).
    """


class MusicSource(ABC):
    """Base class for every music source.

    Subclasses set :attr:`name` (short lowercase identifier, also used as the
    ``source`` value on results) and implement :meth:`search` and
    :meth:`get_track`. URL resolution and streaming have conservative default
    implementations that report "unsupported".
    """

    name: str = "source"

    def __init__(self, settings: Settings, http: aiohttp.ClientSession) -> None:
        self.settings = settings
        self.http = http
        self._timeout = aiohttp.ClientTimeout(total=settings.http_timeout)

    def is_configured(self) -> bool:
        """True when the source has everything it needs to work."""
        return True

    @abstractmethod
    async def search(self, query: str, limit: int = 10) -> list[TrackResult]:
        """Search the source; may return an empty list, never raises for
        "not found"."""

    @abstractmethod
    async def get_track(self, source_id: str) -> TrackResult | None:
        """Fetch a single track by its source id (``None`` when unknown)."""

    async def resolve_url(self, url: str) -> TrackResult | None:
        """Resolve a source permalink to a track. Default: unsupported."""
        return None

    async def get_stream(self, source_id: str) -> StreamInfo | None:
        """Return stream info for a track id. Default: unsupported."""
        return None

    # ------------------------------------------------------------------
    # Shared HTTP helper (GET with one retry on client errors)
    # ------------------------------------------------------------------
    async def _get_json(
        self,
        url: str,
        params: dict[str, str] | None = None,
        *,
        allow_404: bool = False,
    ) -> Any:
        """GET a JSON document with a single retry on client errors.

        Args:
            url: Absolute https URL (never contains secrets in the path —
                credentials go into ``params`` and are not logged).
            params: Query parameters.
            allow_404: When True, a 404 response returns ``None`` instead of
                raising (used by ``get_track`` flows).

        Raises:
            MusicSourceError: On HTTP error status, network failure or
                invalid JSON payload.
        """
        last_error: Exception | None = None
        for attempt in range(1, _HTTP_ATTEMPTS + 1):
            try:
                # Redirects are NOT followed for JSON APIs: a 3xx from a
                # provider endpoint is surfaced as an error instead of
                # silently bouncing to an unvalidated host.
                async with self.http.get(
                    url, params=params, timeout=self._timeout, allow_redirects=False
                ) as resp:
                    if resp.status == 404 and allow_404:
                        return None
                    if resp.status >= 400:
                        body = await resp.text()
                        raise HttpStatusError(
                            f"{self.name}: HTTP {resp.status} for "
                            f"{self._safe_url(url)}: {body[:200]}"
                        )
                    try:
                        return await resp.json(content_type=None)
                    except (json.JSONDecodeError, aiohttp.ContentTypeError) as exc:
                        raise MusicSourceError(
                            f"{self.name}: invalid JSON from {self._safe_url(url)}"
                        ) from exc
            except MusicSourceError:
                raise
            except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
                last_error = exc
                if attempt < _HTTP_ATTEMPTS:
                    logger.warning(
                        "music.source.http_retry",
                        extra=log_extra(
                            source=self.name, host=urlparse(url).hostname or "", attempt=attempt
                        ),
                    )
        raise MusicSourceError(
            f"{self.name}: request to {self._safe_url(url)} failed: {last_error}"
        ) from last_error

    @staticmethod
    def _safe_url(url: str) -> str:
        """Strip the query string so logged URLs never leak credentials."""
        parsed = urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"


__all__ = ["HttpStatusError", "MusicSource"]

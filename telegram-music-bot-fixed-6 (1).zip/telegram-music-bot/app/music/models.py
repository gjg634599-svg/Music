"""Transport dataclasses for the music platform.

These are the source-agnostic representations passed between the search
aggregator, the music sources and the track resolver. They are intentionally
framework-free (no ORM, no aiohttp types) so they can be cached, serialized
to JSON and unit-tested without a database or network.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


def _as_str(value: Any) -> str | None:
    """Coerce a loosely-typed value to ``str | None``."""
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _as_int(value: Any, default: int | None = None) -> int | None:
    """Coerce a loosely-typed value to ``int | None`` (never raises)."""
    if value is None or isinstance(value, bool):
        return default
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


@dataclass(slots=True)
class TrackResult:
    """A single track as returned by a music source or URL resolver.

    ``source`` is one of ``local | jamendo | audius | upload | url``;
    ``source_id`` is the source-scoped identifier (string). The pair
    ``(source, source_id)`` is the dedupe key used by :class:`TrackResolver`.
    """

    title: str
    artist: str | None
    album: str | None
    duration_seconds: int
    source: str
    source_id: str
    stream_url: str | None = None
    artwork_url: str | None = None
    genre: str | None = None
    language: str | None = None
    mood: str | None = None
    tempo: int | None = None
    popularity: int = 0
    isrc: str | None = None
    extra: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Serialization (used by the search result cache)
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Plain-dict form, JSON-serializable (for Redis-backed caching)."""
        return {
            "title": self.title,
            "artist": self.artist,
            "album": self.album,
            "duration_seconds": self.duration_seconds,
            "source": self.source,
            "source_id": self.source_id,
            "stream_url": self.stream_url,
            "artwork_url": self.artwork_url,
            "genre": self.genre,
            "language": self.language,
            "mood": self.mood,
            "tempo": self.tempo,
            "popularity": self.popularity,
            "isrc": self.isrc,
            "extra": self.extra or {},
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TrackResult:
        """Rebuild a :class:`TrackResult` from :meth:`to_dict` output.

        Unknown keys are ignored and loosely-typed values are coerced, so
        cached payloads written by older code versions still load.
        """
        extra = data.get("extra") or {}
        if not isinstance(extra, dict):  # defensive: corrupted cache entry
            extra = {}
        return cls(
            title=_as_str(data.get("title")) or "Unknown",
            artist=_as_str(data.get("artist")),
            album=_as_str(data.get("album")),
            duration_seconds=_as_int(data.get("duration_seconds"), 0) or 0,
            source=_as_str(data.get("source")) or "unknown",
            source_id=str(data.get("source_id") or ""),
            stream_url=_as_str(data.get("stream_url")),
            artwork_url=_as_str(data.get("artwork_url")),
            genre=_as_str(data.get("genre")),
            language=_as_str(data.get("language")),
            mood=_as_str(data.get("mood")),
            tempo=_as_int(data.get("tempo")),
            popularity=_as_int(data.get("popularity"), 0) or 0,
            isrc=_as_str(data.get("isrc")),
            extra=dict(extra),
        )


@dataclass(slots=True)
class StreamInfo:
    """Where and how a track can be streamed right now.

    ``url_or_path`` is either an http(s) URL or an absolute local path;
    ``expires_at`` is a UNIX timestamp for signed URLs (``None`` = stable).
    """

    url_or_path: str
    is_local: bool
    expires_at: float | None = None


@dataclass(slots=True)
class AudioMetadata:
    """Tags extracted from an audio file (ffprobe or injected probe)."""

    title: str | None = None
    artist: str | None = None
    album: str | None = None
    duration_seconds: int = 0
    genre: str | None = None
    language: str | None = None
    tempo: int | None = None


__all__ = ["AudioMetadata", "StreamInfo", "TrackResult"]

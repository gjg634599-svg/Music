"""Text normalization for track titles, artists and dedupe keys.

All search / dedupe comparisons in the music platform go through these
functions so that ``"Héllo   WORLD!"`` and ``"hello world"`` match.

- :func:`normalize_text` — lowercase, strip punctuation and diacritics
  (decomposed accents removed), collapse whitespace.
- :func:`normalized_key` — stable ``(title, artist)`` dedupe key.
- :func:`clean_title` — removes ``(Official Video)``-style suffixes.
"""

from __future__ import annotations

import re
import unicodedata

#: Non-word characters (anything that is not a unicode letter/digit and not
#: an underscore) are replaced with a single space before whitespace collapse.
_PUNCT_RE = re.compile(r"[\W_]+", re.UNICODE)

#: A trailing bracketed segment, e.g. ``(Official Video)`` or ``[HD]``.
_TRAILING_BRACKETS_RE = re.compile(r"[\(\[\{][^\)\]\}]*[\)\]\}]\s*$", re.IGNORECASE)

#: A trailing dash/pipe suffix, e.g. ``- Official Video`` or ``| Audio``.
_TRAILING_SUFFIX_RE = re.compile(
    r"\s*[-–—|]\s*(?:official\s+)?(?:music\s+)?"
    r"(?:video|audio|lyrics?|visualizer|videoclip|mv)\s*$",
    re.IGNORECASE,
)

#: Tokens considered "noise" inside a trailing bracketed segment. If every
#: token of the segment is noise (or a plain number), the segment is removed.
_NOISE_TOKENS = frozenset(
    {
        "official",
        "oficial",
        "officiel",
        "officially",
        "video",
        "videoclip",
        "videomix",
        "music",
        "musica",
        "lyric",
        "lyrics",
        "lyrical",
        "audio",
        "hd",
        "hq",
        "sd",
        "uhd",
        "4k",
        "2k",
        "8k",
        "1080p",
        "720p",
        "60fps",
        "fps",
        "mv",
        "mvm",
        "clip",
        "officialvideo",
        "clipofficial",
        "visualizer",
        "visualiser",
        "remaster",
        "remastered",
        "remasterizada",
        "restored",
        "original",
        "officialaudio",
        "officialmusic",
        "videoclipoficial",
        "sub",
        "subtitulado",
        "subtitulados",
        "subtitulos",
        "espanol",
        "español",
        "esp",
        "english",
        "subtitrate",
        "letra",
        "letras",
        "version",
    }
)

#: Maximum sensible lengths (match ORM column sizes downstream).
_MAX_TITLE = 256


def normalize_text(s: str) -> str:
    """Lowercase, strip punctuation and diacritics-lite, collapse whitespace.

    Accents are removed via NFD decomposition (``é`` → ``e``); punctuation and
    underscores become spaces; runs of whitespace collapse to one space.

    Examples:
        >>> normalize_text("  Héllo   WORLD! ")
        'hello world'
        >>> normalize_text("Rock'n'Roll - Remastered")
        'rock n roll remastered'
    """
    if not s:
        return ""
    decomposed = unicodedata.normalize("NFD", s)
    without_marks = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    lowered = without_marks.lower()
    spaced = _PUNCT_RE.sub(" ", lowered)
    return " ".join(spaced.split())


def normalized_key(title: str | None, artist: str | None = None) -> str:
    """Stable dedupe key for a (title, artist) pair.

    The title is first cleaned of "(Official Video)"-style suffixes so that
    the same song found on two sources (or with different upload titles)
    collapses to one key.

    Examples:
        >>> normalized_key("Believer (Official Video)", "Imagine Dragons")
        'believer::imagine dragons'
    """
    clean = clean_title(title or "")
    return f"{normalize_text(clean)[:_MAX_TITLE]}::{normalize_text(artist or '')[:_MAX_TITLE]}"


def clean_title(title: str | None) -> str:
    """Remove ``(Official Video)``-style noise suffixes from a track title.

    Handles repeated trailing segments (``Song (Official Video) [HD]``),
    square/curly brackets, dash/pipe suffixes (``Song - Official Audio``)
    and keeps meaningful segments like ``(Live at Wembley)``.
    Returns the original (stripped) title when nothing would remain.
    """
    if not title:
        return ""
    cleaned = title.strip()
    changed = False
    for _ in range(6):  # bounded: at most a few trailing noise segments
        stripped = _TRAILING_SUFFIX_RE.sub("", cleaned).rstrip()
        if stripped != cleaned:
            cleaned = stripped
            changed = True
            continue
        match = _TRAILING_BRACKETS_RE.search(cleaned)
        if match is None:
            break
        segment = cleaned[: match.start()].rstrip()
        inner = match.group(0)[1:-1]
        if _is_noise_segment(inner):
            cleaned = segment
            changed = True
        else:
            break
    result = " ".join(cleaned.split())
    if not result:
        # The whole title was noise — keep the original rather than "".
        return title.strip()
    return result


def _is_noise_segment(text: str) -> bool:
    """True when every token in a bracketed segment is noise or a number."""
    tokens = normalize_text(text).split()
    if not tokens:
        return True
    return all(token in _NOISE_TOKENS or token.isdigit() for token in tokens)


__all__ = ["clean_title", "normalize_text", "normalized_key"]

"""Taste profiles built from listening history and likes.

:class:`ProfileBuilder` aggregates a user's (or a group's) recent listening
history into a :class:`TasteProfile`, which the scoring function consumes.

The builder depends on repositories owned by other tasks
(``ListeningHistoryRepository`` / ``LikedTrackRepository`` from
``app.database.repositories.library``), so it talks to them through the
duck-typed interfaces documented on each protocol below. Method-name
fallbacks keep the builder tolerant to small naming differences at wiring
time, and every fetch degrades gracefully (an empty profile still yields
popularity-driven recommendations).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from app.logging import get_logger, log_extra

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models.music import Track
    from app.database.models.users import ListeningHistory

logger = get_logger(__name__)

#: How many history rows feed a personal profile.
USER_HISTORY_LIMIT = 200

#: How many history rows feed a group profile.
GROUP_HISTORY_LIMIT = 500

#: How many unique recent track ids are kept in the profile.
RECENT_TRACK_LIMIT = 50

#: Duck-typed method names tried on the history repository (user scope).
_USER_HISTORY_METHODS = ("user_history", "recent_for_user", "history_for_user", "list_for_user")

#: Duck-typed method names tried on the history repository (group scope).
_GROUP_HISTORY_METHODS = ("group_history", "history_for_group", "list_for_group")

#: Duck-typed method names tried on the liked-tracks repository.
_LIKED_METHODS = ("list_tracks_by_tg", "list_tracks", "liked_tracks", "tracks", "list")


@runtime_checkable
class HistoryStats(Protocol):
    """What ProfileBuilder needs from ListeningHistoryRepository.

    ``user_history`` is expected to accept the *Telegram* user id and return
    rows ordered most-recent-first (a ``limit`` keyword is accepted).
    """

    async def user_history(self, user_tg_id: int, limit: int = 200) -> list[ListeningHistory]: ...

    async def group_history(self, group_tg_id: int, limit: int = 500) -> list[ListeningHistory]: ...


@runtime_checkable
class LikedTracks(Protocol):
    """What ProfileBuilder needs from LikedTrackRepository.

    ``list_tracks`` is expected to return hydrated ``Track`` models (with
    ``artist``/``genres`` loaded) for the given Telegram user id.
    """

    async def list_tracks(self, user_tg_id: int, limit: int = 500) -> list[Track]: ...


@runtime_checkable
class TrackLookup(Protocol):
    """Optional track hydration source (usually TrackRepository)."""

    async def get_by_id(self, track_id: int) -> Track | None: ...


@dataclass(slots=True)
class TasteProfile:
    """Aggregated listening preferences for one user or group."""

    liked_track_ids: set[int] = field(default_factory=set)
    liked_artist_ids: set[int] = field(default_factory=set)
    liked_genre_ids: set[int] = field(default_factory=set)
    recent_track_ids: set[int] = field(default_factory=set)
    recent_artist_ids: set[int] = field(default_factory=set)
    skipped_track_ids: set[int] = field(default_factory=set)
    play_counts: dict[int, int] = field(default_factory=dict)
    artist_weights: dict[int, float] = field(default_factory=dict)

    @property
    def is_empty(self) -> bool:
        """True when the profile carries no signal at all."""
        return not (
            self.liked_track_ids
            or self.liked_artist_ids
            or self.liked_genre_ids
            or self.recent_track_ids
            or self.play_counts
            or self.artist_weights
        )


class ProfileBuilder:
    """Builds :class:`TasteProfile` objects from history rows and likes."""

    def __init__(
        self,
        history: HistoryStats,
        liked: LikedTracks,
        *,
        tracks: TrackLookup | None = None,
    ) -> None:
        self._history = history
        self._liked = liked
        self._tracks = tracks

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def build_user(self, user_tg_id: int) -> TasteProfile:
        """Aggregate the last plays and likes of a single user."""
        rows = await self._user_history_rows(user_tg_id, USER_HISTORY_LIMIT)
        artist_of = await self._artist_map({row.track_id for row in rows})
        profile = self._aggregate(rows, artist_of)

        for track in await self._liked_track_models(user_tg_id):
            profile.liked_track_ids.add(int(track.id))
            if track.artist_id is not None:
                profile.liked_artist_ids.add(int(track.artist_id))
            for genre in self._track_genres(track):
                profile.liked_genre_ids.add(int(genre.id))

        if profile.is_empty:
            logger.info(
                "profile.user_empty",
                extra=log_extra(user_id=user_tg_id),
            )
        return profile

    async def build_group(self, group_tg_id: int) -> TasteProfile:
        """Aggregate the recent listening history of an entire group."""
        rows = await self._group_history_rows(group_tg_id, GROUP_HISTORY_LIMIT)
        artist_of = await self._artist_map({row.track_id for row in rows})
        profile = self._aggregate(rows, artist_of)
        if profile.is_empty:
            logger.info(
                "profile.group_empty",
                extra=log_extra(group_id=group_tg_id),
            )
        return profile

    # ------------------------------------------------------------------
    # Aggregation
    # ------------------------------------------------------------------
    def _aggregate(
        self, rows: list[ListeningHistory], artist_of: dict[int, int]
    ) -> TasteProfile:
        """Turn raw history rows into a taste profile."""
        profile = TasteProfile()
        if not rows:
            return profile

        # Autoincrement ids approximate chronology and are always comparable
        # (SQLite returns naive datetimes, which make tz-aware sorting risky).
        ordered = sorted(rows, key=lambda row: row.id, reverse=True)

        recent: list[int] = []
        for row in ordered:
            track_id = int(row.track_id)
            profile.play_counts[track_id] = profile.play_counts.get(track_id, 0) + 1
            if row.skipped:
                profile.skipped_track_ids.add(track_id)
            if len(recent) < RECENT_TRACK_LIMIT and track_id not in recent:
                recent.append(track_id)
        profile.recent_track_ids = set(recent)

        artist_counts: dict[int, int] = {}
        for track_id, count in profile.play_counts.items():
            artist_id = artist_of.get(track_id)
            if artist_id is None:
                continue
            artist_counts[artist_id] = artist_counts.get(artist_id, 0) + count
        max_count = max(artist_counts.values(), default=0)
        if max_count > 0:
            profile.artist_weights = {
                artist_id: round(count / max_count, 4)
                for artist_id, count in artist_counts.items()
            }

        for track_id in recent:
            artist_id = artist_of.get(track_id)
            if artist_id is not None:
                profile.recent_artist_ids.add(artist_id)
        return profile

    # ------------------------------------------------------------------
    # Duck-typed fetchers
    # ------------------------------------------------------------------
    async def _user_history_rows(
        self, user_tg_id: int, limit: int
    ) -> list[ListeningHistory]:
        for name in _USER_HISTORY_METHODS:
            method = getattr(self._history, name, None)
            if method is None:
                continue
            rows = await self._call_history(method, user_tg_id, limit)
            if rows is not None:
                return rows
        logger.warning(
            "profile.user_history_unavailable",
            extra=log_extra(user_id=user_tg_id),
        )
        return []

    async def _group_history_rows(
        self, group_tg_id: int, limit: int
    ) -> list[ListeningHistory]:
        for name in _GROUP_HISTORY_METHODS:
            method = getattr(self._history, name, None)
            if method is None:
                continue
            rows = await self._call_history(method, group_tg_id, limit)
            if rows is not None:
                return rows
        logger.warning(
            "profile.group_history_unavailable",
            extra=log_extra(group_id=group_tg_id),
        )
        return []

    @staticmethod
    async def _call_history(
        method: Any, owner_id: int, limit: int
    ) -> list[ListeningHistory] | None:
        try:
            rows = await method(owner_id, limit=limit)
        except TypeError:
            try:
                rows = await method(owner_id, limit)
            except Exception:  # noqa: BLE001 — wrong shape, try next name
                return None
        except Exception as exc:  # noqa: BLE001 — fetch errors degrade to []
            logger.warning(
                "profile.history_fetch_failed",
                extra=log_extra(owner_id=owner_id, error=str(exc)[:160]),
            )
            return None
        return list(rows or [])

    async def _liked_track_models(self, user_tg_id: int) -> list[Track]:
        for name in _LIKED_METHODS:
            method = getattr(self._liked, name, None)
            if method is None:
                continue
            try:
                rows = await method(user_tg_id, limit=500)
            except TypeError:
                try:
                    rows = await method(user_tg_id)
                except Exception:  # noqa: BLE001
                    continue
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "profile.likes_fetch_failed",
                    extra=log_extra(user_id=user_tg_id, error=str(exc)[:160]),
                )
                return []
            rows = list(rows or [])
            # Some repositories return bare LikedTrack rows (id + track_id).
            models = [row for row in rows if hasattr(row, "artist_id")]
            if models:
                return models
            track_ids = [
                int(row.track_id) for row in rows if hasattr(row, "track_id")
            ]
            if track_ids:
                return await self._lookup_tracks(track_ids)
            return []
        logger.warning(
            "profile.likes_method_unavailable",
            extra=log_extra(user_id=user_tg_id),
        )
        return []

    # ------------------------------------------------------------------
    # Track hydration helpers
    # ------------------------------------------------------------------
    async def _artist_map(self, track_ids: set[int]) -> dict[int, int]:
        """Map track_id -> artist_id for the given tracks (best effort)."""
        if not track_ids or self._tracks is None:
            return {}
        mapping: dict[int, int] = {}
        get_by_ids = getattr(self._tracks, "get_by_ids", None)
        if get_by_ids is not None:
            try:
                rows = await get_by_ids(list(track_ids))
                for track in rows or []:
                    if track.artist_id is not None:
                        mapping[int(track.id)] = int(track.artist_id)
                if mapping:
                    return mapping
            except Exception as exc:  # noqa: BLE001
                logger.debug(
                    "profile.bulk_lookup_failed",
                    extra=log_extra(error=str(exc)[:160]),
                )
        for track_id in track_ids:
            track = await self._lookup_track(track_id)
            if track is not None and track.artist_id is not None:
                mapping[track_id] = int(track.artist_id)
        return mapping

    async def _lookup_tracks(self, track_ids: list[int]) -> list[Track]:
        """Hydrate Track models by id (best effort, order preserved)."""
        tracks: list[Track] = []
        for track_id in track_ids:
            track = await self._lookup_track(track_id)
            if track is not None:
                tracks.append(track)
        return tracks

    async def _lookup_track(self, track_id: int) -> Track | None:
        if self._tracks is None:
            return None
        try:
            return await self._tracks.get_by_id(int(track_id))
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "profile.track_lookup_failed",
                extra=log_extra(track_id=track_id, error=str(exc)[:160]),
            )
            return None

    @staticmethod
    def _track_genres(track: Track) -> list[Any]:
        """Read ``track.genres`` defensively (detached instances may fail)."""
        try:
            return list(track.genres or [])
        except Exception:  # noqa: BLE001 — detached/unloaded relationship
            return []


__all__ = ["HistoryStats", "LikedTracks", "ProfileBuilder", "TasteProfile", "TrackLookup"]

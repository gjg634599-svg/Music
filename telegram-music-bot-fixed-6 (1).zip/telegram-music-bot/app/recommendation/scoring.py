"""Deterministic, configurable recommendation scoring.

The scoring function is pure: given a list of :class:`CandidateTrack`, a
:class:`~app.recommendation.profile.TasteProfile`, a
:class:`RecommendationWeights` instance and an optional seed track, it
produces a descending-score list of :class:`ScoredTrack` with a short
human-readable ``reason`` for each pick.

Weight defaults are identical to ``DEFAULT_SETTINGS['recommendation_weights']``
in ``app.database.defaults`` so a fresh installation behaves the same before
an admin tunes the weights.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import TYPE_CHECKING, Any

from app.recommendation.similarity import genre_overlap, title_token_overlap

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.recommendation.profile import TasteProfile


@dataclass(slots=True)
class RecommendationWeights:
    """Weights applied to each scoring component (penalties are subtracted)."""

    track_similarity: float = 1.0
    artist_similarity: float = 1.5
    genre_similarity: float = 1.2
    user_preference: float = 2.0
    popularity: float = 0.6
    playlist_context: float = 0.8
    recently_played_penalty: float = 2.5
    skipped_track_penalty: float = 1.8
    same_track_penalty: float = 6.0

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> RecommendationWeights:
        """Build weights from a settings mapping with safe float coercion.

        Unknown keys are ignored; unparsable values fall back to the field
        default — a single bad value must never break recommendations.
        """
        weights = cls()
        if not isinstance(data, dict):
            return weights
        for field_info in fields(weights):
            if field_info.name not in data:
                continue
            raw = data[field_info.name]
            if raw is None:
                continue
            try:
                setattr(weights, field_info.name, float(raw))
            except (TypeError, ValueError):
                continue
        return weights


@dataclass(slots=True)
class CandidateTrack:
    """The minimal track data the scorer needs (source-agnostic)."""

    track_id: int
    artist_id: int | None = None
    genre_ids: set[int] = field(default_factory=set)
    language: str | None = None
    tempo: int | None = None
    popularity: int = 0
    normalized_title: str = ""
    artist_normalized: str = ""


@dataclass(slots=True)
class ScoredTrack:
    """A scored recommendation with a short human-readable reason."""

    track_id: int
    score: float
    reason: str


#: Short reason strings per dominant component.
_REASONS = {
    "artist_similarity": "same artist",
    "artist_liked": "liked artist",
    "track_similarity": "similar title",
    "genre_similarity": "similar genre",
    "user_preference": "matches your taste",
    "popularity": "popular pick",
    "playlist_context": "from your playlist",
}
_FALLBACK_REASON = "catalog pick"


def _reason_for(
    label: str,
    *,
    candidate: CandidateTrack,
    seed: CandidateTrack | None,
    profile: TasteProfile,
) -> str:
    """Map the dominant scoring component to a short reason string."""
    if label == "artist_similarity":
        if seed is not None and candidate.artist_id is not None and candidate.artist_id == seed.artist_id:
            return _REASONS["artist_similarity"]
        return _REASONS["artist_liked"]
    if label == "user_preference":
        if candidate.track_id in profile.liked_track_ids:
            return "liked track"
        return "favorite artist"
    return _REASONS.get(label, _FALLBACK_REASON)


def score_candidates(
    candidates: list[CandidateTrack],
    profile: TasteProfile,
    weights: RecommendationWeights,
    *,
    seed: CandidateTrack | None,
    playlist_context_ids: set[int],
) -> list[ScoredTrack]:
    """Score every candidate and return them sorted by score (descending).

    The score is the weighted sum of positive components minus weighted
    penalty flags (recently played, skipped, identical to the seed).
    """
    scored: list[ScoredTrack] = []
    seen: set[int] = set()
    for candidate in candidates:
        if candidate.track_id in seen:
            continue
        seen.add(candidate.track_id)
        scored.append(_score_one(candidate, profile, weights, seed=seed, playlist_context_ids=playlist_context_ids))
    scored.sort(key=lambda item: item.score, reverse=True)
    return scored


def _score_one(
    candidate: CandidateTrack,
    profile: TasteProfile,
    weights: RecommendationWeights,
    *,
    seed: CandidateTrack | None,
    playlist_context_ids: set[int],
) -> ScoredTrack:
    """Compute the weighted score and dominant reason for one candidate."""
    if seed is not None:
        track_similarity = title_token_overlap(
            candidate.normalized_title, seed.normalized_title
        )
        if candidate.artist_id is not None and candidate.artist_id == seed.artist_id:
            artist_similarity = 1.0
        elif candidate.artist_id in profile.liked_artist_ids:
            artist_similarity = 1.0
        else:
            artist_similarity = 0.0
        genre_similarity = genre_overlap(candidate.genre_ids, seed.genre_ids)
        same_track_flag = 1.0 if candidate.track_id == seed.track_id else 0.0
    else:
        track_similarity = 0.0
        artist_similarity = 1.0 if candidate.artist_id in profile.liked_artist_ids else 0.0
        genre_similarity = genre_overlap(candidate.genre_ids, profile.liked_genre_ids)
        same_track_flag = 0.0

    user_preference = float(profile.artist_weights.get(candidate.artist_id, 0.0)) + (
        1.0 if candidate.track_id in profile.liked_track_ids else 0.0
    )
    popularity = min(1.0, max(0.0, float(candidate.popularity or 0)) / 100.0)
    playlist_context = 1.0 if candidate.track_id in playlist_context_ids else 0.0
    recently_played = 1.0 if candidate.track_id in profile.recent_track_ids else 0.0
    skipped = 1.0 if candidate.track_id in profile.skipped_track_ids else 0.0

    contributions = {
        "track_similarity": track_similarity * weights.track_similarity,
        "artist_similarity": artist_similarity * weights.artist_similarity,
        "genre_similarity": genre_similarity * weights.genre_similarity,
        "user_preference": user_preference * weights.user_preference,
        "popularity": popularity * weights.popularity,
        "playlist_context": playlist_context * weights.playlist_context,
    }
    penalties = (
        recently_played * weights.recently_played_penalty
        + skipped * weights.skipped_track_penalty
        + same_track_flag * weights.same_track_penalty
    )
    score = sum(contributions.values()) - penalties

    label, value = max(contributions.items(), key=lambda kv: kv[1])
    if value <= 0.0:
        reason = _FALLBACK_REASON
    else:
        reason = _reason_for(
            label, candidate=candidate, seed=seed, profile=profile
        )

    return ScoredTrack(
        track_id=candidate.track_id,
        score=round(score, 4),
        reason=reason,
    )


__all__ = [
    "CandidateTrack",
    "RecommendationWeights",
    "ScoredTrack",
    "score_candidates",
]

"""Recommendation engine: candidate gathering + scoring + caching.

The engine assembles candidates from the catalog (popular tracks plus, when
a seed exists, the seed's artist and genres), scores them with the pure
scoring function and caches the top results for a short TTL.

Results are cached *before* per-call exclusions so that successive autoplay
ticks (which exclude everything already queued) still reuse one computation.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from app.cache.redis import CacheProtocol
from app.logging import get_logger, log_extra
from app.recommendation.profile import ProfileBuilder
from app.recommendation.scoring import (
    CandidateTrack,
    RecommendationWeights,
    ScoredTrack,
    score_candidates,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models.music import Track

logger = get_logger(__name__)

#: How many top results are cached per (scope, owner, seed, limit) key.
CACHE_DEPTH = 30

#: Cache TTL in seconds for recommendation lists.
CACHE_TTL = 120

#: Default candidate pool size when no settings are present.
DEFAULT_CANDIDATE_LIMIT = 200

#: Default minimum score for a recommendation to be returned.
DEFAULT_MIN_SCORE = 0.1


@runtime_checkable
class TrackProvider(Protocol):
    """Duck-typed TrackRepository surface used by the engine."""

    async def get_by_id(self, track_id: int) -> Track | None: ...

    async def popular(self, limit: int = 50) -> list[Track]: ...

    async def by_artist(self, artist_id: int, limit: int = 50) -> list[Track]: ...

    async def by_genres(self, genre_ids: set[int], limit: int = 50) -> list[Track]: ...


@runtime_checkable
class SettingsProvider(Protocol):
    """Duck-typed settings source (BotSettingsRepository / SettingsService)."""

    async def get(self, key: str, default: Any = None) -> Any: ...


class RecommendationEngine:
    """Spotify-style recommender with configurable weights and caching."""

    def __init__(
        self,
        tracks: TrackProvider,
        profiles: ProfileBuilder,
        settings: SettingsProvider,
        cache: CacheProtocol,
    ) -> None:
        self._tracks = tracks
        self._profiles = profiles
        self._settings = settings
        self._cache = cache

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def recommend_for_user(
        self,
        user_tg_id: int,
        seed_track_id: int | None = None,
        limit: int = 1,
        exclude: set[int] | None = None,
    ) -> list[ScoredTrack]:
        """Personalized recommendations for a user (seeded or cold-start)."""
        return await self._recommend(
            "user", int(user_tg_id), seed_track_id, limit, exclude
        )

    async def recommend_for_group(
        self,
        group_tg_id: int,
        seed_track_id: int | None = None,
        limit: int = 1,
        exclude: set[int] | None = None,
    ) -> list[ScoredTrack]:
        """Recommendations for a group based on aggregated member history."""
        return await self._recommend(
            "group", int(group_tg_id), seed_track_id, limit, exclude
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _recommend(
        self,
        scope: str,
        owner_id: int,
        seed_track_id: int | None,
        limit: int,
        exclude: set[int] | None,
    ) -> list[ScoredTrack]:
        limit = max(0, int(limit))
        if limit == 0:
            return []
        excluded = {int(tid) for tid in (exclude or set())}

        cache_key = f"reco:{scope}:{owner_id}:{seed_track_id}:{limit}"
        from_cache = True
        scored = await self._cache_get(cache_key)
        if scored is None:
            from_cache = False
            scored = await self._compute(scope, owner_id, seed_track_id)
            await self._cache_put(cache_key, scored)

        result = [
            item for item in scored if item.track_id not in excluded
        ][:limit]
        logger.info(
            "recommendation.served",
            extra=log_extra(
                scope=scope,
                owner_id=owner_id,
                seed_track_id=seed_track_id,
                limit=limit,
                results=len(result),
                cached=from_cache,
            ),
        )
        return result

    async def _compute(
        self, scope: str, owner_id: int, seed_track_id: int | None
    ) -> list[ScoredTrack]:
        """Run the full pipeline and return the top-CACHE_DEPTH scored list."""
        options = await self._setting("recommendation_options", {}) or {}
        try:
            candidate_limit = int(options.get("candidate_limit", DEFAULT_CANDIDATE_LIMIT))
        except (TypeError, ValueError):
            candidate_limit = DEFAULT_CANDIDATE_LIMIT
        try:
            min_score = float(options.get("min_score", DEFAULT_MIN_SCORE))
        except (TypeError, ValueError):
            min_score = DEFAULT_MIN_SCORE

        weights = RecommendationWeights.from_dict(
            await self._setting("recommendation_weights", {})
        )

        seed = await self._seed_candidate(seed_track_id)
        candidates = await self._candidates(seed, max(1, candidate_limit))

        if scope == "group":
            profile = await self._profiles.build_group(owner_id)
        else:
            profile = await self._profiles.build_user(owner_id)

        scored = score_candidates(
            candidates,
            profile,
            weights,
            seed=seed,
            playlist_context_ids=set(),
        )
        filtered = [
            item
            for item in scored
            if item.score >= min_score
            and (seed is None or item.track_id != seed.track_id)
        ]
        return filtered[:CACHE_DEPTH]

    async def _seed_candidate(
        self, seed_track_id: int | None
    ) -> CandidateTrack | None:
        """Load the seed track (if any) as a CandidateTrack."""
        if seed_track_id is None:
            return None
        track = await self._fetch_track(int(seed_track_id))
        if track is None:
            logger.info(
                "recommendation.seed_missing",
                extra=log_extra(seed_track_id=seed_track_id),
            )
            return None
        return _candidate_from_track(track)

    async def _candidates(
        self, seed: CandidateTrack | None, limit: int
    ) -> list[CandidateTrack]:
        """Assemble the candidate pool: popular + seed artist + seed genres."""
        pool: dict[int, Track] = {}

        for track in await self._try_fetch(("popular", "random"), limit=limit):
            pool[int(track.id)] = track

        if seed is not None:
            if seed.artist_id is not None:
                for track in await self._try_fetch(
                    ("by_artist",), seed.artist_id, limit=limit
                ):
                    pool[int(track.id)] = track
            if seed.genre_ids:
                for track in await self._try_fetch(
                    ("by_genres", "by_genre_list"), seed.genre_ids, limit=limit
                ):
                    pool[int(track.id)] = track

        if seed is not None:
            pool.pop(int(seed.track_id), None)

        return [_candidate_from_track(track) for track in pool.values()]

    async def _fetch_track(self, track_id: int) -> Track | None:
        try:
            return await self._tracks.get_by_id(track_id)
        except Exception as exc:  # noqa: BLE001 — duck-typed repo
            logger.warning(
                "recommendation.track_fetch_failed",
                extra=log_extra(track_id=track_id, error=str(exc)[:160]),
            )
            return None

    async def _try_fetch(self, names: tuple[str, ...], *args: Any, **kwargs: Any) -> list[Track]:
        """Call the first available repo method; failures degrade to []."""
        for name in names:
            method = getattr(self._tracks, name, None)
            if method is None:
                continue
            try:
                rows = await method(*args, **kwargs)
            except TypeError:
                continue
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "recommendation.candidate_fetch_failed",
                    extra=log_extra(method=name, error=str(exc)[:160]),
                )
                continue
            return list(rows or [])
        return []

    async def _setting(self, key: str, default: Any = None) -> Any:
        try:
            value = await self._settings.get(key, default)
        except Exception as exc:  # noqa: BLE001 — settings must not break recos
            logger.warning(
                "recommendation.settings_failed",
                extra=log_extra(key=key, error=str(exc)[:160]),
            )
            return default
        return default if value is None else value

    # ------------------------------------------------------------------
    # Cache (JSON-encoded so both memory and Redis caches work)
    # ------------------------------------------------------------------
    async def _cache_get(self, key: str) -> list[ScoredTrack] | None:
        try:
            raw = await self._cache.get(key)
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "recommendation.cache_read_failed",
                extra=log_extra(key=key, error=str(exc)[:160]),
            )
            return None
        if raw is None:
            return None
        try:
            data = json.loads(raw) if isinstance(raw, str) else raw
            return [
                ScoredTrack(
                    track_id=int(item["track_id"]),
                    score=float(item.get("score", 0.0)),
                    reason=str(item.get("reason", "")),
                )
                for item in (data or [])
                if isinstance(item, dict) and "track_id" in item
            ]
        except (ValueError, TypeError, KeyError) as exc:
            logger.debug(
                "recommendation.cache_decode_failed",
                extra=log_extra(key=key, error=str(exc)[:160]),
            )
            return None

    async def _cache_put(self, key: str, scored: list[ScoredTrack]) -> None:
        payload = json.dumps(
            [
                {
                    "track_id": item.track_id,
                    "score": round(item.score, 4),
                    "reason": item.reason,
                }
                for item in scored
            ],
            ensure_ascii=False,
        )
        try:
            await self._cache.set(key, payload, ttl=CACHE_TTL)
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "recommendation.cache_write_failed",
                extra=log_extra(key=key, error=str(exc)[:160]),
            )


def _candidate_from_track(track: Track) -> CandidateTrack:
    """Project an ORM Track onto the scorer's CandidateTrack."""
    try:
        genre_ids = {int(genre.id) for genre in (track.genres or [])}
    except Exception:  # noqa: BLE001 — detached/unloaded relationship
        genre_ids = set()
    try:
        artist = track.artist
    except Exception:  # noqa: BLE001 — DetachedInstanceError etc.
        artist = None
    artist_normalized = (
        getattr(artist, "normalized_name", None)
        or getattr(artist, "name", None)
        or ""
    )
    return CandidateTrack(
        track_id=int(track.id),
        artist_id=int(track.artist_id) if track.artist_id is not None else None,
        genre_ids=genre_ids,
        language=getattr(track, "language", None),
        tempo=getattr(track, "tempo", None),
        popularity=int(getattr(track, "popularity", 0) or 0),
        normalized_title=(getattr(track, "normalized_title", None) or getattr(track, "title", "") or "").lower(),
        artist_normalized=(artist_normalized or "").lower(),
    )


__all__ = ["RecommendationEngine", "SettingsProvider", "TrackProvider"]

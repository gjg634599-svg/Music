"""Pure similarity metrics used by the recommendation scoring function.

All functions are deterministic and side-effect free, which keeps the
scoring pipeline unit-testable and cache-friendly.
"""

from __future__ import annotations

import re

#: Unicode-aware "word" characters: latin, digits and cyrillic.
_TOKEN_RE = re.compile(r"[^0-9a-z\u00c0-\u024f\u0400-\u04ff]+")


def genre_overlap(a: set[int], b: set[int]) -> float:
    """Jaccard similarity between two genre-id sets (0.0 when either is empty)."""
    if not a or not b:
        return 0.0
    intersection = len(a & b)
    if intersection == 0:
        return 0.0
    return intersection / len(a | b)


def tempo_closeness(a: int | None, b: int | None) -> float:
    """How close two tempos (BPM) are, in ``[0, 1]``.

    Unknown tempo (either side ``None``) is neutral: ``0.5``. A difference of
    60 BPM or more scores ``0.0``.
    """
    if a is None or b is None:
        return 0.5
    try:
        delta = abs(float(a) - float(b))
    except (TypeError, ValueError):
        return 0.5
    return 1.0 - min(1.0, delta / 60.0)


def _tokens(text: str) -> set[str]:
    """Lowercased alphanumeric token set of a title."""
    if not text:
        return set()
    return {t for t in _TOKEN_RE.split(text.lower()) if t}


def title_token_overlap(a: str, b: str) -> float:
    """Jaccard similarity between the token sets of two normalized titles."""
    tokens_a = _tokens(a)
    tokens_b = _tokens(b)
    if not tokens_a or not tokens_b:
        return 0.0
    intersection = len(tokens_a & tokens_b)
    if intersection == 0:
        return 0.0
    return intersection / len(tokens_a | tokens_b)


__all__ = ["genre_overlap", "tempo_closeness", "title_token_overlap"]

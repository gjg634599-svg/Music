"""Structured logging with secret redaction.

Log records are rendered as single-line structured messages::

    2026-01-01 10:00:00 INFO playback.start group_id=-100123 track_id=123

Design (fixed after the production ``--- Logging error ---`` incident):

* Records are **never pre-rendered by the filter**. ``record.msg`` and
  positional ``record.args`` stay untouched so the standard
  ``LogRecord.getMessage()`` %-interpolation works for every handler —
  including lazy parameterized logging used by aiogram and Telethon
  (``logger.info("Connecting to %s...", connection)``).
* A record may be formatted by any number of handlers: interpolation is
  pure and idempotent, so no handler can corrupt the record for another.
* Mapping-style args (``logger.info("%(user)s", {"user": ...})``) are
  redacted **by replacing values, keeping keys** — interpolation still
  works while sensitive values are masked.
* The formatter renders defensively: a genuinely malformed record (e.g.
  a placeholder/argument mismatch from a third-party library) renders a
  best-effort representation instead of raising — and never recursively
  logs from inside the logging pipeline.
* Secret redaction works on three layers:
    1. structured ``x_extra`` values (key-name based),
    2. mapping-args values (key-name based),
    3. the final rendered text (pattern based: bot tokens, API hashes,
       session strings, phone numbers, ``key=value`` leaks).

Telegram bot tokens and userbot session strings must never reach the logs.
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any

_REDACT_MARK = "***REDACTED***"
_SENSITIVE_KEYS = (
    "token",
    "session",
    "session_string",
    "password",
    "secret",
    "api_hash",
    "api_key",
    "auth_key",
    "encryption_key",
    "login_code",
)
_EXTRA = "x_extra"

# ----------------------------------------------------------------------
# Pattern-based redaction of *rendered* text (layer 3).
# ----------------------------------------------------------------------
#: Telegram bot tokens look like ``123456789:AA...`` (34+ url-safe chars).
_BOT_TOKEN_RE = re.compile(r"\b\d{8,10}:[A-Za-z0-9_-]{30,}\b")
#: API hashes / hex secrets (Telethon API hashes are 32 hex chars).
_HEX_SECRET_RE = re.compile(r"\b[0-9a-fA-F]{32,}\b")
#: Exported session strings / other long base64-ish blobs.
_LONG_BLOB_RE = re.compile(r"\b[A-Za-z0-9+/=_-]{200,}\b")
#: International phone numbers (E.164-ish) — never log them.
_PHONE_RE = re.compile(r"\+\d{10,15}\b")
#: ``token=...`` / ``password: ...`` style leaks inside rendered text.
_KEY_VALUE_RE = re.compile(
    r"(?i)\b(token|api_hash|api_key|password|session_string|auth_key|"
    r"encryption_key|login_code|secret)\b['\"]?\s*[:=]\s*['\"]?[^\s'\"]+"
)


def is_sensitive_key(key: str) -> bool:
    """Return True when a logging key name looks sensitive."""
    lowered = key.lower()
    return any(marker in lowered for marker in _SENSITIVE_KEYS)


def redact(mapping: Mapping[str, Any]) -> dict[str, Any]:
    """Return a copy of *mapping* with sensitive values masked."""
    safe: dict[str, Any] = {}
    for key, value in mapping.items():
        if is_sensitive_key(str(key)):
            safe[str(key)] = _REDACT_MARK
        else:
            safe[str(key)] = value
    return safe


def redact_text(text: str) -> str:
    """Mask secret-looking substrings inside already-rendered text."""
    redacted = _KEY_VALUE_RE.sub(r"\1=***REDACTED***", text)
    redacted = _BOT_TOKEN_RE.sub(_REDACT_MARK, redacted)
    redacted = _HEX_SECRET_RE.sub(_REDACT_MARK, redacted)
    redacted = _LONG_BLOB_RE.sub(_REDACT_MARK, redacted)
    redacted = _PHONE_RE.sub(_REDACT_MARK, redacted)
    return redacted


class SecretRedactingFilter(logging.Filter):
    """Redact secrets without breaking standard log-record interpolation.

    The filter **never** renders ``record.msg`` and never clears
    ``record.args`` for positional arguments (the root cause of the
    production ``TypeError: not all arguments converted during string
    formatting`` errors: the previous implementation rendered ``msg``
    via ``getMessage()`` and then hit an ``AttributeError`` on the
    nonexistent ``logging.Mapping`` alias, which was silently swallowed
    and left the record with a rendered message *and* its original
    arguments).

    Safe transformations applied here:

    * the structured ``x_extra`` mapping is replaced with a redacted copy;
    * mapping-style ``record.args`` are replaced with a redacted copy
      whose **keys are preserved**, so ``msg % args`` still interpolates
      correctly for every subsequent handler.

    This method never raises and never logs (which would recurse).
    """

    def filter(self, record: logging.LogRecord) -> bool:  # noqa: A003
        extra = getattr(record, _EXTRA, None)
        if isinstance(extra, Mapping):
            setattr(record, _EXTRA, redact(extra))
        args = record.args
        if args and isinstance(args, Mapping):
            record.args = redact(dict(args))
        return True


def render_message(record: logging.LogRecord) -> str:
    """Render ``record`` through the standard interpolation, robustly.

    Normal records — including every aiogram/Telethon parameterized
    record — interpolate through ``LogRecord.getMessage()`` exactly as
    the standard library intends. Only genuinely malformed records
    (placeholder/argument mismatch produced by a third-party caller)
    fall back to a best-effort representation that preserves the raw
    information instead of crashing the logging pipeline.
    """
    try:
        return record.getMessage()
    except Exception as exc:  # noqa: BLE001 — malformed-record safety net
        return f"{record.msg!r} (unformattable: {exc.__class__.__name__})"


class StructuredFormatter(logging.Formatter):
    """Format records as ``timestamp LEVEL logger message key=value ...``."""

    def __init__(self, fmt: str = "text") -> None:
        super().__init__()
        self.fmt = fmt

    def format(self, record: logging.LogRecord) -> str:
        timestamp = datetime.fromtimestamp(record.created, tz=UTC).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        message = redact_text(render_message(record))
        # Exception traceback (cached on the record, as the stdlib does).
        exc_text = record.exc_text
        if record.exc_info and not exc_text:
            exc_text = self.formatException(record.exc_info)
            record.exc_text = exc_text  # standard cache behaviour
        if exc_text:
            message = f"{message}\n{exc_text}"

        extra = getattr(record, _EXTRA, None)
        if self.fmt == "json":
            payload: dict[str, Any] = {
                "ts": timestamp,
                "level": record.levelname,
                "logger": record.name,
                "msg": message,
            }
            if isinstance(extra, Mapping):
                payload.update(redact(extra))
            return json.dumps(payload, default=str, ensure_ascii=False)
        base = f"{timestamp} {record.levelname} {record.name} {message}"
        if not extra:
            return base
        parts = [f"{key}={_stringify(value)}" for key, value in redact(extra).items()]
        return f"{base} {' '.join(parts)}"


def _stringify(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    text = str(value)
    if not text:
        return '""'
    if any(c.isspace() for c in text):
        return json.dumps(text, ensure_ascii=False)
    return text


_CONFIGURED = False


def setup_logging(level: str = "INFO", fmt: str = "text", *, force: bool = False) -> None:
    """Configure the root logger exactly once (unless *force*)."""
    global _CONFIGURED
    if _CONFIGURED and not force:
        return

    handler = logging.StreamHandler()
    handler.setFormatter(StructuredFormatter(fmt=fmt))
    handler.addFilter(SecretRedactingFilter())

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level.upper())

    # Reduce noisy third-party loggers.
    for name in ("aiohttp.access", "asyncio", "aiosqlite", "alembic"):
        logging.getLogger(name).setLevel(logging.WARNING)

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a logger; import-time safe."""
    return logging.getLogger(name)


def log_extra(**kwargs: Any) -> dict[str, Any]:
    """Build an extra mapping attached to a log record via ``extra=``."""
    return {_EXTRA: kwargs}


__all__ = [
    "get_logger",
    "log_extra",
    "redact",
    "redact_text",
    "render_message",
    "setup_logging",
    "is_sensitive_key",
    "SecretRedactingFilter",
    "StructuredFormatter",
]

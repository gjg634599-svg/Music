"""STRICT SILENT GROUP MODE — pure gate logic (no I/O, no async).

Telegram groups must only ever see the bot respond to explicit interactions:
bot commands (optionally qualified for this bot) and callback queries. The
group middleware drops everything else using these helpers.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

BOT_COMMAND_TYPE = "bot_command"


def _iter_entities(entities: Any) -> Iterable[Any]:
    """Yield entity-like objects from a possibly-None container."""
    if not entities:
        return
    try:
        for entity in entities:
            yield entity
    except TypeError:  # not iterable — treat as absent
        return


def should_process_group_message(message: Any) -> bool:
    """True only when the message carries a ``bot_command`` entity.

    ``message`` is duck-typed (aiogram ``Message``): ``entities`` and
    ``caption_entities`` are inspected. ``None`` and plain-text messages
    always return ``False``.
    """
    if message is None:
        return False
    for container in (
        getattr(message, "entities", None),
        getattr(message, "caption_entities", None),
    ):
        for entity in _iter_entities(container):
            if getattr(entity, "type", None) == BOT_COMMAND_TYPE:
                return True
    return False


def command_entity_texts(message: Any) -> list[str]:
    """Extract the raw command strings from ``bot_command`` entities.

    Returns e.g. ``["/play@MyBot"]`` for "/play@MyBot song". The text is
    sliced from the message text/caption at the entity offset — command
    entities are ASCII by Telegram's definition, so plain slicing is safe.
    """
    if message is None:
        return []
    texts: list[str] = []
    for source, container in (
        (getattr(message, "text", None), getattr(message, "entities", None)),
        (getattr(message, "caption", None), getattr(message, "caption_entities", None)),
    ):
        if not source:
            continue
        for entity in _iter_entities(container):
            if getattr(entity, "type", None) != BOT_COMMAND_TYPE:
                continue
            offset = int(getattr(entity, "offset", 0) or 0)
            length = int(getattr(entity, "length", 0) or 0)
            chunk = source[offset : offset + length]
            if chunk:
                texts.append(chunk)
    return texts


def is_explicit_interaction(update: Any) -> bool:
    """Callback queries are explicit interactions → ``True``.

    Accepts either an aiogram ``Update`` (``.callback_query``) or a
    ``CallbackQuery``-like object (``.data``); anything else is not explicit.
    """
    if update is None:
        return False
    if getattr(update, "callback_query", None) is not None:
        return True
    return getattr(update, "data", None) is not None


def is_callback(callback: Any) -> bool:
    """Trivial callback presence check (contract alias)."""
    return callback is not None


def _command_texts(text_entities: Any) -> list[str]:
    """Extract command strings from strings or ``(entity, text)`` pairs."""
    commands: list[str] = []
    for item in text_entities or ():
        if isinstance(item, str):
            commands.append(item)
        elif isinstance(item, (tuple, list)) and item and isinstance(item[-1], str):
            commands.append(item[-1])
    return commands


def is_command_for_bot(text_entities: Any, bot_username: str | None) -> bool:
    """Validate that extracted ``bot_command`` texts target this bot.

    ``/play`` and ``/play@ThisBot`` → ``True``; ``/play@OtherBot`` → ``False``.
    Unqualified commands are accepted (they reach every bot in the chat);
    when ``bot_username`` is unknown every command is accepted.
    """
    commands = _command_texts(text_entities)
    if not commands:
        return False
    target = str(bot_username or "").lstrip("@").strip().lower()
    if not target:
        return True
    unqualified = False
    for command in commands:
        if "@" not in command:
            unqualified = True
            continue
        suffix = command.rsplit("@", 1)[1].strip().lower()
        if suffix == target:
            return True
    return unqualified


__all__ = [
    "BOT_COMMAND_TYPE",
    "command_entity_texts",
    "is_callback",
    "is_command_for_bot",
    "is_explicit_interaction",
    "should_process_group_message",
]

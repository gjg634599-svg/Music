"""Group action permissions.

Permission modes (``GroupSettings.permission_mode``):
  - ``everyone`` — every member can control playback.
  - ``admins``   — only Telegram chat administrators.
  - ``dj``       — chat administrators + members flagged as DJs.

Regardless of mode, the ``dj_manage`` (manage DJs) and ``settings`` (change
group behaviour) actions are always restricted to chat administrators.
"""

from __future__ import annotations

from app.database.models import GroupMember
from app.database.repositories.groups import GroupMemberRepository, GroupSettingsRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Actions only chat administrators may ever perform.
ADMIN_ONLY_ACTIONS = frozenset({"dj_manage", "settings"})
#: Every action understood by the permission engine.
KNOWN_ACTIONS = frozenset(
    {"play", "skip", "pause", "resume", "stop", "queue"} | ADMIN_ONLY_ACTIONS
)
#: Valid permission modes.
PERMISSION_MODES = frozenset({"everyone", "admins", "dj"})


class GroupPermissions:
    """Evaluates per-group action permissions (CONTRACTS §6)."""

    def __init__(
        self,
        settings: GroupSettingsRepository,
        members: GroupMemberRepository,
    ) -> None:
        self.settings = settings
        self.members = members

    async def can(
        self,
        group_tg_id: int,
        user_tg_id: int,
        action: str,
        *,
        is_chat_admin: bool = False,
    ) -> bool:
        """Whether the user may perform ``action`` in the group.

        Unknown actions are denied; chat administrators can always perform
        every action. For unregistered groups the product default
        (``everyone``) applies.
        """
        if action not in KNOWN_ACTIONS:
            logger.warning(
                "permissions.unknown_action",
                extra=log_extra(action=action, group_id=group_tg_id),
            )
            return False
        # DJ management and group settings are admin-only in every mode.
        if action in ADMIN_ONLY_ACTIONS:
            return bool(is_chat_admin)
        mode = "everyone"
        group_db_id: int | None = None
        try:
            settings = await self.settings.get_or_create(group_tg_id)
            mode = settings.permission_mode
            group_db_id = settings.group_id
        except ValidationError:
            logger.warning(
                "permissions.unregistered_group",
                extra=log_extra(group_id=group_tg_id, action=action),
            )
        if is_chat_admin:
            return True
        if mode == "everyone":
            return True
        if mode == "admins":
            return False
        if mode == "dj":
            if group_db_id is None:
                return False
            member = await self.members.get(group_db_id, user_tg_id)
            return bool(member is not None and member.is_dj)
        logger.warning(
            "permissions.unknown_mode",
            extra=log_extra(mode=mode, group_id=group_tg_id, action=action),
        )
        return False

    async def set_dj(self, group_tg_id: int, user_tg_id: int, value: bool) -> bool:
        """Set/clear the DJ flag for a member.

        Raises:
            ValidationError: when the group is unregistered or the user is not
                a synced member (sync via ``GroupService.sync_member`` first).
        """
        settings = await self.settings.get_or_create(group_tg_id)
        updated = await self.members.set_dj(settings.group_id, user_tg_id, value)
        if not updated:
            raise ValidationError(
                f"User {user_tg_id} is not a synced member of group {group_tg_id}",
                user_message="❌ That user isn't active in this group yet.",
            )
        logger.info(
            "permissions.dj_flag_set",
            extra=log_extra(group_id=group_tg_id, tg_id=user_tg_id, value=bool(value)),
        )
        return True

    async def list_members(self, group_tg_id: int) -> list[GroupMember]:
        """All members of the group with their permission flags."""
        settings = await self.settings.get_or_create(group_tg_id)
        return await self.members.list_members(settings.group_id)


__all__ = [
    "ADMIN_ONLY_ACTIONS",
    "KNOWN_ACTIONS",
    "PERMISSION_MODES",
    "GroupPermissions",
]

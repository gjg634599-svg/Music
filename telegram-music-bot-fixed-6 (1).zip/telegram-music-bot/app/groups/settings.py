"""Group settings service with a strict field whitelist."""

from __future__ import annotations

from app.database.models import GroupSettings
from app.database.repositories.groups import GroupSettingsRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)


class GroupSettingsService:
    """Read/update per-group behaviour settings (CONTRACTS §6)."""

    #: Writable settings fields (binding whitelist).
    FIELDS = (
        "permission_mode",
        "silent_mode",
        "mention_mode",
        "autoplay_enabled",
        "queue_limit",
        "idle_timeout_minutes",
        "volume",
    )

    def __init__(self, settings: GroupSettingsRepository) -> None:
        self.settings = settings

    async def get(self, group_tg_id: int) -> GroupSettings:
        """Settings for a group (defaults are created on first access)."""
        return await self.settings.get_or_create(group_tg_id)

    async def update(self, group_tg_id: int, **fields: object) -> GroupSettings:
        """Update whitelisted settings fields; unknown fields are rejected.

        Raises:
            ValidationError: on unknown fields, invalid values or an
                unregistered group.
        """
        unknown = set(fields) - set(self.FIELDS)
        if unknown:
            raise ValidationError(
                f"Unsupported group settings fields: {sorted(unknown)}",
                user_message="❌ Invalid group setting.",
            )
        updated = await self.settings.update(group_tg_id, **fields)
        logger.info(
            "groups.settings_updated",
            extra=log_extra(group_id=group_tg_id, fields=sorted(fields)),
        )
        return updated


__all__ = ["GroupSettingsService"]

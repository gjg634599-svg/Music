"""Group lifecycle, membership sync and status summaries."""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Protocol

from app.database.models import Group, GroupMember, GroupSettings, Track
from app.database.repositories.groups import GroupMemberRepository, GroupRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)


class QueueSizeLike(Protocol):
    """Duck-typed queue dependency (``QueueRepository`` from Task 2-b).

    A ``QueueManager`` exposing ``size(owner)`` is also accepted — see
    :func:`_queue_size`.
    """

    async def size(self, owner_type: str, owner_id: int) -> int: ...


class SessionLookupLike(Protocol):
    """Duck-typed subset of ``PlaybackSessionRepository`` (Task 2-b)."""

    async def get_or_create(self, owner_kind: str, owner_id: int) -> Any: ...


class TrackLookupLike(Protocol):
    """Duck-typed subset of ``TrackRepository`` (Task 2-a)."""

    async def get_by_id(self, track_id: int) -> Track | None: ...


@dataclass(frozen=True, slots=True)
class _OwnerRef:
    """Minimal ``QueueOwner`` duck used with QueueManager-style queues."""

    kind: str
    id: int

    def topic(self) -> str:
        return f"{self.kind}:{self.id}"


async def _maybe_await(value: Any) -> Any:
    """Await coroutine-like results; pass plain values through."""
    if inspect.isawaitable(value):
        return await value
    return value


async def _queue_size(queue: Any, owner_type: str, owner_id: int) -> int:
    """Best-effort queue size lookup that never raises."""
    if queue is None:
        return 0
    try:
        return int(await _maybe_await(queue.size(owner_type, owner_id)))
    except TypeError:
        pass  # fall through to the QueueManager-style call
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "groups.queue_size_failed", extra=log_extra(error=str(exc)[:200])
        )
        return 0
    try:
        return int(await _maybe_await(queue.size(_OwnerRef(owner_type, owner_id))))
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "groups.queue_size_failed", extra=log_extra(error=str(exc)[:200])
        )
        return 0


class GroupService:
    """Group chat lifecycle + status (CONTRACTS §6).

    ``queue``, ``sessions`` and ``tracks`` are optional duck-typed cross-task
    dependencies used to enrich :meth:`status_summary`.
    """

    def __init__(
        self,
        groups: GroupRepository,
        members: GroupMemberRepository,
        queue: QueueSizeLike | None = None,
        sessions: SessionLookupLike | None = None,
        tracks: TrackLookupLike | None = None,
    ) -> None:
        self.groups = groups
        self.members = members
        self.queue = queue
        self.sessions = sessions
        self.tracks = tracks

    async def get_or_create(self, chat: Any) -> Group:
        """Register/refresh a group from an aiogram ``Chat``-like object.

        The object is duck-typed (``id``, ``title``, ``type``); default group
        settings are created on first sight and presence flags refreshed.
        """
        if chat is None:
            raise ValidationError("chat is required", user_message="❌ Invalid chat.")
        chat_id = getattr(chat, "id", None)
        if not isinstance(chat_id, int) or chat_id == 0:
            raise ValidationError(
                "chat.id must be an integer Telegram chat id",
                user_message="❌ Invalid chat.",
            )
        chat_type = str(getattr(chat, "type", "") or "supergroup").strip().lower()
        if chat_type == "private":
            raise ValidationError(
                "private chats are not groups", user_message="❌ This is not a group chat."
            )
        title = getattr(chat, "title", None) or f"Chat {chat_id}"
        return await self.groups.get_or_create(chat_id, title=title, type=chat_type)

    async def sync_member(
        self,
        group_db_id: int,
        user_db_id: int,
        tg_user_id: int,
        *,
        is_admin: bool = False,
        is_dj: bool = False,
    ) -> GroupMember:
        """Upsert a membership row (flags are upgrade-only on existing rows)."""
        return await self.members.upsert(
            group_db_id,
            user_db_id,
            tg_user_id,
            is_group_admin=is_admin,
            is_dj=is_dj,
        )

    async def groups_of_user(self, tg_user_id: int) -> list[Group]:
        """Groups a Telegram user is a member of (DM destination picker)."""
        return await self.groups.groups_of_user(int(tg_user_id))

    async def register_group(
        self, group_tg_id: int, title: str | None, chat_type: str | None
    ) -> Group:
        """Register/refresh a group from raw ids (no aiogram Chat needed).

        Used by the DM→group playback workflow for link-resolved groups the
        bot has not seen as a chat yet (the voice account joined, not the
        bot) so settings/permissions/analytics work identically.
        """
        chat_type = (chat_type or "supergroup").strip().lower()
        if chat_type not in ("group", "supergroup"):
            chat_type = "supergroup"
        return await self.groups.get_or_create(
            int(group_tg_id), title=title, type=chat_type
        )

    async def status_summary(self, group_tg_id: int) -> dict[str, Any]:
        """Snapshot of a group's playback status.

        Returns ``{"group": Group, "settings": GroupSettings, "queue_size":
        int, "current": dict | None}`` — ``current`` is hydrated from the
        optional session/track repositories and is None when unavailable.

        Raises:
            ValidationError: when the group is not registered yet.
        """
        group = await self.groups.get_by_telegram_id(group_tg_id)
        if group is None:
            raise ValidationError(
                f"Group {group_tg_id} is not registered yet",
                user_message="❌ This group isn't registered yet — add the bot first.",
            )
        settings = group.settings
        if settings is None:  # legacy row without settings — heal it
            group = await self.groups.get_or_create(
                group.telegram_id, group.title, type=group.type
            )
            settings = group.settings
        return {
            "group": group,
            "settings": settings,
            "queue_size": await _queue_size(self.queue, "group", group.telegram_id),
            "current": await self._current(group.telegram_id),
        }

    async def _current(self, group_tg_id: int) -> dict[str, Any] | None:
        """Build the "now playing" dict from the optional session repository."""
        if self.sessions is None:
            return None
        try:
            session_obj = await _maybe_await(
                self.sessions.get_or_create("group", group_tg_id)
            )
        except TypeError:
            try:  # alternate repo shape: plain getter
                session_obj = await _maybe_await(self.sessions.get("group", group_tg_id))
            except Exception:  # noqa: BLE001
                return None
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "groups.session_lookup_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:200]),
            )
            return None
        if session_obj is None:
            return None
        track_id = getattr(session_obj, "current_track_id", None)
        track: Track | None = None
        if track_id is not None and self.tracks is not None:
            try:
                track = await _maybe_await(self.tracks.get_by_id(track_id))
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "groups.track_hydration_failed",
                    extra=log_extra(track_id=track_id, error=str(exc)[:200]),
                )
                track = None
        return {
            "track": track,
            "track_id": track_id,
            "queue_item_id": getattr(session_obj, "current_queue_item_id", None),
            "status": getattr(session_obj, "status", None) or "idle",
            "position_seconds": int(getattr(session_obj, "position_seconds", 0) or 0),
            "autoplay": bool(getattr(session_obj, "autoplay", False)),
            "repeat_mode": getattr(session_obj, "repeat_mode", None) or "off",
            "volume": int(getattr(session_obj, "volume", 100) or 100),
        }


__all__ = ["GroupService"]

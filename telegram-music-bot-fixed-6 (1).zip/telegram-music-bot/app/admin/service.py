"""Admin service facade.

Aggregates the admin-domain services (permissions, appearance, buttons,
settings, statistics, audit) behind a single object that the service
container (``app/bot/services.py``) exposes as ``services.admin``.
"""

from __future__ import annotations

from app.admin.appearance import AppearanceService
from app.admin.audit import AuditService
from app.admin.buttons import ButtonService
from app.admin.permissions import PermissionService
from app.admin.settings import SettingsService
from app.admin.statistics import StatisticsService
from app.errors import AdminAccessDeniedError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)


class AdminService:
    """Facade over all admin-domain services.

    Attributes:
        permissions: role/permission checks (env super-admins, DB admins).
        appearance: message templates, logo, start preview.
        buttons: dynamic inline buttons + keyboard rendering.
        settings: dynamic bot settings (autoplay, maintenance, features...).
        statistics: platform overview + system health.
        audit: admin action audit trail.
    """

    def __init__(
        self,
        permission: PermissionService,
        appearance: AppearanceService,
        buttons: ButtonService,
        settings: SettingsService,
        statistics: StatisticsService,
        audit: AuditService,
    ) -> None:
        self.permissions = permission
        self.appearance = appearance
        self.buttons = buttons
        self.settings = settings
        self.statistics = statistics
        self.audit = audit

    async def is_admin(self, tg_id: int) -> bool:
        """Return ``True`` when *tg_id* holds any admin role."""
        return await self.permissions.is_admin(tg_id)

    async def require(self, tg_id: int, permission: str) -> None:
        """Raise :class:`AdminAccessDeniedError` unless *tg_id* may act.

        Used by the admin panel middleware/handlers for `adm:` callbacks and
        screens; denials are logged with the missing permission.
        """
        if not await self.permissions.has(tg_id, permission):
            logger.warning(
                "admin.access_denied",
                extra=log_extra(tg_id=tg_id, permission=permission),
            )
            raise AdminAccessDeniedError(
                f"Missing permission: {permission}",
            )
        return None


__all__ = ["AdminService"]

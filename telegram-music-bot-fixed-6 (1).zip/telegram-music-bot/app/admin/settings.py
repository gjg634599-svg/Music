"""Typed access to dynamic bot settings.

Thin, domain-friendly wrapper over :class:`BotSettingsRepository` providing
default-aware readers and writers for the well-known setting keys
(``autoplay``, ``maintenance``, ``features``, ``broadcast``,
``recommendation_weights``).

Note on recommendation weights: ``recommendation_weights()`` returns the
**raw dict** stored in ``bot_settings``. The recommendation engine
(``app/recommendation/engine.py``, Task 2-b) is responsible for converting
it via ``RecommendationWeights.from_dict(...)`` (see
``app/recommendation/scoring.py``); this module deliberately avoids a
runtime dependency on the recommendation package.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from app.database.defaults import DEFAULT_SETTINGS
from app.database.models import BotSetting
from app.database.repositories.settings import BotSettingsRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

if TYPE_CHECKING:  # pragma: no cover - documentation/typing only
    from app.recommendation.scoring import RecommendationWeights  # noqa: F401

logger = get_logger(__name__)

#: Fallback when the autoplay setting is missing or malformed.
_DEFAULT_AUTOPLAY: dict[str, Any] = {"enabled": True, "count": 1}
#: Fallback when the maintenance setting is missing or malformed.
_DEFAULT_MAINTENANCE: dict[str, Any] = {"enabled": False, "groups_continue": False}
#: Fallback feature flags.
_DEFAULT_FEATURES: dict[str, Any] = {"mention_mode": False, "url_processing": True}
#: Fallback broadcast engine limits.
_DEFAULT_BROADCAST: dict[str, Any] = {
    "rate_per_second": 25,
    "worker_concurrency": 2,
    "max_retries": 3,
}


class SettingsService:
    """Domain access to the dynamic bot settings store."""

    def __init__(self, settings_repo: BotSettingsRepository) -> None:
        self.repo = settings_repo

    # ------------------------------------------------------------------
    # Generic access
    # ------------------------------------------------------------------
    async def get(self, key: str, default: Any = None) -> Any:
        """Return the JSON value for *key* or *default*."""
        return await self.repo.get(key, default)

    async def set(
        self, key: str, value: Any, updated_by: int | None = None
    ) -> BotSetting:
        """Store a JSON value for *key*."""
        return await self.repo.set(key, value, updated_by)

    async def ensure_defaults(self) -> int:
        """Seed missing default settings rows (idempotent)."""
        return await self.repo.ensure_defaults()

    # ------------------------------------------------------------------
    # Recommendation weights
    # ------------------------------------------------------------------
    async def recommendation_weights(self) -> dict[str, Any]:
        """Return the raw recommendation weights mapping.

        The caller (recommendation engine) converts this dict via
        ``RecommendationWeights.from_dict(...)``; malformed values fall back
        to the built-in defaults.
        """
        return await self._get_dict("recommendation_weights")

    # ------------------------------------------------------------------
    # Autoplay
    # ------------------------------------------------------------------
    async def autoplay_enabled(self) -> bool:
        """Return whether autoplay is enabled globally (default ``True``)."""
        data = await self._get_dict("autoplay")
        return bool(data.get("enabled", True))

    async def set_autoplay(
        self, enabled: bool, updated_by: int | None = None
    ) -> None:
        """Update the global autoplay flag, preserving other keys (e.g. count)."""
        data = await self._get_dict("autoplay")
        data["enabled"] = bool(enabled)
        await self.repo.set("autoplay", data, updated_by)
        logger.info(
            "settings.autoplay_set",
            extra=log_extra(enabled=bool(enabled), updated_by=updated_by),
        )

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------
    async def maintenance(self) -> dict[str, Any]:
        """Return ``{'enabled': bool, 'groups_continue': bool}`` (default off)."""
        data = await self._get_dict("maintenance")
        return {
            "enabled": bool(data.get("enabled", False)),
            "groups_continue": bool(data.get("groups_continue", False)),
        }

    async def set_maintenance(
        self,
        enabled: bool,
        groups_continue: bool,
        updated_by: int | None = None,
    ) -> None:
        """Update global maintenance mode."""
        await self.repo.set(
            "maintenance",
            {"enabled": bool(enabled), "groups_continue": bool(groups_continue)},
            updated_by,
        )
        logger.info(
            "settings.maintenance_set",
            extra=log_extra(
                enabled=bool(enabled),
                groups_continue=bool(groups_continue),
                updated_by=updated_by,
            ),
        )

    # ------------------------------------------------------------------
    # Feature flags
    # ------------------------------------------------------------------
    async def feature_flags(self) -> dict[str, Any]:
        """Return merged feature flags (defaults + stored overrides)."""
        stored = await self._get_dict("features")
        merged = dict(_DEFAULT_FEATURES)
        merged.update(stored)
        return merged

    async def set_feature(
        self, flag: str, value: bool, updated_by: int | None = None
    ) -> None:
        """Set a single feature flag, preserving the others."""
        flag = (flag or "").strip()
        if not flag or len(flag) > 64:
            raise ValidationError(
                "Invalid feature flag name", user_message="❌ Invalid feature flag."
            )
        flags = await self.feature_flags()
        flags[flag] = bool(value)
        await self.repo.set("features", flags, updated_by)
        logger.info(
            "settings.feature_set",
            extra=log_extra(flag=flag, value=bool(value), updated_by=updated_by),
        )

    # ------------------------------------------------------------------
    # Broadcast limits
    # ------------------------------------------------------------------
    async def broadcast_limits(self) -> dict[str, Any]:
        """Return merged broadcast engine limits (defaults + overrides)."""
        stored = await self._get_dict("broadcast")
        merged = dict(_DEFAULT_BROADCAST)
        merged.update(stored)
        return merged

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _get_dict(self, key: str) -> dict[str, Any]:
        """Return the stored dict for *key*, falling back to defaults.

        Malformed values (non-dict JSON) are logged and replaced by the
        built-in default so a corrupted row can never crash the bot.
        """
        fallback = DEFAULT_SETTINGS.get(key, {})
        value = await self.repo.get(key)
        if isinstance(value, dict):
            return value
        if value is not None:
            logger.warning(
                "settings.malformed_value",
                extra=log_extra(key=key, type=type(value).__name__),
            )
        return dict(fallback)


__all__ = ["SettingsService"]

"""Dynamic inline button management and keyboard rendering.

Buttons are stored in ``bot_buttons`` and rendered into the start-screen
inline keyboard (rows of two). Supported types:

* ``callback`` — internal dashboard navigation (action must be in
  :data:`KNOWN_ACTIONS`, rendered as ``callback_data``).
* ``url`` — external link (must be a valid ``https://`` URL).
* ``add_group`` — deep link ``https://t.me/<bot_username>?startgroup=true``
  (the username is injected at render time).
* ``inline_query`` — ``switch_inline_query`` button (supported, though the
  start screen does not use it).
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.errors import ValidationError
from app.logging import get_logger, log_extra
from app.security.validation import validate_callback_data

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models import BotButton
    from app.database.repositories.settings import BotButtonRepository

logger = get_logger(__name__)

#: Callback actions usable by ``callback`` type buttons (dashboard navigation).
KNOWN_ACTIONS: frozenset[str] = frozenset(
    {
        "dash:search",
        "dash:library",
        "dash:playlists",
        "dash:history",
        "dash:stats",
        "dash:settings",
        "dash:account",
        "dash:help",
        "dash:commands",
    }
)

#: Supported button types.
BUTTON_TYPES: frozenset[str] = frozenset(
    {"callback", "url", "add_group", "inline_query"}
)

#: Buttons per rendered keyboard row.
BUTTONS_PER_ROW = 2

_MAX_LABEL_LENGTH = 64
_MAX_URL_LENGTH = 512

#: Telegram bot usernames: 5-32 chars, starts with a letter, [A-Za-z0-9_].
_USERNAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{4,31}$")


def _https_url(url: str) -> str:
    """Validate an https URL for a button; return the cleaned URL."""
    cleaned = (url or "").strip()
    parsed = urlparse(cleaned)
    if parsed.scheme.lower() != "https" or not parsed.hostname:
        raise ValidationError(
            "Button URL must be a valid https:// link",
            user_message="❌ Button URL must be a valid https:// link.",
        )
    if len(cleaned) > _MAX_URL_LENGTH:
        raise ValidationError(
            f"Button URL too long (max {_MAX_URL_LENGTH})",
            user_message="❌ Button URL too long.",
        )
    return cleaned


class ButtonService:
    """High-level button management with validation and keyboard rendering."""

    def __init__(self, buttons: BotButtonRepository) -> None:
        self.buttons = buttons

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------
    async def list_buttons(self, enabled_only: bool = False) -> list[BotButton]:
        """Return buttons ordered by position (optionally enabled only)."""
        return await self.buttons.list_buttons(enabled_only=enabled_only)

    async def get(self, button_id: int) -> BotButton | None:
        """Return a single button (or ``None``)."""
        return await self.buttons.get(button_id)

    async def create(
        self,
        label: str,
        action: str,
        button_type: str = "callback",
        url: str | None = None,
        position: int | None = None,
    ) -> BotButton:
        """Create a validated button.

        * ``callback`` requires ``action`` in :data:`KNOWN_ACTIONS`.
        * ``url`` requires a valid ``https://`` URL in *url*.
        * ``add_group`` ignores *action* (normalized to ``'add_group'``).
        """
        button_type = (button_type or "callback").strip().lower()
        label, action, url = self._validate(
            label=label, action=action, button_type=button_type, url=url
        )
        if not action:
            action = button_type if button_type != "add_group" else "add_group"
        return await self.buttons.create(
            label=label,
            action=action,
            button_type=button_type,
            url=url,
            position=position,
        )

    async def update(self, button_id: int, **fields: Any) -> BotButton | None:
        """Update a button after validating the *merged* resulting state."""
        current = await self.buttons.get(button_id)
        if current is None:
            return None
        merged_type = str(fields.get("button_type", current.button_type) or "callback")
        self._validate(
            label=str(fields.get("label", current.label)),
            action=str(fields.get("action", current.action)),
            button_type=merged_type,
            url=fields.get("url", current.url),
        )
        return await self.buttons.update(button_id, **fields)

    async def delete(self, button_id: int) -> bool:
        """Delete a button; ``True`` when it existed."""
        return await self.buttons.delete(button_id)

    async def toggle(self, button_id: int, enabled: bool) -> bool:
        """Enable/disable a button; ``True`` when it existed."""
        return await self.buttons.toggle(button_id, enabled)

    async def move(self, button_id: int, direction: int) -> BotButton | None:
        """Move a button up (``direction < 0``) or down (``> 0``) one slot."""
        return await self.buttons.move(button_id, direction)

    async def ensure_defaults(self) -> int:
        """Seed the default start-screen buttons (only when table is empty)."""
        return await self.buttons.ensure_defaults()

    async def count(self) -> int:
        """Return the total number of buttons."""
        return await self.buttons.count()

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------
    async def render_keyboard(self, bot_username: str) -> InlineKeyboardMarkup:
        """Render enabled buttons into rows of two.

        Invalid buttons (bad URL, unknown action, unusable bot username for
        ``add_group``) are skipped with a warning instead of failing.
        """
        username = (bot_username or "").strip().lstrip("@")
        rows: list[list[InlineKeyboardButton]] = []
        current: list[InlineKeyboardButton] = []
        for btn in await self.buttons.list_buttons(enabled_only=True):
            rendered = self._render_button(btn, username)
            if rendered is None:
                continue
            current.append(rendered)
            if len(current) >= BUTTONS_PER_ROW:
                rows.append(current)
                current = []
        if current:
            rows.append(current)
        return InlineKeyboardMarkup(inline_keyboard=rows)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    @staticmethod
    def _validate(
        *,
        label: str,
        action: str,
        button_type: str,
        url: str | None,
    ) -> tuple[str, str, str | None]:
        """Validate button fields; return the cleaned ``(label, action, url)``.

        ``url`` is only kept for ``url`` type buttons (``None`` otherwise).
        """
        if button_type not in BUTTON_TYPES:
            raise ValidationError(
                f"Unknown button type: {button_type!r}",
                user_message="❌ Unknown button type.",
            )
        label = (label or "").strip()
        if not label:
            raise ValidationError(
                "Button label required", user_message="❌ Button label is required."
            )
        if len(label) > _MAX_LABEL_LENGTH:
            raise ValidationError(
                f"Button label too long (max {_MAX_LABEL_LENGTH})",
                user_message="❌ Button label too long (max 64 characters).",
            )
        action = (action or "").strip()
        if button_type == "callback":
            if action not in KNOWN_ACTIONS:
                raise ValidationError(
                    f"Unknown callback action: {action!r}",
                    user_message="❌ Unknown button action.",
                )
        if button_type == "url":
            url = _https_url(url or "")
        else:
            # Only 'url' buttons use the URL column.
            url = None
        return label, action, url

    def _render_button(
        self, btn: BotButton, username: str
    ) -> InlineKeyboardButton | None:
        """Render one row button; ``None`` to skip (logged)."""
        try:
            if btn.button_type == "callback":
                return InlineKeyboardButton(
                    text=btn.label, callback_data=validate_callback_data(btn.action)
                )
            if btn.button_type == "url":
                return InlineKeyboardButton(text=btn.label, url=_https_url(btn.url or ""))
            if btn.button_type == "add_group":
                if not _USERNAME_RE.match(username):
                    raise ValidationError("Bot username not configured for add_group")
                return InlineKeyboardButton(
                    text=btn.label,
                    url=f"https://t.me/{username}?startgroup=true",
                )
            if btn.button_type == "inline_query":
                return InlineKeyboardButton(
                    text=btn.label, switch_inline_query=""
                )
        except ValidationError as exc:
            logger.warning(
                "buttons.render_skipped",
                extra=log_extra(
                    button_id=btn.id, button_type=btn.button_type, reason=str(exc)
                ),
            )
            return None
        logger.warning(
            "buttons.render_unknown_type",
            extra=log_extra(button_id=btn.id, button_type=btn.button_type),
        )
        return None


__all__ = ["ButtonService", "KNOWN_ACTIONS", "BUTTON_TYPES", "BUTTONS_PER_ROW"]

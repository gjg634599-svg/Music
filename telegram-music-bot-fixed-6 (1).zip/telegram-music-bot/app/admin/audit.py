"""Audit service — thin, failure-tolerant wrapper over the audit repository.

Auditing must never break the admin flow: ``log`` swallows database errors
(after logging them) and returns ``None``; read helpers delegate to the
repository so genuine failures surface in the admin UI.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from app.logging import get_logger, log_extra

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models import AdminAuditLog
    from app.database.repositories.admin import AdminAuditLogRepository

logger = get_logger(__name__)


class AuditService:
    """Records and queries admin actions."""

    def __init__(self, repo: AdminAuditLogRepository) -> None:
        self.repo = repo

    async def log(
        self,
        admin_tg_id: int,
        action: str,
        target_type: str | None = None,
        target_id: str | int | None = None,
        details: dict[str, Any] | None = None,
        result: str = "ok",
    ) -> AdminAuditLog | None:
        """Persist an audit entry; returns the row or ``None`` on failure.

        Database (and validation) errors are logged and swallowed — an audit
        hiccup must never interrupt the admin action being recorded.
        """
        try:
            return await self.repo.log(
                admin_id=admin_tg_id,
                action=action,
                target_type=target_type,
                target_id=target_id,
                details=details,
                result=result,
            )
        except Exception as exc:  # noqa: BLE001 - auditing is best-effort
            logger.error(
                "audit.log_failed",
                extra=log_extra(
                    admin_tg_id=admin_tg_id,
                    action=action,
                    error=str(exc)[:200],
                ),
            )
            return None

    async def recent(self, limit: int = 20) -> list[AdminAuditLog]:
        """Return the most recent audit entries (newest first)."""
        return await self.repo.recent(limit)

    async def count(self) -> int:
        """Return the total number of audit entries."""
        return await self.repo.count()

    async def by_action(self, action: str, limit: int = 50) -> list[AdminAuditLog]:
        """Return recent entries for a given action (newest first)."""
        return await self.repo.by_action(action, limit)


__all__ = ["AuditService"]

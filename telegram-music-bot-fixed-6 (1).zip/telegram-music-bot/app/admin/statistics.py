"""Platform statistics for the admin panel and health endpoints.

All repository dependencies are duck-typed via local
:class:`typing.Protocol` definitions (per CONTRACTS.md — cross-task
references are resolved with local Protocols, never direct imports), so
this module only depends on the foundation layer.

Every section is individually fault-tolerant: a failing repository call is
logged and reported as zero instead of breaking the whole admin screen.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import Any, Protocol, TypeVar

from app.logging import get_logger, log_extra

logger = get_logger(__name__)

T = TypeVar("T")

#: Analytics event types consumed by :meth:`StatisticsService.overview`.
EVENT_TRACK_PLAY = "track_play"
EVENT_TRACK_LIKE = "track_like"
EVENT_AUTOPLAY_SELECTED = "autoplay_selected"

#: Cache key / TTL for the cached overview snapshot.
_CACHE_KEY = "admin:stats:overview:v1"
_CACHE_TTL = 60

#: Voice statuses considered "not an error" for health purposes.
_VOICE_OK_STATUSES = frozenset(
    {"ok", "healthy", "disabled", "off", "not_configured", "idle"}
)


# ----------------------------------------------------------------------
# Duck-typed repository protocols (implemented by Task 2-a/2-d/2-e repos)
# ----------------------------------------------------------------------
class UsersStatsRepo(Protocol):
    """User counters (``UserRepository``)."""

    async def count_total(self) -> int: ...
    async def count_active(self, days: int = 30) -> int: ...
    async def count_new(self, days: int = 7) -> int: ...
    async def count_blocked(self) -> int: ...


class GroupsStatsRepo(Protocol):
    """Group counters (``GroupRepository``)."""

    async def count_total(self) -> int: ...
    async def count_active(self, days: int = 30) -> int: ...


class TracksStatsRepo(Protocol):
    """Track counters (``TrackRepository``)."""

    async def count(self) -> int: ...
    async def top_played(self, limit: int = 10, days: int = 30) -> list[Any]: ...


class AnalyticsStatsRepo(Protocol):
    """Analytics aggregations (``AnalyticsRepository``)."""

    async def counts_by_type(self, hours: int = 24) -> dict[str, int]: ...
    async def daily_plays(self, days: int = 14) -> dict[Any, Any]: ...


class BroadcastStatsRepo(Protocol):
    """Broadcast counters (``BroadcastRepository``)."""

    async def count_by_status(self) -> dict[str, int]: ...


class VoiceStatsRepo(Protocol):
    """Voice engine counters (``VoiceRepository``) — optional."""

    async def list_accounts(self) -> list[Any]: ...
    async def active_sessions_count(self) -> int: ...


class StatsCache(Protocol):
    """Minimal cache interface (``CacheProtocol``-compatible)."""

    async def get(self, key: str) -> Any: ...
    async def set(self, key: str, value: Any, ttl: int | None = None) -> None: ...
    async def delete(self, key: str) -> None: ...


class MaintenanceSource(Protocol):
    """Settings service providing maintenance state (optional)."""

    async def maintenance(self) -> dict[str, Any]: ...


def _latest_count(daily: Any) -> int:
    """Extract "today's" play count from a ``daily_plays`` result.

    Tolerates either shape: ``{date: count}`` mapping (newest key wins) or a
    list of rows (``[{'count': n}, ...]``) as produced by other layouts.
    """
    if isinstance(daily, dict) and daily:
        try:
            value = daily[max(daily)]
        except (TypeError, ValueError):
            values = list(daily.values())
            value = values[-1]
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0
    if isinstance(daily, list) and daily:
        last = daily[-1]
        if isinstance(last, dict):
            return int(last.get("count", last.get("plays", 0)) or 0)
        try:
            return int(last or 0)
        except (TypeError, ValueError):
            return 0
    return 0


class StatisticsService:
    """Aggregated platform statistics with short-TTL caching."""

    def __init__(
        self,
        users_repo: UsersStatsRepo,
        groups_repo: GroupsStatsRepo,
        tracks_repo: TracksStatsRepo,
        analytics_repo: AnalyticsStatsRepo,
        broadcast_repo: BroadcastStatsRepo,
        voice_repo: VoiceStatsRepo | None = None,
        cache: StatsCache | None = None,
        settings_service: MaintenanceSource | None = None,
    ) -> None:
        self.users = users_repo
        self.groups = groups_repo
        self.tracks = tracks_repo
        self.analytics = analytics_repo
        self.broadcast = broadcast_repo
        self.voice = voice_repo
        self.cache = cache
        self.settings_service = settings_service

    # ------------------------------------------------------------------
    # Overview
    # ------------------------------------------------------------------
    async def overview(self) -> dict[str, Any]:
        """Return the admin overview snapshot (cached for ~60 seconds).

        Sections: users, groups, tracks, plays, likes, autoplay, broadcasts
        (+ optional voice and maintenance). Failing sections report zeros.
        """
        if self.cache is not None:
            try:
                cached = await self.cache.get(_CACHE_KEY)
                if isinstance(cached, dict):
                    return cached
            except Exception as exc:  # noqa: BLE001 - cache is best-effort
                logger.warning(
                    "statistics.cache_read_failed",
                    extra=log_extra(error=str(exc)[:200]),
                )
        data = await self._build_overview()
        if self.cache is not None:
            try:
                await self.cache.set(_CACHE_KEY, data, ttl=_CACHE_TTL)
            except Exception as exc:  # noqa: BLE001 - cache is best-effort
                logger.warning(
                    "statistics.cache_write_failed",
                    extra=log_extra(error=str(exc)[:200]),
                )
        return data

    async def refresh(self) -> dict[str, Any]:
        """Force a fresh snapshot (bypasses and clears the cache)."""
        await self.invalidate()
        return await self._build_overview()

    async def invalidate(self) -> None:
        """Drop the cached overview snapshot."""
        if self.cache is None:
            return
        try:
            await self.cache.delete(_CACHE_KEY)
        except Exception as exc:  # noqa: BLE001 - cache is best-effort
            logger.warning(
                "statistics.cache_delete_failed",
                extra=log_extra(error=str(exc)[:200]),
            )

    async def top_tracks(self, limit: int = 10, days: int = 30) -> list[Any]:
        """Most played tracks (best-effort; empty list on failure)."""
        return await self._safe(
            lambda: self.tracks.top_played(limit=limit, days=days), []
        )

    # ------------------------------------------------------------------
    # System health
    # ------------------------------------------------------------------
    async def system_health(
        self,
        db_ok: bool,
        cache_ok: bool,
        workers_ok: bool,
        voice_status: str = "unknown",
        maintenance: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Build the ``/health`` payload for the health endpoint and admin screen.

        ``status`` is ``"down"`` when the database is unreachable, else
        ``"degraded"`` when any subsystem fails or maintenance is enabled,
        else ``"ok"``.
        """
        db_ok = bool(db_ok)
        cache_ok = bool(cache_ok)
        workers_ok = bool(workers_ok)
        core_ok = db_ok and cache_ok and workers_ok
        maintenance = maintenance or {}
        maintenance_enabled = bool(maintenance.get("enabled", False))

        if not db_ok:
            status = "down"
        elif not core_ok or maintenance_enabled:
            status = "degraded"
        else:
            status = "ok"

        return {
            "ok": core_ok,
            "status": status,
            "database": db_ok,
            "cache": cache_ok,
            "workers": workers_ok,
            "voice": {
                "status": voice_status,
                "ok": str(voice_status).lower() in _VOICE_OK_STATUSES,
            },
            "maintenance": {
                "enabled": maintenance_enabled,
                "groups_continue": bool(maintenance.get("groups_continue", False)),
            },
            "checked_at": datetime.now(tz=UTC).isoformat(),
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _build_overview(self) -> dict[str, Any]:
        """Query every section defensively and assemble the snapshot."""
        users_total = await self._safe(self.users.count_total, 0)
        users_active = await self._safe(self.users.count_active, 0)
        users_new = await self._safe(lambda: self.users.count_new(days=7), 0)
        users_blocked = await self._safe(self.users.count_blocked, 0)

        groups_total = await self._safe(self.groups.count_total, 0)
        groups_active = await self._safe(self.groups.count_active, 0)

        tracks_total = await self._safe(self.tracks.count, 0)

        counts = await self._safe(
            lambda: self.analytics.counts_by_type(hours=24), {}
        )
        if not isinstance(counts, dict):
            counts = {}
        daily = await self._safe(lambda: self.analytics.daily_plays(days=1), {})
        plays_today = _latest_count(daily)

        by_status = await self._safe(self.broadcast.count_by_status, {})
        if not isinstance(by_status, dict):
            by_status = {}

        voice = await self._voice_section()
        maintenance = await self._maintenance_section()

        overview: dict[str, Any] = {
            "users": {
                "total": int(users_total or 0),
                "active": int(users_active or 0),
                "new_week": int(users_new or 0),
                "blocked": int(users_blocked or 0),
            },
            "groups": {
                "total": int(groups_total or 0),
                "active": int(groups_active or 0),
            },
            "tracks": {"total": int(tracks_total or 0)},
            "plays": {
                "today": plays_today,
                "24h": int(counts.get(EVENT_TRACK_PLAY, 0) or 0),
            },
            "likes": {"count": int(counts.get(EVENT_TRACK_LIKE, 0) or 0)},
            "autoplay": {
                "selections": int(counts.get(EVENT_AUTOPLAY_SELECTED, 0) or 0)
            },
            "broadcasts": {
                "total": sum(
                    v for v in by_status.values() if isinstance(v, int)
                ),
                "by_status": by_status,
            },
            "generated_at": datetime.now(tz=UTC).isoformat(),
        }
        if voice is not None:
            overview["voice"] = voice
        if maintenance is not None:
            overview["maintenance"] = maintenance
        return overview

    async def _voice_section(self) -> dict[str, Any] | None:
        """Voice engine summary; ``None`` when the repo is unavailable."""
        if self.voice is None:
            return None
        try:
            accounts = await self.voice.list_accounts()
            active_sessions = await self.voice.active_sessions_count()
        except Exception as exc:  # noqa: BLE001 - stats must never crash
            logger.warning(
                "statistics.voice_section_failed",
                extra=log_extra(error=str(exc)[:200]),
            )
            return None
        return {
            "accounts": len(accounts or []),
            "active_sessions": int(active_sessions or 0),
        }

    async def _maintenance_section(self) -> dict[str, Any] | None:
        """Maintenance summary; ``None`` when no settings service was injected."""
        if self.settings_service is None:
            return None
        try:
            return await self.settings_service.maintenance()
        except Exception as exc:  # noqa: BLE001 - stats must never crash
            logger.warning(
                "statistics.maintenance_section_failed",
                extra=log_extra(error=str(exc)[:200]),
            )
            return None

    async def _safe(self, factory: Callable[[], Awaitable[T]], default: T) -> T:
        """Await *factory()*; on any failure log and return *default*."""
        try:
            return await factory()
        except Exception as exc:  # noqa: BLE001 - each section is isolated
            logger.warning(
                "statistics.section_failed",
                extra=log_extra(error=str(exc)[:200]),
            )
            return default


__all__ = ["StatisticsService"]

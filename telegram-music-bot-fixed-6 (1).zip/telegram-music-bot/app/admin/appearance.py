"""Admin-managed bot appearance: message templates, logo asset, start preview.

Message templates support ``str.format`` style placeholders (``{name}``).
Formatting is *safe*: placeholders missing from the call are left untouched
(``Hello {name}`` stays ``Hello {name}``) and any formatting error returns
the original template instead of crashing message rendering.
"""

from __future__ import annotations

import string
from typing import TYPE_CHECKING, Any

from app.database.defaults import DEFAULT_MESSAGES
from app.errors import ValidationError
from app.logging import get_logger, log_extra

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models import BotAsset, BotButton, BotMessage
    from app.database.repositories.settings import (
        BotAssetRepository,
        BotButtonRepository,
        BotMessageRepository,
    )

logger = get_logger(__name__)

#: Maximum length of a customized message (Telegram limit with margin).
MAX_MESSAGE_LENGTH = 4000

#: Asset kind used for the bot logo.
LOGO_KIND = "logo"

#: Admin-UI titles for every customizable message key (all DEFAULT_MESSAGES
#: keys are covered; ``AppearanceService.keys`` falls back to a prettified
#: key for anything added later).
MESSAGES_INDEX: dict[str, str] = {
    "start": "Start message",
    "help": "Help message",
    "about": "About text",
    "commands": "Commands list",
    "group_help": "Group help",
    "error_generic": "Generic error",
    "error_track_unavailable": "Track unavailable error",
    "error_voice_missing": "Voice chat missing error",
    "error_no_results": "No search results",
    "empty_queue": "Empty queue",
    "maintenance": "Maintenance notice",
    "added_to_library": "Added to library",
    "track_added": "Track added to queue",
    "download_ready": "Download ready",
    "search_prompt": "Search prompt",
}


class _SafeFormatter(string.Formatter):
    """:class:`string.Formatter` that leaves unknown placeholders as-is."""

    def __init__(self, values: dict[str, Any]) -> None:
        super().__init__()
        self._values = values

    def get_value(self, key: int | str, args: Any, kwargs: Any) -> Any:  # noqa: D102
        if isinstance(key, int):
            return super().get_value(key, args, kwargs)
        if key in self._values:
            return self._values[key]
        return "{" + str(key) + "}"

    def check_unused_args(self, used_keys: Any, args: Any, kwargs: Any) -> None:
        """Extra placeholders are allowed (never an error)."""


def _safe_format(template: str, values: dict[str, Any]) -> str:
    """Format *template* with *values*; unknown placeholders stay untouched.

    Any formatting failure returns the original template unchanged so user
    message rendering can never crash.
    """
    if not values:
        return template
    try:
        return _SafeFormatter(values).vformat(template, (), values)
    except Exception:  # noqa: BLE001 - rendering must never raise
        logger.warning("appearance.format_failed", extra=log_extra(template_len=len(template)))
        return template


class AppearanceService:
    """Manages customizable messages, the logo asset and the start preview."""

    def __init__(
        self,
        messages: BotMessageRepository,
        assets: BotAssetRepository,
        buttons: BotButtonRepository,
    ) -> None:
        self.messages = messages
        self.assets = assets
        self.buttons = buttons

    async def message(self, key: str, **placeholders: Any) -> str:
        """Return the rendered message for *key*.

        The database is checked first; missing rows fall back to the built-in
        default. Placeholders are applied safely (missing keys stay as-is).
        """
        template = await self.messages.get(key)
        if not placeholders:
            return template
        return _safe_format(template, placeholders)

    async def set_message(
        self, key: str, text: str, updated_by: int | None = None
    ) -> BotMessage:
        """Customize a message template (max 4000 characters)."""
        key = (key or "").strip()
        if not key or len(key) > 64:
            raise ValidationError(
                "Invalid message key", user_message="❌ Invalid message key."
            )
        if not isinstance(text, str) or not text.strip():
            raise ValidationError(
                "Message text required", user_message="❌ Message text cannot be empty."
            )
        if len(text) > MAX_MESSAGE_LENGTH:
            raise ValidationError(
                f"Message too long (max {MAX_MESSAGE_LENGTH})",
                user_message=f"❌ Message too long (max {MAX_MESSAGE_LENGTH} characters).",
            )
        row = await self.messages.set(key, text, updated_by)
        logger.info(
            "appearance.message_set",
            extra=log_extra(key=key, updated_by=updated_by, length=len(text)),
        )
        return row

    async def reset_message(self, key: str) -> bool:
        """Remove a customization so the built-in default is used again."""
        reset = await self.messages.reset(key)
        if reset:
            logger.info("appearance.message_reset", extra=log_extra(key=key))
        return reset

    async def set_logo(
        self,
        file_id: str,
        file_unique_id: str | None = None,
        created_by: int | None = None,
    ) -> BotAsset:
        """Store a new logo asset (kind ``'logo'``) and return the row."""
        file_id = (file_id or "").strip()
        if not file_id or len(file_id) > 256:
            raise ValidationError(
                "Invalid file_id", user_message="❌ Invalid logo file."
            )
        asset = await self.assets.save(
            kind=LOGO_KIND,
            file_id=file_id,
            file_unique_id=file_unique_id,
            created_by=created_by,
        )
        logger.info(
            "appearance.logo_set",
            extra=log_extra(asset_id=asset.id, created_by=created_by),
        )
        return asset

    async def logo(self) -> BotAsset | None:
        """Return the most recent logo asset (or ``None`` when unset)."""
        return await self.assets.latest(LOGO_KIND)

    async def remove_logo(self) -> int:
        """Delete all stored logo assets; returns the number removed."""
        removed = await self.assets.delete(LOGO_KIND)
        if removed:
            logger.info("appearance.logo_removed", extra=log_extra(removed=removed))
        return removed

    async def preview_start(self, **placeholders: Any) -> tuple[str, list[BotButton]]:
        """Return the rendered start message plus enabled start buttons."""
        text = await self.message("start", **placeholders)
        buttons = await self.buttons.list_buttons(enabled_only=True)
        return text, buttons

    def keys(self) -> list[tuple[str, str]]:
        """Return ``(key, title)`` pairs for every customizable message."""
        return [
            (key, MESSAGES_INDEX.get(key, key.replace("_", " ").title()))
            for key in DEFAULT_MESSAGES
        ]


__all__ = ["AppearanceService", "MESSAGES_INDEX", "MAX_MESSAGE_LENGTH", "LOGO_KIND"]

"""Role-based permission model for the admin panel.

Roles (most → least privileged):

* ``super_admin`` — full access incl. role management and maintenance mode.
* ``admin`` — everything except role management and maintenance mode.
* ``moderator`` — read-only style access to users, groups and statistics.

Telegram ids listed in the environment (``ADMIN_IDS`` → ``env_admin_ids``)
are *always* treated as super admins regardless of any database row and can
never be demoted or removed.
"""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING

from app.errors import ValidationError
from app.logging import get_logger, log_extra

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models import Admin
    from app.database.repositories.admin import AdminRepository

logger = get_logger(__name__)


class Role(str, Enum):
    """Admin roles."""

    SUPER_ADMIN = "super_admin"
    ADMIN = "admin"
    MODERATOR = "moderator"


#: Permission areas granted per role.
PERMISSIONS: dict[Role, set[str]] = {
    Role.SUPER_ADMIN: {
        "users",
        "groups",
        "broadcast",
        "appearance",
        "buttons",
        "voice",
        "settings",
        "stats",
        "roles",
        "maintenance",
    },
    Role.ADMIN: {
        "users",
        "groups",
        "broadcast",
        "appearance",
        "buttons",
        "voice",
        "settings",
        "stats",
    },
    Role.MODERATOR: {"users", "groups", "stats"},
}

_ROLE_ICONS: dict[Role, str] = {
    Role.SUPER_ADMIN: "👑",
    Role.ADMIN: "🛡️",
    Role.MODERATOR: "🔧",
}


def _coerce_role(role: Role | str) -> Role:
    """Coerce *role* to a :class:`Role`, raising for unknown values."""
    if isinstance(role, Role):
        return role
    try:
        return Role(str(role).strip().lower())
    except ValueError as exc:
        raise ValidationError(
            f"Unknown admin role: {role!r}",
            user_message="❌ Unknown admin role.",
        ) from exc


class PermissionService:
    """Resolves admin roles and permissions.

    Environment admins are checked first (always super admins); database
    rows provide roles for everyone else. Inactive DB rows grant nothing.
    """

    def __init__(
        self, admins: AdminRepository, env_admin_ids: tuple[int, ...] = ()
    ) -> None:
        self.admins = admins
        self.env_admin_ids: tuple[int, ...] = tuple(dict.fromkeys(env_admin_ids))

    async def role_of(self, tg_id: int) -> Role | None:
        """Return the effective role of *tg_id* (``None`` when not an admin)."""
        if tg_id in self.env_admin_ids:
            return Role.SUPER_ADMIN
        row = await self.admins.get_by_telegram_id(tg_id)
        if row is None or not row.is_active:
            return None
        try:
            return Role(row.role)
        except ValueError:
            logger.warning(
                "permissions.unknown_role",
                extra=log_extra(tg_id=tg_id, role=row.role),
            )
            return None

    async def is_admin(self, tg_id: int) -> bool:
        """Return ``True`` when *tg_id* has any effective admin role."""
        return await self.role_of(tg_id) is not None

    async def has(self, tg_id: int, permission: str) -> bool:
        """Return ``True`` when *tg_id*'s role grants *permission*."""
        role = await self.role_of(tg_id)
        if role is None:
            return False
        return permission in PERMISSIONS.get(role, set())

    async def add_admin(
        self,
        tg_id: int,
        role: Role | str = Role.ADMIN,
        added_by: int | None = None,
    ) -> Admin | None:
        """Add (or re-role) a database admin.

        Environment super admins are never demoted: the call is a logged
        no-op returning ``None``.
        """
        if tg_id in self.env_admin_ids:
            logger.info(
                "permissions.env_admin_unchanged",
                extra=log_extra(tg_id=tg_id),
            )
            return None
        resolved = _coerce_role(role)
        return await self.admins.add(tg_id, resolved.value, added_by)

    async def remove_admin(self, tg_id: int) -> bool:
        """Remove a database admin; environment admins cannot be removed."""
        if tg_id in self.env_admin_ids:
            logger.warning(
                "permissions.env_admin_remove_denied",
                extra=log_extra(tg_id=tg_id),
            )
            return False
        return await self.admins.remove(tg_id)

    async def list_admins(self) -> list[Admin]:
        """Return all database admin rows (environment admins may be absent)."""
        return await self.admins.list_all()

    @staticmethod
    def role_icon(role: Role | str | None) -> str:
        """Return the role icon (👑 super admin, 🛡️ admin, 🔧 moderator)."""
        if role is None:
            return ""
        try:
            resolved = role if isinstance(role, Role) else Role(str(role))
        except ValueError:
            return ""
        return _ROLE_ICONS.get(resolved, "")


__all__ = ["Role", "PERMISSIONS", "PermissionService"]

"""Centralized error taxonomy with user-friendly messages.

Every subsystem raises subclasses of :class:`BotError`. The Telegram layer
maps exceptions to short, understandable messages (see ``user_message``) and
logs the technical details with structured logging.
"""

from __future__ import annotations


class BotError(Exception):
    """Base class for all application errors."""

    #: Short, user-friendly message shown in Telegram.
    user_message: str = "❌ Something went wrong. Please try again later."

    def __init__(self, message: str = "", *, user_message: str | None = None) -> None:
        super().__init__(message or self.__class__.__name__)
        if user_message:
            self.user_message = user_message


class ConfigError(BotError):
    user_message = "❌ The bot is misconfigured. Please contact the administrator."


class DatabaseError(BotError):
    user_message = "❌ A database error occurred. Please try again in a moment."


class CacheError(BotError):
    user_message = "❌ A temporary internal error occurred. Please try again."


# --- Music -------------------------------------------------------------
class MusicSourceError(BotError):
    user_message = "❌ Music source is temporarily unavailable. Try again shortly."


class TrackNotFoundError(BotError):
    user_message = "❌ Track not found."


class UnsupportedUrlError(BotError):
    user_message = (
        "❌ This link is not supported.\n\n"
        "I can only process links from authorized music sources."
    )


class UnauthorizedSourceError(BotError):
    user_message = (
        "❌ This source does not permit bot playback.\n\n"
        "Try searching for the track instead."
    )


class DownloadError(BotError):
    user_message = "❌ Couldn't download this track. Please try another one."


class FileTooLargeError(BotError):
    user_message = "❌ File is too large. Maximum size is 45 MB."

    @classmethod
    def with_limit_mb(cls, limit_mb: int, *, streaming: bool = False) -> "FileTooLargeError":
        """Build the error with the ACTUAL configured limit in the message.

        The old hardcoded "45 MB" message was wrong whenever the configured
        cap differed (e.g. the 200 MB voice-streaming cap), leaving users
        without an actionable explanation.
        """
        limit_mb = max(1, int(limit_mb))
        if streaming:
            return cls(
                f"File exceeds the {limit_mb} MB streaming cap",
                user_message=(
                    f"❌ This track is too large to stream safely (over "
                    f"{limit_mb} MB).\n\nTry a shorter version, or ask an admin "
                    f"to raise VOICE_MAX_AUDIO_SIZE_MB."
                ),
            )
        return cls(
            f"File exceeds the {limit_mb} MB download cap",
            user_message=(
                f"❌ This file is too large — the limit is {limit_mb} MB."
            ),
        )


class InvalidAudioError(BotError):
    user_message = "❌ This doesn't look like a valid audio file."


# --- Playback ----------------------------------------------------------
class PlaybackError(BotError):
    user_message = "❌ Couldn't play this track."


class QueueEmptyError(BotError):
    user_message = "📋 Your queue is empty."


class NothingPlayingError(BotError):
    user_message = "ℹ️ Nothing is playing right now."


# --- Voice -------------------------------------------------------------
class VoiceError(BotError):
    user_message = "❌ Voice engine error. Please try again."


class VoiceUnavailableError(VoiceError):
    user_message = (
        "🎙️ The voice engine is not configured yet.\n\n"
        "The bot owner can connect a voice account from the admin panel."
    )


class VoiceChatMissingError(VoiceError):
    user_message = (
        "🎙️ No active voice chat in this group.\n\n"
        "Start a voice chat first, then use /play."
    )


class VoiceNotJoinedError(VoiceError):
    user_message = "🎙️ I'm not connected to the voice chat right now."


class VoiceAccountOfflineError(VoiceError):
    user_message = "🎙️ All voice accounts are busy or offline. Please try again later."


class VoiceGroupAccessError(VoiceError):
    """The voice (user) account cannot access the target group.

    Raised after membership verification and (when enabled) the automatic
    invite-link join attempt both failed — the ``user_message`` carries the
    actionable reason (missing bot permission, expired link, pending join
    approval, ban, flood limit, ...).
    """

    user_message = "🎙️ The voice account cannot access this group."


# --- Permissions / security ---------------------------------------------
class PermissionDeniedError(BotError):
    user_message = "❌ You don't have permission to do that."


class AdminAccessDeniedError(PermissionDeniedError):
    user_message = "❌ You don't have permission to access the admin panel."


class RateLimitedError(BotError):
    user_message = "⏳ Too many requests. Please slow down and try again in a minute."


class BlockedUserError(BotError):
    user_message = "❌ Your account is restricted."


class MaintenanceError(BotError):
    user_message = "🚧 The bot is under maintenance. Please try again later."


class ValidationError(BotError):
    user_message = "❌ Invalid input."


# --- Broadcast ----------------------------------------------------------
class BroadcastError(BotError):
    user_message = "❌ Broadcast error. Please check and try again."


class BroadcastCancelledError(BroadcastError):
    user_message = "⛔ Broadcast cancelled."

"""Cache service and rate limiting with Redis + in-memory fallback.

When REDIS_URL is not configured, an in-memory implementation with TTL
sweeping is used so the application still runs (single-process demo mode).
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from app.logging import get_logger

logger = get_logger(__name__)


class CacheProtocol:
    """Minimal async cache interface."""

    async def get(self, key: str) -> Any: ...
    async def set(self, key: str, value: Any, ttl: int | None = None) -> None: ...
    async def delete(self, key: str) -> None: ...
    async def get_or_set(self, key: str, factory: Any, ttl: int | None = None) -> Any: ...
    async def incr(self, key: str, ttl: int) -> int: ...
    async def ping(self) -> bool: ...
    async def close(self) -> None: ...


class MemoryCache(CacheProtocol):
    """In-process TTL cache (demo / single-process mode)."""

    def __init__(self) -> None:
        self._data: dict[str, tuple[Any, float | None]] = {}
        self._lock = asyncio.Lock()

    def _expired(self, key: str) -> bool:
        entry = self._data.get(key)
        if entry is None:
            return True
        _, expires_at = entry
        return expires_at is not None and expires_at <= time.monotonic()

    async def get(self, key: str) -> Any:
        async with self._lock:
            if self._expired(key):
                self._data.pop(key, None)
                return None
            return self._data[key][0]

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        expires_at = time.monotonic() + ttl if ttl else None
        async with self._lock:
            self._data[key] = (value, expires_at)

    async def delete(self, key: str) -> None:
        async with self._lock:
            self._data.pop(key, None)

    async def get_or_set(self, key: str, factory: Any, ttl: int | None = None) -> Any:
        cached = await self.get(key)
        if cached is not None:
            return cached
        value = await _resolve_factory(factory)
        await self.set(key, value, ttl)
        return value

    async def incr(self, key: str, ttl: int) -> int:
        async with self._lock:
            if self._expired(key):
                self._data[key] = (1, time.monotonic() + ttl)
                return 1
            current = self._data[key][0]
            self._data[key] = (current + 1, self._data[key][1])
            return current + 1

    async def ping(self) -> bool:
        return True

    async def close(self) -> None:
        async with self._lock:
            self._data.clear()


class RedisCache(CacheProtocol):
    """Redis-backed cache (production)."""

    def __init__(self, url: str) -> None:
        import redis.asyncio as aioredis  # imported lazily

        self._redis = aioredis.from_url(url, decode_responses=True)

    async def get(self, key: str) -> Any:
        return await self._redis.get(key)

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        await self._redis.set(key, value, ex=ttl)

    async def delete(self, key: str) -> None:
        await self._redis.delete(key)

    async def get_or_set(self, key: str, factory: Any, ttl: int | None = None) -> Any:
        cached = await self._redis.get(key)
        if cached is not None:
            return cached
        value = await _resolve_factory(factory)
        await self._redis.set(key, value, ex=ttl)
        return value

    async def incr(self, key: str, ttl: int) -> int:
        count = await self._redis.incr(key)
        if count == 1:
            await self._redis.expire(key, ttl)
        return int(count)

    async def ping(self) -> bool:
        try:
            return bool(await self._redis.ping())
        except Exception:  # noqa: BLE001
            return False

    async def close(self) -> None:
        await self._redis.aclose()


async def _resolve_factory(factory: Any) -> Any:
    return await factory() if callable(factory) else factory


def create_cache(redis_url: str | None) -> CacheProtocol:
    """Create a Redis cache when configured, else an in-memory cache."""
    if redis_url:
        try:
            return RedisCache(redis_url)
        except Exception as exc:  # noqa: BLE001
            logger.warning("cache.redis_unavailable_falling_back", extra={"error": str(exc)})
    return MemoryCache()


# ----------------------------------------------------------------------
# Rate limiting
# ----------------------------------------------------------------------
class RateLimiter:
    """Fixed-window rate limiter: ``check`` returns False when over limit."""

    def __init__(self, cache: CacheProtocol, *, prefix: str = "rl") -> None:
        self._cache = cache
        self._prefix = prefix

    async def check(self, key: str, limit: int, window_seconds: int = 60) -> bool:
        """Record a hit; return True when allowed, False when limited."""
        count = await self._cache.incr(f"{self._prefix}:{key}:{window_seconds}", window_seconds)
        return count <= limit

    async def remaining(self, key: str, limit: int, window_seconds: int = 60) -> int:
        count = await self._cache.get(f"{self._prefix}:{key}:{window_seconds}")
        return max(0, limit - int(count or 0))


# ----------------------------------------------------------------------
# Distributed locks (idempotency for failover / worker claims)
# ----------------------------------------------------------------------
class Lock:
    """An acquired lock handle."""

    def __init__(self, name: str, releaser) -> None:
        self.name = name
        self._releaser = releaser

    async def release(self) -> None:
        await self._releaser(self.name)


class LockManager:
    """Best-effort distributed lock (SET NX) with in-memory fallback."""

    def __init__(self, cache: CacheProtocol, *, prefix: str = "lock", ttl: int = 60) -> None:
        self._cache = cache
        self._prefix = prefix
        self._ttl = ttl
        self._local: set[str] = set()

    @asynccontextmanager
    async def acquire(self, name: str, ttl: int | None = None) -> AsyncIterator[Lock | None]:
        lock: Lock | None = None
        try:
            lock = await self.try_acquire(name, ttl)
            yield lock
        finally:
            if lock is not None:
                await lock.release()

    async def try_acquire(self, name: str, ttl: int | None = None) -> Lock | None:
        key = f"{self._prefix}:{name}"
        ttl = ttl or self._ttl
        count = await self._cache.incr(key, ttl)
        if count == 1:
            return Lock(key, self._release)
        return None

    async def _release(self, key: str) -> None:
        await self._cache.delete(key)


def create_lock_manager(cache: CacheProtocol, ttl: int = 60) -> LockManager:
    return LockManager(cache, ttl=ttl)

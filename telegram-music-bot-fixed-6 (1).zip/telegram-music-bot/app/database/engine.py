"""Async engine and session management."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from app.database.base import Base
from app.logging import get_logger

logger = get_logger(__name__)


class Database:
    """Owns the async engine and session factory."""

    def __init__(self, url: str, *, echo: bool = False) -> None:
        self.url = url
        self.engine: AsyncEngine = create_async_engine(url, echo=echo, pool_pre_ping=True)
        self.session_factory = async_sessionmaker(
            self.engine, class_=AsyncSession, expire_on_commit=False
        )

    @asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        """Provide a session with commit/rollback handling."""
        session = self.session_factory()
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

    def sessionmaker(self) -> async_sessionmaker[AsyncSession]:
        return self.session_factory

    async def create_all(self) -> None:
        """Create all tables (used for SQLite demo mode & tests).

        Production PostgreSQL deployments should use Alembic migrations.
        """
        # Import models so metadata is fully populated.
        from app.database import models  # noqa: F401

        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("database.schema_created", extra={"url": self._safe_url()})

    async def drop_all(self) -> None:
        from app.database import models  # noqa: F401

        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)

    async def ping(self) -> bool:
        """Health check."""
        from sqlalchemy import text

        try:
            async with self.engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            return True
        except Exception as exc:  # noqa: BLE001
            logger.error("database.ping_failed", extra={"error": str(exc)[:200]})
            return False

    async def dispose(self) -> None:
        await self.engine.dispose()

    def _safe_url(self) -> str:
        """Database URL with credentials stripped."""
        if "://" not in self.url:
            return self.url
        scheme, rest = self.url.split("://", 1)
        if "@" in rest:
            rest = rest.split("@", 1)[1]
        return f"{scheme}://***@{rest}"


def create_database(url: str, *, create_schema: bool = False) -> Database:
    """Factory used at startup."""
    return Database(url)

"""Repositories for bot customization tables.

Covers dynamic settings (``bot_settings``), editable message templates
(``bot_messages``), reusable Telegram media assets (``bot_assets``) and
dynamic inline buttons (``bot_buttons``).

All methods open one session per call via :class:`BaseRepository._session`
(commit inside) and return detached ORM instances (``expire_on_commit`` is
disabled on the shared session factory).
"""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import delete, func, select

from app.database.defaults import (
    DEFAULT_BUTTONS,
    DEFAULT_MESSAGES,
    DEFAULT_SETTINGS,
    SETTING_DESCRIPTIONS,
)
from app.database.models import BotAsset, BotButton, BotMessage, BotSetting
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: ``key`` columns are String(64).
_MAX_KEY_LENGTH = 64
#: Message templates must fit a Telegram message with a safety margin.
_MAX_TEXT_LENGTH = 4000


def _validate_key(key: str) -> str:
    """Validate a settings/messages key and return the cleaned value."""
    cleaned = (key or "").strip()
    if not cleaned:
        raise ValidationError("Key must not be empty")
    if len(cleaned) > _MAX_KEY_LENGTH:
        raise ValidationError(f"Key too long (max {_MAX_KEY_LENGTH} characters)")
    return cleaned


# ----------------------------------------------------------------------
# Bot settings (JSON key/value store)
# ----------------------------------------------------------------------
class BotSettingsRepository(BaseRepository):
    """Dynamic configuration key/value store (JSON values)."""

    async def get(self, key: str, default: Any = None) -> Any:
        """Return the JSON value stored for *key*, or *default* when missing."""
        async with self._session() as s:
            row = await s.get(BotSetting, key)
            if row is None or row.value is None:
                return default
            return row.value

    async def get_raw(self, key: str) -> BotSetting | None:
        """Return the ORM row for *key* (or ``None`` when absent)."""
        async with self._session() as s:
            return await s.get(BotSetting, key)

    async def set(
        self, key: str, value: Any, updated_by: int | None = None
    ) -> BotSetting:
        """Insert or update *key* with a JSON-serializable *value*.

        Existing rows keep their ``description``; new rows inherit it from
        ``SETTING_DESCRIPTIONS`` when known.
        """
        key = _validate_key(key)
        try:
            json.dumps(value)
        except (TypeError, ValueError) as exc:
            raise ValidationError("Setting value must be JSON serializable") from exc

        async with self._session() as s:
            row = await s.get(BotSetting, key)
            if row is None:
                row = BotSetting(
                    key=key,
                    value=value,
                    description=SETTING_DESCRIPTIONS.get(key),
                    updated_by=updated_by,
                )
                s.add(row)
                logger.info("settings.created", extra=log_extra(key=key))
            else:
                row.value = value
                row.updated_by = updated_by
                logger.info("settings.updated", extra=log_extra(key=key))
            await s.flush()
            return row

    async def delete(self, key: str) -> bool:
        """Delete *key*; return ``True`` when a row was removed."""
        async with self._session() as s:
            row = await s.get(BotSetting, key)
            if row is None:
                return False
            await s.delete(row)
            logger.info("settings.deleted", extra=log_extra(key=key))
            return True

    async def ensure_defaults(self) -> int:
        """Insert missing ``DEFAULT_SETTINGS`` rows (existing keys untouched).

        Implements ``INSERT ... ON CONFLICT DO NOTHING`` semantics by checking
        existence first (portable across SQLite and PostgreSQL).
        """
        inserted = 0
        async with self._session() as s:
            for key, value in DEFAULT_SETTINGS.items():
                if await s.get(BotSetting, key) is not None:
                    continue
                s.add(
                    BotSetting(
                        key=key,
                        value=value,
                        description=SETTING_DESCRIPTIONS.get(key),
                    )
                )
                inserted += 1
        if inserted:
            logger.info("settings.defaults_seeded", extra=log_extra(count=inserted))
        return inserted

    async def all(self) -> list[BotSetting]:
        """Return every settings row ordered by key."""
        async with self._session() as s:
            result = await s.execute(select(BotSetting).order_by(BotSetting.key))
            return list(result.scalars().all())


# ----------------------------------------------------------------------
# Bot messages (editable templates)
# ----------------------------------------------------------------------
class BotMessageRepository(BaseRepository):
    """Editable user-visible message templates.

    Defaults live in code (``DEFAULT_MESSAGES``) and are resolved at read
    time, so only *customized* templates are stored in the database.
    """

    async def get(self, key: str) -> str:
        """Return the customized text for *key*, falling back to the default.

        Unknown keys (no row and no default) log a warning and return ``""``.
        """
        async with self._session() as s:
            row = await s.get(BotMessage, key)
            if row is not None:
                return row.text
        if key in DEFAULT_MESSAGES:
            return DEFAULT_MESSAGES[key]
        logger.warning("messages.unknown_key", extra=log_extra(key=key))
        return ""

    async def get_raw(self, key: str) -> BotMessage | None:
        """Return the ORM row for *key* (or ``None`` when not customized)."""
        async with self._session() as s:
            return await s.get(BotMessage, key)

    async def set(self, key: str, text: str, updated_by: int | None = None) -> BotMessage:
        """Insert or update the customized template for *key*."""
        key = _validate_key(key)
        if not isinstance(text, str) or not text.strip():
            raise ValidationError("Message text must be a non-empty string")
        if len(text) > _MAX_TEXT_LENGTH:
            raise ValidationError(
                f"Message text too long (max {_MAX_TEXT_LENGTH} characters)"
            )
        async with self._session() as s:
            row = await s.get(BotMessage, key)
            if row is None:
                row = BotMessage(key=key, text=text, updated_by=updated_by)
                s.add(row)
                logger.info("messages.customized", extra=log_extra(key=key))
            else:
                row.text = text
                row.updated_by = updated_by
            await s.flush()
            return row

    async def reset(self, key: str) -> bool:
        """Delete the customized row so the built-in default is used again."""
        async with self._session() as s:
            row = await s.get(BotMessage, key)
            if row is None:
                return False
            await s.delete(row)
            logger.info("messages.reset", extra=log_extra(key=key))
            return True

    async def ensure_defaults(self) -> int:
        """No-op kept for interface symmetry.

        Message defaults are resolved at read time (see :meth:`get`), so rows
        are never bulk-inserted; only admin customizations are persisted.
        """
        return 0

    async def list_customized(self) -> list[BotMessage]:
        """Return all customized message rows ordered by key."""
        async with self._session() as s:
            result = await s.execute(select(BotMessage).order_by(BotMessage.key))
            return list(result.scalars().all())

    def keys(self) -> list[str]:
        """Return every known message key (from ``DEFAULT_MESSAGES``)."""
        return list(DEFAULT_MESSAGES)


# ----------------------------------------------------------------------
# Bot assets (logo etc.)
# ----------------------------------------------------------------------
class BotAssetRepository(BaseRepository):
    """Reusable Telegram media assets referenced by ``file_id``."""

    async def save(
        self,
        kind: str,
        file_id: str,
        file_unique_id: str | None = None,
        mime_type: str | None = None,
        size: int | None = None,
        created_by: int | None = None,
    ) -> BotAsset:
        """Store a new asset of *kind* and return the persisted row."""
        kind = (kind or "").strip()
        file_id = (file_id or "").strip()
        if not kind or len(kind) > 32:
            raise ValidationError("Asset kind must be 1-32 characters")
        if not file_id or len(file_id) > 256:
            raise ValidationError("Asset file_id must be 1-256 characters")
        async with self._session() as s:
            asset = BotAsset(
                kind=kind,
                file_id=file_id,
                file_unique_id=file_unique_id,
                mime_type=mime_type,
                size=size,
                created_by=created_by,
            )
            s.add(asset)
            await s.flush()
            await s.refresh(asset)
            logger.info(
                "assets.saved", extra=log_extra(kind=kind, file_unique_id=file_unique_id)
            )
            return asset

    async def latest(self, kind: str) -> BotAsset | None:
        """Return the newest asset of *kind* (by ``created_at``) or ``None``."""
        async with self._session() as s:
            result = await s.execute(
                select(BotAsset)
                .where(BotAsset.kind == kind)
                .order_by(BotAsset.created_at.desc(), BotAsset.id.desc())
                .limit(1)
            )
            return result.scalars().first()

    async def delete(self, kind: str) -> int:
        """Delete all assets of *kind*; return the number of removed rows."""
        async with self._session() as s:
            result = await s.execute(delete(BotAsset).where(BotAsset.kind == kind))
            removed = int(result.rowcount or 0)
        if removed:
            logger.info("assets.deleted", extra=log_extra(kind=kind, removed=removed))
        return removed


# ----------------------------------------------------------------------
# Bot buttons (dynamic inline keyboard)
# ----------------------------------------------------------------------
class BotButtonRepository(BaseRepository):
    """Ordered dynamic inline buttons (start screen)."""

    _UPDATE_FIELDS = frozenset(
        {"label", "action", "button_type", "url", "position", "is_enabled"}
    )

    async def list_buttons(self, enabled_only: bool = False) -> list[BotButton]:
        """Return buttons ordered by ``position`` (optionally enabled only)."""
        async with self._session() as s:
            stmt = select(BotButton).order_by(BotButton.position, BotButton.id)
            if enabled_only:
                stmt = stmt.where(BotButton.is_enabled.is_(True))
            result = await s.execute(stmt)
            return list(result.scalars().all())

    async def get(self, button_id: int) -> BotButton | None:
        """Return the button with *button_id* (or ``None``)."""
        async with self._session() as s:
            return await s.get(BotButton, button_id)

    async def create(
        self,
        label: str,
        action: str,
        button_type: str = "callback",
        url: str | None = None,
        position: int | None = None,
    ) -> BotButton:
        """Create a button; ``position`` defaults to ``max(position) + 10``."""
        async with self._session() as s:
            if position is None:
                result = await s.execute(select(func.max(BotButton.position)))
                position = int(result.scalar() or 0) + 10
            button = BotButton(
                label=label,
                action=action,
                button_type=button_type,
                url=url,
                position=position,
                is_enabled=True,
            )
            s.add(button)
            await s.flush()
            await s.refresh(button)
            logger.info(
                "buttons.created",
                extra=log_extra(button_id=button.id, action=action, position=position),
            )
            return button

    async def update(self, button_id: int, **fields: Any) -> BotButton | None:
        """Update whitelisted fields of a button; ``None`` when not found.

        Allowed fields: ``label``, ``action``, ``button_type``, ``url``,
        ``position``, ``is_enabled``. Unknown fields raise
        :class:`~app.errors.ValidationError`.
        """
        unknown = set(fields) - self._UPDATE_FIELDS
        if unknown:
            raise ValidationError(f"Cannot update button fields: {sorted(unknown)}")
        async with self._session() as s:
            button = await s.get(BotButton, button_id)
            if button is None:
                return None
            for name, value in fields.items():
                setattr(button, name, value)
            await s.flush()
            await s.refresh(button)
            logger.info(
                "buttons.updated", extra=log_extra(button_id=button_id, fields=sorted(fields))
            )
            return button

    async def delete(self, button_id: int) -> bool:
        """Delete a button; return ``True`` when it existed."""
        async with self._session() as s:
            button = await s.get(BotButton, button_id)
            if button is None:
                return False
            await s.delete(button)
            logger.info("buttons.deleted", extra=log_extra(button_id=button_id))
            return True

    async def toggle(self, button_id: int, enabled: bool) -> bool:
        """Enable/disable a button; return ``True`` when it existed."""
        async with self._session() as s:
            button = await s.get(BotButton, button_id)
            if button is None:
                return False
            button.is_enabled = bool(enabled)
            await s.flush()
            logger.info(
                "buttons.toggled",
                extra=log_extra(button_id=button_id, enabled=bool(enabled)),
            )
            return True

    async def move(self, button_id: int, direction: int) -> BotButton | None:
        """Swap positions with the neighbour in the ordered list.

        ``direction`` > 0 moves the button down (later position), < 0 moves it
        up; movement is clamped at the list ends. Returns the (possibly
        unchanged) button, or ``None`` when *button_id* does not exist.
        """
        async with self._session() as s:
            result = await s.execute(
                select(BotButton).order_by(BotButton.position, BotButton.id)
            )
            ordered = list(result.scalars().all())
            index = next((i for i, b in enumerate(ordered) if b.id == button_id), None)
            if index is None:
                return None
            if direction == 0:
                return ordered[index]
            target = index + (1 if direction > 0 else -1)
            if target < 0 or target >= len(ordered):
                return ordered[index]  # clamped at the ends — no move
            current, neighbour = ordered[index], ordered[target]
            current.position, neighbour.position = neighbour.position, current.position
            await s.flush()
            await s.refresh(current)
            logger.info(
                "buttons.moved",
                extra=log_extra(button_id=button_id, direction=direction),
            )
            return current

    async def ensure_defaults(self) -> int:
        """Seed ``DEFAULT_BUTTONS`` once (only when the table is empty)."""
        async with self._session() as s:
            result = await s.execute(select(func.count()).select_from(BotButton))
            if int(result.scalar() or 0) > 0:
                return 0
            for spec in DEFAULT_BUTTONS:
                s.add(
                    BotButton(
                        label=spec["label"],
                        action=spec["action"],
                        button_type=spec["button_type"],
                        position=spec["position"],
                        is_enabled=True,
                    )
                )
        logger.info("buttons.defaults_seeded", extra=log_extra(count=len(DEFAULT_BUTTONS)))
        return len(DEFAULT_BUTTONS)

    async def count(self) -> int:
        """Return the total number of buttons."""
        async with self._session() as s:
            result = await s.execute(select(func.count()).select_from(BotButton))
            return int(result.scalar() or 0)


__all__ = [
    "BotSettingsRepository",
    "BotMessageRepository",
    "BotAssetRepository",
    "BotButtonRepository",
]

"""Repositories for playback: queue items and playback sessions.

A single ``queue_items`` table backs both personal (``owner_type='user'``)
and group (``owner_type='group'``) queues. Positions start at ``1`` and are
gap-free among ``queued`` items; popping marks an item ``played`` rather than
deleting it so the currently playing item can still be resolved.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import delete, func, select, update

from app.database.base import utcnow
from app.database.models.playback import PlaybackSession, QueueItem
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Allowed lifecycle statuses of a queue item.
QUEUE_ITEM_STATUSES = ("queued", "played", "skipped")

#: Allowed playback session statuses.
SESSION_STATUSES = ("idle", "playing", "paused", "stopped")

#: Columns that may be written through ``PlaybackSessionRepository.update*``.
SESSION_UPDATABLE_FIELDS: frozenset[str] = frozenset(
    {
        "current_track_id",
        "current_queue_item_id",
        "position_seconds",
        "status",
        "shuffle",
        "repeat_mode",
        "autoplay",
        "volume",
        "now_playing_message_id",
        "control_chat_id",
        "started_at",
    }
)


class QueueRepository(BaseRepository):
    """Persistent FIFO queue of tracks per owner (user or group)."""

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _owner_filter(owner_type: str, owner_id: int) -> list[Any]:
        return [
            QueueItem.owner_type == owner_type,
            QueueItem.owner_id == int(owner_id),
        ]

    async def _next_position_value(
        self, session: Any, owner_type: str, owner_id: int
    ) -> int:
        result = await session.execute(
            select(func.max(QueueItem.position)).where(
                *self._owner_filter(owner_type, owner_id),
                QueueItem.status == "queued",
            )
        )
        current = result.scalar_one_or_none()
        return int(current or 0) + 1

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def next_position(self, owner_type: str, owner_id: int) -> int:
        """Return the position a newly appended item would receive."""
        async with self._session() as s:
            return await self._next_position_value(s, owner_type, owner_id)

    async def add(
        self,
        owner_type: str,
        owner_id: int,
        track_id: int,
        position: int | None = None,
        added_by: int | None = None,
    ) -> QueueItem:
        """Insert a queue item (position defaults to the end of the queue)."""
        async with self._session() as s:
            if position is None:
                position = await self._next_position_value(s, owner_type, owner_id)
            item = QueueItem(
                owner_type=owner_type,
                owner_id=int(owner_id),
                track_id=int(track_id),
                position=int(position),
                status="queued",
                added_by=added_by,
            )
            s.add(item)
            await s.flush()
            item_id = int(item.id)
        loaded = await self.get_item(item_id)
        if loaded is not None:
            return loaded
        return item

    async def list_queue(
        self, owner_type: str, owner_id: int, limit: int | None = None
    ) -> list[QueueItem]:
        """List queued items ordered by position (ascending)."""
        async with self._session() as s:
            stmt = (
                select(QueueItem)
                .where(*self._owner_filter(owner_type, owner_id), QueueItem.status == "queued")
                .order_by(QueueItem.position.asc(), QueueItem.id.asc())
            )
            if limit is not None:
                stmt = stmt.limit(int(limit))
            result = await s.execute(stmt)
            items = list(result.scalars().all())
        return items

    async def pop_next(self, owner_type: str, owner_id: int) -> QueueItem | None:
        """Atomically take the lowest-position queued item and mark it played."""
        async with self._session() as s:
            result = await s.execute(
                select(QueueItem)
                .where(*self._owner_filter(owner_type, owner_id), QueueItem.status == "queued")
                .order_by(QueueItem.position.asc(), QueueItem.id.asc())
                .limit(1)
            )
            item = result.scalar_one_or_none()
            if item is None:
                return None
            item.status = "played"
            item.played_at = utcnow()
            item_id = int(item.id)
        loaded = await self.get_item(item_id)
        return loaded if loaded is not None else item

    async def peek_next(self, owner_type: str, owner_id: int) -> QueueItem | None:
        """Return the next queued item without changing its state."""
        async with self._session() as s:
            result = await s.execute(
                select(QueueItem)
                .where(*self._owner_filter(owner_type, owner_id), QueueItem.status == "queued")
                .order_by(QueueItem.position.asc(), QueueItem.id.asc())
                .limit(1)
            )
            return result.scalar_one_or_none()

    async def mark_played(self, item_id: int) -> bool:
        """Force-mark an item as played (used on stop/flush paths)."""
        async with self._session() as s:
            item = await s.get(QueueItem, int(item_id))
            if item is None:
                return False
            item.status = "played"
            item.played_at = utcnow()
            return True

    async def clear(self, owner_type: str, owner_id: int) -> int:
        """Delete all queued items for the owner; returns the deleted count.

        Items already marked ``played`` are kept as a cheap playback log.
        """
        async with self._session() as s:
            result = await s.execute(
                delete(QueueItem).where(
                    *self._owner_filter(owner_type, owner_id),
                    QueueItem.status == "queued",
                )
            )
            deleted = int(result.rowcount or 0)
        if deleted:
            logger.info(
                "queue.cleared",
                extra=log_extra(owner_type=owner_type, owner_id=owner_id, deleted=deleted),
            )
        return deleted

    async def shuffle(self, owner_type: str, owner_id: int) -> int:
        """Randomize queued positions to 1..n; returns the new queue size."""
        import random

        async with self._session() as s:
            result = await s.execute(
                select(QueueItem)
                .where(*self._owner_filter(owner_type, owner_id), QueueItem.status == "queued")
                .order_by(QueueItem.position.asc(), QueueItem.id.asc())
            )
            items = list(result.scalars().all())
            if not items:
                return 0
            random.shuffle(items)
            for index, item in enumerate(items, start=1):
                item.position = index
            return len(items)

    async def remove(self, owner_type: str, owner_id: int, item_id: int) -> bool:
        """Remove a specific queued item; True when a row was deleted."""
        async with self._session() as s:
            result = await s.execute(
                delete(QueueItem).where(
                    QueueItem.id == int(item_id),
                    *self._owner_filter(owner_type, owner_id),
                    QueueItem.status == "queued",
                )
            )
            return bool(result.rowcount)

    async def size(self, owner_type: str, owner_id: int) -> int:
        """Count queued items for the owner."""
        async with self._session() as s:
            result = await s.execute(
                select(func.count())
                .select_from(QueueItem)
                .where(*self._owner_filter(owner_type, owner_id), QueueItem.status == "queued")
            )
            return int(result.scalar_one() or 0)

    async def get_item(self, item_id: int) -> QueueItem | None:
        """Fetch a queue item by primary key (any status)."""
        async with self._session() as s:
            return await s.get(QueueItem, int(item_id))

    async def get_current_item(self, owner_type: str, owner_id: int) -> QueueItem | None:
        """Return the most recently played item for the owner, if any."""
        async with self._session() as s:
            result = await s.execute(
                select(QueueItem)
                .where(
                    *self._owner_filter(owner_type, owner_id),
                    QueueItem.status == "played",
                    QueueItem.played_at.is_not(None),
                )
                .order_by(QueueItem.played_at.desc(), QueueItem.id.desc())
                .limit(1)
            )
            return result.scalar_one_or_none()

    async def shift_positions(
        self, owner_type: str, owner_id: int, from_position: int, delta: int = 1
    ) -> int:
        """Move queued items at/after ``from_position`` by ``delta`` slots.

        Used by :class:`~app.playback.queue.QueueManager` to insert items at
        the front of the queue. Returns the number of moved rows.
        """
        async with self._session() as s:
            result = await s.execute(
                update(QueueItem)
                .where(
                    *self._owner_filter(owner_type, owner_id),
                    QueueItem.status == "queued",
                    QueueItem.position >= int(from_position),
                )
                .values(position=QueueItem.position + int(delta))
            )
            return int(result.rowcount or 0)


class PlaybackSessionRepository(BaseRepository):
    """Durable playback state: one session row per user / group."""

    @staticmethod
    def _kind_to_type(owner_kind: str) -> str:
        return "personal" if owner_kind == "user" else "group"

    @staticmethod
    def _validate_fields(fields: dict[str, Any]) -> None:
        unknown = set(fields) - SESSION_UPDATABLE_FIELDS
        if unknown:
            raise ValidationError(
                f"Unsupported playback session fields: {sorted(unknown)}"
            )
        if "status" in fields and fields["status"] not in SESSION_STATUSES:
            raise ValidationError(
                f"Invalid playback status: {fields['status']!r}"
            )

    async def _select_by_owner(
        self, session: Any, owner_kind: str, owner_id: int
    ) -> PlaybackSession | None:
        session_type = self._kind_to_type(owner_kind)
        stmt = select(PlaybackSession).where(
            PlaybackSession.session_type == session_type
        )
        if session_type == "personal":
            stmt = stmt.where(PlaybackSession.user_id == int(owner_id))
        else:
            stmt = stmt.where(PlaybackSession.group_id == int(owner_id))
        result = await session.execute(stmt.limit(1))
        return result.scalar_one_or_none()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def get_or_create(self, owner_kind: str, owner_id: int) -> PlaybackSession:
        """Fetch the owner's session row, creating it on first use."""
        session_type = self._kind_to_type(owner_kind)
        async with self._session() as s:
            existing = await self._select_by_owner(s, owner_kind, owner_id)
            if existing is not None:
                return existing
            created = PlaybackSession(
                session_type=session_type,
                user_id=int(owner_id) if session_type == "personal" else None,
                group_id=int(owner_id) if session_type == "group" else None,
                status="idle",
            )
            s.add(created)
            await s.flush()
            return created

    async def get(self, session_id: int) -> PlaybackSession | None:
        """Fetch a session row by primary key."""
        async with self._session() as s:
            return await s.get(PlaybackSession, int(session_id))

    async def by_owner(self, owner_kind: str, owner_id: int) -> PlaybackSession | None:
        """Fetch the session row for an owner without creating it."""
        async with self._session() as s:
            return await self._select_by_owner(s, owner_kind, owner_id)

    async def update(self, session_id: int, **fields: Any) -> PlaybackSession | None:
        """Update arbitrary whitelisted fields of a session by primary key."""
        self._validate_fields(fields)
        async with self._session() as s:
            session = await s.get(PlaybackSession, int(session_id))
            if session is None:
                return None
            for key, value in fields.items():
                setattr(session, key, value)
            return session

    async def update_for_owner(
        self, owner_kind: str, owner_id: int, **fields: Any
    ) -> PlaybackSession | None:
        """Update whitelisted fields of the owner's session row."""
        self._validate_fields(fields)
        async with self._session() as s:
            session = await self._select_by_owner(s, owner_kind, owner_id)
            if session is None:
                return None
            for key, value in fields.items():
                setattr(session, key, value)
            return session

    async def set_now_playing(
        self,
        owner_kind: str,
        owner_id: int,
        track_id: int,
        queue_item_id: int | None,
        message_id: int | None,
        chat_id: int | None,
    ) -> PlaybackSession:
        """Mark a track as now playing and reset the position counter.

        Creates the session row on first use, so this method is safe to call
        before any ``get_or_create``.
        """
        fields: dict[str, Any] = {
            "current_track_id": int(track_id),
            "current_queue_item_id": queue_item_id,
            "status": "playing",
            "position_seconds": 0,
            "started_at": utcnow(),
        }
        if message_id is not None:
            fields["now_playing_message_id"] = int(message_id)
        if chat_id:
            fields["control_chat_id"] = int(chat_id)
        self._validate_fields(fields)
        async with self._session() as s:
            session = await self._select_by_owner(s, owner_kind, owner_id)
            if session is None:
                session_type = self._kind_to_type(owner_kind)
                session = PlaybackSession(
                    session_type=session_type,
                    user_id=int(owner_id) if session_type == "personal" else None,
                    group_id=int(owner_id) if session_type == "group" else None,
                    status="idle",
                )
                s.add(session)
                await s.flush()
            for key, value in fields.items():
                setattr(session, key, value)
            return session

    async def active_sessions(self) -> list[PlaybackSession]:
        """List sessions that are currently playing or paused."""
        async with self._session() as s:
            result = await s.execute(
                select(PlaybackSession)
                .where(PlaybackSession.status.in_(("playing", "paused")))
                .order_by(PlaybackSession.id.asc())
            )
            return list(result.scalars().all())

    async def count_active(self) -> int:
        """Count sessions that are currently playing or paused."""
        async with self._session() as s:
            result = await s.execute(
                select(func.count())
                .select_from(PlaybackSession)
                .where(PlaybackSession.status.in_(("playing", "paused")))
            )
            return int(result.scalar_one() or 0)

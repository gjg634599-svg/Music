"""Voice engine persistence: accounts, health, sessions, events, assignments.

All voice-related DB access goes through :class:`VoiceRepository` (see
CONTRACTS.md section 4). Encrypted session strings are write-only from this
repository's perspective — they are never logged, returned in diagnostics or
exposed through admin surfaces.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import delete, func, select, update

from app.database.base import utcnow
from app.database.models.voice import (
    VoiceAccount,
    VoiceAccountAssignment,
    VoiceAccountHealth,
    VoiceSession,
    VoiceSessionEvent,
)
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Account status values allowed by the engine state machine.
ACCOUNT_STATUSES = frozenset({"offline", "healthy", "degraded", "disabled", "auth_required"})

#: Session statuses that represent a live lease on a group voice chat.
ACTIVE_SESSION_STATUSES = ("joining", "playing", "paused")

#: Columns writable through VoiceRepository.update (account).
ACCOUNT_UPDATABLE_FIELDS = frozenset(
    {"label", "max_sessions", "priority", "status", "telegram_id", "username"}
)

#: Columns writable through VoiceRepository.update_session.
SESSION_UPDATABLE_FIELDS = frozenset({"status", "current_track_id", "last_heartbeat"})


def _filter_fields(fields: dict[str, Any], allowed: frozenset[str], what: str) -> dict[str, Any]:
    """Keep only whitelisted columns; unknown keys raise ``ValidationError``."""
    unknown = set(fields) - allowed
    if unknown:
        raise ValidationError(f"Unknown {what} fields: {', '.join(sorted(unknown))}")
    return dict(fields)


class VoiceRepository(BaseRepository):
    """Accounts CRUD + health history + sessions + events + assignments."""

    # ==================================================================
    # Accounts
    # ==================================================================
    async def list_accounts(self, include_disabled: bool = False) -> list[VoiceAccount]:
        """List accounts (priority desc, id asc); skip 'disabled' by default."""
        async with self._session() as s:
            stmt = select(VoiceAccount).order_by(VoiceAccount.priority.desc(), VoiceAccount.id)
            if not include_disabled:
                stmt = stmt.where(VoiceAccount.status != "disabled")
            return list((await s.scalars(stmt)).all())

    async def get(self, account_id: int) -> VoiceAccount | None:
        """Fetch an account by primary key."""
        async with self._session() as s:
            return await s.get(VoiceAccount, int(account_id))

    async def get_by_telegram_id(self, telegram_id: int) -> VoiceAccount | None:
        """Find an account by its Telegram user id (duplicate detection)."""
        async with self._session() as s:
            stmt = select(VoiceAccount).where(VoiceAccount.telegram_id == int(telegram_id))
            return (await s.scalars(stmt)).first()

    async def create(
        self,
        label: str,
        session_encrypted: str,
        *,
        telegram_id: int | None = None,
        username: str | None = None,
        phone_hint: str | None = None,
        max_sessions: int = 5,
        priority: int = 0,
    ) -> VoiceAccount:
        """Insert a voice account.

        ``session_encrypted`` is the Fernet-encrypted Telethon session — it is
        stored verbatim and never logged.
        """
        if not label:
            raise ValidationError("Voice account requires a label")
        if not session_encrypted:
            raise ValidationError("Voice account requires an encrypted session")
        async with self._session() as s:
            account = VoiceAccount(
                label=label,
                session_encrypted=session_encrypted,
                telegram_id=telegram_id,
                username=username,
                phone_hint=phone_hint,
                max_sessions=max(1, int(max_sessions)),
                priority=int(priority),
                status="offline",
            )
            s.add(account)
            await s.flush()
            logger.info(
                "repo.voice.account_created",
                extra=log_extra(account_id=account.id, label=label),
            )
            return account

    async def update(self, account_id: int, **fields: Any) -> VoiceAccount | None:
        """Update whitelisted account columns and return the fresh row."""
        values = _filter_fields(fields, ACCOUNT_UPDATABLE_FIELDS, "account")
        if "status" in values and values["status"] not in ACCOUNT_STATUSES:
            raise ValidationError(f"Unknown account status: {values['status']!r}")
        async with self._session() as s:
            if values:
                await s.execute(
                    update(VoiceAccount).where(VoiceAccount.id == int(account_id)).values(**values)
                )
            return await s.get(VoiceAccount, int(account_id))

    async def set_status(
        self, account_id: int, status: str, error: str | None = None
    ) -> None:
        """Transition an account to ``status`` recording the last error."""
        if status not in ACCOUNT_STATUSES:
            raise ValidationError(f"Unknown account status: {status!r}")
        async with self._session() as s:
            await s.execute(
                update(VoiceAccount)
                .where(VoiceAccount.id == int(account_id))
                .values(status=status, last_error=(error or None))
            )
        logger.info(
            "repo.voice.account_status",
            extra=log_extra(account_id=account_id, status=status),
        )

    async def delete(self, account_id: int) -> bool:
        """Delete an account together with its dependent rows.

        Sessions served by the account (and their event audit rows) are
        removed as well: ``voice_sessions.account_id`` is NOT NULL, so the
        FK's ``ON DELETE SET NULL`` cannot detach them — keeping the rows
        would block the account delete on PostgreSQL. Health and assignment
        history for the account is removed too.
        """
        account_id = int(account_id)
        async with self._session() as s:
            account = await s.get(VoiceAccount, account_id)
            if account is None:
                return False
            session_ids = select(VoiceSession.id).where(
                VoiceSession.account_id == account_id
            )
            # Explicit deletes: SQLite runs without FK enforcement.
            await s.execute(
                delete(VoiceSessionEvent).where(
                    VoiceSessionEvent.session_id.in_(session_ids)
                )
            )
            await s.execute(
                delete(VoiceSession).where(VoiceSession.account_id == account_id)
            )
            await s.execute(
                delete(VoiceAccountHealth).where(VoiceAccountHealth.account_id == account_id)
            )
            await s.execute(
                delete(VoiceAccountAssignment).where(
                    VoiceAccountAssignment.account_id == account_id
                )
            )
            await s.delete(account)
        logger.info(
            "repo.voice.account_deleted", extra=log_extra(account_id=account_id)
        )
        return True

    # ==================================================================
    # Health history
    # ==================================================================
    async def record_health(
        self,
        account_id: int,
        status: str,
        latency_ms: int | None = None,
        error: str | None = None,
    ) -> None:
        """Append a health-check row and stamp ``last_health_check_at``."""
        async with self._session() as s:
            s.add(
                VoiceAccountHealth(
                    account_id=int(account_id),
                    status=status,
                    latency_ms=latency_ms,
                    error=(error or None),
                )
            )
            await s.execute(
                update(VoiceAccount)
                .where(VoiceAccount.id == int(account_id))
                .values(last_health_check_at=utcnow())
            )

    async def latest_health(
        self, account_id: int, limit: int = 10
    ) -> list[VoiceAccountHealth]:
        """Most recent health rows for an account (newest first)."""
        async with self._session() as s:
            stmt = (
                select(VoiceAccountHealth)
                .where(VoiceAccountHealth.account_id == int(account_id))
                .order_by(VoiceAccountHealth.id.desc())
                .limit(max(1, int(limit)))
            )
            return list((await s.scalars(stmt)).all())

    # ==================================================================
    # Sessions
    # ==================================================================
    async def create_session(self, group_id: int, account_id: int) -> VoiceSession:
        """Create a voice session lease for a group on an account."""
        async with self._session() as s:
            now = utcnow()
            session = VoiceSession(
                group_id=int(group_id),
                account_id=int(account_id),
                status="joining",
                started_at=now,
                last_heartbeat=now,
            )
            s.add(session)
            await s.flush()
            logger.info(
                "repo.voice.session_created",
                extra=log_extra(
                    session_id=session.id, group_id=group_id, account_id=account_id
                ),
            )
            return session

    async def get_active_by_group(self, group_id: int) -> VoiceSession | None:
        """Return the live session for a group, if any."""
        async with self._session() as s:
            stmt = (
                select(VoiceSession)
                .where(
                    VoiceSession.group_id == int(group_id),
                    VoiceSession.status.in_(ACTIVE_SESSION_STATUSES),
                )
                .order_by(VoiceSession.id.desc())
            )
            return (await s.scalars(stmt)).first()

    async def update_session(self, session_id: int, **fields: Any) -> None:
        """Update whitelisted session columns."""
        values = _filter_fields(fields, SESSION_UPDATABLE_FIELDS, "session")
        if not values:
            return
        async with self._session() as s:
            await s.execute(
                update(VoiceSession)
                .where(VoiceSession.id == int(session_id))
                .values(**values)
            )

    async def touch_heartbeat(self, session_id: int) -> None:
        """Stamp ``last_heartbeat`` for a live session."""
        async with self._session() as s:
            await s.execute(
                update(VoiceSession)
                .where(VoiceSession.id == int(session_id))
                .values(last_heartbeat=utcnow())
            )

    async def end_session(self, session_id: int, status: str = "ended") -> None:
        """Close a session (status + ``ended_at`` stamp)."""
        async with self._session() as s:
            await s.execute(
                update(VoiceSession)
                .where(VoiceSession.id == int(session_id))
                .values(status=status, ended_at=utcnow())
            )

    async def active_sessions(self) -> list[VoiceSession]:
        """All live sessions (any group)."""
        async with self._session() as s:
            stmt = (
                select(VoiceSession)
                .where(VoiceSession.status.in_(ACTIVE_SESSION_STATUSES))
                .order_by(VoiceSession.id)
            )
            return list((await s.scalars(stmt)).all())

    async def count_active_sessions(self) -> int:
        """Number of live sessions."""
        async with self._session() as s:
            stmt = (
                select(func.count())
                .select_from(VoiceSession)
                .where(VoiceSession.status.in_(ACTIVE_SESSION_STATUSES))
            )
            return int(await s.scalar(stmt) or 0)

    # ==================================================================
    # Session events (audit trail)
    # ==================================================================
    async def add_event(
        self, session_id: int, event: str, details: dict | None = None
    ) -> None:
        """Append an event row for a session (never raises on bad payloads)."""
        async with self._session() as s:
            s.add(
                VoiceSessionEvent(
                    session_id=int(session_id),
                    event=event,
                    details=details if isinstance(details, dict) else None,
                )
            )

    async def list_events(self, session_id: int, limit: int = 50) -> list[VoiceSessionEvent]:
        """Most recent events for a session (newest first)."""
        async with self._session() as s:
            stmt = (
                select(VoiceSessionEvent)
                .where(VoiceSessionEvent.session_id == int(session_id))
                .order_by(VoiceSessionEvent.id.desc())
                .limit(max(1, int(limit)))
            )
            return list((await s.scalars(stmt)).all())

    # ==================================================================
    # Assignments (account ↔ group history, incl. failover)
    # ==================================================================
    async def record_assignment(
        self, account_id: int, group_id: int, session_id: int | None = None
    ) -> VoiceAccountAssignment:
        """Record that an account took over a group."""
        async with self._session() as s:
            assignment = VoiceAccountAssignment(
                account_id=int(account_id),
                group_id=int(group_id),
                session_id=session_id,
            )
            s.add(assignment)
            await s.flush()
            return assignment

    async def release_assignment_for_group(self, group_id: int) -> int:
        """Mark all open assignments for a group as released; return count."""
        async with self._session() as s:
            result = await s.execute(
                update(VoiceAccountAssignment)
                .where(
                    VoiceAccountAssignment.group_id == int(group_id),
                    VoiceAccountAssignment.released_at.is_(None),
                )
                .values(released_at=utcnow())
            )
            return int(result.rowcount or 0)

    async def active_assignments(self) -> list[VoiceAccountAssignment]:
        """All currently-open account→group assignments."""
        async with self._session() as s:
            stmt = (
                select(VoiceAccountAssignment)
                .where(VoiceAccountAssignment.released_at.is_(None))
                .order_by(VoiceAccountAssignment.id)
            )
            return list((await s.scalars(stmt)).all())


__all__ = [
    "ACCOUNT_STATUSES",
    "ACTIVE_SESSION_STATUSES",
    "VoiceRepository",
]

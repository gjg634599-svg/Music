"""Base repository — shared session/transaction handling.

Every repository opens one session per method via :meth:`BaseRepository._session`;
the context manager commits on success and rolls back on error. Session
factories must be built with ``expire_on_commit=False`` (see
:class:`app.database.engine.Database`) so returned ORM instances stay readable
after the session closes.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker


class BaseRepository:
    """Provides a transactional session scope to repository subclasses."""

    def __init__(self, sessions: async_sessionmaker[AsyncSession]) -> None:
        """Store the shared session factory.

        Args:
            sessions: Async session factory (``expire_on_commit=False``).
        """
        self.sessions = sessions

    @asynccontextmanager
    async def _session(self) -> AsyncIterator[AsyncSession]:
        """Yield a session; commit on success, rollback on any error."""
        async with self.sessions() as s:
            try:
                yield s
                await s.commit()
            except Exception:
                await s.rollback()
                raise


__all__ = ["BaseRepository"]

"""Repository for broadcast campaigns, targets and delivery records.

Implements the persistence layer of the broadcast engine (CONTRACTS.md
section 5): campaign creation, target lists, per-target status transitions,
delivery audit rows and counter updates. All methods are async and open one
session per call via :class:`BaseRepository._session`.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.database.base import utcnow
from app.database.models.broadcast import Broadcast, BroadcastDelivery, BroadcastTarget
from app.database.repositories.base import BaseRepository
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Statuses in which a broadcast still has work to do.
ACTIVE_STATUSES: tuple[str, ...] = ("pending", "sending", "paused")

#: Every legal campaign status (see the Broadcast model docstring).
ALL_STATUSES: tuple[str, ...] = (
    "draft",
    "pending",
    "sending",
    "paused",
    "completed",
    "cancelled",
    "failed",
)


class BroadcastRepository(BaseRepository):
    """Persistence for :class:`Broadcast` campaigns and their targets."""

    # ------------------------------------------------------------------
    # Campaign CRUD
    # ------------------------------------------------------------------
    async def create(
        self,
        created_by: int,
        content_type: str,
        target_type: str,
        *,
        text: str | None = None,
        caption: str | None = None,
        media: list[dict] | None = None,
        copy_source: dict | None = None,
        buttons: list[dict] | None = None,
        parse_mode: str = "HTML",
        target_filter: dict | None = None,
    ) -> Broadcast:
        """Create a new draft broadcast row and return it."""
        broadcast = Broadcast(
            created_by=created_by,
            content_type=content_type,
            target_type=target_type,
            text=text,
            caption=caption,
            media=media,
            copy_source=copy_source,
            buttons=buttons,
            parse_mode=parse_mode,
            target_filter=target_filter,
            status="draft",
        )
        async with self._session() as s:
            s.add(broadcast)
            await s.flush()
            bid = broadcast.id
        logger.info(
            "broadcast.created",
            extra=log_extra(
                broadcast_id=bid, content_type=content_type, target_type=target_type
            ),
        )
        return broadcast

    async def get(self, broadcast_id: int) -> Broadcast | None:
        """Return a broadcast by id (or None)."""
        async with self._session() as s:
            result = await s.execute(
                select(Broadcast).where(Broadcast.id == broadcast_id)
            )
            return result.scalar_one_or_none()

    async def list_history(
        self, limit: int = 20, offset: int = 0
    ) -> list[Broadcast]:
        """Most recent broadcasts first (admin history page)."""
        async with self._session() as s:
            result = await s.execute(
                select(Broadcast)
                .order_by(Broadcast.created_at.desc(), Broadcast.id.desc())
                .limit(limit)
                .offset(offset)
            )
            return list(result.scalars().all())

    async def list_active(self) -> list[Broadcast]:
        """Broadcasts that are pending, sending or paused."""
        async with self._session() as s:
            result = await s.execute(
                select(Broadcast)
                .where(Broadcast.status.in_(ACTIVE_STATUSES))
                .order_by(Broadcast.created_at.asc())
            )
            return list(result.scalars().all())

    async def active_or_pending(self) -> list[Broadcast]:
        """Alias of :meth:`list_active` — campaigns with remaining work."""
        return await self.list_active()

    async def count_by_status(self) -> dict[str, int]:
        """Aggregate counts per campaign status (admin statistics)."""
        async with self._session() as s:
            result = await s.execute(
                select(Broadcast.status, func.count(Broadcast.id)).group_by(
                    Broadcast.status
                )
            )
            return {status: int(count) for status, count in result.all()}

    # ------------------------------------------------------------------
    # Targets
    # ------------------------------------------------------------------
    async def set_targets(
        self, broadcast_id: int, targets: list[tuple[str, int]]
    ) -> int:
        """Replace the target list of a broadcast (bulk insert).

        Returns the number of targets stored. Also refreshes
        ``Broadcast.target_count``. Duplicate chat ids are ignored (the table
        enforces uniqueness per broadcast).
        """
        if not targets:
            await self._set_target_count(broadcast_id, 0)
            return 0

        async with self._session() as s:
            existing = await s.execute(
                select(BroadcastTarget.chat_id).where(
                    BroadcastTarget.broadcast_id == broadcast_id
                )
            )
            seen = {row[0] for row in existing.all()}
            rows: list[BroadcastTarget] = []
            for chat_type, chat_id in targets:
                if chat_id in seen:
                    continue
                seen.add(chat_id)
                rows.append(
                    BroadcastTarget(
                        broadcast_id=broadcast_id,
                        chat_type=chat_type,
                        chat_id=chat_id,
                        status="pending",
                    )
                )
            if rows:
                s.add_all(rows)
                await s.flush()
            total = len(seen)

        await self._set_target_count(broadcast_id, total)
        logger.info(
            "broadcast.targets_set",
            extra=log_extra(broadcast_id=broadcast_id, target_count=total),
        )
        return total

    async def _set_target_count(self, broadcast_id: int, count: int) -> None:
        async with self._session() as s:
            await s.execute(
                update(Broadcast)
                .where(Broadcast.id == broadcast_id)
                .values(target_count=count)
            )

    async def pending_targets(
        self, broadcast_id: int, limit: int = 500
    ) -> list[BroadcastTarget]:
        """Targets still pending, in stable (id) order — worker batch fetch."""
        async with self._session() as s:
            result = await s.execute(
                select(BroadcastTarget)
                .where(
                    BroadcastTarget.broadcast_id == broadcast_id,
                    BroadcastTarget.status == "pending",
                )
                .order_by(BroadcastTarget.id.asc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def mark_target(
        self, target_id: int, status: str, error: str | None = None
    ) -> None:
        """Record the outcome of one delivery attempt for a target.

        Increments ``attempts`` and stamps ``sent_at`` when the status is
        ``sent``.
        """
        values: dict[str, Any] = {
            "status": status,
            "attempts": BroadcastTarget.attempts + 1,
        }
        if error is not None:
            values["last_error"] = error[:512]
        if status == "sent":
            values["sent_at"] = utcnow()
        async with self._session() as s:
            await s.execute(
                update(BroadcastTarget).where(BroadcastTarget.id == target_id).values(values)
            )

    async def target_count(self, broadcast_id: int) -> int:
        """Number of target rows for a broadcast."""
        async with self._session() as s:
            result = await s.execute(
                select(func.count(BroadcastTarget.id)).where(
                    BroadcastTarget.broadcast_id == broadcast_id
                )
            )
            return int(result.scalar_one())

    async def remaining_count(self, broadcast_id: int) -> int:
        """Number of still-pending targets."""
        async with self._session() as s:
            result = await s.execute(
                select(func.count(BroadcastTarget.id)).where(
                    BroadcastTarget.broadcast_id == broadcast_id,
                    BroadcastTarget.status == "pending",
                )
            )
            return int(result.scalar_one())

    # ------------------------------------------------------------------
    # Deliveries (audit trail)
    # ------------------------------------------------------------------
    async def record_delivery(
        self,
        broadcast_id: int,
        chat_id: int,
        ok: bool,
        error: str | None = None,
        latency_ms: int | None = None,
    ) -> None:
        """Insert (or refresh) the delivery outcome row for a chat.

        A unique constraint on (broadcast_id, chat_id) means retries update
        the existing row instead of duplicating it.
        """
        async with self._session() as s:
            existing = await s.execute(
                select(BroadcastDelivery).where(
                    BroadcastDelivery.broadcast_id == broadcast_id,
                    BroadcastDelivery.chat_id == chat_id,
                )
            )
            row = existing.scalar_one_or_none()
            if row is None:
                s.add(
                    BroadcastDelivery(
                        broadcast_id=broadcast_id,
                        chat_id=chat_id,
                        ok=ok,
                        error=error[:512] if error else None,
                        latency_ms=latency_ms,
                    )
                )
            else:
                row.ok = ok
                row.error = error[:512] if error else None
                row.latency_ms = latency_ms
                row.created_at = utcnow()

    # ------------------------------------------------------------------
    # Counters and status transitions
    # ------------------------------------------------------------------
    async def update_counters(
        self, broadcast_id: int, sent: int = 0, failed: int = 0
    ) -> None:
        """Atomically increment sent/failed counters."""
        values: dict[str, Any] = {}
        if sent:
            values["sent_count"] = Broadcast.sent_count + sent
        if failed:
            values["failed_count"] = Broadcast.failed_count + failed
        if not values:
            return
        async with self._session() as s:
            await s.execute(
                update(Broadcast).where(Broadcast.id == broadcast_id).values(values)
            )

    async def set_status(
        self,
        broadcast_id: int,
        status: str,
        error: str | None = None,
        *,
        started: bool = False,
        completed: bool = False,
    ) -> None:
        """Transition a broadcast to a new status.

        ``started`` stamps ``started_at``; ``completed`` stamps
        ``completed_at``.
        """
        values: dict[str, Any] = {"status": status}
        if error is not None:
            values["error"] = error[:2000]
        if started:
            values["started_at"] = utcnow()
        if completed:
            values["completed_at"] = utcnow()
        async with self._session() as s:
            await s.execute(
                update(Broadcast).where(Broadcast.id == broadcast_id).values(values)
            )
        logger.info(
            "broadcast.status",
            extra=log_extra(broadcast_id=broadcast_id, status=status),
        )

    async def retry_failed(self, broadcast_id: int) -> int:
        """Reset failed targets to pending for a new delivery pass.

        Keeps per-target attempt history. Returns the number of targets
        requeued; resets ``failed_count`` and sets campaign status back to
        ``pending``.
        """
        async with self._session() as s:
            result = await s.execute(
                update(BroadcastTarget)
                .where(
                    BroadcastTarget.broadcast_id == broadcast_id,
                    BroadcastTarget.status == "failed",
                )
                .values(status="pending", last_error=None)
            )
            requeued = int(result.rowcount or 0)
            await s.execute(
                update(Broadcast)
                .where(Broadcast.id == broadcast_id)
                .values(failed_count=0, status="pending", error=None)
            )
        if requeued:
            logger.info(
                "broadcast.retry_failed",
                extra=log_extra(broadcast_id=broadcast_id, requeued=requeued),
            )
        return requeued

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------
    async def stats(self, broadcast_id: int) -> dict[str, Any]:
        """Progress snapshot for the admin progress view."""
        async with self._session() as s:
            result = await s.execute(
                select(Broadcast).where(Broadcast.id == broadcast_id)
            )
            b = result.scalar_one_or_none()
            if b is None:
                return {}
            remaining = int(
                (
                    await s.execute(
                        select(func.count(BroadcastTarget.id)).where(
                            BroadcastTarget.broadcast_id == broadcast_id,
                            BroadcastTarget.status == "pending",
                        )
                    )
                ).scalar_one()
            )
            return {
                "id": b.id,
                "status": b.status,
                "content_type": b.content_type,
                "target_type": b.target_type,
                "target_count": int(b.target_count),
                "sent_count": int(b.sent_count),
                "failed_count": int(b.failed_count),
                "remaining": remaining,
                "created_by": int(b.created_by),
                "created_at": b.created_at.isoformat() if b.created_at else None,
                "started_at": _iso(b.started_at),
                "completed_at": _iso(b.completed_at),
                "error": b.error,
            }


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


__all__ = ["BroadcastRepository", "ACTIVE_STATUSES", "ALL_STATUSES"]

"""User, preference and search-history repositories.

All methods open their own session via :class:`BaseRepository._session` and
commit inside the scope. Telegram ids are ``BigInteger``; database ids are
plain integers.
"""

from __future__ import annotations

from datetime import timedelta

from sqlalchemy import delete, func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.base import utcnow
from app.database.models import GroupMember, SearchHistory, User, UserPreferences
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Preference fields writable through :meth:`UserPreferenceRepository.update`.
PREFERENCE_FIELDS = frozenset(
    {"autoplay_enabled", "shuffle_enabled", "repeat_mode", "volume", "language"}
)
_REPEAT_MODES = frozenset({"off", "one", "all"})
#: "Active" broadcast window (days) — matches CONTRACTS §5.
_ACTIVE_WINDOW_DAYS = 30


def _clean_language(value: object) -> str:
    """Normalize and validate an ISO-like language code."""
    language = str(value or "").strip().lower()
    if not language or len(language) > 8:
        raise ValidationError(
            f"Invalid language code: {value!r}", user_message="❌ Unsupported language."
        )
    return language


def _validate_preference_fields(fields: dict[str, object]) -> dict[str, object]:
    """Whitelist + validate preference fields for update."""
    unknown = set(fields) - PREFERENCE_FIELDS
    if unknown:
        raise ValidationError(
            f"Unsupported preference fields: {sorted(unknown)}",
            user_message="❌ Invalid setting.",
        )
    clean: dict[str, object] = {}
    for key, value in fields.items():
        if key in ("autoplay_enabled", "shuffle_enabled"):
            clean[key] = bool(value)
        elif key == "repeat_mode":
            mode = str(value or "").strip().lower()
            if mode not in _REPEAT_MODES:
                raise ValidationError(
                    f"Invalid repeat_mode: {value!r}", user_message="❌ Invalid repeat mode."
                )
            clean[key] = mode
        elif key == "volume":
            try:
                volume = int(value)  # type: ignore[arg-type]
            except (TypeError, ValueError) as exc:
                raise ValidationError("volume must be an integer") from exc
            if not 0 <= volume <= 100:
                raise ValidationError("volume must be 0-100", user_message="❌ Invalid volume.")
            clean[key] = volume
        else:  # language
            clean[key] = _clean_language(value)
    return clean


class UserRepository(BaseRepository):
    """Persistence for :class:`User` rows."""

    @staticmethod
    async def _select_user(s: AsyncSession, tg_id: int) -> User | None:
        return (
            await s.execute(
                select(User)
                .where(User.telegram_id == tg_id)
                .options(selectinload(User.preferences))
            )
        ).scalar_one_or_none()

    async def get_by_telegram_id(self, tg_id: int) -> User | None:
        """Fetch a user with eager-loaded preferences (read-only)."""
        async with self._session() as s:
            return await self._select_user(s, tg_id)

    async def get_or_create(
        self,
        tg_id: int,
        username: str | None = None,
        first_name: str | None = None,
    ) -> User:
        """Fetch a user by Telegram id, creating it (with preferences) if missing.

        ``last_seen_at`` is refreshed on every call and the profile fields are
        updated when provided. Safe against concurrent registration.
        """
        async with self._session() as s:
            user = await self._select_user(s, tg_id)
            if user is None:
                candidate = User(
                    telegram_id=tg_id,
                    username=username,
                    first_name=first_name,
                    last_seen_at=utcnow(),
                )
                candidate.preferences = UserPreferences()
                s.add(candidate)
                try:
                    await s.flush()
                    user = candidate
                    logger.info("users.created", extra=log_extra(tg_id=tg_id))
                except IntegrityError:
                    # Lost a concurrent-registration race — re-fetch the winner.
                    await s.rollback()
                    user = await self._select_user(s, tg_id)
                    if user is None:
                        raise
            user.last_seen_at = utcnow()
            if username is not None:
                user.username = username
            if first_name is not None:
                user.first_name = first_name
            if user.preferences is None:
                user.preferences = UserPreferences()
            await s.flush()
            return user

    async def update_profile(
        self,
        tg_id: int,
        username: str | None = None,
        first_name: str | None = None,
        language: str | None = None,
    ) -> User | None:
        """Update profile fields (only provided values change)."""
        async with self._session() as s:
            user = (
                await s.execute(select(User).where(User.telegram_id == tg_id))
            ).scalar_one_or_none()
            if user is None:
                return None
            if username is not None:
                user.username = str(username).strip()[:64] or None
            if first_name is not None:
                user.first_name = str(first_name).strip()[:128] or None
            if language is not None:
                user.language = _clean_language(language)
            await s.flush()
            return user

    async def set_blocked(self, tg_id: int, blocked: bool) -> bool:
        """Mark a user blocked/unblocked. Returns True when a row was updated."""
        async with self._session() as s:
            result = await s.execute(
                update(User)
                .where(User.telegram_id == tg_id)
                .values(is_blocked=bool(blocked))
            )
            return bool(result.rowcount)

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------
    async def count_total(self) -> int:
        """Total known users."""
        async with self._session() as s:
            return int(
                (await s.execute(select(func.count()).select_from(User))).scalar_one()
            )

    async def count_active(self, days: int = 30) -> int:
        """Users seen within ``days`` days."""
        cutoff = utcnow() - timedelta(days=max(1, days))
        async with self._session() as s:
            return int(
                (
                    await s.execute(
                        select(func.count())
                        .select_from(User)
                        .where(User.last_seen_at >= cutoff)
                    )
                ).scalar_one()
            )

    async def count_blocked(self) -> int:
        """Blocked users."""
        async with self._session() as s:
            return int(
                (
                    await s.execute(
                        select(func.count()).select_from(User).where(User.is_blocked.is_(True))
                    )
                ).scalar_one()
            )

    async def count_new(self, days: int = 7) -> int:
        """Users first seen within ``days`` days."""
        cutoff = utcnow() - timedelta(days=max(1, days))
        async with self._session() as s:
            return int(
                (
                    await s.execute(
                        select(func.count()).select_from(User).where(User.created_at >= cutoff)
                    )
                ).scalar_one()
            )

    # ------------------------------------------------------------------
    # Broadcast segments
    # ------------------------------------------------------------------
    async def by_language(self, language: str) -> list[int]:
        """Telegram ids of users with the given UI language."""
        code = _clean_language(language)
        async with self._session() as s:
            rows = await s.execute(
                select(User.telegram_id).where(User.language == code).order_by(User.telegram_id)
            )
            return [int(row[0]) for row in rows.all()]

    async def with_groups(self) -> list[int]:
        """Distinct telegram ids of users that are members of any group."""
        async with self._session() as s:
            rows = await s.execute(
                select(User.telegram_id)
                .join(GroupMember, GroupMember.user_id == User.id)
                .distinct()
                .order_by(User.telegram_id)
            )
            return [int(row[0]) for row in rows.all()]

    async def specific(self, ids: list[int]) -> list[int]:
        """The subset of ``ids`` that are known users."""
        if not ids:
            return []
        async with self._session() as s:
            rows = await s.execute(
                select(User.telegram_id)
                .where(User.telegram_id.in_(ids))
                .order_by(User.telegram_id)
            )
            return [int(row[0]) for row in rows.all()]

    async def broadcast_segment(
        self,
        segment: str,
        language: str | None = None,
        ids: list[int] | None = None,
    ) -> list[int]:
        """Telegram ids matching a broadcast segment (blocked users excluded).

        Segments: ``all``, ``active`` (seen within 30 days), ``inactive``
        (older / never seen), ``by_language`` (requires ``language``),
        ``with_groups``, ``specific`` (requires ``ids``).
        """
        cutoff = utcnow() - timedelta(days=_ACTIVE_WINDOW_DAYS)
        async with self._session() as s:
            if segment == "all":
                stmt = select(User.telegram_id).where(User.is_blocked.is_(False))
            elif segment == "active":
                stmt = select(User.telegram_id).where(
                    User.is_blocked.is_(False), User.last_seen_at >= cutoff
                )
            elif segment == "inactive":
                stmt = select(User.telegram_id).where(
                    User.is_blocked.is_(False),
                    or_(User.last_seen_at.is_(None), User.last_seen_at < cutoff),
                )
            elif segment == "by_language":
                if not language:
                    raise ValidationError(
                        "by_language segment requires a language",
                        user_message="❌ No language selected.",
                    )
                stmt = select(User.telegram_id).where(
                    User.is_blocked.is_(False), User.language == _clean_language(language)
                )
            elif segment == "with_groups":
                stmt = (
                    select(User.telegram_id)
                    .join(GroupMember, GroupMember.user_id == User.id)
                    .where(User.is_blocked.is_(False))
                    .distinct()
                )
            elif segment == "specific":
                if not ids:
                    raise ValidationError(
                        "specific segment requires ids", user_message="❌ No users selected."
                    )
                stmt = select(User.telegram_id).where(
                    User.is_blocked.is_(False), User.telegram_id.in_(ids)
                )
            else:
                raise ValidationError(
                    f"Unknown broadcast segment: {segment!r}",
                    user_message="❌ Invalid broadcast segment.",
                )
            rows = await s.execute(stmt.order_by(User.telegram_id))
            return [int(row[0]) for row in rows.all()]

    # ------------------------------------------------------------------
    # Listing / counters
    # ------------------------------------------------------------------
    async def list_page(self, limit: int, offset: int = 0) -> tuple[list[User], int]:
        """One page of users (newest first) plus the total row count."""
        async with self._session() as s:
            total = int(
                (await s.execute(select(func.count()).select_from(User))).scalar_one()
            )
            rows = await s.execute(
                select(User).order_by(User.id.desc()).limit(max(1, limit)).offset(max(0, offset))
            )
            return list(rows.scalars().all()), total

    async def increment_play_count(self, tg_id: int) -> bool:
        """Atomically bump ``users.play_count``. True when a row was updated."""
        async with self._session() as s:
            result = await s.execute(
                update(User)
                .where(User.telegram_id == tg_id)
                .values(play_count=User.play_count + 1)
            )
            return bool(result.rowcount)


class UserPreferenceRepository(BaseRepository):
    """Persistence for :class:`UserPreferences` rows."""

    @staticmethod
    async def _select(s: AsyncSession, user_db_id: int) -> UserPreferences | None:
        return (
            await s.execute(
                select(UserPreferences).where(UserPreferences.user_id == user_db_id)
            )
        ).scalar_one_or_none()

    async def get_or_create(self, user_db_id: int) -> UserPreferences:
        """Fetch the preferences row, creating defaults when missing."""
        async with self._session() as s:
            prefs = await self._select(s, user_db_id)
            if prefs is None:
                user_exists = (
                    await s.execute(select(User.id).where(User.id == user_db_id))
                ).scalar_one_or_none()
                if user_exists is None:
                    raise ValidationError(
                        f"User #{user_db_id} does not exist",
                        user_message="❌ Unknown account.",
                    )
                prefs = UserPreferences(user_id=user_db_id)
                s.add(prefs)
                await s.flush()
                logger.info(
                    "user_preferences.created", extra=log_extra(user_id=user_db_id)
                )
            return prefs

    async def update(self, user_db_id: int, **fields: object) -> UserPreferences:
        """Update whitelisted preference fields (creates the row when missing)."""
        clean = _validate_preference_fields(fields)
        async with self._session() as s:
            prefs = await self._select(s, user_db_id)
            if prefs is None:
                user_exists = (
                    await s.execute(select(User.id).where(User.id == user_db_id))
                ).scalar_one_or_none()
                if user_exists is None:
                    raise ValidationError(
                        f"User #{user_db_id} does not exist",
                        user_message="❌ Unknown account.",
                    )
                prefs = UserPreferences(user_id=user_db_id)
                s.add(prefs)
            for key, value in clean.items():
                setattr(prefs, key, value)
            await s.flush()
            return prefs


class SearchHistoryRepository(BaseRepository):
    """Persistence for :class:`SearchHistory` rows."""

    async def add(self, user_db_id: int, query: str, results_count: int = 0) -> SearchHistory:
        """Append one search entry (newest last)."""
        text = str(query or "").strip()
        if not text:
            raise ValidationError(
                "Search query must not be empty", user_message="❌ Empty search query."
            )
        async with self._session() as s:
            entry = SearchHistory(
                user_id=user_db_id,
                query=text[:256],
                results_count=max(0, int(results_count)),
            )
            s.add(entry)
            await s.flush()
            return entry

    async def recent(self, user_db_id: int, limit: int = 10) -> list[SearchHistory]:
        """Newest search entries for a user."""
        async with self._session() as s:
            rows = await s.execute(
                select(SearchHistory)
                .where(SearchHistory.user_id == user_db_id)
                .order_by(SearchHistory.created_at.desc(), SearchHistory.id.desc())
                .limit(max(1, limit))
            )
            return list(rows.scalars().all())

    async def clear(self, user_db_id: int) -> int:
        """Delete all search history rows for a user; returns rows removed."""
        async with self._session() as s:
            result = await s.execute(
                delete(SearchHistory).where(SearchHistory.user_id == user_db_id)
            )
            return int(result.rowcount or 0)


__all__ = [
    "PREFERENCE_FIELDS",
    "SearchHistoryRepository",
    "UserPreferenceRepository",
    "UserRepository",
]

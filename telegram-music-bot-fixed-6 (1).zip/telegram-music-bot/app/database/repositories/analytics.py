"""Analytics repository — product events and recommendation feedback.

:meth:`AnalyticsRepository.track` and :meth:`AnalyticsRepository.track_many`
are fire-and-forget safe: they catch their own errors and log them, because a
failed analytics write must never break a user-facing feature.
"""

from __future__ import annotations

from datetime import timedelta

from sqlalchemy import func, select

from app.database.base import utcnow
from app.database.models import AnalyticsEvent, RecommendationEvent, Track
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Canonical analytics event types (shared vocabulary across tasks).
EVENT_TRACK_PLAY = "track_play"
EVENT_TRACK_COMPLETE = "track_complete"
EVENT_SEARCH = "search"
EVENT_LIKE = "like"
EVENT_UNLIKE = "unlike"
EVENT_AUTOPLAY_SELECTED = "autoplay_selected"
#: Event types counted as "plays" for statistics.
PLAY_EVENT_TYPES = (EVENT_TRACK_PLAY, EVENT_TRACK_COMPLETE)


def _clean_event_type(event_type: object) -> str:
    """Validate an event type string."""
    cleaned = str(event_type or "").strip()
    if not cleaned or len(cleaned) > 32:
        raise ValidationError(f"Invalid analytics event type: {event_type!r}")
    return cleaned


class AnalyticsRepository(BaseRepository):
    """Writes and aggregations for :class:`AnalyticsEvent` rows."""

    async def track(
        self,
        event_type: str,
        *,
        user_id: int | None = None,
        group_id: int | None = None,
        track_id: int | None = None,
        payload: dict | None = None,
    ) -> None:
        """Record one event; never raises (logs failures instead)."""
        try:
            cleaned = _clean_event_type(event_type)
        except ValidationError as exc:
            logger.warning(
                "analytics.invalid_event_type",
                extra=log_extra(event_type=str(event_type)[:64], error=str(exc)),
            )
            return
        try:
            async with self._session() as s:
                s.add(
                    AnalyticsEvent(
                        event_type=cleaned,
                        user_id=user_id,
                        group_id=group_id,
                        track_id=track_id,
                        payload=payload,
                    )
                )
        except Exception as exc:  # noqa: BLE001 — analytics must never break features
            logger.warning(
                "analytics.track_failed",
                extra=log_extra(event_type=cleaned, error=str(exc)[:200]),
            )

    async def track_many(self, events: list[dict]) -> None:
        """Record many events in one transaction; never raises.

        Each item is a dict with an ``event_type`` key plus optional
        ``user_id`` / ``group_id`` / ``track_id`` / ``payload`` keys.
        """
        rows: list[AnalyticsEvent] = []
        for event in events:
            if not isinstance(event, dict):
                continue
            try:
                cleaned = _clean_event_type(event.get("event_type"))
            except ValidationError:
                logger.warning(
                    "analytics.invalid_event_type",
                    extra=log_extra(event_type=str(event.get("event_type"))[:64]),
                )
                continue
            rows.append(
                AnalyticsEvent(
                    event_type=cleaned,
                    user_id=event.get("user_id"),
                    group_id=event.get("group_id"),
                    track_id=event.get("track_id"),
                    payload=event.get("payload"),
                )
            )
        if not rows:
            return
        try:
            async with self._session() as s:
                s.add_all(rows)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "analytics.track_many_failed",
                extra=log_extra(count=len(rows), error=str(exc)[:200]),
            )

    async def counts_by_type(self, hours: int = 24) -> dict[str, int]:
        """``event_type → count`` within the last ``hours`` hours."""
        cutoff = utcnow() - timedelta(hours=max(1, hours))
        async with self._session() as s:
            rows = await s.execute(
                select(AnalyticsEvent.event_type, func.count())
                .where(AnalyticsEvent.created_at >= cutoff)
                .group_by(AnalyticsEvent.event_type)
            )
            return {str(row[0]): int(row[1]) for row in rows.all()}

    async def top_tracks(self, limit: int = 10, days: int = 30) -> list[tuple[Track, int]]:
        """Most played tracks ``(track, play count)`` within ``days`` days.

        Counts ``track_play`` + ``track_complete`` events joined to the catalog.
        """
        cutoff = utcnow() - timedelta(days=max(1, days))
        plays = func.count().label("plays")
        async with self._session() as s:
            rows = await s.execute(
                select(Track, plays)
                .join(AnalyticsEvent, AnalyticsEvent.track_id == Track.id)
                .where(
                    AnalyticsEvent.event_type.in_(PLAY_EVENT_TYPES),
                    AnalyticsEvent.created_at >= cutoff,
                )
                .group_by(Track)
                .order_by(plays.desc())
                .limit(max(1, limit))
            )
            return [(row[0], int(row[1])) for row in rows.all()]

    async def daily_plays(self, days: int = 14) -> dict[str, int]:
        """Plays per day (ISO date string → count), zero-filled for the window."""
        span = max(1, days)
        cutoff = utcnow() - timedelta(days=span)
        today = utcnow().date()
        result = {
            (today - timedelta(days=offset)).isoformat(): 0
            for offset in range(span - 1, -1, -1)
        }
        day = func.date(AnalyticsEvent.created_at).label("day")
        async with self._session() as s:
            rows = await s.execute(
                select(day, func.count())
                .where(
                    AnalyticsEvent.event_type.in_(PLAY_EVENT_TYPES),
                    AnalyticsEvent.created_at >= cutoff,
                )
                .group_by(day)
            )
            for row in rows.all():
                raw = row[0]
                key = raw.isoformat() if hasattr(raw, "isoformat") else str(raw)
                result[key] = int(row[1])
            return result

    async def count(self, event_type: str, hours: int | None = None) -> int:
        """Occurrences of one event type (optionally within ``hours``)."""
        cleaned = _clean_event_type(event_type)
        stmt = (
            select(func.count())
            .select_from(AnalyticsEvent)
            .where(AnalyticsEvent.event_type == cleaned)
        )
        if hours is not None:
            stmt = stmt.where(
                AnalyticsEvent.created_at >= utcnow() - timedelta(hours=max(1, hours))
            )
        async with self._session() as s:
            return int((await s.execute(stmt)).scalar_one())

    async def recent_recommendations(self, limit: int = 50) -> list[RecommendationEvent]:
        """Newest recommendation feedback events."""
        async with self._session() as s:
            rows = await s.execute(
                select(RecommendationEvent)
                .order_by(RecommendationEvent.created_at.desc(), RecommendationEvent.id.desc())
                .limit(max(1, limit))
            )
            return list(rows.scalars().all())

    async def log_recommendation(
        self,
        *,
        user_id: int | None = None,
        group_id: int | None = None,
        seed_track_id: int | None = None,
        selected_track_id: int | None = None,
        score: float | None = None,
        reason: str | None = None,
    ) -> RecommendationEvent:
        """Persist one recommendation feedback record.

        Raises:
            ValidationError: when ``selected_track_id`` is missing.
        """
        if selected_track_id is None:
            raise ValidationError(
                "selected_track_id is required",
                user_message="❌ Invalid recommendation.",
            )
        async with self._session() as s:
            event = RecommendationEvent(
                user_id=user_id,
                group_id=group_id,
                seed_track_id=seed_track_id,
                selected_track_id=int(selected_track_id),
                score=float(score) if score is not None else None,
                reason=(str(reason).strip()[:256] or None) if reason else None,
            )
            s.add(event)
            await s.flush()
            return event


__all__ = [
    "EVENT_AUTOPLAY_SELECTED",
    "EVENT_LIKE",
    "EVENT_SEARCH",
    "EVENT_TRACK_COMPLETE",
    "EVENT_TRACK_PLAY",
    "EVENT_UNLIKE",
    "PLAY_EVENT_TYPES",
    "AnalyticsRepository",
]

"""Playlist repository (playlists + ordered playlist tracks)."""

from __future__ import annotations

from sqlalchemy import delete, func, select
from sqlalchemy.orm import joinedload, selectinload

from app.database.models import Playlist, PlaylistTrack, Track
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)


def _clean_title(title: object) -> str:
    """Validate and normalize a playlist title."""
    clean = str(title or "").strip()
    if not clean or len(clean) > 128:
        raise ValidationError(
            "Playlist title must be 1-128 characters",
            user_message="❌ Playlist title must be 1-128 characters.",
        )
    return clean


class PlaylistRepository(BaseRepository):
    """Persistence for :class:`Playlist` and :class:`PlaylistTrack` rows."""

    async def create(
        self, user_db_id: int, title: str, description: str | None = None
    ) -> Playlist:
        """Create a new playlist owned by the user."""
        clean_title = _clean_title(title)
        clean_description = str(description).strip()[:512] if description else None
        async with self._session() as s:
            playlist = Playlist(
                user_id=user_db_id,
                title=clean_title,
                description=clean_description,
            )
            s.add(playlist)
            await s.flush()
            logger.info(
                "playlists.created",
                extra=log_extra(playlist_id=playlist.id, user_id=user_db_id),
            )
            return playlist

    async def list_for_user(self, user_db_id: int) -> list[Playlist]:
        """All playlists of a user (newest first) with items eager-loaded."""
        async with self._session() as s:
            rows = await s.execute(
                select(Playlist)
                .where(Playlist.user_id == user_db_id)
                .options(selectinload(Playlist.items))
                .order_by(Playlist.id.desc())
            )
            return list(rows.scalars().all())

    async def get(self, playlist_id: int) -> Playlist | None:
        """Fetch one playlist with ordered items, tracks and their artists.

        Artists are eager-loaded so track rows stay fully readable after the
        session closes (``expire_on_commit=False`` keeps loaded attributes,
        but lazy loads would fail on detached rows).
        """
        async with self._session() as s:
            return (
                await s.execute(
                    select(Playlist)
                    .where(Playlist.id == playlist_id)
                    .options(
                        selectinload(Playlist.items)
                        .joinedload(PlaylistTrack.track)
                        .joinedload(Track.artist)
                    )
                )
            ).scalar_one_or_none()

    async def delete(self, playlist_id: int, user_db_id: int) -> bool:
        """Delete a playlist owned by ``user_db_id`` (items cascade)."""
        async with self._session() as s:
            playlist = (
                await s.execute(
                    select(Playlist).where(
                        Playlist.id == playlist_id, Playlist.user_id == user_db_id
                    )
                )
            ).scalar_one_or_none()
            if playlist is None:
                return False
            await s.delete(playlist)
            await s.flush()
            logger.info("playlists.deleted", extra=log_extra(playlist_id=playlist_id))
            return True

    async def rename(
        self, playlist_id: int, user_db_id: int, title: str
    ) -> Playlist | None:
        """Rename a playlist owned by ``user_db_id``."""
        clean = _clean_title(title)
        async with self._session() as s:
            playlist = (
                await s.execute(
                    select(Playlist).where(
                        Playlist.id == playlist_id, Playlist.user_id == user_db_id
                    )
                )
            ).scalar_one_or_none()
            if playlist is None:
                return None
            playlist.title = clean
            await s.flush()
            return playlist

    async def add_track(
        self, playlist_id: int, track_id: int, added_by: int | None = None
    ) -> bool:
        """Append a track (next position). False when it is already present."""
        async with self._session() as s:
            duplicate = (
                await s.execute(
                    select(PlaylistTrack.id)
                    .where(
                        PlaylistTrack.playlist_id == playlist_id,
                        PlaylistTrack.track_id == track_id,
                    )
                    .limit(1)
                )
            ).scalar_one_or_none()
            if duplicate is not None:
                return False
            last_position = (
                await s.execute(
                    select(func.max(PlaylistTrack.position)).where(
                        PlaylistTrack.playlist_id == playlist_id
                    )
                )
            ).scalar_one()
            s.add(
                PlaylistTrack(
                    playlist_id=playlist_id,
                    track_id=track_id,
                    position=(last_position or 0) + 1,
                    added_by=added_by,
                )
            )
            await s.flush()
            return True

    async def remove_track(self, playlist_id: int, track_id: int) -> bool:
        """Remove a track from a playlist. True when a row was removed."""
        async with self._session() as s:
            result = await s.execute(
                delete(PlaylistTrack).where(
                    PlaylistTrack.playlist_id == playlist_id,
                    PlaylistTrack.track_id == track_id,
                )
            )
            return bool(result.rowcount)

    async def track_ids(self, playlist_id: int) -> list[int]:
        """Ordered track ids of a playlist (by position)."""
        async with self._session() as s:
            rows = await s.execute(
                select(PlaylistTrack.track_id)
                .where(PlaylistTrack.playlist_id == playlist_id)
                .order_by(PlaylistTrack.position, PlaylistTrack.id)
            )
            return [int(row[0]) for row in rows.all()]

    async def count_for_user(self, user_db_id: int) -> int:
        """Number of playlists owned by the user."""
        async with self._session() as s:
            return int(
                (
                    await s.execute(
                        select(func.count())
                        .select_from(Playlist)
                        .where(Playlist.user_id == user_db_id)
                    )
                ).scalar_one()
            )


__all__ = ["PlaylistRepository"]

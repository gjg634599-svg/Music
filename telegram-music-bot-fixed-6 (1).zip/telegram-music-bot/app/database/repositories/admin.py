"""Repositories for bot administrators and the admin audit log."""

from __future__ import annotations

from typing import Any

from sqlalchemy import delete, func, select

from app.database.models import Admin, AdminAuditLog
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Valid admin roles (mirrors ``app.admin.permissions.Role``; duplicated here
#: to keep the repository layer free of service-layer imports).
ROLES: frozenset[str] = frozenset({"super_admin", "admin", "moderator"})

#: Upper bound for ``recent``/``by_action`` style queries.
_MAX_LIMIT = 500


class AdminRepository(BaseRepository):
    """CRUD for bot administrators (role-based, one row per Telegram id)."""

    async def get_by_telegram_id(self, tg_id: int) -> Admin | None:
        """Return the admin row for *tg_id* (or ``None``)."""
        async with self._session() as s:
            result = await s.execute(select(Admin).where(Admin.telegram_id == tg_id))
            return result.scalars().first()

    async def add(
        self, tg_id: int, role: str = "admin", added_by: int | None = None
    ) -> Admin:
        """Add an admin, or update the role of an existing row.

        Re-adding an existing admin also restores ``is_active`` and records
        the new ``added_by``.
        """
        role = (role or "admin").strip().lower()
        if role not in ROLES:
            raise ValidationError(f"Unknown admin role: {role!r}")
        async with self._session() as s:
            result = await s.execute(select(Admin).where(Admin.telegram_id == tg_id))
            row = result.scalars().first()
            if row is None:
                row = Admin(
                    telegram_id=tg_id, role=role, added_by=added_by, is_active=True
                )
                s.add(row)
                logger.info("admins.added", extra=log_extra(tg_id=tg_id, role=role))
            else:
                row.role = role
                row.added_by = added_by
                row.is_active = True
                logger.info(
                    "admins.updated", extra=log_extra(tg_id=tg_id, role=role)
                )
            await s.flush()
            await s.refresh(row)
            return row

    async def remove(self, tg_id: int) -> bool:
        """Remove the admin row for *tg_id*; ``True`` when a row was deleted."""
        async with self._session() as s:
            result = await s.execute(delete(Admin).where(Admin.telegram_id == tg_id))
            removed = bool(result.rowcount)
        if removed:
            logger.info("admins.removed", extra=log_extra(tg_id=tg_id))
        return removed

    async def set_active(self, tg_id: int, active: bool) -> bool:
        """Activate/deactivate an admin; ``True`` when the row exists."""
        async with self._session() as s:
            result = await s.execute(select(Admin).where(Admin.telegram_id == tg_id))
            row = result.scalars().first()
            if row is None:
                return False
            row.is_active = bool(active)
            await s.flush()
            logger.info(
                "admins.set_active",
                extra=log_extra(tg_id=tg_id, active=bool(active)),
            )
            return True

    async def list_all(self) -> list[Admin]:
        """Return every admin row ordered by id."""
        async with self._session() as s:
            result = await s.execute(select(Admin).order_by(Admin.id))
            return list(result.scalars().all())


class AdminAuditLogRepository(BaseRepository):
    """Append-only audit trail of admin actions (never contains secrets)."""

    async def log(
        self,
        admin_id: int,
        action: str,
        target_type: str | None = None,
        target_id: str | int | None = None,
        details: dict[str, Any] | None = None,
        result: str = "ok",
    ) -> AdminAuditLog:
        """Record an admin action and return the persisted row.

        * ``admin_id`` is the acting admin's Telegram id.
        * ``target_id`` accepts str or int (stored as text, column-limited).
        * Non-dict ``details`` are wrapped as ``{"value": ...}`` to satisfy
          the JSON column.
        """
        action = (action or "").strip()
        if not action or len(action) > 64:
            raise ValidationError("Audit action must be 1-64 characters")
        if details is not None and not isinstance(details, dict):
            details = {"value": details}
        async with self._session() as s:
            row = AdminAuditLog(
                admin_id=int(admin_id),
                action=action,
                target_type=str(target_type)[:32] if target_type is not None else None,
                target_id=str(target_id)[:64] if target_id is not None else None,
                details=details,
                result=(result or "ok")[:16],
            )
            s.add(row)
            await s.flush()
            await s.refresh(row)
            return row

    async def recent(self, limit: int = 20) -> list[AdminAuditLog]:
        """Return the most recent audit entries (newest first)."""
        limit = max(1, min(int(limit), _MAX_LIMIT))
        async with self._session() as s:
            result = await s.execute(
                select(AdminAuditLog)
                .order_by(AdminAuditLog.created_at.desc(), AdminAuditLog.id.desc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def count(self) -> int:
        """Return the total number of audit entries."""
        async with self._session() as s:
            result = await s.execute(select(func.count()).select_from(AdminAuditLog))
            return int(result.scalar() or 0)

    async def by_action(self, action: str, limit: int = 50) -> list[AdminAuditLog]:
        """Return recent entries for a given *action* (newest first)."""
        limit = max(1, min(int(limit), _MAX_LIMIT))
        async with self._session() as s:
            result = await s.execute(
                select(AdminAuditLog)
                .where(AdminAuditLog.action == action)
                .order_by(AdminAuditLog.created_at.desc(), AdminAuditLog.id.desc())
                .limit(limit)
            )
            return list(result.scalars().all())


__all__ = ["AdminRepository", "AdminAuditLogRepository", "ROLES"]

"""Group, group-member and group-settings repositories."""

from __future__ import annotations

from sqlalchemy import delete, func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload, selectinload

from app.database.models import Group, GroupMember, GroupSettings
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Group columns writable through :meth:`GroupRepository.update`.
GROUP_FIELDS = frozenset({"title", "member_count", "is_active", "bot_in_chat"})
#: GroupSettings columns writable through :meth:`GroupSettingsRepository.update`.
SETTINGS_FIELDS = frozenset(
    {
        "permission_mode",
        "silent_mode",
        "mention_mode",
        "autoplay_enabled",
        "queue_limit",
        "idle_timeout_minutes",
        "volume",
    }
)
PERMISSION_MODES = frozenset({"everyone", "admins", "dj"})


def _validate_group_fields(fields: dict[str, object]) -> dict[str, object]:
    """Whitelist + validate group columns for update."""
    unknown = set(fields) - GROUP_FIELDS
    if unknown:
        raise ValidationError(f"Unsupported group fields: {sorted(unknown)}")
    clean: dict[str, object] = {}
    for key, value in fields.items():
        if key == "title":
            title = str(value or "").strip()
            if not title or len(title) > 256:
                raise ValidationError("title must be 1-256 characters")
            clean[key] = title
        elif key == "member_count":
            try:
                count = int(value)  # type: ignore[arg-type]
            except (TypeError, ValueError) as exc:
                raise ValidationError("member_count must be an integer") from exc
            if count < 0:
                raise ValidationError("member_count must be >= 0")
            clean[key] = count
        else:  # is_active / bot_in_chat
            clean[key] = bool(value)
    return clean


def _validate_settings_fields(fields: dict[str, object]) -> dict[str, object]:
    """Whitelist + validate group settings columns for update."""
    unknown = set(fields) - SETTINGS_FIELDS
    if unknown:
        raise ValidationError(
            f"Unsupported group settings fields: {sorted(unknown)}",
            user_message="❌ Invalid group setting.",
        )
    clean: dict[str, object] = {}
    for key, value in fields.items():
        if key in ("silent_mode", "mention_mode", "autoplay_enabled"):
            clean[key] = bool(value)
        elif key == "permission_mode":
            mode = str(value or "").strip().lower()
            if mode not in PERMISSION_MODES:
                raise ValidationError(
                    f"Invalid permission_mode: {value!r}",
                    user_message="❌ Invalid permission mode.",
                )
            clean[key] = mode
        else:  # integer fields
            try:
                number = int(value)  # type: ignore[arg-type]
            except (TypeError, ValueError) as exc:
                raise ValidationError(f"{key} must be an integer") from exc
            if number < 0:
                raise ValidationError(f"{key} must be >= 0")
            if number == 0 and key in ("queue_limit", "idle_timeout_minutes"):
                raise ValidationError(f"{key} must be >= 1")
            if key == "queue_limit" and number > 500:
                raise ValidationError("queue_limit must be <= 500")
            if key == "volume" and number > 200:
                raise ValidationError("volume must be <= 200")
            clean[key] = number
    return clean


class GroupRepository(BaseRepository):
    """Persistence for :class:`Group` rows."""

    @staticmethod
    async def _select_group(s: AsyncSession, tg_id: int) -> Group | None:
        return (
            await s.execute(
                select(Group)
                .where(Group.telegram_id == tg_id)
                .options(joinedload(Group.settings), selectinload(Group.members))
            )
        ).scalar_one_or_none()

    async def get_by_telegram_id(self, tg_id: int) -> Group | None:
        """Fetch a group with settings and members eager-loaded."""
        async with self._session() as s:
            return await self._select_group(s, tg_id)

    async def get_or_create(
        self,
        tg_id: int,
        title: str | None = None,
        type: str = "supergroup",  # noqa: A002 — binding contract signature
    ) -> Group:
        """Fetch a group by Telegram id, creating it with default settings.

        On every fetch presence flags are refreshed (``bot_in_chat``/``is_active``)
        and a missing settings row is healed. Safe against concurrent creation.
        """
        async with self._session() as s:
            group = await self._select_group(s, tg_id)
            if group is None:
                candidate = Group(
                    telegram_id=tg_id,
                    title=(str(title).strip() if title else f"Chat {tg_id}")[:256],
                    type=(type or "supergroup")[:16],
                    is_active=True,
                    bot_in_chat=True,
                )
                candidate.settings = GroupSettings()
                s.add(candidate)
                try:
                    await s.flush()
                    group = candidate
                    logger.info("groups.created", extra=log_extra(group_id=tg_id))
                except IntegrityError:
                    # Lost a concurrent-registration race — re-fetch the winner.
                    await s.rollback()
                    group = await self._select_group(s, tg_id)
                    if group is None:
                        raise
            if title:
                clean_title = str(title).strip()[:256]
                if clean_title:
                    group.title = clean_title
            if type:
                group.type = str(type)[:16]
            group.bot_in_chat = True
            group.is_active = True
            if group.settings is None:
                group.settings = GroupSettings()
            await s.flush()
            return group

    async def update(self, tg_id: int, **fields: object) -> Group | None:
        """Update whitelisted group columns. None when the group is unknown."""
        clean = _validate_group_fields(fields)
        async with self._session() as s:
            group = await self._select_group(s, tg_id)
            if group is None:
                return None
            for key, value in clean.items():
                setattr(group, key, value)
            await s.flush()
            return group

    async def deactivate(self, tg_id: int) -> bool:
        """Mark a group inactive (bot left / removed)."""
        async with self._session() as s:
            result = await s.execute(
                update(Group)
                .where(Group.telegram_id == tg_id)
                .values(is_active=False, bot_in_chat=False)
            )
            updated = bool(result.rowcount)
            if updated:
                logger.info("groups.deactivated", extra=log_extra(group_id=tg_id))
            return updated

    async def count_total(self) -> int:
        """Total known groups."""
        async with self._session() as s:
            return int(
                (await s.execute(select(func.count()).select_from(Group))).scalar_one()
            )

    async def count_active(self) -> int:
        """Groups actively using the bot."""
        async with self._session() as s:
            return int(
                (
                    await s.execute(
                        select(func.count())
                        .select_from(Group)
                        .where(Group.is_active.is_(True))
                    )
                ).scalar_one()
            )

    async def broadcast_segment(
        self, segment: str, ids: list[int] | None = None
    ) -> list[int]:
        """Telegram ids of groups matching a broadcast segment.

        Segments: ``all`` (bot still in chat), ``active`` (active and in chat),
        ``specific`` (subset of ``ids`` where the bot is still in the chat).
        """
        async with self._session() as s:
            if segment == "all":
                stmt = select(Group.telegram_id).where(Group.bot_in_chat.is_(True))
            elif segment == "active":
                stmt = select(Group.telegram_id).where(
                    Group.bot_in_chat.is_(True), Group.is_active.is_(True)
                )
            elif segment == "specific":
                if not ids:
                    raise ValidationError(
                        "specific segment requires ids",
                        user_message="❌ No target groups selected.",
                    )
                stmt = select(Group.telegram_id).where(
                    Group.bot_in_chat.is_(True), Group.telegram_id.in_(ids)
                )
            else:
                raise ValidationError(
                    f"Unknown group broadcast segment: {segment!r}",
                    user_message="❌ Invalid broadcast segment.",
                )
            rows = await s.execute(stmt.order_by(Group.telegram_id))
            return [int(row[0]) for row in rows.all()]

    async def list_page(self, limit: int, offset: int = 0) -> tuple[list[Group], int]:
        """One page of groups (newest first) plus the total row count."""
        async with self._session() as s:
            total = int(
                (await s.execute(select(func.count()).select_from(Group))).scalar_one()
            )
            rows = await s.execute(
                select(Group)
                .order_by(Group.id.desc())
                .limit(max(1, limit))
                .offset(max(0, offset))
            )
            return list(rows.scalars().all()), total

    async def groups_of_user(self, tg_user_id: int) -> list[Group]:
        """Groups a Telegram user is a member of (settings eager-loaded)."""
        async with self._session() as s:
            rows = await s.execute(
                select(Group)
                .join(GroupMember, GroupMember.group_id == Group.id)
                .where(GroupMember.telegram_user_id == tg_user_id)
                .options(joinedload(Group.settings))
                .order_by(Group.id)
            )
            return list(rows.scalars().unique().all())

    async def all_with_members(self) -> list[Group]:
        """All groups with members eager-loaded (admin tooling)."""
        async with self._session() as s:
            rows = await s.execute(
                select(Group)
                .options(joinedload(Group.settings), selectinload(Group.members))
                .order_by(Group.id)
            )
            return list(rows.scalars().unique().all())


class GroupMemberRepository(BaseRepository):
    """Persistence for :class:`GroupMember` rows."""

    async def upsert(
        self,
        group_db_id: int,
        user_db_id: int,
        tg_user_id: int,
        *,
        is_group_admin: bool = False,
        is_dj: bool = False,
    ) -> GroupMember:
        """Create or refresh a membership row.

        On existing rows the admin/DJ flags are upgrade-only (``True`` wins) so
        routine member syncs never wipe DJ status; use :meth:`set_dj` and
        :meth:`set_admin_flag` for explicit changes in either direction.
        """
        async with self._session() as s:
            member = (
                await s.execute(
                    select(GroupMember).where(
                        GroupMember.group_id == group_db_id,
                        GroupMember.telegram_user_id == tg_user_id,
                    )
                )
            ).scalar_one_or_none()
            if member is None:
                member = GroupMember(
                    group_id=group_db_id,
                    user_id=user_db_id,
                    telegram_user_id=tg_user_id,
                    is_group_admin=bool(is_group_admin),
                    is_dj=bool(is_dj),
                )
                s.add(member)
                await s.flush()
                logger.info(
                    "group_members.created",
                    extra=log_extra(group_id=group_db_id, tg_id=tg_user_id),
                )
            else:
                member.user_id = user_db_id
                if is_group_admin:
                    member.is_group_admin = True
                if is_dj:
                    member.is_dj = True
                await s.flush()
            return member

    async def get(self, group_db_id: int, tg_user_id: int) -> GroupMember | None:
        """Fetch one membership row by group db id + member Telegram id."""
        async with self._session() as s:
            return (
                await s.execute(
                    select(GroupMember).where(
                        GroupMember.group_id == group_db_id,
                        GroupMember.telegram_user_id == tg_user_id,
                    )
                )
            ).scalar_one_or_none()

    async def set_dj(self, group_db_id: int, tg_user_id: int, value: bool) -> bool:
        """Explicitly set the DJ flag. False when the member is unknown."""
        async with self._session() as s:
            member = (
                await s.execute(
                    select(GroupMember).where(
                        GroupMember.group_id == group_db_id,
                        GroupMember.telegram_user_id == tg_user_id,
                    )
                )
            ).scalar_one_or_none()
            if member is None:
                return False
            member.is_dj = bool(value)
            await s.flush()
            return True

    async def set_admin_flag(self, group_db_id: int, tg_user_id: int, value: bool) -> bool:
        """Explicitly set the chat-admin flag. False when the member is unknown."""
        async with self._session() as s:
            member = (
                await s.execute(
                    select(GroupMember).where(
                        GroupMember.group_id == group_db_id,
                        GroupMember.telegram_user_id == tg_user_id,
                    )
                )
            ).scalar_one_or_none()
            if member is None:
                return False
            member.is_group_admin = bool(value)
            await s.flush()
            return True

    async def list_members(self, group_db_id: int) -> list[GroupMember]:
        """All members of a group (join order)."""
        async with self._session() as s:
            rows = await s.execute(
                select(GroupMember)
                .where(GroupMember.group_id == group_db_id)
                .order_by(GroupMember.joined_at, GroupMember.id)
            )
            return list(rows.scalars().all())

    async def admins(self, group_db_id: int) -> list[GroupMember]:
        """Members flagged as chat administrators."""
        async with self._session() as s:
            rows = await s.execute(
                select(GroupMember)
                .where(
                    GroupMember.group_id == group_db_id,
                    GroupMember.is_group_admin.is_(True),
                )
                .order_by(GroupMember.joined_at, GroupMember.id)
            )
            return list(rows.scalars().all())

    async def remove(self, group_db_id: int, tg_user_id: int) -> bool:
        """Delete a membership row. True when a row was removed."""
        async with self._session() as s:
            result = await s.execute(
                delete(GroupMember).where(
                    GroupMember.group_id == group_db_id,
                    GroupMember.telegram_user_id == tg_user_id,
                )
            )
            return bool(result.rowcount)


class GroupSettingsRepository(BaseRepository):
    """Persistence for :class:`GroupSettings` rows, keyed by Telegram group id."""

    @staticmethod
    async def _select_settings(s: AsyncSession, group_tg_id: int) -> GroupSettings | None:
        return (
            await s.execute(
                select(GroupSettings)
                .join(Group, Group.id == GroupSettings.group_id)
                .where(Group.telegram_id == group_tg_id)
            )
        ).scalar_one_or_none()

    async def get(self, group_tg_id: int) -> GroupSettings | None:
        """Fetch settings for a group (None when group/settings unknown)."""
        async with self._session() as s:
            return await self._select_settings(s, group_tg_id)

    async def get_or_create(self, group_tg_id: int) -> GroupSettings:
        """Fetch settings, creating defaults for a registered group.

        Raises:
            ValidationError: when the group itself is not registered yet.
        """
        async with self._session() as s:
            settings = await self._select_settings(s, group_tg_id)
            if settings is not None:
                return settings
            group = (
                await s.execute(select(Group).where(Group.telegram_id == group_tg_id))
            ).scalar_one_or_none()
            if group is None:
                raise ValidationError(
                    f"Group {group_tg_id} is not registered yet",
                    user_message="❌ This group isn't registered yet — add the bot first.",
                )
            settings = GroupSettings(group_id=group.id)
            s.add(settings)
            await s.flush()
            logger.info("group_settings.created", extra=log_extra(group_id=group_tg_id))
            return settings

    async def update(self, group_tg_id: int, **fields: object) -> GroupSettings:
        """Update whitelisted settings fields (creates the row when missing)."""
        clean = _validate_settings_fields(fields)
        async with self._session() as s:
            settings = await self._select_settings(s, group_tg_id)
            if settings is None:
                group = (
                    await s.execute(
                        select(Group).where(Group.telegram_id == group_tg_id)
                    )
                ).scalar_one_or_none()
                if group is None:
                    raise ValidationError(
                        f"Group {group_tg_id} is not registered yet",
                        user_message="❌ This group isn't registered yet — add the bot first.",
                    )
                settings = GroupSettings(group_id=group.id)
                s.add(settings)
            for key, value in clean.items():
                setattr(settings, key, value)
            await s.flush()
            return settings


__all__ = [
    "GROUP_FIELDS",
    "PERMISSION_MODES",
    "SETTINGS_FIELDS",
    "GroupMemberRepository",
    "GroupRepository",
    "GroupSettingsRepository",
]

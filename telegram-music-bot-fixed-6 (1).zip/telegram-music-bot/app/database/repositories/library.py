"""Liked tracks and listening history repositories.

``ListeningHistory.user_id`` is a DB user id (FK to ``users.id``); callers that
hold Telegram ids resolve them first (see :class:`app.users.history.HistoryService`).
``ListeningHistory.group_id`` stores the *Telegram* group id.
"""

from __future__ import annotations

from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.base import utcnow
from app.database.models import LikedTrack, ListeningHistory, Track
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

_MAX_HISTORY_LIMIT = 1000


class LikedTrackRepository(BaseRepository):
    """Persistence for :class:`LikedTrack` rows."""

    async def toggle(self, user_db_id: int, track_id: int) -> bool:
        """Flip the like state. Returns True when the track is now liked."""
        async with self._session() as s:
            existing = (
                await s.execute(
                    select(LikedTrack).where(
                        LikedTrack.user_id == user_db_id,
                        LikedTrack.track_id == track_id,
                    )
                )
            ).scalar_one_or_none()
            if existing is not None:
                await s.delete(existing)
                await s.flush()
                logger.info(
                    "likes.removed", extra=log_extra(user_id=user_db_id, track_id=track_id)
                )
                return False
            s.add(LikedTrack(user_id=user_db_id, track_id=track_id))
            await s.flush()
            logger.info("likes.added", extra=log_extra(user_id=user_db_id, track_id=track_id))
            return True

    async def is_liked(self, user_db_id: int, track_id: int) -> bool:
        """Whether the track is currently liked by the user."""
        async with self._session() as s:
            found = (
                await s.execute(
                    select(LikedTrack.id)
                    .where(
                        LikedTrack.user_id == user_db_id,
                        LikedTrack.track_id == track_id,
                    )
                    .limit(1)
                )
            ).scalar_one_or_none()
            return found is not None

    async def list_tracks(self, user_db_id: int, limit: int = 100) -> list[Track]:
        """Liked tracks, newest like first."""
        async with self._session() as s:
            rows = await s.execute(
                select(Track)
                .join(LikedTrack, LikedTrack.track_id == Track.id)
                .where(LikedTrack.user_id == user_db_id)
                .order_by(LikedTrack.created_at.desc(), LikedTrack.id.desc())
                .limit(max(1, min(limit, _MAX_HISTORY_LIMIT)))
            )
            return list(rows.scalars().all())

    async def count(self, user_db_id: int) -> int:
        """Number of liked tracks for the user."""
        async with self._session() as s:
            return int(
                (
                    await s.execute(
                        select(func.count())
                        .select_from(LikedTrack)
                        .where(LikedTrack.user_id == user_db_id)
                    )
                ).scalar_one()
            )

    async def liked_track_ids(self, user_db_id: int) -> set[int]:
        """Set of liked track ids (taste-profile input)."""
        async with self._session() as s:
            rows = await s.execute(
                select(LikedTrack.track_id).where(LikedTrack.user_id == user_db_id)
            )
            return {int(row[0]) for row in rows.all()}

    async def liked_artist_ids(self, user_db_id: int) -> set[int]:
        """Set of artist ids referenced by the user's liked tracks."""
        async with self._session() as s:
            rows = await s.execute(
                select(Track.artist_id)
                .join(LikedTrack, LikedTrack.track_id == Track.id)
                .where(LikedTrack.user_id == user_db_id, Track.artist_id.is_not(None))
                .distinct()
            )
            return {int(row[0]) for row in rows.all()}


class ListeningHistoryRepository(BaseRepository):
    """Persistence and aggregations for :class:`ListeningHistory` rows."""

    # ------------------------------------------------------------------
    # Writes
    # ------------------------------------------------------------------
    async def record(
        self,
        user_db_id: int,
        track_id: int,
        *,
        group_id: int | None = None,
        context: str = "personal",
        completed: bool = False,
        skipped: bool = False,
        duration_played: int = 0,
    ) -> ListeningHistory:
        """Insert one listening event."""
        ctx = str(context or "personal").strip() or "personal"
        if len(ctx) > 16:
            raise ValidationError(f"Invalid history context: {context!r}")
        if int(duration_played) < 0:
            raise ValidationError("duration_played must be >= 0")
        async with self._session() as s:
            entry = ListeningHistory(
                user_id=user_db_id,
                track_id=int(track_id),
                group_id=group_id,
                context=ctx,
                completed=bool(completed),
                skipped=bool(skipped),
                duration_played=int(duration_played),
            )
            s.add(entry)
            await s.flush()
            return entry

    # ------------------------------------------------------------------
    # Personal queries
    # ------------------------------------------------------------------
    @staticmethod
    async def _attach_tracks(s: AsyncSession, stmt) -> list[ListeningHistory]:
        """Execute a (history, track) select and attach ``track`` to each row.

        ``ListeningHistory`` declares no ORM relationship to ``Track``; the
        joined track is attached as a plain attribute for consumer convenience.
        """
        rows = (await s.execute(stmt)).all()
        entries: list[ListeningHistory] = []
        for entry, track in rows:
            try:
                entry.track = track  # type: ignore[attr-defined]  # convenience attribute
            except Exception:  # pragma: no cover — never break a read on attach
                pass
            entries.append(entry)
        return entries

    async def recent(self, user_db_id: int, limit: int = 20) -> list[ListeningHistory]:
        """Newest history entries with the played track attached."""
        async with self._session() as s:
            stmt = (
                select(ListeningHistory, Track)
                .outerjoin(Track, ListeningHistory.track_id == Track.id)
                .where(ListeningHistory.user_id == user_db_id)
                .order_by(ListeningHistory.played_at.desc(), ListeningHistory.id.desc())
                .limit(max(1, min(limit, _MAX_HISTORY_LIMIT)))
            )
            return await self._attach_tracks(s, stmt)

    @staticmethod
    def _distinct_recent_stmt(*conditions, limit: int):
        """Select distinct track ids ordered by most recent play."""
        last_played = func.max(ListeningHistory.played_at).label("last_played")
        return (
            select(ListeningHistory.track_id, last_played)
            .where(*conditions)
            .group_by(ListeningHistory.track_id)
            .order_by(last_played.desc())
            .limit(max(1, min(limit, _MAX_HISTORY_LIMIT)))
        )

    async def recent_track_ids(self, user_db_id: int, limit: int = 50) -> list[int]:
        """Distinct recently played track ids, newest first."""
        async with self._session() as s:
            rows = await s.execute(
                self._distinct_recent_stmt(
                    ListeningHistory.user_id == user_db_id, limit=limit
                )
            )
            return [int(row[0]) for row in rows.all()]

    async def recent_tracks(self, user_db_id: int, limit: int = 50) -> list[Track]:
        """Distinct recently played tracks, newest first."""
        ids = await self.recent_track_ids(user_db_id, limit=limit)
        if not ids:
            return []
        async with self._session() as s:
            rows = await s.execute(select(Track).where(Track.id.in_(ids)))
            by_id = {track.id: track for track in rows.scalars().all()}
            return [by_id[track_id] for track_id in ids if track_id in by_id]

    async def skipped_track_ids(self, user_db_id: int, limit: int = 100) -> list[int]:
        """Distinct recently skipped track ids, newest skip first."""
        async with self._session() as s:
            rows = await s.execute(
                self._distinct_recent_stmt(
                    ListeningHistory.user_id == user_db_id,
                    ListeningHistory.skipped.is_(True),
                    limit=limit,
                )
            )
            return [int(row[0]) for row in rows.all()]

    async def play_counts(self, user_db_id: int, limit: int = 200) -> dict[int, int]:
        """``track_id → play count`` for the user (top ``limit`` by plays)."""
        plays = func.count().label("plays")
        async with self._session() as s:
            rows = await s.execute(
                select(ListeningHistory.track_id, plays)
                .where(ListeningHistory.user_id == user_db_id)
                .group_by(ListeningHistory.track_id)
                .order_by(plays.desc())
                .limit(max(1, min(limit, _MAX_HISTORY_LIMIT)))
            )
            return {int(row[0]): int(row[1]) for row in rows.all()}

    async def listening_seconds(self, user_db_id: int) -> int:
        """Total seconds of audio actually played by one user.

        Sums ``duration_played`` across every history row (personal and
        group-context plays alike — the metric answers "how much music did
        this user actually listen to").
        """
        async with self._session() as s:
            result = await s.execute(
                select(func.coalesce(func.sum(ListeningHistory.duration_played), 0)).where(
                    ListeningHistory.user_id == user_db_id
                )
            )
            return int(result.scalar() or 0)

    async def artist_play_counts(self, user_db_id: int) -> dict[int, int]:
        """``artist_id → play count`` aggregated over the user's history."""
        plays = func.count().label("plays")
        async with self._session() as s:
            rows = await s.execute(
                select(Track.artist_id, plays)
                .select_from(ListeningHistory)
                .join(Track, Track.id == ListeningHistory.track_id)
                .where(
                    ListeningHistory.user_id == user_db_id,
                    Track.artist_id.is_not(None),
                )
                .group_by(Track.artist_id)
            )
            return {int(row[0]): int(row[1]) for row in rows.all()}

    # ------------------------------------------------------------------
    # Group queries (filtered by Telegram group id)
    # ------------------------------------------------------------------
    async def group_history(
        self, group_tg_id: int, limit: int = 500
    ) -> list[ListeningHistory]:
        """Newest history entries recorded inside a group (track attached)."""
        async with self._session() as s:
            stmt = (
                select(ListeningHistory, Track)
                .outerjoin(Track, ListeningHistory.track_id == Track.id)
                .where(ListeningHistory.group_id == group_tg_id)
                .order_by(ListeningHistory.played_at.desc(), ListeningHistory.id.desc())
                .limit(max(1, min(limit, _MAX_HISTORY_LIMIT)))
            )
            return await self._attach_tracks(s, stmt)

    async def group_recent_track_ids(
        self, group_tg_id: int, limit: int = 50
    ) -> list[int]:
        """Distinct recently played track ids inside a group, newest first."""
        async with self._session() as s:
            rows = await s.execute(
                self._distinct_recent_stmt(
                    ListeningHistory.group_id == group_tg_id, limit=limit
                )
            )
            return [int(row[0]) for row in rows.all()]

    async def group_skipped_track_ids(
        self, group_tg_id: int, limit: int = 100
    ) -> list[int]:
        """Distinct recently skipped track ids inside a group, newest first."""
        async with self._session() as s:
            rows = await s.execute(
                self._distinct_recent_stmt(
                    ListeningHistory.group_id == group_tg_id,
                    ListeningHistory.skipped.is_(True),
                    limit=limit,
                )
            )
            return [int(row[0]) for row in rows.all()]

    async def group_artist_play_counts(self, group_tg_id: int) -> dict[int, int]:
        """``artist_id → play count`` aggregated over a group's history."""
        plays = func.count().label("plays")
        async with self._session() as s:
            rows = await s.execute(
                select(Track.artist_id, plays)
                .select_from(ListeningHistory)
                .join(Track, Track.id == ListeningHistory.track_id)
                .where(
                    ListeningHistory.group_id == group_tg_id,
                    Track.artist_id.is_not(None),
                )
                .group_by(Track.artist_id)
            )
            return {int(row[0]): int(row[1]) for row in rows.all()}

    # ------------------------------------------------------------------
    # Global counters
    # ------------------------------------------------------------------
    async def count_for_user(self, user_db_id: int) -> int:
        """Total history rows for one user."""
        async with self._session() as s:
            return int(
                (
                    await s.execute(
                        select(func.count())
                        .select_from(ListeningHistory)
                        .where(ListeningHistory.user_id == user_db_id)
                    )
                ).scalar_one()
            )

    async def total_plays(self) -> int:
        """Total recorded listening events."""
        async with self._session() as s:
            return int(
                (
                    await s.execute(
                        select(func.count()).select_from(ListeningHistory)
                    )
                ).scalar_one()
            )

    async def plays_since(self, hours: int = 24) -> int:
        """Listening events within the last ``hours`` hours."""
        cutoff = utcnow() - timedelta(hours=max(1, hours))
        async with self._session() as s:
            return int(
                (
                    await s.execute(
                        select(func.count())
                        .select_from(ListeningHistory)
                        .where(ListeningHistory.played_at >= cutoff)
                    )
                ).scalar_one()
            )


__all__ = ["LikedTrackRepository", "ListeningHistoryRepository"]

"""Music catalog repositories: tracks, artists, albums, genres.

All catalog persistence goes through these classes (see CONTRACTS.md
section 2). Each method opens its own session and commits atomically;
returned ORM objects are detached but fully loaded (artist / album /
genres eagerly loaded), because the engine uses ``expire_on_commit=False``.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import delete, func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database.models.music import (
    Album,
    Artist,
    Genre,
    Track,
    artist_genres,
    track_genres,
)
from app.database.models.users import ListeningHistory
from app.database.repositories.base import BaseRepository
from app.errors import ValidationError
from app.logging import get_logger, log_extra
from app.music.normalizer import normalize_text

logger = get_logger(__name__)

#: Eager loading for relationships accessed on detached Track objects.
_TRACK_OPTIONS = (selectinload(Track.artist), selectinload(Track.album))

#: Columns that may be written through TrackRepository.create/update.
TRACK_UPDATABLE_FIELDS = frozenset(
    {
        "title",
        "normalized_title",
        "artist_id",
        "album_id",
        "duration_seconds",
        "language",
        "mood",
        "tempo",
        "popularity",
        "isrc",
        "source",
        "source_id",
        "stream_url",
        "file_path",
        "audio_file_id",
        "artwork_url",
        "artwork_file_id",
        "is_playable",
        "play_count",
        "uploaded_by",
        "description",
    }
)


def _escape_like(term: str) -> str:
    """Escape LIKE wildcards so user input cannot broaden the match."""
    return term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


class TrackRepository(BaseRepository):
    """CRUD + catalog queries for :class:`~app.database.models.music.Track`."""

    async def get(self, track_id: int) -> Track | None:
        """Fetch a track by primary key (artist/album eagerly loaded)."""
        async with self._session() as s:
            return await self._loaded(s, track_id)

    async def get_by_id(self, track_id: int) -> Track | None:
        """Alias of :meth:`get` — the name consumers use via the duck-typed
        ``TrackLookup``/``TrackProvider`` protocols (queue, sessions, engine,
        library, group service).  Added by task 4-a as a minimal cross-agent
        interface reconciliation (see worklog).
        """
        return await self.get(track_id)

    async def get_by_source(self, source: str, source_id: str) -> Track | None:
        """Fetch a track by its ``(source, source_id)`` natural key."""
        async with self._session() as s:
            return (
                await s.scalars(
                    select(Track)
                    .where(Track.source == source, Track.source_id == source_id)
                    .options(*_TRACK_OPTIONS)
                )
            ).first()

    @staticmethod
    async def _loaded(s: AsyncSession, track_id: int) -> Track | None:
        """Select one track with relationships eagerly loaded."""
        return await s.scalar(
            select(Track).where(Track.id == track_id).options(*_TRACK_OPTIONS)
        )

    async def create(self, **fields: Any) -> Track:
        """Insert a track; unknown columns raise ``ValidationError``."""
        values = _filter_track_fields(fields)
        if not values.get("title"):
            raise ValidationError("Track.create requires a title")
        if not values.get("source") or not values.get("source_id"):
            raise ValidationError("Track.create requires source and source_id")
        values.setdefault("normalized_title", normalize_text(str(values["title"]))[:256])
        async with self._session() as s:
            track = Track(**values)
            s.add(track)
            try:
                await s.flush()
            except IntegrityError as exc:
                raise ValidationError(f"Track already exists: {exc}") from exc
            logger.info(
                "repo.track.created",
                extra=log_extra(track_id=track.id, source=values["source"]),
            )
            # Re-select with eager loading so the detached object carries
            # artist / album / genres for the caller.
            return await self._loaded(s, track.id)

    async def update(self, track_id: int, **fields: Any) -> Track | None:
        """Update allowed columns; returns the track or ``None`` if missing."""
        values = _filter_track_fields(fields)
        if not values:
            return await self.get(track_id)
        if "title" in values and "normalized_title" not in values:
            values["normalized_title"] = normalize_text(str(values["title"]))[:256]
        async with self._session() as s:
            track = await s.get(Track, track_id)
            if track is None:
                return None
            for key, value in values.items():
                setattr(track, key, value)
            await s.flush()
            return await self._loaded(s, track_id)

    async def search_catalog(self, query: str, limit: int = 20) -> list[Track]:
        """LIKE search on title and artist name.

        The query is split into words; every word must match the title OR
        the artist name (AND of ORs), so ``daft punk one more`` still finds
        the right catalog rows. Ordered by popularity, then play count.
        """
        words = [w for w in normalize_text(query).split() if w][:8]
        if not words:
            return []
        clauses = []
        for word in words:
            pattern = f"%{_escape_like(word)}%"
            clauses.append(
                or_(
                    Track.title.ilike(pattern, escape="\\"),
                    Artist.name.ilike(pattern, escape="\\"),
                )
            )
        async with self._session() as s:
            stmt = (
                select(Track)
                .outerjoin(Artist, Track.artist_id == Artist.id)
                .where(*clauses)
                .options(*_TRACK_OPTIONS)
                .order_by(Track.popularity.desc(), Track.play_count.desc())
                .limit(max(1, min(int(limit), 100)))
            )
            rows = await s.scalars(stmt)
            return list(rows)

    async def by_artist(self, artist_id: int, limit: int = 20) -> list[Track]:
        """An artist's tracks ordered by popularity."""
        async with self._session() as s:
            stmt = (
                select(Track)
                .where(Track.artist_id == artist_id)
                .options(*_TRACK_OPTIONS)
                .order_by(Track.popularity.desc(), Track.play_count.desc())
                .limit(max(1, min(int(limit), 100)))
            )
            return list(await s.scalars(stmt))

    async def by_genres(self, genre_ids: list[int], limit: int = 20) -> list[Track]:
        """Tracks sharing any of the given genre ids, most popular first."""
        ids = sorted({gid for gid in genre_ids if gid})
        if not ids:
            return []
        async with self._session() as s:
            stmt = (
                select(Track)
                .join(track_genres, track_genres.c.track_id == Track.id)
                .where(track_genres.c.genre_id.in_(ids))
                .options(*_TRACK_OPTIONS)
                .order_by(Track.popularity.desc(), Track.play_count.desc())
                .limit(max(1, min(int(limit), 100)))
            )
            return list((await s.scalars(stmt)).unique())

    async def random(
        self, limit: int = 10, exclude_ids: list[int] | None = None
    ) -> list[Track]:
        """Random playable tracks, excluding the given ids."""
        exclude = [i for i in (exclude_ids or []) if i]
        async with self._session() as s:
            stmt = select(Track).options(*_TRACK_OPTIONS)
            if exclude:
                stmt = stmt.where(Track.id.not_in(exclude))
            stmt = stmt.order_by(func.random()).limit(max(1, min(int(limit), 100)))
            return list(await s.scalars(stmt))

    async def popular(self, limit: int = 10) -> list[Track]:
        """Most popular tracks overall."""
        async with self._session() as s:
            stmt = (
                select(Track)
                .options(*_TRACK_OPTIONS)
                .order_by(Track.popularity.desc(), Track.play_count.desc())
                .limit(max(1, min(int(limit), 100)))
            )
            return list(await s.scalars(stmt))

    async def recent(
        self, limit: int = 10, offset: int = 0, playable_only: bool = True
    ) -> list[Track]:
        """Newest catalog tracks first (``created_at`` DESC, id DESC tiebreak).

        Powers the /new browse screen; ``offset`` enables real offset
        pagination so arbitrarily large catalogs never load fully. Rows are
        optionally restricted to playable tracks (default: yes).
        """
        async with self._session() as s:
            stmt = select(Track).options(*_TRACK_OPTIONS)
            if playable_only:
                stmt = stmt.where(Track.is_playable.is_(True))
            stmt = (
                stmt.order_by(Track.created_at.desc(), Track.id.desc())
                .offset(max(0, int(offset)))
                .limit(max(1, min(int(limit), 100)))
            )
            return list(await s.scalars(stmt))

    async def count_playable(self) -> int:
        """Total playable tracks (denominator for /new pagination)."""
        async with self._session() as s:
            return int(
                await s.scalar(
                    select(func.count()).select_from(Track).where(Track.is_playable.is_(True))
                )
                or 0
            )

    async def increment_play_count(self, track_id: int) -> int:
        """Atomically bump play_count; returns the new value (0 if missing)."""
        async with self._session() as s:
            await s.execute(
                update(Track)
                .where(Track.id == track_id)
                .values(play_count=Track.play_count + 1)
            )
            value = await s.scalar(select(Track.play_count).where(Track.id == track_id))
            return int(value or 0)

    async def count(self) -> int:
        """Total number of tracks in the catalog."""
        async with self._session() as s:
            return int(await s.scalar(select(func.count()).select_from(Track)) or 0)

    async def top_played(self, limit: int = 10, days: int = 30) -> list[Track]:
        """Most played tracks within the last ``days`` days (history-based)."""
        cutoff = datetime.now(tz=UTC) - timedelta(days=max(1, days))
        async with self._session() as s:
            stmt = (
                select(Track)
                .join(ListeningHistory, ListeningHistory.track_id == Track.id)
                .where(ListeningHistory.played_at >= cutoff)
                .group_by(Track.id)
                .order_by(func.count(ListeningHistory.id).desc(), Track.popularity.desc())
                .limit(max(1, min(int(limit), 100)))
            )
            return list((await s.scalars(stmt)).unique())


class ArtistRepository(BaseRepository):
    """Artist lookups and upserts (dedupe by ``normalized_name``)."""

    async def get_or_create(self, name: str) -> Artist:
        """Return the artist for *name*, creating it when unknown.

        Race-safe: a concurrent insert hitting the unique constraint is
        caught and resolved by re-reading.
        """
        clean = (name or "").strip()[:256]
        if not clean:
            raise ValidationError("Artist name cannot be empty")
        normalized = normalize_text(clean)[:256]
        async with self._session() as s:
            found = await s.scalar(
                select(Artist).where(Artist.normalized_name == normalized)
            )
            if found is not None:
                return found
            artist = Artist(name=clean, normalized_name=normalized)
            s.add(artist)
            try:
                await s.flush()
                return artist
            except IntegrityError:
                await s.rollback()
        async with self._session() as s:
            found = await s.scalar(
                select(Artist).where(Artist.normalized_name == normalized)
            )
            if found is None:  # pragma: no cover - should be unreachable
                raise ValidationError(f"Artist upsert failed for {clean!r}")
            return found

    async def get_by_normalized(self, name: str) -> Artist | None:
        """Find an artist by normalized name."""
        normalized = normalize_text(name or "")[:256]
        if not normalized:
            return None
        async with self._session() as s:
            return await s.scalar(
                select(Artist).where(Artist.normalized_name == normalized)
            )

    async def get_by_ids(self, artist_ids: list[int]) -> list[Artist]:
        """Bulk artist lookup by primary keys (order not guaranteed)."""
        ids = [int(a) for a in artist_ids if int(a) > 0]
        if not ids:
            return []
        async with self._session() as s:
            rows = await s.execute(select(Artist).where(Artist.id.in_(ids)))
            return list(rows.scalars().all())

    async def search_by_name(self, q: str, limit: int = 10) -> list[Artist]:
        """LIKE search on artist name, most popular first."""
        term = (q or "").strip()
        if not term:
            return []
        pattern = f"%{_escape_like(normalize_text(term))}%"
        async with self._session() as s:
            stmt = (
                select(Artist)
                .where(Artist.name.ilike(pattern, escape="\\"))
                .order_by(Artist.popularity.desc())
                .limit(max(1, min(int(limit), 50)))
            )
            return list(await s.scalars(stmt))


class AlbumRepository(BaseRepository):
    """Album lookups and upserts (dedupe by title + artist)."""

    async def get_or_create(
        self,
        title: str,
        artist_id: int | None = None,
        release_date: Any = None,
        artwork_url: str | None = None,
        source: str = "local",
    ) -> Album:
        """Return the album for (title, artist), creating it when unknown.

        When an existing album lacks artwork and one is provided, the
        artwork is filled in (idempotent upsert behavior).
        """
        clean = (title or "").strip()[:256]
        if not clean:
            raise ValidationError("Album title cannot be empty")
        normalized = normalize_text(clean)[:256]
        async with self._session() as s:
            stmt = select(Album).where(
                Album.normalized_title == normalized,
                Album.artist_id.is_(None) if artist_id is None else Album.artist_id == artist_id,
            )
            found = await s.scalar(stmt)
            if found is not None:
                if artwork_url and not found.artwork_url:
                    found.artwork_url = artwork_url[:1024]
                    await s.flush()
                return found
            album = Album(
                title=clean,
                normalized_title=normalized,
                artist_id=artist_id,
                release_date=release_date,
                artwork_url=(artwork_url[:1024] if artwork_url else None),
                source=source[:32],
            )
            s.add(album)
            try:
                await s.flush()
                return album
            except IntegrityError:
                await s.rollback()
        async with self._session() as s:
            found = await s.scalar(stmt)
            if found is None:  # pragma: no cover - should be unreachable
                raise ValidationError(f"Album upsert failed for {clean!r}")
            return found

    async def by_artist(self, artist_id: int, limit: int = 50) -> list[Album]:
        """Albums of one artist."""
        async with self._session() as s:
            stmt = (
                select(Album)
                .where(Album.artist_id == artist_id)
                .order_by(Album.release_date.desc().nulls_last())
                .limit(max(1, min(int(limit), 100)))
            )
            return list(await s.scalars(stmt))


class GenreRepository(BaseRepository):
    """Genre upserts and track/artist genre associations."""

    async def get_or_create(self, name: str) -> Genre:
        """Return the genre for *name*, creating it when unknown (race-safe)."""
        clean = (name or "").strip()[:64]
        if not clean:
            raise ValidationError("Genre name cannot be empty")
        normalized = normalize_text(clean)[:64]
        async with self._session() as s:
            found = await s.scalar(
                select(Genre).where(Genre.normalized_name == normalized)
            )
            if found is not None:
                return found
            genre = Genre(name=clean, normalized_name=normalized)
            s.add(genre)
            try:
                await s.flush()
                return genre
            except IntegrityError:
                await s.rollback()
        async with self._session() as s:
            found = await s.scalar(
                select(Genre).where(Genre.normalized_name == normalized)
            )
            if found is None:  # pragma: no cover - should be unreachable
                raise ValidationError(f"Genre upsert failed for {clean!r}")
            return found

    async def get_ids_for_track(self, track_id: int) -> list[int]:
        """Genre ids currently associated with a track."""
        async with self._session() as s:
            rows = await s.scalars(
                select(track_genres.c.genre_id).where(track_genres.c.track_id == track_id)
            )
            return [int(row) for row in rows]

    async def associate_track(self, track_id: int, genre_ids: list[int]) -> int:
        """Link genres to a track (idempotent); returns associations added."""
        ids = sorted({int(gid) for gid in genre_ids if gid})
        if not ids:
            return 0
        async with self._session() as s:
            existing = set(
                await s.scalars(
                    select(track_genres.c.genre_id).where(
                        track_genres.c.track_id == track_id
                    )
                )
            )
            missing = [gid for gid in ids if gid not in existing]
            if missing:
                await s.execute(
                    track_genres.insert(),
                    [{"track_id": track_id, "genre_id": gid} for gid in missing],
                )
            return len(missing)

    async def associate_artist(self, artist_id: int, genre_ids: list[int]) -> int:
        """Link genres to an artist (idempotent); returns associations added."""
        ids = sorted({int(gid) for gid in genre_ids if gid})
        if not ids:
            return 0
        async with self._session() as s:
            existing = set(
                await s.scalars(
                    select(artist_genres.c.genre_id).where(
                        artist_genres.c.artist_id == artist_id
                    )
                )
            )
            missing = [gid for gid in ids if gid not in existing]
            if missing:
                await s.execute(
                    artist_genres.insert(),
                    [{"artist_id": artist_id, "genre_id": gid} for gid in missing],
                )
            return len(missing)

    async def clear_track_genres(self, track_id: int, genre_ids: list[int]) -> int:
        """Remove specific genre links from a track; returns links removed."""
        ids = sorted({int(gid) for gid in genre_ids if gid})
        if not ids:
            return 0
        async with self._session() as s:
            result = await s.execute(
                delete(track_genres).where(
                    track_genres.c.track_id == track_id,
                    track_genres.c.genre_id.in_(ids),
                )
            )
            return int(result.rowcount or 0)


def _filter_track_fields(fields: dict[str, Any]) -> dict[str, Any]:
    """Whitelist-filter track columns, rejecting unknown keys loudly."""
    unknown = set(fields) - TRACK_UPDATABLE_FIELDS
    if unknown:
        raise ValidationError(f"Unknown track fields: {sorted(unknown)}")
    return {key: value for key, value in fields.items()}


__all__ = [
    "TRACK_UPDATABLE_FIELDS",
    "AlbumRepository",
    "ArtistRepository",
    "GenreRepository",
    "TrackRepository",
]

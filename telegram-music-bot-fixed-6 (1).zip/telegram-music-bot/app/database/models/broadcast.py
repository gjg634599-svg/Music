"""Broadcast models: broadcasts, targets, deliveries."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    BigInteger,
    DateTime,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base
from app.database.models.playback import JSONVariant


class Broadcast(Base):
    """A broadcast campaign."""

    __tablename__ = "broadcasts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_by: Mapped[int] = mapped_column(BigInteger, index=True)
    #: text | photo | video | audio | document | animation | voice | album | copy
    content_type: Mapped[str] = mapped_column(String(24))
    #: all_users | active_users | inactive_users | users_by_language | users_with_groups |
    #: group_admins | specific_users | all_groups | active_groups | groups_with_vc | specific_groups
    target_type: Mapped[str] = mapped_column(String(32))
    target_filter: Mapped[dict | None] = mapped_column(JSONVariant)
    text: Mapped[str | None] = mapped_column(Text)
    caption: Mapped[str | None] = mapped_column(Text)
    #: list of {"type": ..., "file_id": ...}
    media: Mapped[list | None] = mapped_column(JSONVariant)
    #: {"chat_id": ..., "message_ids": [...]} — for copy_message based broadcasts
    copy_source: Mapped[dict | None] = mapped_column(JSONVariant)
    #: list of {"label": ..., "url": ...}
    buttons: Mapped[list | None] = mapped_column(JSONVariant)
    parse_mode: Mapped[str | None] = mapped_column(String(16), default="HTML")
    target_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    sent_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    failed_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    #: draft | pending | sending | paused | completed | cancelled | failed
    status: Mapped[str] = mapped_column(String(16), default="draft", server_default="draft")
    error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class BroadcastTarget(Base):
    """Planned destination of a broadcast."""

    __tablename__ = "broadcast_targets"
    __table_args__ = (
        UniqueConstraint("broadcast_id", "chat_id", name="uq_broadcast_targets_broadcast_chat"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    broadcast_id: Mapped[int] = mapped_column(
        Integer, index=True
    )
    chat_type: Mapped[str] = mapped_column(String(8))  # 'user' | 'group'
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    status: Mapped[str] = mapped_column(String(16), default="pending", server_default="pending")
    attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    last_error: Mapped[str | None] = mapped_column(String(512))
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class BroadcastDelivery(Base):
    """Per-message delivery outcome record (audit trail)."""

    __tablename__ = "broadcast_deliveries"
    __table_args__ = (UniqueConstraint("broadcast_id", "chat_id", name="uq_broadcast_deliveries_broadcast_chat"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    broadcast_id: Mapped[int] = mapped_column(Integer, index=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    ok: Mapped[bool] = mapped_column(default=True)
    error: Mapped[str | None] = mapped_column(String(512))
    latency_ms: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

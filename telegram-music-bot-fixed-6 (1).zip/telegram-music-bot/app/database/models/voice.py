"""Voice engine models: accounts, health, sessions, events, assignments."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, ForeignKey, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin
from app.database.models.playback import JSONVariant


class VoiceAccount(Base, TimestampMixin):
    """A Telegram user account used as the voice participant in group VCs.

    The MTProto session is stored encrypted (Fernet) in ``session_encrypted``
    and is never logged, exported or shown in Telegram.
    """

    __tablename__ = "voice_accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    label: Mapped[str] = mapped_column(String(64))
    #: unique among accounts (one Telegram user ↔ one voice account);
    #: NULL for legacy rows whose identity was never captured.
    telegram_id: Mapped[int | None] = mapped_column(
        BigInteger, index=True, unique=True
    )
    username: Mapped[str | None] = mapped_column(String(64))
    #: masked hint only, e.g. '+98***12'
    phone_hint: Mapped[str | None] = mapped_column(String(32))
    session_encrypted: Mapped[str] = mapped_column(String(1024))
    #: offline | healthy | degraded | disabled | auth_required
    status: Mapped[str] = mapped_column(String(16), default="offline", server_default="offline")
    max_sessions: Mapped[int] = mapped_column(Integer, default=5, server_default="5")
    priority: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    last_error: Mapped[str | None] = mapped_column(String(512))
    last_health_check_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class VoiceAccountHealth(Base):
    """Health check history for a voice account."""

    __tablename__ = "voice_account_health"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(
        ForeignKey("voice_accounts.id", ondelete="CASCADE"), index=True
    )
    #: healthy | degraded | offline | disabled | auth_required
    status: Mapped[str] = mapped_column(String(16))
    latency_ms: Mapped[int | None] = mapped_column(Integer)
    error: Mapped[str | None] = mapped_column(String(512))
    checked_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )


class VoiceSession(Base):
    """An active (or historical) voice-chat session for a group."""

    __tablename__ = "voice_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    group_id: Mapped[int] = mapped_column(BigInteger, index=True)
    account_id: Mapped[int] = mapped_column(
        ForeignKey("voice_accounts.id", ondelete="SET NULL"), index=True
    )
    #: joining | playing | paused | ended | failed
    status: Mapped[str] = mapped_column(String(16), default="joining", server_default="joining")
    current_track_id: Mapped[int | None] = mapped_column(Integer)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_heartbeat: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    meta: Mapped[dict | None] = mapped_column(JSONVariant)


class VoiceSessionEvent(Base):
    """Event log for a voice session (joined, track started, failover...)."""

    __tablename__ = "voice_session_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    session_id: Mapped[int] = mapped_column(
        ForeignKey("voice_sessions.id", ondelete="CASCADE"), index=True
    )
    event: Mapped[str] = mapped_column(String(64))
    details: Mapped[dict | None] = mapped_column(JSONVariant)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class VoiceAccountAssignment(Base):
    """History of account ↔ group assignments (incl. failover)."""

    __tablename__ = "voice_account_assignments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(
        ForeignKey("voice_accounts.id", ondelete="CASCADE"), index=True
    )
    group_id: Mapped[int] = mapped_column(BigInteger, index=True)
    session_id: Mapped[int | None] = mapped_column(Integer)
    assigned_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

"""Playback models: queue items and playback sessions.

A single ``queue_items`` table serves both personal (owner_type='user') and
group (owner_type='group') queues, replacing the spec's separate group_queue
table with a cleaner discriminated design.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import JSON

from app.database.base import Base

# JSONB on PostgreSQL, plain JSON elsewhere (SQLite/tests).
JSONVariant = JSON().with_variant(JSONB(), "postgresql")


class QueueItem(Base):
    """One queued track for a personal or group queue."""

    __tablename__ = "queue_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    owner_type: Mapped[str] = mapped_column(String(8), index=True)  # 'user' | 'group'
    owner_id: Mapped[int] = mapped_column(BigInteger, index=True)  # telegram user/group id
    track_id: Mapped[int] = mapped_column(
        ForeignKey("tracks.id", ondelete="CASCADE"), index=True
    )
    position: Mapped[int] = mapped_column(Integer, index=True)
    status: Mapped[str] = mapped_column(String(16), default="queued", server_default="queued")
    added_by: Mapped[int | None] = mapped_column(BigInteger)
    added_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    played_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # Hotfix (Task 2-f): explicit string target required — a bare
    # relationship() with Mapped[object] cannot be resolved by SQLAlchemy
    # and breaks global mapper configuration.
    track: Mapped[object] = relationship("Track", lazy="joined")


class PlaybackSession(Base):
    """Durable playback state for a personal or group session."""

    __tablename__ = "playback_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    session_type: Mapped[str] = mapped_column(String(8), index=True)  # 'personal' | 'group'
    user_id: Mapped[int | None] = mapped_column(BigInteger, index=True, nullable=True)
    group_id: Mapped[int | None] = mapped_column(BigInteger, index=True, nullable=True)
    current_track_id: Mapped[int | None] = mapped_column(
        ForeignKey("tracks.id", ondelete="SET NULL"), nullable=True
    )
    current_queue_item_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    position_seconds: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    status: Mapped[str] = mapped_column(String(16), default="idle", server_default="idle")
    shuffle: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    repeat_mode: Mapped[str] = mapped_column(String(8), default="off", server_default="off")
    autoplay: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")
    volume: Mapped[int] = mapped_column(Integer, default=100, server_default="100")
    now_playing_message_id: Mapped[int | None] = mapped_column(BigInteger)
    control_chat_id: Mapped[int | None] = mapped_column(BigInteger)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    current_track: Mapped[object] = relationship("Track")  # hotfix: explicit target


_ = Text  # reserved for future columns
_ = JSONVariant  # re-exported for migrations & other models

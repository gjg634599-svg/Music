"""All ORM models — import this module to populate Base.metadata."""

from __future__ import annotations

from app.database.models.admin import (
    Admin,
    AdminAuditLog,
    BotAsset,
    BotButton,
    BotMessage,
    BotSetting,
)
from app.database.models.analytics import AnalyticsEvent, RecommendationEvent
from app.database.models.broadcast import Broadcast, BroadcastDelivery, BroadcastTarget
from app.database.models.groups import Group, GroupMember, GroupSettings
from app.database.models.music import Album, Artist, Genre, Track, TrackSource
from app.database.models.playback import PlaybackSession, QueueItem
from app.database.models.playlists import Playlist, PlaylistTrack
from app.database.models.users import (
    LikedTrack,
    ListeningHistory,
    SearchHistory,
    User,
    UserPreferences,
)
from app.database.models.voice import (
    VoiceAccount,
    VoiceAccountAssignment,
    VoiceAccountHealth,
    VoiceSession,
    VoiceSessionEvent,
)

__all__ = [
    "Admin",
    "AdminAuditLog",
    "AnalyticsEvent",
    "Album",
    "Artist",
    "BotAsset",
    "BotButton",
    "BotMessage",
    "BotSetting",
    "Broadcast",
    "BroadcastDelivery",
    "BroadcastTarget",
    "Genre",
    "Group",
    "GroupMember",
    "GroupSettings",
    "LikedTrack",
    "ListeningHistory",
    "PlaybackSession",
    "Playlist",
    "PlaylistTrack",
    "QueueItem",
    "RecommendationEvent",
    "SearchHistory",
    "Track",
    "TrackSource",
    "User",
    "UserPreferences",
    "VoiceAccount",
    "VoiceAccountAssignment",
    "VoiceAccountHealth",
    "VoiceSession",
    "VoiceSessionEvent",
]

"""Music catalog models: artists, albums, genres, tracks, track sources."""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    ForeignKey,

    Integer,
    String,
    Table,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin

track_genres = Table(
    "track_genres",
    Base.metadata,
    Column("track_id", ForeignKey("tracks.id", ondelete="CASCADE"), primary_key=True),
    Column("genre_id", ForeignKey("genres.id", ondelete="CASCADE"), primary_key=True),
)

artist_genres = Table(
    "artist_genres",
    Base.metadata,
    Column("artist_id", ForeignKey("artists.id", ondelete="CASCADE"), primary_key=True),
    Column("genre_id", ForeignKey("genres.id", ondelete="CASCADE"), primary_key=True),
)


class Genre(Base):
    """A music genre."""

    __tablename__ = "genres"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(64))
    normalized_name: Mapped[str] = mapped_column(String(64), unique=True, index=True)


class Artist(Base, TimestampMixin):
    """A music artist."""

    __tablename__ = "artists"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(256), index=True)
    normalized_name: Mapped[str] = mapped_column(String(256), unique=True, index=True)
    popularity: Mapped[int] = mapped_column(Integer, default=0, server_default="0")

    genres: Mapped[list[Genre]] = relationship(secondary=artist_genres, lazy="selectin")
    albums: Mapped[list["Album"]] = relationship(back_populates="artist")


class Album(Base, TimestampMixin):
    """An album."""

    __tablename__ = "albums"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(256), index=True)
    normalized_title: Mapped[str] = mapped_column(String(256), index=True)
    artist_id: Mapped[int | None] = mapped_column(
        ForeignKey("artists.id", ondelete="SET NULL"), nullable=True
    )
    release_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    artwork_url: Mapped[str | None] = mapped_column(String(1024))
    source: Mapped[str] = mapped_column(String(32), default="local", server_default="local")

    artist: Mapped[Artist | None] = relationship(back_populates="albums")


class Track(Base, TimestampMixin):
    """A normalized track from any authorized source.

    ``source`` + ``source_id`` uniquely identify the source track; the
    ``audio_file_id`` caches a Telegram file_id for fast re-sends.
    """

    __tablename__ = "tracks"
    __table_args__ = (
        UniqueConstraint("source", "source_id", name="uq_tracks_source_source_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(256), index=True)
    normalized_title: Mapped[str] = mapped_column(String(256), index=True)
    artist_id: Mapped[int | None] = mapped_column(
        ForeignKey("artists.id", ondelete="SET NULL"), nullable=True
    )
    album_id: Mapped[int | None] = mapped_column(
        ForeignKey("albums.id", ondelete="SET NULL"), nullable=True
    )
    duration_seconds: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    language: Mapped[str | None] = mapped_column(String(8))
    mood: Mapped[str | None] = mapped_column(String(32))
    tempo: Mapped[int | None] = mapped_column(Integer)
    popularity: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    isrc: Mapped[str | None] = mapped_column(String(32), index=True)
    source: Mapped[str] = mapped_column(String(32), default="local", server_default="local")
    source_id: Mapped[str] = mapped_column(String(128))
    stream_url: Mapped[str | None] = mapped_column(String(1024))
    file_path: Mapped[str | None] = mapped_column(String(512))
    audio_file_id: Mapped[str | None] = mapped_column(String(256), index=True)
    artwork_url: Mapped[str | None] = mapped_column(String(1024))
    artwork_file_id: Mapped[str | None] = mapped_column(String(256))
    is_playable: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")
    play_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    uploaded_by: Mapped[str | None] = mapped_column(String(64))
    description: Mapped[str | None] = mapped_column(Text)

    artist: Mapped[Artist | None] = relationship()
    album: Mapped[Album | None] = relationship()
    genres: Mapped[list[Genre]] = relationship(secondary=track_genres, lazy="selectin")
    sources: Mapped[list["TrackSource"]] = relationship(
        back_populates="track", cascade="all, delete-orphan"
    )


class TrackSource(Base):
    """An alternative source for the same normalized track."""

    __tablename__ = "track_sources"
    __table_args__ = (
        UniqueConstraint("source", "source_id", name="uq_track_sources_source_source_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    track_id: Mapped[int] = mapped_column(
        ForeignKey("tracks.id", ondelete="CASCADE"), index=True
    )
    source: Mapped[str] = mapped_column(String(32))
    source_id: Mapped[str] = mapped_column(String(128))
    url: Mapped[str | None] = mapped_column(String(1024))
    quality: Mapped[str | None] = mapped_column(String(16))
    is_available: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    track: Mapped[Track] = relationship(back_populates="sources")

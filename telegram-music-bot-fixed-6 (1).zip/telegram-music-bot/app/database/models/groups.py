"""Group models: groups, members, settings."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin
from app.database.models.playback import JSONVariant


class Group(Base, TimestampMixin):
    """A Telegram group where the bot is present."""

    __tablename__ = "groups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    title: Mapped[str] = mapped_column(String(256))
    type: Mapped[str] = mapped_column(String(16), default="supergroup")
    member_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")
    bot_in_chat: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")

    settings: Mapped["GroupSettings"] = relationship(
        back_populates="group", uselist=False, lazy="joined"
    )
    members: Mapped[list["GroupMember"]] = relationship(
        back_populates="group", cascade="all, delete-orphan"
    )


class GroupMember(Base):
    """Membership + permission flags for a user inside a group."""

    __tablename__ = "group_members"
    __table_args__ = (
        UniqueConstraint("group_id", "user_id", name="uq_group_members_group_user"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    group_id: Mapped[int] = mapped_column(
        ForeignKey("groups.id", ondelete="CASCADE"), index=True
    )
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    telegram_user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    is_group_admin: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    is_dj: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    joined_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    group: Mapped[Group] = relationship(back_populates="members")


class GroupSettings(Base):
    """Per-group behaviour configuration (editable by group admins)."""

    __tablename__ = "group_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    group_id: Mapped[int] = mapped_column(
        ForeignKey("groups.id", ondelete="CASCADE"), unique=True, index=True
    )
    #: everyone | admins | dj
    permission_mode: Mapped[str] = mapped_column(
        String(16), default="everyone", server_default="everyone"
    )
    silent_mode: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")
    mention_mode: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    autoplay_enabled: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")
    queue_limit: Mapped[int] = mapped_column(Integer, default=50, server_default="50")
    idle_timeout_minutes: Mapped[int] = mapped_column(Integer, default=5, server_default="5")
    volume: Mapped[int] = mapped_column(Integer, default=100, server_default="100")
    extra: Mapped[dict] = mapped_column(JSONVariant, default=dict, server_default="{}")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    group: Mapped[Group] = relationship(back_populates="settings")

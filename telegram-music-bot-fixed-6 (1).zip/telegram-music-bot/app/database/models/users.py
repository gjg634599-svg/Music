"""User-related models: users, preferences, likes, history."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin


class User(Base, TimestampMixin):
    """A Telegram user known to the bot."""

    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    username: Mapped[str | None] = mapped_column(String(64))
    first_name: Mapped[str | None] = mapped_column(String(128))
    language: Mapped[str] = mapped_column(String(8), default="en", server_default="en")
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # Aggregated counters (cheap, used for admin statistics).
    play_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0")

    preferences: Mapped["UserPreferences"] = relationship(
        back_populates="user", uselist=False, lazy="joined"
    )
    playlists: Mapped[list["Playlist"]] = relationship(back_populates="user")

    # String identifiers used by ``str(model)`` in logs.
    def __repr__(self) -> str:  # pragma: no cover
        return f"<User tg={self.telegram_id}>"


class UserPreferences(Base):
    """Per-user playback and product preferences."""

    __tablename__ = "user_preferences"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), unique=True, index=True
    )
    autoplay_enabled: Mapped[bool] = mapped_column(
        Boolean, default=True, server_default="1"
    )
    shuffle_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    repeat_mode: Mapped[str] = mapped_column(String(8), default="off", server_default="off")
    volume: Mapped[int] = mapped_column(Integer, default=100, server_default="100")
    language: Mapped[str] = mapped_column(String(8), default="en", server_default="en")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    user: Mapped[User] = relationship(back_populates="preferences")


class LikedTrack(Base):
    """A liked (❤️) track."""

    __tablename__ = "liked_tracks"
    __table_args__ = (UniqueConstraint("user_id", "track_id", name="uq_liked_tracks_user_track"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    track_id: Mapped[int] = mapped_column(
        ForeignKey("tracks.id", ondelete="CASCADE"), index=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class ListeningHistory(Base):
    """Every track play, completion or skip (personal or group context)."""

    __tablename__ = "listening_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    track_id: Mapped[int] = mapped_column(
        ForeignKey("tracks.id", ondelete="CASCADE"), index=True
    )
    group_id: Mapped[int | None] = mapped_column(BigInteger, index=True, nullable=True)
    context: Mapped[str] = mapped_column(String(16), default="personal", server_default="personal")
    completed: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    skipped: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    duration_played: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    played_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )


class SearchHistory(Base):
    """Recent search queries per user."""

    __tablename__ = "search_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    query: Mapped[str] = mapped_column(String(256))
    results_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


from app.database.models.music import Track  # noqa: E402, TID252
from app.database.models.playlists import Playlist  # noqa: E402, TID252

"""Analytics models: product events and recommendation feedback."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Float, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base
from app.database.models.playback import JSONVariant


class AnalyticsEvent(Base):
    """A product analytics event (no unnecessary personal data)."""

    __tablename__ = "analytics_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_type: Mapped[str] = mapped_column(String(32), index=True)
    user_id: Mapped[int | None] = mapped_column(BigInteger, index=True, nullable=True)
    group_id: Mapped[int | None] = mapped_column(BigInteger, index=True, nullable=True)
    track_id: Mapped[int | None] = mapped_column(Integer, index=True, nullable=True)
    payload: Mapped[dict | None] = mapped_column(JSONVariant)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )


class RecommendationEvent(Base):
    """Feedback loop record for the recommendation engine."""

    __tablename__ = "recommendation_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int | None] = mapped_column(BigInteger, index=True, nullable=True)
    group_id: Mapped[int | None] = mapped_column(BigInteger, index=True, nullable=True)
    seed_track_id: Mapped[int | None] = mapped_column(Integer, index=True)
    selected_track_id: Mapped[int] = mapped_column(Integer, index=True)
    score: Mapped[float | None] = mapped_column(Float)
    reason: Mapped[str | None] = mapped_column(String(256))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

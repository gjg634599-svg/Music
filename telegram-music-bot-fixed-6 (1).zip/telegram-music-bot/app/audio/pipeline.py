"""Audio pipeline — orchestration layer used by the background workers.

Wraps :class:`AudioProcessor` with the event bus so heavy jobs (downloads,
transcodes, upload normalization) run off the request path:

* ``process_track`` — voice-ready path + ``audio:processed`` event.
* ``process_upload`` — probe + move into the music library + metadata dict.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from app.audio.processor import AudioProcessor
from app.errors import InvalidAudioError, PlaybackError
from app.logging import get_logger, log_extra
from app.playback.events import EventBus

if TYPE_CHECKING:
    from app.database.models.music import Track

logger = get_logger(__name__)


class AudioPipeline:
    """Heavy audio jobs (download → probe → convert) for the worker pool."""

    def __init__(self, processor: AudioProcessor, events: EventBus) -> None:
        self._processor = processor
        self._events = events

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def process_track(self, track: Track) -> Path:
        """Prepare a track for voice playback and notify listeners.

        Publishes ``audio:processed`` with ``track_id`` once the opus file is
        ready (the event fires even when the file was already cached).
        """
        path = await self._processor.prepare_for_voice(track)
        await self._events.publish("audio:processed", track_id=track.id)
        logger.info(
            "audio.pipeline.track_processed",
            extra=log_extra(track_id=track.id, path=path.name),
        )
        return path

    async def process_upload(self, src_path: str | Path) -> tuple[Path, dict]:
        """Normalize an uploaded file into the music library.

        Probes the source (invalid audio → :class:`InvalidAudioError`), copies
        it into the storage music directory under a unique name and returns
        ``(stored_path, metadata_dict)``. The source file is left in place —
        its lifecycle belongs to the caller (bot upload handler / worker).
        """
        source = Path(src_path)
        if not source.is_file():
            raise InvalidAudioError(f"Upload source does not exist: {source.name}")
        try:
            meta = await self._processor.probe_metadata(source)
        except PlaybackError as exc:
            logger.info(
                "audio.pipeline.upload_probe_failed",
                extra=log_extra(path=source.name),
            )
            raise InvalidAudioError("Uploaded file is not valid audio") from exc

        storage = self._processor.storage
        relative = f"music/{storage.unique_name(source.name, prefix='upload-')}"
        stored = storage.save(relative, source)
        metadata = {
            "title": meta.title,
            "artist": meta.artist,
            "album": meta.album,
            "duration": int(meta.duration_seconds or 0),
            "genre": meta.genre,
            "language": meta.language,
            "tempo": meta.tempo,
        }
        logger.info(
            "audio.pipeline.upload_processed",
            extra=log_extra(path=stored.name, duration=metadata["duration"]),
        )
        return stored, metadata


__all__ = ["AudioPipeline"]

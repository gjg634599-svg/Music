"""FFmpeg toolkit — all audio/video operations as async subprocesses.

Every operation shells out through :func:`asyncio.create_subprocess_exec`
(never a blocking ``subprocess`` call) with a hard timeout. Failures raise
:class:`app.errors.PlaybackError` with a *generic* internal message — the raw
ffmpeg stderr is logged (truncated) but never propagated into user-facing
exceptions.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
from pathlib import Path
from typing import Any

from app.config import Settings
from app.errors import PlaybackError
from app.logging import get_logger, log_extra
from app.music.models import AudioMetadata

logger = get_logger(__name__)

#: Default wall-clock budget for a single ffmpeg/ffprobe invocation.
DEFAULT_TIMEOUT_SECONDS = 120.0

#: Bytes of stderr kept for logs when a command fails.
_STDERR_LOG_LIMIT = 800


class FFmpegToolkit:
    """Probing, transcoding and synthetic media generation via ffmpeg."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._timeout = DEFAULT_TIMEOUT_SECONDS

    # ------------------------------------------------------------------
    # Subprocess plumbing
    # ------------------------------------------------------------------
    async def _run(
        self, args: list[str], *, timeout: float | None = None
    ) -> tuple[int, str, str]:
        """Run a command; return ``(returncode, stdout, stderr)``.

        Raises :class:`PlaybackError` only when the process times out (a
        non-zero exit code is the caller's decision).
        """
        budget = timeout if timeout is not None else self._timeout
        try:
            proc = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except FileNotFoundError as exc:
            raise PlaybackError(f"{args[0]} executable not found") from exc
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), budget)
        except asyncio.TimeoutError as exc:
            with contextlib.suppress(ProcessLookupError):
                proc.kill()
            await proc.wait()
            raise PlaybackError(f"{args[0]} timed out after {budget:.0f}s") from exc
        return (
            proc.returncode or 0,
            stdout.decode("utf-8", errors="replace"),
            stderr.decode("utf-8", errors="replace"),
        )

    async def _run_checked(
        self,
        args: list[str],
        *,
        what: str,
        timeout: float | None = None,
    ) -> None:
        """Run a command and raise :class:`PlaybackError` on failure."""
        returncode, _, stderr = await self._run(args, timeout=timeout)
        if returncode != 0:
            logger.error(
                "audio.ffmpeg_failed",
                extra=log_extra(
                    what=what,
                    program=args[0],
                    returncode=returncode,
                    stderr=stderr[-_STDERR_LOG_LIMIT:].strip(),
                ),
            )
            raise PlaybackError(f"{what} failed (exit {returncode})")

    @staticmethod
    def _ffmpeg_args(settings: Settings, *args: str) -> list[str]:
        """Build an ffmpeg argv with quiet logging."""
        return [settings.ffmpeg_path, "-hide_banner", "-loglevel", "error", *args]

    # ------------------------------------------------------------------
    # Probing
    # ------------------------------------------------------------------
    async def probe(self, path: str | Path) -> dict[str, Any]:
        """Run ffprobe and return the parsed JSON output.

        Args:
            path: Media file path.

        Returns:
            The raw ffprobe dict (``format`` and ``streams`` keys).

        Raises:
            PlaybackError: ffprobe failed or produced invalid JSON.
        """
        args = [
            self._settings.ffprobe_path,
            "-v",
            "error",
            "-print_format",
            "json",
            "-show_format",
            "-show_streams",
            str(path),
        ]
        returncode, stdout, stderr = await self._run(args)
        if returncode != 0:
            logger.error(
                "audio.ffprobe_failed",
                extra=log_extra(
                    path=Path(path).name,
                    returncode=returncode,
                    stderr=stderr[-_STDERR_LOG_LIMIT:].strip(),
                ),
            )
            raise PlaybackError("ffprobe failed")
        try:
            data = json.loads(stdout)
        except json.JSONDecodeError as exc:
            logger.error(
                "audio.ffprobe_bad_json",
                extra=log_extra(path=Path(path).name),
            )
            raise PlaybackError("ffprobe returned invalid JSON") from exc
        if not isinstance(data, dict):
            raise PlaybackError("ffprobe returned unexpected output")
        return data

    async def probe_metadata(self, path: str | Path) -> dict[str, Any]:
        """Extract the common metadata tags from a media file.

        Tag lookup is case-insensitive (ffprobe tag casing varies by container).
        Duration is normalised to a whole number of seconds.
        """
        data = await self.probe(path)
        fmt = data.get("format") if isinstance(data.get("format"), dict) else {}
        tags = fmt.get("tags") if isinstance(fmt.get("tags"), dict) else {}
        return {
            "title": _tag(tags, "title"),
            "artist": _tag(tags, "artist"),
            "album": _tag(tags, "album"),
            "duration": _duration_seconds(data),
            "genre": _tag(tags, "genre"),
            "language": _tag(tags, "language"),
        }

    async def extract_metadata(self, path: str | Path) -> AudioMetadata:
        """Probe a file and map the result onto :class:`AudioMetadata`."""
        meta = await self.probe_metadata(path)
        return AudioMetadata(
            title=meta.get("title"),
            artist=meta.get("artist"),
            album=meta.get("album"),
            duration_seconds=int(meta.get("duration") or 0),
            genre=meta.get("genre"),
            language=meta.get("language"),
        )

    # ------------------------------------------------------------------
    # Conversion
    # ------------------------------------------------------------------
    async def to_voice_format(self, src: str | Path, dst: str | Path) -> Path:
        """Transcode any audio into the Telegram voice-chat format.

        Opus 96 kbps, 48 kHz, stereo — the exact profile py-tgcalls streams.
        """
        dst_path = Path(dst)
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        args = self._ffmpeg_args(
            self._settings,
            "-y",
            "-i",
            str(src),
            "-vn",
            "-c:a",
            "libopus",
            "-b:a",
            "96k",
            "-ar",
            "48000",
            "-ac",
            "2",
            str(dst_path),
        )
        await self._run_checked(args, what="voice-format conversion")
        logger.info(
            "audio.voice_converted",
            extra=log_extra(src=Path(src).name, dst=dst_path.name),
        )
        return dst_path

    async def to_thumbnail(self, src: str | Path, dst: str | Path) -> Path | None:
        """Extract embedded artwork, or ``None`` when the file has none.

        Artwork is optional — a missing cover must never fail playback. First
        the embedded stream is copied as-is; if the container has no stream
        cover, a scaled re-encode is attempted.
        """
        dst_path = Path(dst)
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        attempts = (
            self._ffmpeg_args(
                self._settings, "-y", "-i", str(src), "-an", "-c:v", "copy",
                "-frames:v", "1", str(dst_path),
            ),
            self._ffmpeg_args(
                self._settings, "-y", "-i", str(src), "-an", "-vf", "scale=320:320",
                "-frames:v", "1", str(dst_path),
            ),
        )
        for args in attempts:
            returncode, _, _stderr = await self._run(args)
            if returncode == 0 and dst_path.exists() and dst_path.stat().st_size > 0:
                logger.info(
                    "audio.thumbnail_extracted",
                    extra=log_extra(src=Path(src).name, dst=dst_path.name),
                )
                return dst_path
            dst_path.unlink(missing_ok=True)
        logger.info(
            "audio.thumbnail_missing", extra=log_extra(src=Path(src).name)
        )
        return None

    # ------------------------------------------------------------------
    # Synthetic media (demo content & artwork generation)
    # ------------------------------------------------------------------
    async def synth_demo_track(
        self, dst: str | Path, *, freq: int, duration: int, tempo: int
    ) -> Path:
        """Synthesize a short demo track (sine + tremolo at ``tempo`` BPM).

        Encoded as MP3; when libmp3lame is unavailable the track is re-encoded
        as AAC into a ``.m4a`` sibling and *that* path is returned.
        """
        dst_path = Path(dst)
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        rate = max(0.1, (int(tempo) / 60.0) if tempo else 2.0)
        filter_chain = f"tremolo=f={rate:.2f}:d=0.6,aformat=channel_layouts=stereo"
        args = self._ffmpeg_args(
            self._settings,
            "-y",
            "-f",
            "lavfi",
            "-i",
            f"sine=frequency={int(freq)}:duration={int(duration)}",
            "-af",
            filter_chain,
            "-c:a",
            "libmp3lame",
            "-b:a",
            "128k",
            str(dst_path),
        )
        returncode, _, stderr = await self._run(args)
        if returncode == 0 and dst_path.exists() and dst_path.stat().st_size > 0:
            logger.info(
                "audio.demo_synthesized",
                extra=log_extra(dst=dst_path.name, freq=freq, duration=duration),
            )
            return dst_path
        dst_path.unlink(missing_ok=True)

        # Fallback: AAC in an .m4a container (no libmp3lame in the build).
        m4a_path = dst_path.with_suffix(".m4a")
        m4a_path.unlink(missing_ok=True)
        args = self._ffmpeg_args(
            self._settings,
            "-y",
            "-f",
            "lavfi",
            "-i",
            f"sine=frequency={int(freq)}:duration={int(duration)}",
            "-af",
            filter_chain,
            "-c:a",
            "aac",
            "-b:a",
            "128k",
            str(m4a_path),
        )
        returncode, _, stderr = await self._run(args)
        if returncode == 0 and m4a_path.exists() and m4a_path.stat().st_size > 0:
            logger.warning(
                "audio.demo_synthesized_fallback",
                extra=log_extra(dst=m4a_path.name, mp3_error=stderr[-_STDERR_LOG_LIMIT:].strip()),
            )
            return m4a_path
        m4a_path.unlink(missing_ok=True)
        logger.error(
            "audio.demo_synth_failed",
            extra=log_extra(stderr=stderr[-_STDERR_LOG_LIMIT:].strip()),
        )
        raise PlaybackError("demo track synthesis failed")

    async def synth_artwork(self, dst: str | Path, *, color: str) -> Path:
        """Render a 640×640 cover image (gradients, solid-color fallback)."""
        dst_path = Path(dst)
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        attempts = (
            self._ffmpeg_args(
                self._settings,
                "-y",
                "-f",
                "lavfi",
                "-i",
                f"gradients=s=640x640:c0={color}:c1=0x101418:nb_colors=2",
                "-frames:v",
                "1",
                str(dst_path),
            ),
            self._ffmpeg_args(
                self._settings,
                "-y",
                "-f",
                "lavfi",
                "-i",
                f"color=c={color}:s=640x640",
                "-frames:v",
                "1",
                str(dst_path),
            ),
        )
        for args in attempts:
            returncode, _, _stderr = await self._run(args)
            if returncode == 0 and dst_path.exists() and dst_path.stat().st_size > 0:
                return dst_path
            dst_path.unlink(missing_ok=True)
        logger.error("audio.artwork_synth_failed", extra=log_extra(color=color))
        raise PlaybackError("artwork synthesis failed")


def _tag(tags: dict[str, Any], name: str) -> str | None:
    """Case-insensitive tag lookup (ffprobe tag casing varies by container)."""
    lowered = {str(key).lower(): value for key, value in tags.items()}
    value = lowered.get(name.lower())
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _duration_seconds(data: dict[str, Any]) -> int:
    """Best-effort duration: format-level first, then audio streams."""
    fmt = data.get("format") if isinstance(data.get("format"), dict) else {}
    for candidate in (fmt.get("duration"), _first_stream_duration(data)):
        if candidate is None:
            continue
        try:
            return int(float(candidate))
        except (TypeError, ValueError):
            continue
    return 0


def _first_stream_duration(data: dict[str, Any]) -> Any:
    streams = data.get("streams")
    if isinstance(streams, list):
        for stream in streams:
            if isinstance(stream, dict) and stream.get("duration") is not None:
                return stream["duration"]
    return None


__all__ = ["DEFAULT_TIMEOUT_SECONDS", "FFmpegToolkit"]

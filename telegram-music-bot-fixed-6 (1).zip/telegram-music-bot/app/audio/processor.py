"""Audio processor — local-file preparation for voice playback and sending.

Bridges the catalog (:class:`app.database.models.music.Track`) with
:class:`FFmpegToolkit` and :class:`app.storage.StorageService`:

* ``prepare_for_voice`` — transcode to the voice-chat opus profile (cached).
* ``prepare_for_send`` — guarantee a local playable file (download if needed).
* ``probe_metadata`` — extract tags as :class:`AudioMetadata`.

Database updates (e.g. persisting a downloaded ``file_path``) are *not* done
here — that is :class:`app.music.service.MusicService`'s responsibility.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import urlparse

import aiohttp

from app.audio.ffmpeg import FFmpegToolkit
from app.cache.redis import CacheProtocol
from app.config import Settings
from app.errors import DownloadError
from app.logging import get_logger, log_extra
from app.music.models import AudioMetadata
from app.security.validation import sanitize_filename, validate_url
from app.storage import StorageService

if TYPE_CHECKING:
    from app.database.models.music import Track

logger = get_logger(__name__)

#: Cache key marking a track as already voice-ready (opus converted).
def _voice_ready_key(track_id: int) -> str:
    return f"vready:{track_id}"

#: Download chunk size (1 MiB).
_CHUNK = 1024 * 1024

#: Optional callable resolving a fresh stream URL for a track (the
#: MusicService's source-backed resolver — see ``resolve_stream_url``).
StreamUrlResolver = Callable[["Track"], Awaitable[str | None]]


class AudioProcessor:
    """File-level audio preparation with a Redis/memory readiness cache."""

    def __init__(
        self,
        settings: Settings,
        ffmpeg: FFmpegToolkit,
        storage: StorageService,
        cache: CacheProtocol,
        stream_resolver: StreamUrlResolver | None = None,
    ) -> None:
        self._settings = settings
        self._ffmpeg = ffmpeg
        self._storage = storage
        self._cache = cache
        # Optional source-backed stream URL resolver (wired to
        # ``MusicService.resolve_stream_url`` by the composition root) so the
        # background pipeline can also handle tracks whose search results
        # carry no direct URL (Audius).
        self._stream_resolver = stream_resolver

    # ------------------------------------------------------------------
    # Read-only dependency accessors (used by AudioPipeline)
    # ------------------------------------------------------------------
    @property
    def storage(self) -> StorageService:
        """The underlying storage service."""
        return self._storage

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def prepare_for_voice(self, track: Track) -> Path:
        """Return a voice-chat-ready opus file for ``track``.

        The conversion result is cached (key ``vready:<track_id>``, 1 h TTL) —
        repeated plays of the same track transcode at most once per hour.
        """
        cache_key = _voice_ready_key(int(track.id))
        dst = self._storage.tmp_dir() / f"voice_{track.id}.opus"
        try:
            cached = await self._cache.get(cache_key)
        except Exception:  # noqa: BLE001 — cache outage must not break playback
            cached = None
        if cached and dst.exists():
            logger.debug(
                "audio.voice_cached", extra=log_extra(track_id=track.id)
            )
            return dst

        src = await self._ensure_local(track)
        await self._ffmpeg.to_voice_format(src, dst)
        try:
            await self._cache.set(cache_key, 1, ttl=3600)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "audio.voice_cache_set_failed",
                extra=log_extra(track_id=track.id, error=str(exc)[:160]),
            )
        logger.info(
            "audio.voice_prepared",
            extra=log_extra(track_id=track.id, path=dst.name),
        )
        return dst

    async def prepare_for_send(self, track: Track) -> Path:
        """Return a local playable file (downloading remote tracks on demand)."""
        return await self._ensure_local(track)

    async def probe_metadata(self, path: str | Path) -> AudioMetadata:
        """Extract tags from a local audio file."""
        return await self._ffmpeg.extract_metadata(path)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _ensure_local(self, track: Track) -> Path:
        """Resolve a local file path for the track, downloading when needed."""
        if track.file_path:
            if self._storage.exists(track.file_path):
                return self._storage.resolve(track.file_path)
            absolute = Path(track.file_path)
            if absolute.is_absolute() and absolute.is_file():
                return absolute  # legacy / externally-managed path
        if not track.stream_url and self._stream_resolver is not None:
            # Tracks whose source maps no direct URL at search time (Audius):
            # ask the owning source's stream endpoint for one.
            try:
                track.stream_url = await self._stream_resolver(track)
            except Exception as exc:  # noqa: BLE001 — resolver is best-effort
                logger.warning(
                    "audio.stream_resolve_failed",
                    extra=log_extra(track_id=track.id, error=str(exc)[:160]),
                )
        if not track.stream_url:
            raise DownloadError(f"Track {track.id} has no local file or stream URL")
        return await self._download(track)

    async def _download(self, track: Track) -> Path:
        """Stream ``track.stream_url`` into the downloads dir (SSRF-checked).

        Raises:
            DownloadError: URL rejected, HTTP failure, or size cap exceeded.
        """
        url = str(track.stream_url)
        try:
            # validate_url performs DNS resolution — keep it off the loop.
            safe_url = await asyncio.to_thread(validate_url, url)
        except Exception as exc:  # noqa: BLE001 — UnsupportedUrlError/ValidationError
            logger.warning(
                "audio.download_url_rejected",
                extra=log_extra(track_id=track.id, error=str(exc)[:160]),
            )
            raise DownloadError(f"Stream URL rejected for track {track.id}") from exc

        extension = Path(urlparse(safe_url).path).suffix.lower()
        if not extension or len(extension) > 6:
            extension = ".mp3"
        target = self._storage.downloads_dir() / self._storage.unique_name(
            sanitize_filename(f"track-{track.id}{extension}")
        )
        max_bytes = self._settings.max_audio_size_mb * 1024 * 1024
        # Generous total budget for large media (mirrors MusicService).
        timeout = aiohttp.ClientTimeout(total=max(60, self._settings.http_timeout * 3))
        received = 0
        try:
            async with aiohttp.ClientSession(timeout=timeout) as http:
                # Redirects are followed manually — every destination is
                # re-validated (SSRF) before the request is made.
                from app.music.sources.url_resolver import follow_redirects_safely

                final_url = await follow_redirects_safely(safe_url, http, timeout)
                async with http.get(final_url, allow_redirects=False) as response:
                    if response.status >= 400:
                        raise DownloadError(
                            f"Download failed with HTTP {response.status}"
                        )
                    content_length = response.headers.get("Content-Length")
                    if content_length and int(content_length) > max_bytes:
                        raise DownloadError(
                            f"Remote file exceeds {self._settings.max_audio_size_mb} MB limit"
                        )
                    with target.open("wb") as handle:
                        async for chunk in response.content.iter_chunked(_CHUNK):
                            received += len(chunk)
                            if received > max_bytes:
                                raise DownloadError(
                                    f"Remote file exceeds "
                                    f"{self._settings.max_audio_size_mb} MB limit"
                                )
                            handle.write(chunk)
        except DownloadError:
            target.unlink(missing_ok=True)
            raise
        except asyncio.TimeoutError as exc:
            target.unlink(missing_ok=True)
            raise DownloadError("Download timed out") from exc
        except aiohttp.ClientError as exc:
            target.unlink(missing_ok=True)
            raise DownloadError(f"Download failed: {type(exc).__name__}") from exc
        except OSError as exc:
            target.unlink(missing_ok=True)
            raise DownloadError("Download failed (storage error)") from exc

        logger.info(
            "audio.downloaded",
            extra=log_extra(track_id=track.id, path=target.name, bytes=received),
        )
        return target


__all__ = ["AudioProcessor"]

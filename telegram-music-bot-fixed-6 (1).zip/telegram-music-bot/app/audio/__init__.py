"""Audio subsystem: ffmpeg toolkit, processor and worker pipeline.

* :class:`FFmpegToolkit` — probe / convert / synth via async subprocesses.
* :class:`AudioProcessor` — voice-ready + send-ready local files.
* :class:`AudioPipeline` — heavy-job orchestration with events (workers).
"""

from __future__ import annotations

from app.audio.ffmpeg import FFmpegToolkit
from app.audio.pipeline import AudioPipeline
from app.audio.processor import AudioProcessor

__all__ = [
    "AudioPipeline",
    "AudioProcessor",
    "FFmpegToolkit",
]

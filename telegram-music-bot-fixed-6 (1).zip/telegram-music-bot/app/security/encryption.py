"""Fernet encryption for secrets at rest (voice-account sessions).

The key comes from ``VOICE_SESSION_ENCRYPTION_KEY``. Encrypted values are
stored as url-safe base64 tokens. Decrypted values live only in memory.
"""

from __future__ import annotations

from cryptography.fernet import Fernet, InvalidToken

from app.errors import ConfigError


def generate_key() -> str:
    """Generate a new Fernet key (used by the setup CLI)."""
    return Fernet.generate_key().decode()


class SessionCipher:
    """Encrypt/decrypt session strings."""

    def __init__(self, key: str) -> None:
        try:
            self._fernet = Fernet(key.encode() if isinstance(key, str) else key)
        except (ValueError, TypeError) as exc:
            raise ConfigError(
                "VOICE_SESSION_ENCRYPTION_KEY is not a valid Fernet key. "
                "Generate one with: python -c \"from cryptography.fernet import Fernet; "
                "print(Fernet.generate_key().decode())\""
            ) from exc

    def encrypt(self, plaintext: str) -> str:
        return self._fernet.encrypt(plaintext.encode()).decode()

    def decrypt(self, token: str) -> str:
        try:
            return self._fernet.decrypt(token.encode()).decode()
        except InvalidToken as exc:
            raise ConfigError(
                "Failed to decrypt stored session — the encryption key has changed "
                "or the data is corrupted."
            ) from exc


_CIPHER: SessionCipher | None = None


def get_cipher(key: str | None) -> SessionCipher | None:
    """Return a cipher for the given key, or None when no key is configured."""
    global _CIPHER
    if key is None:
        return None
    if _CIPHER is None or _CIPHER._fernet is not Fernet(key.encode()):  # noqa: SLF001
        _CIPHER = SessionCipher(key)
    return _CIPHER

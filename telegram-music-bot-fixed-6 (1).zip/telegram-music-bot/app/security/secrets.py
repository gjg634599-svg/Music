"""Secret masking helpers (used by logging and admin displays)."""

from __future__ import annotations

import re

_TOKEN_RE = re.compile(r"\b\d{6,}:[A-Za-z0-9_-]{20,}\b")
_SESSION_RE = re.compile(r"\b1[A-Za-z0-9_-]{40,}\b")  # Telethon StringSession shape


def mask_secret(value: str | None, visible: int = 3) -> str:
    """Mask a secret, keeping only the first ``visible`` characters."""
    if not value:
        return ""
    if len(value) <= visible:
        return "***"
    return f"{value[:visible]}***"

def mask_phone(phone: str | None) -> str:
    """Mask a phone number: '+989123456789' -> '+98***89'."""
    if not phone:
        return ""
    digits = re.sub(r"\D", "", phone)
    if len(digits) < 6:
        return "***"
    prefix = "+" if phone.startswith("+") else ""
    return f"{prefix}{digits[:2]}***{digits[-2:]}"


def scrub_text(text: str) -> str:
    """Remove token- and session-shaped substrings from free text."""
    text = _TOKEN_RE.sub("***", text)
    text = _SESSION_RE.sub("***", text)
    return text

"""Input validation: URLs (SSRF-safe), callback data, audio uploads, filenames."""

from __future__ import annotations

import ipaddress
import re
import socket
from pathlib import PurePosixPath
from urllib.parse import urlparse

from app.errors import UnsupportedUrlError, ValidationError

#: URL schemes the bot is allowed to fetch.
ALLOWED_URL_SCHEMES = {"https", "http"}

#: Maximum accepted URL length.
MAX_URL_LENGTH = 1024

#: Direct-audio URL content types / extensions considered playable.
AUDIO_EXTENSIONS = {".mp3", ".m4a", ".aac", ".flac", ".wav", ".ogg", ".opus", ".wma"}

#: Callback data constraints (Telegram hard limit is 64 bytes).
_CALLBACK_RE = re.compile(r"^[a-z0-9_]+(?::[A-Za-z0-9_\-\.]{1,48}){0,4}$")
MAX_CALLBACK_LENGTH = 64

#: Audio upload constraints.
ALLOWED_AUDIO_MIME = {
    "audio/mpeg", "audio/mp3", "audio/mp4", "audio/aac", "audio/ogg",
    "audio/opus", "audio/opus", "audio/x-wav", "audio/wav", "audio/flac",
    "audio/x-flac", "audio/ogg; codecs=opus", "audio/webm", "audio/x-m4a", "audio/m4a",
}
ALLOWED_AUDIO_EXTENSIONS = {".mp3", ".m4a", ".aac", ".flac", ".wav", ".ogg", ".opus", ".weba"}

_PRIVATE_NETWORKS = (
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fe80::/10"),
    ipaddress.ip_network("fc00::/7"),
)


def validate_url(raw_url: str, *, allow_private: bool = False) -> str:
    """Validate a user-supplied URL and return the normalized form.

    Raises :class:`UnsupportedUrlError` for invalid, unsupported or dangerous
    schemes; raises :class:`ValidationError` when the host resolves to a
    private address (SSRF protection) unless ``allow_private`` is True.
    """
    url = (raw_url or "").strip()
    if not url:
        raise UnsupportedUrlError("Empty URL")
    if len(url) > MAX_URL_LENGTH:
        raise UnsupportedUrlError("URL too long")

    try:
        parsed = urlparse(url)
    except ValueError as exc:
        raise UnsupportedUrlError("Malformed URL") from exc

    if parsed.scheme.lower() not in ALLOWED_URL_SCHEMES:
        raise UnsupportedUrlError(f"Scheme {parsed.scheme!r} not allowed")
    if not parsed.hostname:
        raise UnsupportedUrlError("URL has no hostname")
    if parsed.username or parsed.password:
        raise UnsupportedUrlError("Credentials in URL are not allowed")

    hostname = parsed.hostname.lower()
    if not allow_private:
        _assert_public_host(hostname)

    return url


def _assert_public_host(hostname: str) -> None:
    """Reject hostnames that resolve to private/loopback addresses (SSRF)."""
    if hostname in {"localhost", "localhost.localdomain", "ip6-localhost"}:
        raise ValidationError("Local addresses are not allowed")
    try:
        ip = ipaddress.ip_address(hostname)
    except ValueError:
        ip = None
    if ip is not None:
        if any(ip in network for network in _PRIVATE_NETWORKS) or ip.is_unspecified:
            raise ValidationError("Private addresses are not allowed")
        return
    try:
        infos = socket.getaddrinfo(hostname, None)
    except OSError as exc:
        raise ValidationError("Could not resolve host") from exc
    for info in infos:
        address = ipaddress.ip_address(info[4][0])
        if any(address in network for network in _PRIVATE_NETWORKS) or address.is_unspecified:
            raise ValidationError("Private addresses are not allowed")


def validate_callback_data(data: str | None) -> str:
    """Validate Telegram callback data and return it."""
    if not data:
        raise ValidationError("Empty callback data")
    if len(data) > MAX_CALLBACK_LENGTH:
        raise ValidationError("Callback data too long")
    if not _CALLBACK_RE.match(data):
        raise ValidationError("Malformed callback data")
    return data


def validate_audio_upload(
    *, mime_type: str | None, file_name: str | None, size: int, max_size_bytes: int
) -> None:
    """Validate a user-sent audio file."""
    if size > max_size_bytes:
        raise ValidationError("Audio file too large")
    if size <= 0:
        raise ValidationError("Empty file")

    name = (file_name or "").lower()
    extension = PurePosixPath(name).suffix
    if extension and extension not in ALLOWED_AUDIO_EXTENSIONS:
        raise ValidationError("Unsupported audio format")

    if mime_type:
        mime = mime_type.split(";")[0].strip().lower()
        if mime and mime not in ALLOWED_AUDIO_MIME and not mime.startswith("audio/"):
            raise ValidationError("Unsupported audio type")


def sanitize_filename(name: str, *, max_length: int = 128) -> str:
    """Return a safe, flat filename (no directories, no control chars)."""
    name = (name or "audio").replace("\\", "/").split("/")[-1]
    cleaned = re.sub(r"[^\w\-. ]+", "_", name).strip("._ ")
    if not cleaned:
        cleaned = "audio"
    return cleaned[:max_length]


def is_direct_audio_url(url: str) -> bool:
    """Heuristic: does the URL point directly at an audio file?"""
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    return PurePosixPath(parsed.path.lower()).suffix in AUDIO_EXTENSIONS

"""Playback subsystem: queue, sessions, autoplay, controller and events."""

from __future__ import annotations

from app.playback.autoplay import AutoplayService
from app.playback.controller import PlaybackController
from app.playback.events import EventBus
from app.playback.queue import QueueManager, QueueOwner
from app.playback.session import PlaybackSessionData, SessionManager

__all__ = [
    "AutoplayService",
    "EventBus",
    "PlaybackController",
    "PlaybackSessionData",
    "QueueManager",
    "QueueOwner",
    "SessionManager",
]

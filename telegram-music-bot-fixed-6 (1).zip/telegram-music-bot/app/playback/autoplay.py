"""Autoplay: keep the music going when a queue runs dry.

When the last queued track finishes, the playback controller asks
:class:`AutoplayService` to *refill* the queue from the recommendation
engine. Every pick is logged as an ``autoplay_selected`` analytics event
(and as a :class:`~app.database.models.analytics.RecommendationEvent` when
the analytics repository supports it) so admins can study autoplay quality.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from app.errors import BotError
from app.logging import get_logger, log_extra
from app.playback.queue import QueueManager, QueueOwner

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.recommendation.engine import RecommendationEngine
    from app.recommendation.scoring import ScoredTrack

logger = get_logger(__name__)

#: How many picks a single refill may add at most.
MAX_REFILL_COUNT = 10


@runtime_checkable
class AnalyticsRecorder(Protocol):
    """Duck-typed AnalyticsRepository surface used by autoplay."""

    async def track(
        self,
        event_type: str,
        user_id: int | None = None,
        group_id: int | None = None,
        track_id: int | None = None,
        payload: dict | None = None,
    ) -> None: ...


class AutoplayService:
    """Refills an owner's queue from the recommendation engine."""

    def __init__(
        self,
        engine: RecommendationEngine,
        queue: QueueManager,
        analytics: AnalyticsRecorder,
        *,
        default_enabled: bool = True,
        enabled_check: Callable[[], Awaitable[bool]] | None = None,
    ) -> None:
        self._engine = engine
        self._queue = queue
        self._analytics = analytics
        self._default_enabled = bool(default_enabled)
        self._enabled_check = enabled_check

    async def refill(
        self,
        owner: QueueOwner,
        seed_track_id: int | None,
        count: int = 1,
    ) -> int:
        """Add up to ``count`` recommended tracks to the owner's queue.

        Returns the number of tracks actually added (0 when autoplay is
        disabled or the engine found nothing suitable).
        """
        if not await self._enabled():
            logger.info(
                "autoplay.disabled",
                extra=log_extra(owner=owner.topic()),
            )
            return 0
        count = max(0, min(MAX_REFILL_COUNT, int(count)))
        if count == 0:
            return 0

        try:
            if owner.kind == "group":
                scored = await self._engine.recommend_for_group(
                    owner.id, seed_track_id, limit=count
                )
            else:
                scored = await self._engine.recommend_for_user(
                    owner.id, seed_track_id, limit=count
                )
        except BotError as exc:
            logger.warning(
                "autoplay.recommend_failed",
                extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
            )
            return 0

        added = 0
        for pick in scored[:count]:
            if not await self._add_pick(owner, seed_track_id, pick):
                continue
            added += 1
        logger.info(
            "autoplay.refilled",
            extra=log_extra(
                owner=owner.topic(),
                seed_track_id=seed_track_id,
                requested=count,
                added=added,
            ),
        )
        return added

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _add_pick(
        self, owner: QueueOwner, seed_track_id: int | None, pick: ScoredTrack
    ) -> bool:
        """Queue one recommendation and record why it was chosen."""
        try:
            await self._queue.add(owner, pick.track_id, added_by=None)
        except BotError as exc:
            logger.warning(
                "autoplay.enqueue_failed",
                extra=log_extra(
                    owner=owner.topic(),
                    track_id=pick.track_id,
                    error=str(exc)[:160],
                ),
            )
            return False
        payload = {
            "score": round(pick.score, 4),
            "reason": pick.reason,
            "seed_track_id": seed_track_id,
        }
        await self._record(owner, seed_track_id, pick, payload)
        return True

    async def _record(
        self,
        owner: QueueOwner,
        seed_track_id: int | None,
        pick: ScoredTrack,
        payload: dict,
    ) -> None:
        """Fire analytics + recommendation feedback records (best effort)."""
        user_id = owner.id if owner.kind == "user" else None
        group_id = owner.id if owner.kind == "group" else None
        try:
            await self._analytics.track(
                "autoplay_selected",
                user_id=user_id,
                group_id=group_id,
                track_id=pick.track_id,
                payload=payload,
            )
        except Exception as exc:  # noqa: BLE001 — analytics must not break playback
            logger.debug(
                "autoplay.analytics_failed",
                extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
            )
        # RecommendationEvent feedback loop — only when the analytics
        # repository exposes the dedicated writer.
        log_recommendation = getattr(self._analytics, "log_recommendation", None)
        if log_recommendation is None:
            return
        try:
            await log_recommendation(
                user_id=user_id,
                group_id=group_id,
                seed_track_id=seed_track_id,
                selected_track_id=pick.track_id,
                score=pick.score,
                reason=pick.reason,
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "autoplay.recommendation_event_failed",
                extra=log_extra(owner=owner.topic(), error=str(exc)[:160]),
            )

    async def _enabled(self) -> bool:
        """Resolve the autoplay flag: injected check first, default second."""
        if self._enabled_check is None:
            return self._default_enabled
        try:
            return bool(await self._enabled_check())
        except Exception as exc:  # noqa: BLE001 — flag failures fall back
            logger.warning(
                "autoplay.enabled_check_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
            return self._default_enabled


__all__ = ["AnalyticsRecorder", "AutoplayService"]

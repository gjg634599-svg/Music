"""Owner-addressed queue management on top of the queue repository.

:class:`QueueManager` wraps :class:`QueueRepository` (persistence) and a
duck-typed track repository (hydration) and publishes ``queue_empty``
events on the shared :class:`~app.playback.events.EventBus` whenever an
owner's queue runs dry.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from app.database.repositories.playback import QueueRepository
from app.errors import TrackNotFoundError, ValidationError
from app.logging import get_logger, log_extra
from app.playback.events import EventBus

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models.music import Track
    from app.database.models.playback import QueueItem

logger = get_logger(__name__)

#: Allowed owner kinds (mirrors the queue_items.owner_type column).
OWNER_KINDS = ("user", "group")


@runtime_checkable
class TrackProvider(Protocol):
    """Duck-typed TrackRepository surface used for hydration."""

    async def get_by_id(self, track_id: int) -> Track | None: ...


@dataclass(frozen=True, slots=True)
class QueueOwner:
    """Identifies whose queue is being manipulated (a user or a group)."""

    kind: str  # 'user' | 'group'
    id: int  # telegram id

    def __post_init__(self) -> None:
        if self.kind not in OWNER_KINDS:
            raise ValidationError(
                f"QueueOwner.kind must be one of {OWNER_KINDS}, got {self.kind!r}"
            )

    def topic(self) -> str:
        """Event-bus topic suffix, e.g. ``user:123``."""
        return f"{self.kind}:{self.id}"


class QueueManager:
    """High-level queue operations for a :class:`QueueOwner`.

    All positions are 1-based; ``front=True`` inserts at the head of the
    queue by shifting existing items via the repository.
    """

    def __init__(
        self,
        queue: QueueRepository,
        tracks: TrackProvider | None = None,
        events: EventBus | None = None,
    ) -> None:
        self._queue = queue
        self._tracks = tracks
        self._events = events or EventBus()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def add(
        self,
        owner: QueueOwner,
        track_id: int,
        added_by: int | None = None,
        *,
        front: bool = False,
    ) -> int:
        """Append (or prepend) a track; returns the resulting queue size."""
        await self._ensure_track(track_id)
        if front:
            await self._queue.shift_positions(
                owner.kind, owner.id, from_position=1, delta=1
            )
            item = await self._queue.add(
                owner.kind, owner.id, track_id, position=1, added_by=added_by
            )
        else:
            item = await self._queue.add(
                owner.kind, owner.id, track_id, added_by=added_by
            )
        size = await self.size(owner)
        logger.info(
            "queue.added",
            extra=log_extra(
                owner=owner.topic(),
                track_id=track_id,
                item_id=item.id,
                position=item.position,
                size=size,
            ),
        )
        return size

    async def get_queue(self, owner: QueueOwner) -> list[QueueItem]:
        """Return the queued items (position order) with hydrated tracks."""
        items = await self._queue.list_queue(owner.kind, owner.id)
        return [await self._hydrate(item) for item in items]

    async def pop_next(self, owner: QueueOwner) -> QueueItem | None:
        """Take the next item (marks it played) or ``None`` when empty.

        Publishes ``queue_empty:<owner>`` when the queue runs dry — either
        because the pop drained the last item or because the queue was
        already empty (e.g. right after a clear).
        """
        item = await self._queue.pop_next(owner.kind, owner.id)
        if item is not None:
            item = await self._hydrate(item)
        if await self.size(owner) == 0:
            await self._events.publish(f"queue_empty:{owner.topic()}")
        if item is not None:
            logger.info(
                "queue.popped",
                extra=log_extra(owner=owner.topic(), track_id=item.track_id),
            )
        return item

    async def peek_next(self, owner: QueueOwner) -> QueueItem | None:
        """Return the next queued item without consuming it."""
        item = await self._queue.peek_next(owner.kind, owner.id)
        if item is None:
            return None
        return await self._hydrate(item)

    async def clear(self, owner: QueueOwner) -> int:
        """Remove all queued items; returns the number deleted."""
        deleted = await self._queue.clear(owner.kind, owner.id)
        logger.info(
            "queue.cleared",
            extra=log_extra(owner=owner.topic(), deleted=deleted),
        )
        return deleted

    async def shuffle(self, owner: QueueOwner) -> int:
        """Shuffle the queued items; returns the (unchanged) queue size."""
        size = await self._queue.shuffle(owner.kind, owner.id)
        logger.info(
            "queue.shuffled",
            extra=log_extra(owner=owner.topic(), size=size),
        )
        return size

    async def remove(self, owner: QueueOwner, item_id: int) -> bool:
        """Remove one queued item; True when it existed."""
        removed = await self._queue.remove(owner.kind, owner.id, int(item_id))
        if removed:
            logger.info(
                "queue.removed",
                extra=log_extra(owner=owner.topic(), item_id=item_id),
            )
        return removed

    async def size(self, owner: QueueOwner) -> int:
        """Number of queued (not yet played) items."""
        return await self._queue.size(owner.kind, owner.id)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _ensure_track(self, track_id: int) -> None:
        """Reject unknown tracks before they reach the database."""
        if self._tracks is None:
            return
        try:
            track = await self._tracks.get_by_id(int(track_id))
        except Exception as exc:  # noqa: BLE001 — duck-typed repo
            logger.warning(
                "queue.track_check_failed",
                extra=log_extra(track_id=track_id, error=str(exc)[:160]),
            )
            return
        if track is None:
            raise TrackNotFoundError(f"track {track_id} not found")

    async def _hydrate(self, item: QueueItem) -> QueueItem:
        """Fill ``item.track`` when the relationship was not loaded."""
        if getattr(item, "track", None) is not None or self._tracks is None:
            return item
        try:
            track = await self._tracks.get_by_id(item.track_id)
        except Exception as exc:  # noqa: BLE001 — hydration is best effort
            logger.debug(
                "queue.hydrate_failed",
                extra=log_extra(track_id=item.track_id, error=str(exc)[:160]),
            )
            return item
        if track is not None:
            try:
                item.track = track
            except Exception:  # noqa: BLE001 — detached instance
                pass
        return item


__all__ = ["QueueManager", "QueueOwner", "TrackProvider"]

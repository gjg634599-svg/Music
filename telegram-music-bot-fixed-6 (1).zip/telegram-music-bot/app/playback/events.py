"""Async event bus shared by playback, voice and worker subsystems.

The bus decouples producers (playback timers, voice transport events) from
consumers (PlaybackController) and keeps the four architectural layers
loosely coupled.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from collections.abc import Awaitable, Callable
from typing import Any

from app.logging import get_logger

logger = get_logger(__name__)

Handler = Callable[..., Awaitable[Any]]


class Event:
    """A named event with a payload."""

    __slots__ = ("name", "data")

    def __init__(self, name: str, **data: Any) -> None:
        self.name = name
        self.data = data

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Event {self.name} {self.data}>"


class EventBus:
    """Topic-based async publish/subscribe.

    Topics used in this project:
      - ``track_end:<owner_kind>:<owner_id>``   a track finished playing
      - ``track_start:<owner_kind>:<owner_id>`` a track started playing
      - ``queue_empty:<owner_kind>:<owner_id>`` the queue ran dry
      - ``voice_failure:<group_id>``            voice account failed mid-playback
      - ``broadcast_update``                    broadcast progress ticks
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[Handler]] = defaultdict(list)

    def subscribe(self, topic: str, handler: Handler) -> None:
        """Register a coroutine handler for a topic (or topic prefix)."""
        self._handlers[topic].append(handler)

    def unsubscribe(self, topic: str, handler: Handler) -> None:
        try:
            self._handlers[topic].remove(handler)
        except (KeyError, ValueError):
            pass

    async def publish(self, name: str, **data: Any) -> None:
        """Dispatch an event to matching handlers.

        Handler failures are logged and never propagate — one broken
        subscriber must not break playback.
        """
        for topic, handlers in self._handlers.items():
            if name == topic or name.startswith(topic):
                for handler in handlers:
                    try:
                        result = handler(Event(name, **data))
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as exc:  # noqa: BLE001
                        logger.error(
                            "events.handler_failed",
                            extra={"topic": topic, "error": str(exc)[:200]},
                        )

    async def wait_for(self, name: str, timeout: float | None = None) -> Event:
        """Await a single event occurrence (used in tests / failover)."""
        loop = asyncio.get_running_loop()
        future: asyncio.Future[Event] = loop.create_future()

        def _on_event(event: Event) -> None:
            if not future.done():
                future.set_result(event)

        self.subscribe(name, _on_event)
        try:
            return await asyncio.wait_for(future, timeout)
        finally:
            self.unsubscribe(name, _on_event)

"""Typed application configuration.

All runtime configuration is loaded from environment variables (optionally a
`.env` file). Missing required values produce a clear, actionable error at
startup — the application never silently continues with invalid config.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

try:  # pragma: no cover - optional dependency
    from dotenv import load_dotenv  # type: ignore[import-untyped]

    _HAS_DOTENV = True
except ImportError:  # pragma: no cover
    _HAS_DOTENV = False


class ConfigError(Exception):
    """Raised when configuration is invalid or incomplete."""


class Role(str, Enum):
    """Process role (bot / worker / all)."""

    BOT = "bot"
    WORKER = "worker"
    ALL = "all"


@dataclass(frozen=True, slots=True)
class RateLimits:
    """User-facing rate limits (requests per minute)."""

    search_per_minute: int = 10
    heavy_per_minute: int = 3
    commands_per_minute: int = 30
    group_per_minute: int = 20


@dataclass(frozen=True, slots=True)
class BroadcastSettings:
    """Broadcast engine tuning."""

    rate_per_second: float = 25.0
    worker_concurrency: int = 2
    max_retries: int = 3


@dataclass(frozen=True, slots=True)
class VoiceSettings:
    """Voice engine tuning."""

    max_sessions_per_account: int = 5
    health_check_interval: int = 60
    idle_timeout_minutes: int = 5
    encryption_key: str | None = None
    # Private-group automatic joining (invite-link workflow).
    #: When enabled, a voice account that is not yet a member of the group
    #: it was asked to play in may join via a bot-exported invite link.
    auto_join_enabled: bool = True
    #: Cooldown after a failed join attempt for the same group (seconds) —
    #: prevents endless retries and respects Telegram flood limits.
    join_cooldown_seconds: int = 300
    #: How long an exported invite link is reused before re-export (seconds).
    invite_link_cache_seconds: int = 600
    #: How long a positive membership check is trusted before re-checking.
    membership_cache_seconds: int = 600


@dataclass(frozen=True, slots=True)
class CacheRetentionSettings:
    """Completed download-cache retention policy.

    ``retention_hours``: how long a fully-downloaded cached track stays on
    disk after its last use (0 disables cleanup entirely).
    ``cleanup_interval_minutes``: how often the sweeper runs (0 disables
    the periodic job; manual runs remain possible).
    """

    retention_hours: int = 72
    cleanup_interval_minutes: int = 60


@dataclass(frozen=True, slots=True)
class Settings:
    """Fully typed application settings."""

    # Telegram
    bot_token: str = ""
    telegram_api_id: int | None = None
    telegram_api_hash: str | None = None

    # Storage
    database_url: str = "sqlite+aiosqlite:///./storage/musicbot.db"
    redis_url: str | None = None
    storage_dir: Path = field(default_factory=lambda: Path("storage"))

    # Administration
    admin_ids: tuple[int, ...] = ()

    # Feature defaults
    autoplay_enabled: bool = True
    group_silent_mode: bool = True
    default_group_queue_limit: int = 50
    maintenance_mode: bool = False
    #: Best-effort deletion of recognized group command messages after
    #: they are handled (never in private chats; never plain messages).
    group_command_auto_delete: bool = True

    # Audio
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    #: Cap for files that must be re-uploaded through the Bot API
    #: (personal playback / direct-URL tracks sent as audio) — Telegram's
    #: upload limit for bots is 50 MB, so this stays <= 49.
    max_audio_size_mb: int = 45
    #: Cap for VOICE-CHAT streaming downloads (played locally through
    #: ffmpeg/PyTgCalls, never re-uploaded) — bounded by disk only, so it
    #: can safely exceed the Bot API limit. Long DJ mixes commonly exceed
    #: 45 MiB, which used to abort group playback mid-flow.
    voice_max_audio_size_mb: int = 200
    http_timeout: int = 20
    #: Seconds between live progress edits of the group Now Playing
    #: message (0 disables the live progress ticker).
    progress_edit_interval: int = 15

    # Music sources
    jamendo_client_id: str | None = None

    # Sub-configs
    rate_limits: RateLimits = field(default_factory=RateLimits)
    broadcast: BroadcastSettings = field(default_factory=BroadcastSettings)
    voice: VoiceSettings = field(default_factory=VoiceSettings)
    cache_retention: CacheRetentionSettings = field(
        default_factory=CacheRetentionSettings
    )

    # Misc
    log_level: str = "INFO"
    log_format: str = "text"
    health_port: int = 8080
    app_root: Path = field(default_factory=lambda: Path.cwd())

    # ------------------------------------------------------------------
    # Derived helpers
    # ------------------------------------------------------------------
    @property
    def redis_enabled(self) -> bool:
        return bool(self.redis_url)

    @property
    def voice_enabled(self) -> bool:
        """Voice engine requires MTProto credentials and an encryption key."""
        return (
            self.telegram_api_id is not None
            and bool(self.telegram_api_hash)
            and bool(self.voice.encryption_key)
        )

    @property
    def jamendo_enabled(self) -> bool:
        return bool(self.jamendo_client_id)

    def storage_path(self, *parts: str) -> Path:
        """Resolve a path inside the storage directory (created on demand)."""
        path = self.storage_dir.joinpath(*parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def is_admin(self, telegram_id: int) -> bool:
        return telegram_id in self.admin_ids


# ----------------------------------------------------------------------
# Parsing helpers
# ----------------------------------------------------------------------
def _parse_int_list(raw: str) -> tuple[int, ...]:
    values: list[int] = []
    for chunk in raw.replace(";", ",").split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        try:
            values.append(int(chunk))
        except ValueError as exc:
            raise ConfigError(f"ADMIN_IDS contains a non-numeric value: {chunk!r}") from exc
    return tuple(values)


def _parse_int(raw: str, name: str, default: int | None = None) -> int | None:
    if raw == "":
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} must be an integer, got {raw!r}") from exc


def _parse_bool(raw: str, name: str, default: bool) -> bool:
    if raw == "":
        return default
    normalized = raw.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ConfigError(f"{name} must be a boolean, got {raw!r}")


def _parse_int_or_default(raw: str, default: int) -> int:
    """Parse an int, treating empty/invalid as *default* but keeping 0.

    Unlike ``_parse_int(...) or default``, an explicit ``0`` stays ``0`` —
    several settings use 0 as a meaningful "disabled" value.
    """
    text = (raw or "").strip()
    if text == "":
        return default
    try:
        return int(text)
    except ValueError:
        return default


def load_settings(env_file: str | Path | None = None) -> Settings:
    """Build typed settings from the environment (and optional .env file)."""
    if _HAS_DOTENV:
        if env_file is None:
            env_file = Path(".env")
            if not env_file.exists():
                env_file = None
        if env_file is not None:
            load_dotenv(env_file)

    get = os.getenv

    settings = Settings(
        bot_token=(get("BOT_TOKEN") or "").strip(),
        telegram_api_id=_parse_int(get("TELEGRAM_API_ID", ""), "TELEGRAM_API_ID"),
        telegram_api_hash=(get("TELEGRAM_API_HASH") or "").strip() or None,
        database_url=(get("DATABASE_URL") or "").strip()
        or "sqlite+aiosqlite:///./storage/musicbot.db",
        redis_url=(get("REDIS_URL") or "").strip() or None,
        storage_dir=Path((get("STORAGE_DIR") or "storage").strip()),
        admin_ids=_parse_int_list(get("ADMIN_IDS", "")),
        autoplay_enabled=_parse_bool(get("AUTOPLAY_ENABLED", ""), "AUTOPLAY_ENABLED", True),
        group_silent_mode=_parse_bool(get("GROUP_SILENT_MODE", ""), "GROUP_SILENT_MODE", True),
        default_group_queue_limit=_parse_int(
            get("DEFAULT_GROUP_QUEUE_LIMIT", ""),
            "DEFAULT_GROUP_QUEUE_LIMIT",
            50,
        )
        or 50,
        maintenance_mode=_parse_bool(get("MAINTENANCE_MODE", ""), "MAINTENANCE_MODE", False),
        group_command_auto_delete=_parse_bool(
            get("GROUP_COMMAND_AUTO_DELETE", ""), "GROUP_COMMAND_AUTO_DELETE", True
        ),
        ffmpeg_path=(get("FFMPEG_PATH") or "ffmpeg").strip(),
        ffprobe_path=(get("FFPROBE_PATH") or "ffprobe").strip(),
        max_audio_size_mb=_parse_int(get("MAX_AUDIO_SIZE_MB", ""), "MAX_AUDIO_SIZE_MB", 45) or 45,
        voice_max_audio_size_mb=_parse_int(
            get("VOICE_MAX_AUDIO_SIZE_MB", ""), "VOICE_MAX_AUDIO_SIZE_MB", 200
        )
        or 200,
        http_timeout=_parse_int(get("HTTP_TIMEOUT", ""), "HTTP_TIMEOUT", 20) or 20,
        progress_edit_interval=_parse_int_or_default(
            get("PROGRESS_EDIT_INTERVAL", ""), 15
        ),
        jamendo_client_id=(get("JAMENDO_CLIENT_ID") or "").strip() or None,
        rate_limits=RateLimits(
            search_per_minute=_parse_int(
                get("RATE_LIMIT_SEARCH_PER_MINUTE", ""), "RATE_LIMIT_SEARCH_PER_MINUTE", 10
            )
            or 10,
            heavy_per_minute=_parse_int(
                get("RATE_LIMIT_HEAVY_PER_MINUTE", ""), "RATE_LIMIT_HEAVY_PER_MINUTE", 3
            )
            or 3,
            commands_per_minute=_parse_int(
                get("RATE_LIMIT_COMMANDS_PER_MINUTE", ""), "RATE_LIMIT_COMMANDS_PER_MINUTE", 30
            )
            or 30,
            group_per_minute=_parse_int(
                get("RATE_LIMIT_GROUP_PER_MINUTE", ""), "RATE_LIMIT_GROUP_PER_MINUTE", 20
            )
            or 20,
        ),
        broadcast=BroadcastSettings(
            rate_per_second=float(
                _parse_int(get("BROADCAST_RATE_PER_SECOND", ""), "BROADCAST_RATE_PER_SECOND", 25)
                or 25
            ),
            worker_concurrency=_parse_int(
                get("BROADCAST_WORKER_CONCURRENCY", ""), "BROADCAST_WORKER_CONCURRENCY", 2
            )
            or 2,
            max_retries=_parse_int(
                get("BROADCAST_MAX_RETRIES", ""), "BROADCAST_MAX_RETRIES", 3
            )
            or 3,
        ),
        voice=VoiceSettings(
            max_sessions_per_account=_parse_int(
                get("MAX_VOICE_SESSIONS_PER_ACCOUNT", ""),
                "MAX_VOICE_SESSIONS_PER_ACCOUNT",
                5,
            )
            or 5,
            health_check_interval=_parse_int(
                get("VOICE_HEALTH_CHECK_INTERVAL", ""), "VOICE_HEALTH_CHECK_INTERVAL", 60
            )
            or 60,
            idle_timeout_minutes=_parse_int(
                get("VOICE_IDLE_TIMEOUT_MINUTES", ""), "VOICE_IDLE_TIMEOUT_MINUTES", 5
            )
            or 5,
            encryption_key=(get("VOICE_SESSION_ENCRYPTION_KEY") or "").strip() or None,
            auto_join_enabled=_parse_bool(
                get("VOICE_AUTO_JOIN_ENABLED", ""), "VOICE_AUTO_JOIN_ENABLED", True
            ),
            join_cooldown_seconds=_parse_int(
                get("VOICE_JOIN_COOLDOWN_SECONDS", ""),
                "VOICE_JOIN_COOLDOWN_SECONDS",
                300,
            )
            or 300,
            invite_link_cache_seconds=_parse_int(
                get("VOICE_INVITE_LINK_CACHE_SECONDS", ""),
                "VOICE_INVITE_LINK_CACHE_SECONDS",
                600,
            )
            or 600,
            membership_cache_seconds=_parse_int(
                get("VOICE_MEMBERSHIP_CACHE_SECONDS", ""),
                "VOICE_MEMBERSHIP_CACHE_SECONDS",
                600,
            )
            or 600,
        ),
        cache_retention=CacheRetentionSettings(
            retention_hours=_parse_int(
                get("DOWNLOAD_CACHE_RETENTION_HOURS", ""),
                "DOWNLOAD_CACHE_RETENTION_HOURS",
                72,
            )
            or 72,
            cleanup_interval_minutes=_parse_int(
                get("DOWNLOAD_CACHE_CLEANUP_INTERVAL_MINUTES", ""),
                "DOWNLOAD_CACHE_CLEANUP_INTERVAL_MINUTES",
                60,
            )
            or 60,
        ),
        log_level=(get("LOG_LEVEL") or "INFO").strip().upper(),
        log_format=(get("LOG_FORMAT") or "text").strip().lower(),
        health_port=_parse_int(get("HEALTH_PORT", ""), "HEALTH_PORT", 8080) or 0,
    )

    validate_settings(settings)
    return settings


def validate_settings(settings: Settings) -> None:
    """Fail fast on invalid or incomplete configuration."""
    if not settings.bot_token:
        raise ConfigError(
            "BOT_TOKEN is required. Create a bot with @BotFather and set BOT_TOKEN "
            "in your environment or .env file."
        )
    if settings.bot_token.count(":") < 1 or len(settings.bot_token) < 20:
        raise ConfigError("BOT_TOKEN does not look like a valid Telegram bot token.")

    if settings.telegram_api_id is not None and not settings.telegram_api_hash:
        raise ConfigError("TELEGRAM_API_HASH is required when TELEGRAM_API_ID is set.")
    if settings.telegram_api_hash and settings.telegram_api_id is None:
        raise ConfigError("TELEGRAM_API_ID is required when TELEGRAM_API_HASH is set.")

    if not settings.database_url.startswith(
        ("postgresql+asyncpg://", "sqlite+aiosqlite://")
    ):
        raise ConfigError(
            "DATABASE_URL must be a postgresql+asyncpg:// or sqlite+aiosqlite:// URL."
        )
    if settings.database_url.startswith("sqlite") and "aiosqlite" not in settings.database_url:
        raise ConfigError("SQLite DATABASE_URL must use the sqlite+aiosqlite:// scheme.")

    if settings.health_port < 0 or settings.health_port > 65535:
        raise ConfigError("HEALTH_PORT must be between 0 and 65535 (0 disables the endpoint).")
    if settings.broadcast.rate_per_second <= 0 or settings.broadcast.rate_per_second > 30:
        raise ConfigError("BROADCAST_RATE_PER_SECOND must be within (0, 30].")
    if settings.max_audio_size_mb > 49:
        raise ConfigError("MAX_AUDIO_SIZE_MB cannot exceed 49 (Telegram upload limit is 50 MB).")
    if settings.voice_max_audio_size_mb < 1:
        raise ConfigError("VOICE_MAX_AUDIO_SIZE_MB must be at least 1.")
    if settings.voice_max_audio_size_mb > 2000:
        raise ConfigError(
            "VOICE_MAX_AUDIO_SIZE_MB cannot exceed 2000 (keep disk usage bounded)."
        )
    if settings.cache_retention.retention_hours < 0:
        raise ConfigError("DOWNLOAD_CACHE_RETENTION_HOURS cannot be negative.")
    if settings.cache_retention.cleanup_interval_minutes < 0:
        raise ConfigError("DOWNLOAD_CACHE_CLEANUP_INTERVAL_MINUTES cannot be negative.")
    if settings.progress_edit_interval < 0:
        raise ConfigError("PROGRESS_EDIT_INTERVAL cannot be negative.")

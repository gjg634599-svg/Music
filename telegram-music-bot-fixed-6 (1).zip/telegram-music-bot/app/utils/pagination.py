"""Pagination helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, Sequence, TypeVar

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class Page(Generic[T]):
    """One page of items."""

    items: Sequence[T]
    page: int
    total_pages: int
    total_items: int

    @property
    def has_prev(self) -> bool:
        return self.page > 1

    @property
    def has_next(self) -> bool:
        return self.page < self.total_pages

    @property
    def prev_page(self) -> int | None:
        return self.page - 1 if self.has_prev else None

    @property
    def next_page(self) -> int | None:
        return self.page + 1 if self.has_next else None


def paginate(items: Sequence[T], page: int, per_page: int) -> Page[T]:
    """Paginate an in-memory sequence (1-based pages)."""
    total = len(items)
    total_pages = max(1, (total + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start = (page - 1) * per_page
    return Page(
        items=items[start : start + per_page],
        page=page,
        total_pages=total_pages,
        total_items=total,
    )

"""Telegram-specific utilities (edit-or-send, command extraction, chat checks)."""

from __future__ import annotations

import html
from typing import Any

from app.errors import BotError
from app.logging import get_logger
from app.utils.formatting import chunk_text

logger = get_logger(__name__)


def is_private(chat_type: str | None) -> bool:
    return chat_type == "private"


def is_group(chat_type: str | None) -> bool:
    return chat_type in {"group", "supergroup"}


def command_target(command_text: str, bot_username: str | None) -> str | None:
    """Extract the command name from a BOT_COMMAND entity text.

    '/play@MyBot args' -> 'play'; '/play' -> 'play'.
    Returns None when the command is addressed to a different bot.
    """
    text = command_text.split()[0] if command_text.strip() else ""
    if not text.startswith("/"):
        return None
    body = text[1:]
    if "@" in body:
        name, _, mention = body.partition("@")
        if bot_username and mention.lower() != bot_username.lower():
            return None
        body = name
    return body or None


def parse_command_message(text: str) -> tuple[str, str] | None:
    """Split '/play Believer' into ('play', 'Believer')."""
    if not text or not text.startswith("/"):
        return None
    parts = text.split(maxsplit=1)
    if not parts:
        return None
    command = parts[0].lstrip("/").split("@", 1)[0]
    args = parts[1].strip() if len(parts) > 1 else ""
    if not command:
        return None
    return command, args


def display_name(message_from: Any) -> str:
    """Best-effort display name of a Telegram user."""
    first = getattr(message_from, "first_name", None) or ""
    last = getattr(message_from, "last_name", None) or ""
    name = f"{first} {last}".strip()
    return name or (getattr(message_from, "username", None) or "there")


def mention_html(message_from: Any) -> str:
    """An HTML mention link for a user (or their name)."""
    tg_id = getattr(message_from, "id", None)
    name = html.escape(display_name(message_from))
    if tg_id:
        return f'<a href="tg://user?id={tg_id}">{name}</a>'
    return name


async def safe_edit(message: Any, text: str, reply_markup: Any = None) -> Any:
    """Edit a message, falling back gracefully when editing is impossible."""
    try:
        return await message.edit_text(text, reply_markup=reply_markup)
    except Exception as exc:  # noqa: BLE001 — Telegram raises many edit errors
        logger.debug("telegram.edit_failed", extra={"error": str(exc)[:120]})
        return None


async def safe_answer(callback: Any, text: str | None = None, show_alert: bool = False) -> None:
    """Answer a callback query without crashing."""
    try:
        await callback.answer(text=text, show_alert=show_alert)
    except Exception as exc:  # noqa: BLE001
        logger.debug("telegram.answer_failed", extra={"error": str(exc)[:120]})


async def edit_or_send(
    message: Any, text: str, reply_markup: Any = None, *, use_edit: bool = True
) -> Any:
    """Edit in place when possible, otherwise send a new message."""
    if use_edit:
        edited = await safe_edit(message, text, reply_markup)
        if edited is not None:
            return edited
    chunks = chunk_text(text)
    last = None
    for chunk in chunks:
        last = await message.answer(chunk, reply_markup=reply_markup if chunk is chunks[-1] else None)
    return last


def user_friendly_error(exc: Exception) -> str:
    """Map an exception to a short user-facing message."""
    if isinstance(exc, BotError):
        return exc.user_message
    return "❌ Something went wrong. Please try again later."

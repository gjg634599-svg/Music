"""Time helpers."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta


def utcnow() -> datetime:
    return datetime.now(tz=UTC)


def human_delta(dt: datetime | None) -> str:
    """'3 seconds ago', '2 hours ago', '5 days ago'..."""
    if dt is None:
        return "never"
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    delta = utcnow() - dt
    seconds = delta.total_seconds()
    if seconds < 5:
        return "just now"
    if seconds < 60:
        return f"{int(seconds)} seconds ago"
    if seconds < 3600:
        return f"{int(seconds // 60)} minutes ago"
    if seconds < 86400:
        hours = int(seconds // 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    days = int(seconds // 86400)
    return f"{days} day{'s' if days != 1 else ''} ago"


def minutes_ago(minutes: int) -> datetime:
    return utcnow() - timedelta(minutes=minutes)

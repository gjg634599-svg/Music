"""Telegram bot factory: Bot instance + Dispatcher with middlewares.

Business wiring lives in :mod:`app.application`; this module only knows how
to assemble the aiogram objects.
"""

from __future__ import annotations

from typing import Any

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.base import BaseStorage
from aiogram.fsm.storage.memory import MemoryStorage

from app.bot.middleware.auth import AdminGuardMiddleware, MaintenanceMiddleware
from app.bot.middleware.command_cleanup import CommandAutoDeleteMiddleware
from app.bot.middleware.group_silent import GroupSilentMiddleware
from app.bot.middleware.logging import LoggingMiddleware
from app.bot.middleware.rate_limit import (
    CallbackRateLimitMiddleware,
    RateLimitMiddleware,
)
from app.bot.router import build_router
from app.logging import get_logger

logger = get_logger(__name__)


def build_bot(token: str) -> Bot:
    """Create the Bot instance with project-wide defaults."""
    return Bot(
        token=token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )


def create_dispatcher(fsm_storage: BaseStorage | None = None) -> Dispatcher:
    """Create the Dispatcher with all middlewares and routers registered."""
    dispatcher = Dispatcher(storage=fsm_storage or MemoryStorage())

    # --- Routers (handler modules) -------------------------------------
    dispatcher.include_router(build_router())

    # --- Middlewares -----------------------------------------------------
    # Update-level logging first.
    dispatcher.message.outer_middleware(LoggingMiddleware())
    dispatcher.callback_query.outer_middleware(LoggingMiddleware())

    # THE silent-group gate: in groups only explicit commands pass.
    # Must run before any handler filter can accidentally react to text.
    dispatcher.message.outer_middleware(GroupSilentMiddleware())

    # Maintenance mode + blocked users (admins bypass maintenance).
    dispatcher.message.outer_middleware(MaintenanceMiddleware())
    dispatcher.callback_query.outer_middleware(MaintenanceMiddleware())

    # Admin-only callback namespace guard (adm:*).
    dispatcher.callback_query.outer_middleware(AdminGuardMiddleware())

    # Rate limiting (search / heavy / commands) — after the gates so
    # dropped updates never consume quota.
    dispatcher.message.outer_middleware(RateLimitMiddleware())
    dispatcher.callback_query.outer_middleware(CallbackRateLimitMiddleware())

    # Best-effort deletion of RECOGNIZED group commands after handling
    # (inner middleware: wraps the handler, deletes in a finally block).
    # Private chats are never touched; GROUP_COMMAND_AUTO_DELETE=false
    # disables it entirely.
    dispatcher.message.middleware(CommandAutoDeleteMiddleware())

    return dispatcher


def attach_services(dispatcher: Dispatcher, services: Any) -> None:
    """Inject the service container into handler workflow data."""
    dispatcher["services"] = services
    dispatcher["service_container"] = services  # alias for clarity

"""Keyboards for the personal library: home, likes, playlists, settings."""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.bot.keyboards.common import back_button

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.database.models import Playlist

#: Liked tracks shown per page.
LIKED_PAGE_SIZE = 8

#: New releases shown per page (/new browse).
NEW_PAGE_SIZE = 8

#: Buttons per row in list keyboards.
_PER_ROW = 2


def library_home_keyboard() -> InlineKeyboardMarkup:
    """The My Library hub."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="❤️ Liked Songs", callback_data="lib:liked"),
                InlineKeyboardButton(text="📋 My Playlists", callback_data="lib:pl"),
            ],
            [
                InlineKeyboardButton(text="🆕 New Releases", callback_data="lib:new"),
                InlineKeyboardButton(text="🕘 Recently Played", callback_data="lib:recent"),
            ],
            [
                back_button("nav:home"),
            ],
        ]
    )


def new_releases_keyboard(
    page: int,
    total_pages: int,
    track_ids: list[int] | None = None,
) -> InlineKeyboardMarkup:
    """Numbered track buttons for one page of new releases.

    ``page`` is 1-based; navigation callbacks use ``lib:new:<page>``.
    """
    rows: list[list[InlineKeyboardButton]] = []
    row: list[InlineKeyboardButton] = []
    for offset, track_id in enumerate(track_ids or []):
        number = (page - 1) * NEW_PAGE_SIZE + offset + 1
        row.append(InlineKeyboardButton(text=str(number), callback_data=f"trk:{track_id}"))
        if len(row) >= _PER_ROW:
            rows.append(row)
            row = []
    if row:
        rows.append(row)

    if total_pages > 1:
        nav: list[InlineKeyboardButton] = [
            InlineKeyboardButton(text=f"📄 {page}/{total_pages}", callback_data="lib:new:1")
        ]
        if page > 1:
            nav.insert(
                0,
                InlineKeyboardButton(text="⬅️", callback_data=f"lib:new:{page - 1}"),
            )
        if page < total_pages:
            nav.append(InlineKeyboardButton(text="➡️", callback_data=f"lib:new:{page + 1}"))
        rows.append(nav)
    rows.append([back_button("lib:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def liked_keyboard(
    page: int,
    total_pages: int,
    track_ids: list[int] | None = None,
) -> InlineKeyboardMarkup:
    """Numbered track buttons for one page of liked songs.

    ``page`` is 1-based.  ``track_ids`` are the tracks of *this* page; when
    omitted only the navigation rows are rendered.
    """
    rows: list[list[InlineKeyboardButton]] = []
    row: list[InlineKeyboardButton] = []
    for offset, track_id in enumerate(track_ids or []):
        number = (page - 1) * LIKED_PAGE_SIZE + offset + 1
        row.append(InlineKeyboardButton(text=str(number), callback_data=f"trk:{track_id}"))
        if len(row) >= _PER_ROW:
            rows.append(row)
            row = []
    if row:
        rows.append(row)

    if total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if page > 1:
            nav.append(
                InlineKeyboardButton(text="⬅️", callback_data=f"lib:liked:{page - 1}")
            )
        if page < total_pages:
            nav.append(
                InlineKeyboardButton(text="➡️", callback_data=f"lib:liked:{page + 1}")
            )
        if nav:
            rows.append(nav)
    rows.append([back_button("lib:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def playlists_keyboard(playlists: "list[Playlist] | None") -> InlineKeyboardMarkup:
    """The playlist list: one row per playlist + New + Back."""
    rows: list[list[InlineKeyboardButton]] = []
    for playlist in playlists or []:
        count = len(getattr(playlist, "items", None) or [])
        label = f"🎵 {playlist.title}"
        if count:
            label += f" · {count}"
        rows.append(
            [InlineKeyboardButton(text=label[:64], callback_data=f"pl:{playlist.id}")]
        )
    rows.append(
        [
            InlineKeyboardButton(text="➕ New Playlist", callback_data="pl:new"),
            InlineKeyboardButton(text="📥 Import", callback_data="pl:import"),
        ]
    )
    rows.append([back_button("lib:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def playlist_page_keyboard(playlist_id: int) -> InlineKeyboardMarkup:
    """Action row set for one playlist page."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="▶️ Play All", callback_data=f"pl:play:{playlist_id}"),
                InlineKeyboardButton(text="🔀 Shuffle", callback_data=f"pl:shuf:{playlist_id}"),
            ],
            [
                InlineKeyboardButton(text="➕ Add Songs", callback_data=f"pl:add:{playlist_id}"),
                InlineKeyboardButton(text="✏️ Rename", callback_data=f"pl:ren:{playlist_id}"),
            ],
            [
                InlineKeyboardButton(text="📤 Export", callback_data=f"pl:export:{playlist_id}"),
                InlineKeyboardButton(text="🗑️ Delete", callback_data=f"pl:del:{playlist_id}"),
            ],
            [
                back_button("lib:pl"),
            ],
        ]
    )


def add_to_playlist_keyboard(
    playlists: "list[Playlist] | None", track_id: int
) -> InlineKeyboardMarkup:
    """Playlist picker shown from a track page (➕ Playlist)."""
    rows: list[list[InlineKeyboardButton]] = []
    for playlist in playlists or []:
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"🎵 {playlist.title}"[:64],
                    callback_data=f"pladd:{playlist.id}:{track_id}",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="➕ New Playlist", callback_data="pl:new")])
    rows.append([back_button(f"trk:{track_id}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def settings_keyboard(
    autoplay: bool,
    shuffle: bool,
    repeat: str,
    language: str = "en",
) -> InlineKeyboardMarkup:
    """Playback preference toggles for the personal session.

    ``language`` is accepted for forward compatibility; a language picker is
    not exposed yet (see worklog — scope decision).
    """
    del language  # reserved for a future language picker
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"🤖 Autoplay: {'on' if autoplay else 'off'}",
                    callback_data="set:autoplay",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"🔀 Shuffle: {'on' if shuffle else 'off'}",
                    callback_data="set:shuffle",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"🔁 Repeat: {repeat}", callback_data="set:repeat"
                )
            ],
            [back_button("nav:home")],
        ]
    )


__all__ = [
    "LIKED_PAGE_SIZE",
    "NEW_PAGE_SIZE",
    "add_to_playlist_keyboard",
    "library_home_keyboard",
    "liked_keyboard",
    "new_releases_keyboard",
    "playlist_page_keyboard",
    "playlists_keyboard",
    "settings_keyboard",
]

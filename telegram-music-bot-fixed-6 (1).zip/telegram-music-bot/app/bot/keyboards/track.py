"""Keyboards for track pages, search results and the share screen."""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

#: Search results shown per page (numbered buttons "1".."5").
SEARCH_PAGE_SIZE = 5


def track_page_keyboard(
    track_id: int,
    *,
    liked: bool,
    in_group: bool = False,
    page: int = 0,
) -> InlineKeyboardMarkup:
    """The track detail keyboard (private chats).

    Rows: Play/Download, Like/Playlist, Share/Back.  ``page`` is the search
    results page the Back button returns to.  In a group context there is no
    personal search context, so Back goes to the dashboard instead.

    In private chats **Play** opens the destination chooser
    (``trk:dest:<id>`` — play in a group voice chat via the DM→group
    workflow, or fall back to the personal audio file); group track pages
    use their own keyboard with a direct ``trk:play`` button.
    """
    back_target = "nav:home" if in_group else f"trk:back:{max(0, int(page))}"
    play_target = f"trk:play:{track_id}" if in_group else f"trk:dest:{track_id}"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="▶️ Play", callback_data=play_target),
                InlineKeyboardButton(text="⬇️ Download", callback_data=f"trk:dl:{track_id}"),
            ],
            [
                InlineKeyboardButton(
                    text="💔 Unlike" if liked else "❤️ Like",
                    callback_data=f"trk:like:{track_id}",
                ),
                InlineKeyboardButton(text="➕ Playlist", callback_data=f"trk:pl:{track_id}"),
            ],
            [
                InlineKeyboardButton(text="📤 Share", callback_data=f"trk:share:{track_id}"),
                InlineKeyboardButton(text="🔙 Back", callback_data=back_target),
            ],
        ]
    )


def search_results_keyboard(
    page: int, total_pages: int, track_ids: list[int]
) -> InlineKeyboardMarkup:
    """Numbered track buttons for one search-results page.

    ``page`` is 0-based; button labels carry the absolute result number so
    page 2 shows "6".."10".  The Previous/Next row only appears when there
    is more than one page.  A final navigation row (New Search / Home)
    guarantees the results screen is never a dead end — users could
    previously only escape it with ``/start``.
    """
    rows: list[list[InlineKeyboardButton]] = []
    row: list[InlineKeyboardButton] = []
    for offset, track_id in enumerate(track_ids[:SEARCH_PAGE_SIZE]):
        number = page * SEARCH_PAGE_SIZE + offset + 1
        row.append(InlineKeyboardButton(text=str(number), callback_data=f"trk:{track_id}"))
        if len(row) >= SEARCH_PAGE_SIZE:
            rows.append(row)
            row = []
    if row:
        rows.append(row)

    if total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if page > 0:
            nav.append(
                InlineKeyboardButton(text="⬅️ Previous", callback_data=f"sch:pg:{page - 1}")
            )
        if page < total_pages - 1:
            nav.append(
                InlineKeyboardButton(text="➡️ Next", callback_data=f"sch:pg:{page + 1}")
            )
        if nav:
            rows.append(nav)
    rows.append(
        [
            InlineKeyboardButton(text="🔄 New Search", callback_data="dash:search"),
            InlineKeyboardButton(text="🏠 Home", callback_data="nav:home"),
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def track_share_keyboard(url: str) -> InlineKeyboardMarkup:
    """Keyboard for the share screen: open the track via its deep link."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🎵 Open Track", url=url)],
            [InlineKeyboardButton(text="🔙 Back", callback_data="trk:back:0")],
        ]
    )


__all__ = [
    "SEARCH_PAGE_SIZE",
    "search_results_keyboard",
    "track_page_keyboard",
    "track_share_keyboard",
]

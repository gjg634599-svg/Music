"""Inline keyboard builders for the admin panel (``adm:`` callback namespace).

Every screen of the admin panel edits the message it was triggered from
(aiogram callback navigation) — these builders only produce the
:class:`aiogram.types.InlineKeyboardMarkup` payloads.  Rows hold two buttons
unless a layout explicitly needs more (button list rows use three columns).

All callbacks stay within Telegram's 64-byte limit and follow the registry in
CONTRACTS.md §8 plus the Task 3-c extensions (documented per builder).
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from typing import Protocol

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.admin.appearance import MESSAGES_INDEX
from app.admin.buttons import KNOWN_ACTIONS
from app.database.defaults import DEFAULT_MESSAGES

#: Entries per admin list page (users, groups, broadcasts history).
PAGE_SIZE = 10

#: Maximum items in a Telegram media group (album broadcast).
ALBUM_MAX_ITEMS = 10

#: Common UI language codes offered for language-targeted broadcasts.
LANGUAGE_CODES: tuple[str, ...] = ("en", "ru", "fa", "es", "de", "ar", "tr", "fr")


class ButtonLike(Protocol):
    """Structural type of a ``BotButton`` row (id + label)."""

    id: int  # noqa: A003 — mirrors the DB column name
    label: str


class AccountLike(Protocol):
    """Structural type of a voice account row used by keyboards."""

    id: int  # noqa: A003 — mirrors the DB column name
    label: str


class SessionLike(Protocol):
    """Structural type of a voice session row used by keyboards."""

    id: int  # noqa: A003 — mirrors the DB column name
    group_id: int


# ----------------------------------------------------------------------
# Internals
# ----------------------------------------------------------------------
def _btn(label: str, callback_data: str) -> InlineKeyboardButton:
    """Build one inline button."""
    return InlineKeyboardButton(text=label, callback_data=callback_data)


def _markup(rows: Sequence[Sequence[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    """Assemble a markup skipping empty rows."""
    return InlineKeyboardMarkup(inline_keyboard=[list(row) for row in rows if row])


def _pairs(buttons: Sequence[InlineKeyboardButton]) -> list[list[InlineKeyboardButton]]:
    """Chunk buttons into rows of two."""
    return [list(buttons[i : i + 2]) for i in range(0, len(buttons), 2)]


def _total_pages(total_items: int, per_page: int = PAGE_SIZE) -> int:
    """Number of pages needed for *total_items*."""
    return max(1, math.ceil(max(0, total_items) / per_page))


# ----------------------------------------------------------------------
# Home / panel
# ----------------------------------------------------------------------
def admin_home_keyboard(role_icon: str = "") -> InlineKeyboardMarkup:
    """The admin panel home menu.

    *role_icon* is appended to the "My Account" button so the admin instantly
    sees their own role (👑 / 🛡️ / 🔧).
    """
    me_label = f"👤 My Account {role_icon}".strip() if role_icon else "👤 My Account"
    return _markup(
        [
            [_btn("👥 Users", "adm:users"), _btn("👥 Groups", "adm:groups")],
            [_btn("📢 Broadcast", "adm:bc")],
            [_btn("🎨 Appearance", "adm:app"), _btn("🔘 Buttons", "adm:btn")],
            [_btn("🎙️ Voice Engine", "adm:vc"), _btn("🤖 Autoplay", "adm:set:auto")],
            [_btn("📊 Statistics", "adm:stats"), _btn("🩺 System", "adm:sys")],
            [_btn("⚙️ Settings", "adm:set"), _btn(me_label, "adm:me")],
            [_btn("🔙 Back", "nav:home")],
        ]
    )


# ----------------------------------------------------------------------
# Users / groups lists
# ----------------------------------------------------------------------
def admin_users_keyboard(page: int, total: int) -> InlineKeyboardMarkup:
    """Pagination for the admin users list.

    Args:
        page: zero-based page index.
        total: total number of users.
    """
    total_pages = _total_pages(total)
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(_btn("⬅️ Prev", f"adm:users:{page - 1}"))
    if page < total_pages - 1:
        nav.append(_btn("➡️ Next", f"adm:users:{page + 1}"))
    return _markup([nav, [_btn("🔙 Back", "adm:home")]])


def admin_groups_keyboard(page: int, total: int) -> InlineKeyboardMarkup:
    """Pagination for the admin groups list (same shape as the users one)."""
    total_pages = _total_pages(total)
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(_btn("⬅️ Prev", f"adm:groups:{page - 1}"))
    if page < total_pages - 1:
        nav.append(_btn("➡️ Next", f"adm:groups:{page + 1}"))
    return _markup([nav, [_btn("🔙 Back", "adm:home")]])


def admin_user_detail_keyboard(tg_id: int, blocked: bool) -> InlineKeyboardMarkup:
    """User detail actions: block (with confirmation) or unblock."""
    if blocked:
        action = [_btn("✅ Unblock", f"adm:user:{tg_id}:unblock")]
    else:
        action = [_btn("🚫 Block", f"adm:user:{tg_id}:block")]
    return _markup([action, [_btn("🔙 Back", "adm:users")]])


def admin_user_block_confirm_keyboard(tg_id: int) -> InlineKeyboardMarkup:
    """Two-step confirmation row for blocking a user."""
    return _markup(
        [
            [_btn("🚫 Yes, block", f"adm:user:{tg_id}:block:yes")],
            [_btn("❌ Cancel", f"adm:user:{tg_id}")],
        ]
    )


def admin_group_detail_keyboard() -> InlineKeyboardMarkup:
    """Group detail screen is read-only — a single back button."""
    return _markup([[_btn("🔙 Back", "adm:groups")]])


# ----------------------------------------------------------------------
# Broadcast
# ----------------------------------------------------------------------
def admin_broadcast_keyboard() -> InlineKeyboardMarkup:
    """Broadcast home menu."""
    return _markup(
        [
            [_btn("📢 New Broadcast", "adm:bc:new"), _btn("📜 History", "adm:bc:hist")],
            [_btn("⏸️ Active", "adm:bc:act"), _btn("🔙 Back", "adm:home")],
        ]
    )


def admin_broadcast_composer_keyboard() -> InlineKeyboardMarkup:
    """Content-type picker of the broadcast composer."""
    return _markup(
        [
            [_btn("📝 Text", "adm:bc:type:text"), _btn("🖼️ Photo", "adm:bc:type:photo")],
            [_btn("🎬 Video", "adm:bc:type:video"), _btn("🎵 Audio", "adm:bc:type:audio")],
            [
                _btn("📄 Document", "adm:bc:type:document"),
                _btn("🎞️ Animation", "adm:bc:type:animation"),
            ],
            [_btn("🎙️ Voice", "adm:bc:type:voice"), _btn("🖼️ Album", "adm:bc:type:album")],
            [_btn("📦 Copy Message", "adm:bc:type:copy")],
            [_btn("🔙 Back", "adm:bc")],
        ]
    )


def admin_broadcast_composer_screen_keyboard() -> InlineKeyboardMarkup:
    """Composer screen shown once content has been captured."""
    return _markup(
        [
            [
                _btn("➕ Add URL Button", "adm:bc:btn"),
                _btn("🎯 Choose Target", "adm:bc:targets"),
            ],
            [_btn("👁️ Preview", "adm:bc:preview"), _btn("🔄 Change Content", "adm:bc:new")],
            [_btn("❌ Cancel", "adm:bc:cancel")],
        ]
    )


def admin_broadcast_targets_keyboard() -> InlineKeyboardMarkup:
    """Audience picker (rows of two) of the broadcast composer."""
    return _markup(
        [
            [
                _btn("👥 All Users", "adm:bc:target:all_users"),
                _btn("🟢 Active Users", "adm:bc:target:active_users"),
            ],
            [
                _btn("⚪ Inactive", "adm:bc:target:inactive_users"),
                _btn("🌐 By Language", "adm:bc:target:users_by_language"),
            ],
            [
                _btn("👥 With Groups", "adm:bc:target:users_with_groups"),
                _btn("🎯 Specific Users", "adm:bc:target:specific_users"),
            ],
            [
                _btn("👥 All Groups", "adm:bc:target:all_groups"),
                _btn("🟢 Active Groups", "adm:bc:target:active_groups"),
            ],
            [
                _btn("🎯 Specific Groups", "adm:bc:target:specific_groups"),
                _btn("🔙 Back", "adm:bc:new-restore"),
            ],
        ]
    )


def admin_broadcast_language_keyboard(codes: Sequence[str] = LANGUAGE_CODES) -> InlineKeyboardMarkup:
    """Language picker for ``users_by_language`` broadcasts."""
    rows = _pairs([_btn(f"🌐 {code}", f"adm:bc:lang:{code}") for code in codes])
    rows.append([_btn("🔙 Back", "adm:bc:new-restore")])
    return _markup(rows)


def admin_broadcast_confirm_keyboard(bid: int | None = None) -> InlineKeyboardMarkup:
    """Final confirmation before a broadcast is created and started.

    *bid* is reserved for future per-draft callbacks — the current flow
    addresses the in-progress draft through FSM state.
    """
    del bid  # currently unused; kept for API compatibility
    return _markup(
        [
            [_btn("✅ Start", "adm:bc:send"), _btn("✏️ Edit", "adm:bc:edit")],
            [_btn("❌ Cancel", "adm:bc:cancel")],
        ]
    )


def admin_broadcast_progress_keyboard(bid: int) -> InlineKeyboardMarkup:
    """Controls for a running (pending/sending/paused) broadcast."""
    return _markup(
        [
            [_btn("⏸️ Pause", f"adm:bc:{bid}:pause"), _btn("🛑 Stop", f"adm:bc:{bid}:stop")],
            [_btn("🔄 Refresh", f"adm:bc:{bid}:refresh")],
        ]
    )


def admin_broadcast_result_keyboard(bid: int) -> InlineKeyboardMarkup:
    """Controls for a finished (completed/cancelled/failed) broadcast."""
    return _markup(
        [
            [
                _btn("📊 Details", f"adm:bc:{bid}:refresh"),
                _btn("🔁 Retry Failed", f"adm:bc:{bid}:retry"),
            ],
            [_btn("📢 New", "adm:bc:new"), _btn("🔙 Back", "adm:home")],
        ]
    )


def admin_broadcast_history_keyboard(page: int, total_pages: int) -> InlineKeyboardMarkup:
    """Pagination for the broadcast history (10 per page)."""
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(_btn("⬅️ Prev", f"adm:bc:hist:{page - 1}"))
    if page < max(1, total_pages) - 1:
        nav.append(_btn("➡️ Next", f"adm:bc:hist:{page + 1}"))
    return _markup([nav, [_btn("🔙 Back", "adm:bc")]])


def admin_broadcast_active_keyboard(ids: Sequence[int]) -> InlineKeyboardMarkup:
    """One refresh button per active broadcast (rows of two) + back."""
    rows = _pairs([_btn(f"📊 #{bid}", f"adm:bc:{bid}:refresh") for bid in ids])
    rows.append([_btn("🔙 Back", "adm:bc")])
    return _markup(rows)


def admin_broadcast_album_keyboard() -> InlineKeyboardMarkup:
    """Shown while collecting a media-group album."""
    return _markup(
        [[_btn("✅ Done", "adm:bc:album:done"), _btn("❌ Cancel", "adm:bc:cancel")]]
    )


# ----------------------------------------------------------------------
# Appearance
# ----------------------------------------------------------------------
def admin_appearance_keyboard(
    keys: Sequence[tuple[str, str]] | None = None,
) -> InlineKeyboardMarkup:
    """Appearance menu: the logo entry plus one button per message template.

    Args:
        keys: optional ``(key, title)`` pairs from
            ``AdminService.appearance.keys()``; when omitted the built-in
            default index is used so the builder can be called standalone.
    """
    if keys is None:
        keys = [
            (key, MESSAGES_INDEX.get(key, key.replace("_", " ").title()))
            for key in DEFAULT_MESSAGES
        ]
    buttons: list[InlineKeyboardButton] = [_btn("🖼️ Logo", "adm:app:logo")]
    buttons.extend(_btn(f"📝 {title}", f"adm:app:msg:{key}") for key, title in keys)
    rows = _pairs(buttons)
    rows.append([_btn("🔙 Back", "adm:home")])
    return _markup(rows)


def admin_logo_keyboard() -> InlineKeyboardMarkup:
    """Logo manager actions."""
    return _markup(
        [
            [
                _btn("🖼️ Change Logo", "adm:app:logo:change"),
                _btn("👁️ Preview", "adm:app:logo:preview"),
            ],
            [_btn("🗑️ Remove", "adm:app:logo:del"), _btn("🔙 Back", "adm:app")],
        ]
    )


def admin_message_keyboard(key: str) -> InlineKeyboardMarkup:
    """Actions for one customizable message template."""
    return _markup(
        [
            [
                _btn("✏️ Edit", f"adm:app:msg:{key}:edit"),
                _btn("👁️ Preview", f"adm:app:msg:{key}:preview"),
            ],
            [_btn("↩️ Reset", f"adm:app:msg:{key}:reset"), _btn("🔙 Back", "adm:app")],
        ]
    )


# ----------------------------------------------------------------------
# Dynamic buttons
# ----------------------------------------------------------------------
def admin_buttons_keyboard(buttons: Sequence[ButtonLike]) -> InlineKeyboardMarkup:
    """The dynamic-button manager list.

    One row per configured button (three columns): edit / move up / move
    down, followed by the add & preview row.
    """
    rows: list[list[InlineKeyboardButton]] = []
    for btn in buttons:
        rows.append(
            [
                _btn(f"🔘 {btn.label}", f"adm:btn:{btn.id}:edit"),
                _btn("⬆️", f"adm:btn:{btn.id}:up"),
                _btn("⬇️", f"adm:btn:{btn.id}:down"),
            ]
        )
    rows.append([_btn("➕ Add Button", "adm:btn:add"), _btn("👁️ Preview", "adm:btn:preview")])
    rows.append([_btn("🔙 Back", "adm:home")])
    return _markup(rows)


def admin_button_edit_keyboard(bid: int, is_url: bool = False) -> InlineKeyboardMarkup:
    """Actions for one dynamic button.

    The URL editor is only offered for ``url`` type buttons.
    """
    row_edit = [_btn("✏️ Label", f"adm:btn:{bid}:edit:label")]
    if is_url:
        row_edit.append(_btn("🔗 URL", f"adm:btn:{bid}:edit:url"))
    return _markup(
        [
            row_edit,
            [_btn("🔁 Toggle", f"adm:btn:{bid}:toggle"), _btn("🗑️ Delete", f"adm:btn:{bid}:del")],
            [_btn("🔙 Back", "adm:btn")],
        ]
    )


def admin_button_delete_confirm_keyboard(bid: int) -> InlineKeyboardMarkup:
    """Two-step confirmation row for deleting a dynamic button."""
    return _markup(
        [
            [_btn("🗑️ Yes, delete", f"adm:btn:{bid}:del:yes")],
            [_btn("❌ Cancel", f"adm:btn:{bid}:edit")],
        ]
    )


def admin_add_button_type_keyboard() -> InlineKeyboardMarkup:
    """New-button type picker."""
    return _markup(
        [
            [_btn("🔄 Callback", "adm:btn:new:callback"), _btn("🔗 URL", "adm:btn:new:url")],
            [_btn("👥 Add to Group", "adm:btn:new:add_group"), _btn("🔙 Back", "adm:btn")],
        ]
    )


#: Friendly labels for the KNOWN_ACTIONS callback-action picker.
_ACTION_LABELS: dict[str, str] = {
    "dash:search": "🔍 Search",
    "dash:library": "📚 Library",
    "dash:playlists": "📋 Playlists",
    "dash:history": "🕘 History",
    "dash:settings": "⚙️ Settings",
    "dash:account": "👤 Account",
    "dash:help": "ℹ️ Help",
    "dash:commands": "📜 Commands",
}


def admin_button_action_picker_keyboard() -> InlineKeyboardMarkup:
    """Picker of known callback actions (for ``callback`` type buttons)."""
    rows = _pairs(
        [
            _btn(_ACTION_LABELS.get(action, action), f"adm:btn:action:{action}")
            for action in sorted(KNOWN_ACTIONS)
        ]
    )
    rows.append([_btn("🔙 Back", "adm:btn:add")])
    return _markup(rows)


# ----------------------------------------------------------------------
# Voice engine
# ----------------------------------------------------------------------
def admin_voice_keyboard() -> InlineKeyboardMarkup:
    """Voice engine dashboard menu."""
    return _markup(
        [
            [_btn("👤 Accounts", "adm:vc:acc"), _btn("🎵 Active Sessions", "adm:vc:ses")],
            [_btn("🩺 Health Check", "adm:vc:health"), _btn("🔄 Reload", "adm:vc:reload")],
            [_btn("➕ Add Account", "adm:vc:add"), _btn("🔙 Back", "adm:home")],
        ]
    )


def admin_voice_accounts_keyboard(accounts: Sequence[AccountLike]) -> InlineKeyboardMarkup:
    """One button per voice account (rows of two) + back."""
    rows = _pairs([_btn(f"👤 #{acc.id} · {acc.label}", f"adm:vc:acc:{acc.id}") for acc in accounts])
    rows.append([_btn("🔙 Back", "adm:vc")])
    return _markup(rows)


def admin_voice_account_keyboard(acc_id: int, is_disabled: bool = False) -> InlineKeyboardMarkup:
    """Actions for one voice account.

    Args:
        acc_id: voice account database id.
        is_disabled: current status — flips the Disable/Enable label.
    """
    toggle_label = "▶️ Enable" if is_disabled else "⏸️ Disable"
    return _markup(
        [
            [
                _btn("🩺 Health", f"adm:vc:acc:{acc_id}:health"),
                _btn(toggle_label, f"adm:vc:acc:{acc_id}:toggle"),
            ],
            [
                _btn("🔄 Reconnect", f"adm:vc:acc:{acc_id}:reconnect"),
                _btn("🚪 Group Access", f"adm:vc:acc:{acc_id}:access"),
            ],
            [_btn("🗑️ Remove", f"adm:vc:acc:{acc_id}:del")],
            [_btn("🔙 Back", "adm:vc:acc")],
        ]
    )


def admin_voice_account_delete_confirm_keyboard(acc_id: int) -> InlineKeyboardMarkup:
    """Two-step confirmation row for removing a voice account."""
    return _markup(
        [
            [_btn("🗑️ Yes, remove", f"adm:vc:acc:{acc_id}:del:yes")],
            [_btn("❌ Cancel", f"adm:vc:acc:{acc_id}")],
        ]
    )


# ----------------------------------------------------------------------
# Voice-account login wizard (admin-private chat only)
# ----------------------------------------------------------------------
def admin_voice_login_intro_keyboard() -> InlineKeyboardMarkup:
    """Step A — wizard introduction: Connect / Cancel."""
    return _markup(
        [
            [_btn("🔗 Connect Account", "adm:vc:add:start")],
            [_btn("❌ Cancel", "adm:vc:add:cancel")],
        ]
    )


def admin_voice_login_step_keyboard(step: str) -> InlineKeyboardMarkup:
    """Per-step wizard keyboard (``phone`` / ``code`` / ``password``)."""
    if step == "code":
        return _markup(
            [
                [_btn("📨 Resend Code", "adm:vc:add:resend")],
                [_btn("❌ Cancel Login", "adm:vc:add:cancel")],
            ]
        )
    return _markup(
        [
            [_btn("❌ Cancel Login", "adm:vc:add:cancel")],
        ]
    )


def admin_voice_login_success_keyboard() -> InlineKeyboardMarkup:
    """Step E — connected account: health check / accounts / close."""
    return _markup(
        [
            [_btn("🩺 Run Health Check", "adm:vc:add:check")],
            [_btn("👤 Voice Accounts", "adm:vc:acc")],
            [_btn("✅ Close", "adm:vc")],
        ]
    )


def admin_voice_sessions_keyboard(sessions: Sequence[SessionLike]) -> InlineKeyboardMarkup:
    """One button per active voice session (rows of two) + back."""
    rows = _pairs(
        [_btn(f"🎵 #{ses.id} · group {ses.group_id}", f"adm:vc:ses:{ses.id}") for ses in sessions]
    )
    rows.append([_btn("🔙 Back", "adm:vc")])
    return _markup(rows)


def admin_voice_session_keyboard(ses_id: int) -> InlineKeyboardMarkup:
    """Playback actions on the group served by a voice session."""
    return _markup(
        [
            [_btn("⏭️ Skip", f"adm:vc:ses:{ses_id}:skip"), _btn("⏸️ Pause", f"adm:vc:ses:{ses_id}:pause")],
            [_btn("🛑 Stop", f"adm:vc:ses:{ses_id}:stop"), _btn("🔙 Back", "adm:vc:ses")],
        ]
    )


# ----------------------------------------------------------------------
# Settings / stats / account
# ----------------------------------------------------------------------
def admin_settings_keyboard(autoplay: bool) -> InlineKeyboardMarkup:
    """Settings menu.

    The autoplay button carries the value it will switch TO (``adm:set:auto:0``
    turns it off, ``adm:set:auto:1`` turns it on).
    """
    autoplay_label = "🤖 Autoplay: ✅ On" if autoplay else "🤖 Autoplay: ❌ Off"
    autoplay_target = "adm:set:auto:0" if autoplay else "adm:set:auto:1"
    return _markup(
        [
            [_btn(autoplay_label, autoplay_target), _btn("🚧 Maintenance", "adm:set:maintenance")],
            [_btn("📢 Broadcast Limits", "adm:set:broadcast"), _btn("🔙 Back", "adm:home")],
        ]
    )


def admin_maintenance_keyboard(enabled: bool, groups_continue: bool) -> InlineKeyboardMarkup:
    """Maintenance-mode controls.

    When maintenance is off only "Enable" is offered; when on, "Disable" plus
    the "groups continue playing" toggle are shown.
    """
    if not enabled:
        return _markup(
            [
                [_btn("✅ Enable Maintenance", "adm:set:maintenance:1:on")],
                [_btn("🔙 Back", "adm:set")],
            ]
        )
    groups_label = "👥 Groups continue: ✅ On" if groups_continue else "👥 Groups continue: ❌ Off"
    groups_target = "adm:set:maintenance:groups:0" if groups_continue else "adm:set:maintenance:groups:1"
    return _markup(
        [
            [_btn("✅ Disable Maintenance", "adm:set:maintenance:0:off")],
            [_btn(groups_label, groups_target)],
            [_btn("🔙 Back", "adm:set")],
        ]
    )


def admin_stats_keyboard() -> InlineKeyboardMarkup:
    """Statistics / system screens — a single back button."""
    return _markup([[_btn("🔙 Back", "adm:home")]])


def admin_me_keyboard(is_super: bool = False) -> InlineKeyboardMarkup:
    """My-admin-account menu (👑 marks super admins)."""
    panel_label = "🎛️ Admin Panel 👑" if is_super else "🎛️ Admin Panel"
    return _markup(
        [
            [_btn("👥 My Groups", "adm:me:groups"), _btn("🎙️ Voice Accounts", "adm:vc:acc")],
            [_btn("📊 My Activity", "adm:me:activity"), _btn(panel_label, "adm:home")],
        ]
    )


def admin_back_keyboard(target: str = "adm:home", label: str = "🔙 Back") -> InlineKeyboardMarkup:
    """Generic single back-button keyboard."""
    return _markup([[_btn(label, target)]])


__all__ = [
    "PAGE_SIZE",
    "ALBUM_MAX_ITEMS",
    "LANGUAGE_CODES",
    "admin_home_keyboard",
    "admin_users_keyboard",
    "admin_groups_keyboard",
    "admin_user_detail_keyboard",
    "admin_user_block_confirm_keyboard",
    "admin_group_detail_keyboard",
    "admin_broadcast_keyboard",
    "admin_broadcast_composer_keyboard",
    "admin_broadcast_composer_screen_keyboard",
    "admin_broadcast_targets_keyboard",
    "admin_broadcast_language_keyboard",
    "admin_broadcast_confirm_keyboard",
    "admin_broadcast_progress_keyboard",
    "admin_broadcast_result_keyboard",
    "admin_broadcast_history_keyboard",
    "admin_broadcast_active_keyboard",
    "admin_broadcast_album_keyboard",
    "admin_appearance_keyboard",
    "admin_logo_keyboard",
    "admin_message_keyboard",
    "admin_buttons_keyboard",
    "admin_button_edit_keyboard",
    "admin_button_delete_confirm_keyboard",
    "admin_add_button_type_keyboard",
    "admin_button_action_picker_keyboard",
    "admin_voice_keyboard",
    "admin_voice_accounts_keyboard",
    "admin_voice_account_keyboard",
    "admin_voice_account_delete_confirm_keyboard",
    "admin_voice_login_intro_keyboard",
    "admin_voice_login_step_keyboard",
    "admin_voice_login_success_keyboard",
    "admin_voice_sessions_keyboard",
    "admin_voice_session_keyboard",
    "admin_settings_keyboard",
    "admin_maintenance_keyboard",
    "admin_stats_keyboard",
    "admin_me_keyboard",
    "admin_back_keyboard",
]

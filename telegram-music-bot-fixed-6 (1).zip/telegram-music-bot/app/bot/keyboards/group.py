"""Inline keyboards for group chats (the ``grp:`` callback namespace).

Every keyboard here must only emit callback data registered in
``CONTRACTS.md`` §8 (``grp:home``, ``grp:queue``, ``grp:np``, ``grp:settings``,
``grp:set:<key>:<value>``, ``grp:pmode:<mode>``, ``grp:dj:<user_id>`` plus the
group-context ``trk:*`` buttons). All callback strings stay well below the
64-byte Telegram limit.
"""

from __future__ import annotations

from typing import Any

from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.utils import repeat_label, truncate

#: Maximum number of member toggle buttons on the DJ management screen.
MAX_DJ_BUTTONS = 12

#: Tracks per page of the group ``/new`` browse (matches the private /new).
GROUP_NEW_PAGE_SIZE = 8

#: Human labels for the three permission modes.
PERMISSION_MODE_LABELS: dict[str, str] = {
    "everyone": "Everyone",
    "admins": "Admins",
    "dj": "DJ Mode",
}


def _mode_label(mode: str) -> str:
    """Human label for a permission mode (unknown values pass through)."""
    return PERMISSION_MODE_LABELS.get(mode, mode or "Everyone")


def group_dashboard_keyboard(*, playing: bool) -> InlineKeyboardMarkup:
    """Group dashboard: search, voice chat, queue, now playing, settings.

    An extra ``⏹️ Stop`` button appears while playback is active.
    """
    builder = InlineKeyboardBuilder()
    builder.button(text="🔎 Search Music", callback_data="grp:search")
    builder.button(text="🎧 Join VC", callback_data="grp:vc")
    builder.button(text="📋 Queue", callback_data="grp:queue")
    builder.button(text="▶️ Now Playing", callback_data="grp:np")
    builder.button(text="⚙️ Settings", callback_data="grp:settings")
    builder.button(text="ℹ️ Help", callback_data="grp:help")
    if playing:
        builder.button(text="⏹️ Stop", callback_data="grp:stop")
        builder.adjust(2, 2, 2, 1)
    else:
        builder.adjust(2, 2, 2)
    return builder.as_markup()


def group_controls_keyboard(
    *,
    paused: bool,
    shuffle: bool = False,
    repeat_mode: str = "off",
    volume: int | None = None,
    autoplay: bool = False,
) -> InlineKeyboardMarkup:
    """Transport controls attached to the group Now Playing view.

    Full persistent panel (the pattern the inspected reference bots —
    Yukki / AnonXMusic / VCPlay lineage — converge on): transport pair,
    stateful shuffle/repeat/autoplay toggles, queue access and volume
    steps — all one tap away, all permission-checked per press.

    Layout is compact and mobile-first: two-button rows with short labels
    (every label ≤ 16 characters, so no row ever clips — production once
    showed "Shuffle: Of…" / "Repeat: Of…" from longer labels), with Stop
    as a full-width safety action:

    .. code-block:: text

        ⏸️ Pause  | ⏭️ Skip
        🔀 Shuffle On | 🔁 Repeat: Off
        🤖 Autoplay ON | 📋 Queue
        🔉 Vol − 75 | 🔊 Vol + 100
        🛑 Stop

    Volume is a human percent (0-100); the voice engine maps it to its
    own 0-200 scale internally.
    """
    vol = volume if isinstance(volume, int) else 100
    vol = max(0, min(100, vol))
    builder = InlineKeyboardBuilder()
    builder.button(
        text="▶️ Resume" if paused else "⏸️ Pause",
        callback_data="grp:resume" if paused else "grp:pause",
    )
    builder.button(text="⏭️ Skip", callback_data="grp:skip")
    builder.button(
        text=f"🔀 Shuffle {'On' if shuffle else 'Off'}",
        callback_data="grp:shuf",
    )
    builder.button(
        text=f"🔁 Repeat: {repeat_label(repeat_mode)}",
        callback_data="grp:rep",
    )
    builder.button(
        text=f"🤖 Autoplay {'ON' if autoplay else 'OFF'}",
        callback_data="grp:auto",
    )
    builder.button(text="📋 Queue", callback_data="grp:queue")
    builder.button(
        text=f"🔉 Vol − {max(0, vol - 25)}",
        callback_data="grp:vol:dn",
    )
    builder.button(
        text=f"🔊 Vol + {min(100, vol + 25)}",
        callback_data="grp:vol:up",
    )
    builder.button(text="🛑 Stop", callback_data="grp:stop")
    builder.adjust(2, 2, 2, 2, 1)
    return builder.as_markup()


def group_queue_keyboard(
    *, shuffle: bool = False, repeat_mode: str = "off", autoplay: bool = False
) -> InlineKeyboardMarkup:
    """Controls attached to the group queue view (stateful toggles).

    The autoplay toggle rides here too — the task's "near queue
    information" placement: see the queue, flip whether the bot keeps
    playing when it runs dry.
    """
    builder = InlineKeyboardBuilder()
    builder.button(text="⏭️ Skip", callback_data="grp:skip")
    builder.button(
        text=f"🔀 Shuffle: {'On' if shuffle else 'Off'}",
        callback_data="grp:shuf",
    )
    builder.button(
        text=f"🔁 Repeat: {repeat_label(repeat_mode)}",
        callback_data="grp:rep",
    )
    builder.button(
        text=f"🤖 Autoplay: {'ON' if autoplay else 'OFF'}",
        callback_data="grp:auto",
    )
    builder.button(text="🛑 Stop", callback_data="grp:stop")
    builder.adjust(2, 1, 1, 1)
    return builder.as_markup()


def group_settings_keyboard(settings: Any) -> InlineKeyboardMarkup:
    """Group settings screen built from a ``GroupSettings``-like object.

    Toggle buttons carry the value that pressing them would SET (e.g. silent
    mode currently on → ``grp:set:silent:0``). The permissions button carries
    the currently active mode; the handler opens the mode picker for it.
    """
    silent = bool(getattr(settings, "silent_mode", True))
    autoplay = bool(getattr(settings, "autoplay_enabled", True))
    mode = str(getattr(settings, "permission_mode", "everyone") or "everyone")
    if mode not in PERMISSION_MODE_LABELS:
        mode = "everyone"

    builder = InlineKeyboardBuilder()
    builder.button(
        text=f"🔇 Silent Mode: {'On' if silent else 'Off'}",
        callback_data=f"grp:set:silent:{0 if silent else 1}",
    )
    builder.button(
        text=f"🤖 Autoplay: {'On' if autoplay else 'Off'}",
        callback_data=f"grp:set:auto:{0 if autoplay else 1}",
    )
    builder.button(
        text=f"🎛️ Permissions: {_mode_label(mode)}",
        callback_data=f"grp:pmode:{mode}",
    )
    builder.button(text="👤 DJs", callback_data="grp:djs")
    builder.button(text="🔙 Back", callback_data="grp:home")
    builder.adjust(2, 1, 2)
    return builder.as_markup()


def permission_mode_keyboard() -> InlineKeyboardMarkup:
    """Picker for the group permission mode (who may control playback)."""
    builder = InlineKeyboardBuilder()
    builder.button(text="👥 Everyone", callback_data="grp:pmode:everyone")
    builder.button(text="🛡️ Admins", callback_data="grp:pmode:admins")
    builder.button(text="🎤 DJ Mode", callback_data="grp:pmode:dj")
    builder.button(text="🔙 Back", callback_data="grp:settings")
    builder.adjust(1, 1, 1, 1)
    return builder.as_markup()


def dj_list_keyboard(
    members: Any,
    group_id: int,
    *,
    names: dict[int, str] | None = None,
) -> InlineKeyboardMarkup:
    """DJ management screen: one toggle button per synced member.

    ``members`` is any iterable of ``GroupMember``-like objects exposing
    ``telegram_user_id`` and ``is_dj``; at most :data:`MAX_DJ_BUTTONS` toggle
    buttons are rendered. ``names`` optionally maps Telegram user ids to
    display names (resolved best-effort by the handler).

    Args:
        members: Group member rows (only the first 12 are rendered).
        group_id: Group Telegram id — accepted for interface stability; the
            callback payload itself already carries its chat context.
        names: Optional ``{telegram_user_id: display_name}`` mapping.
    """
    builder = InlineKeyboardBuilder()
    rendered = 0
    for member in members or ():
        if rendered >= MAX_DJ_BUTTONS:
            break
        tg_id = getattr(member, "telegram_user_id", None)
        if not isinstance(tg_id, int) or tg_id <= 0:
            continue
        is_dj = bool(getattr(member, "is_dj", False))
        label = (names or {}).get(tg_id) or f"User {tg_id}"
        builder.button(
            text=truncate(("👑 " if is_dj else "👤 ") + label, 60),
            callback_data=f"grp:dj:{tg_id}:{0 if is_dj else 1}",
        )
        rendered += 1
    builder.button(text="🔙 Back", callback_data="grp:settings")
    builder.adjust(*([1] * rendered + [1]))
    return builder.as_markup()


def group_search_results_keyboard(tracks: Any) -> InlineKeyboardMarkup:
    """Numbered result buttons (``trk:<track_id>``) for a group search.

    A follow-up row (Now Playing / Queue) rides below the results — after a
    search the natural next actions are checking the player state or the
    queue, not scrolling for a command.
    """
    builder = InlineKeyboardBuilder()
    rendered = 0
    for index, track in enumerate(tracks or (), start=1):
        track_id = getattr(track, "id", None)
        if not isinstance(track_id, int):
            continue
        title = str(getattr(track, "title", "") or "Unknown")
        artist = getattr(getattr(track, "artist", None), "name", None) or ""
        label = f"{index}. {title}" + (f" · {artist}" if artist else "")
        builder.button(text=truncate(label, 48), callback_data=f"trk:{track_id}")
        rendered += 1
    builder.button(text="🎧 Now Playing", callback_data="grp:np")
    builder.button(text="📋 Queue", callback_data="grp:queue")
    sizes = [1] * rendered + [2]
    builder.adjust(*sizes)
    return builder.as_markup()


def group_new_releases_keyboard(
    page: int,
    total_pages: int,
    tracks: Any,
) -> InlineKeyboardMarkup:
    """One page of the group ``/new`` browse (radio-style queue seeding).

    Every numbered row is a **one-tap enqueue** button (``grp:newq:<track_id>``)
    — the group "radio" flow: browse the freshest catalog tracks and tap them
    straight into the voice-chat queue. Navigation uses ``grp:new:<page>``
    (1-based, identical payload grammar to the private ``lib:new:<page>``);
    the page-indicator button jumps back to page 1. ``tracks`` is any iterable
    of track-like objects exposing ``id``, ``title`` and ``artist.name``.
    """
    builder = InlineKeyboardBuilder()
    items = list(tracks or ())
    for index, track in enumerate(items, start=1):
        track_id = getattr(track, "id", None)
        if not isinstance(track_id, int):
            continue
        title = str(getattr(track, "title", "") or "Unknown")
        artist = getattr(getattr(track, "artist", None), "name", None) or ""
        number = (page - 1) * GROUP_NEW_PAGE_SIZE + index
        label = f"{number}. {title}" + (f" · {artist}" if artist else "")
        builder.button(text=truncate(label, 48), callback_data=f"grp:newq:{track_id}")
    nav_count = 0
    if total_pages > 1:
        nav: list[tuple[str, str]] = [(f"📄 {page}/{total_pages}", "grp:new:1")]
        if page > 1:
            nav.insert(0, ("⬅️", f"grp:new:{page - 1}"))
        if page < total_pages:
            nav.append(("➡️", f"grp:new:{page + 1}"))
        for text, data in nav:
            builder.button(text=text, callback_data=data)
        nav_count = len(nav)
    builder.button(text="🔙 Back", callback_data="grp:home")
    rendered = sum(1 for t in items if isinstance(getattr(t, "id", None), int))
    sizes = [1] * rendered
    if nav_count:
        sizes.append(nav_count)
    sizes.append(1)
    builder.adjust(*sizes)
    return builder.as_markup()


def group_track_keyboard(track_id: int) -> InlineKeyboardMarkup:
    """Actions for a track page opened from a group search result."""
    builder = InlineKeyboardBuilder()
    builder.button(text="▶️ Play", callback_data=f"trk:play:{track_id}")
    builder.button(text="➕ Queue", callback_data=f"trk:queue:{track_id}")
    builder.button(text="❤️ Like", callback_data=f"trk:like:{track_id}")
    builder.button(text="🔙 Back", callback_data="grp:queue")
    builder.adjust(2, 2)
    return builder.as_markup()


__all__ = [
    "GROUP_NEW_PAGE_SIZE",
    "MAX_DJ_BUTTONS",
    "PERMISSION_MODE_LABELS",
    "dj_list_keyboard",
    "group_controls_keyboard",
    "group_dashboard_keyboard",
    "group_new_releases_keyboard",
    "group_queue_keyboard",
    "group_search_results_keyboard",
    "group_settings_keyboard",
    "group_track_keyboard",
    "permission_mode_keyboard",
]

"""Keyboards for the start dashboard and the search prompt."""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.bot.keyboards.common import cancel_button

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer


async def dashboard_keyboard(
    services: "ServiceContainer", bot_username: str
) -> InlineKeyboardMarkup:
    """The dynamic start-screen keyboard (admin-managed DB buttons)."""
    return await services.admin.buttons.render_keyboard(bot_username)


def search_prompt_keyboard() -> InlineKeyboardMarkup:
    """Keyboard shown while waiting for the user's search query."""
    return InlineKeyboardMarkup(inline_keyboard=[[cancel_button()]])


def group_invite_keyboard(bot_username: str) -> InlineKeyboardMarkup:
    """The 'Add me to a group' deep-link keyboard (used by /group)."""
    username = (bot_username or "").strip().lstrip("@")
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="➕ Add Me to Group",
                    url=f"https://t.me/{username}?startgroup=true",
                )
            ],
            [InlineKeyboardButton(text="🔙 Back", callback_data="nav:home")],
        ]
    )


__all__ = [
    "dashboard_keyboard",
    "group_invite_keyboard",
    "search_prompt_keyboard",
]

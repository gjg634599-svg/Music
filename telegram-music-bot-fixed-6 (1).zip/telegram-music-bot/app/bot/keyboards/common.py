"""Shared inline-keyboard primitives and screen-edit plumbing.

Every personal-mode keyboard is built from the small helpers here so labels
and navigation callbacks stay consistent across the bot (CONTRACTS §8 UX
rules: always a Back button, edit instead of send, short messages).

This module also hosts :func:`edit_screen` — the flexible edit-or-send
primitive used by every personal handler — because it must be importable by
all handler modules without creating import cycles.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.logging import get_logger, log_extra

if TYPE_CHECKING:  # pragma: no cover - typing only
    from aiogram.types import Message

logger = get_logger(__name__)

#: Default labels for the shared navigation buttons.
BACK_LABEL = "🔙 Back"
CANCEL_LABEL = "❌ Cancel"
CLOSE_LABEL = "🚫 Close"


def back_button(callback_data: str, label: str = BACK_LABEL) -> InlineKeyboardButton:
    """A Back button pointing at *callback_data* (e.g. ``lib:home``)."""
    return InlineKeyboardButton(text=label, callback_data=callback_data)


def cancel_button() -> InlineKeyboardButton:
    """The universal Cancel button — cancels FSM state and returns home."""
    return InlineKeyboardButton(text=CANCEL_LABEL, callback_data="nav:cancel")


def close_button(callback_data: str = "nav:cancel") -> InlineKeyboardButton:
    """A generic Close button (defaults to the cancel-and-home callback)."""
    return InlineKeyboardButton(text=CLOSE_LABEL, callback_data=callback_data)


def nav_row(*buttons: InlineKeyboardButton) -> list[InlineKeyboardButton]:
    """Group buttons into one keyboard row."""
    return list(buttons)


async def edit_screen(
    message: "Message | Any",
    text: str,
    keyboard: InlineKeyboardMarkup | None = None,
) -> Any:
    """Edit *message* in place (text, then caption), else send a new one.

    Personal navigation must EDIT the current message (UX rule).  The start
    dashboard may be a photo message, so the fallback chain is:

    1. ``edit_text`` (plain text messages),
    2. ``edit_caption`` (photo / media messages — the dashboard with a logo),
    3. ``answer`` (message too old / not editable).

    HTML parse mode is always passed explicitly so rendering does not depend
    on the bot's default parse-mode configuration.
    """
    edit_text = getattr(message, "edit_text", None)
    if callable(edit_text):
        try:
            return await edit_text(text, parse_mode="HTML", reply_markup=keyboard)
        except Exception as exc:  # noqa: BLE001 — Telegram raises many edit errors
            logger.debug("telegram.edit_text_failed", extra=log_extra(error=str(exc)[:160]))

    edit_caption = getattr(message, "caption", None)
    if edit_caption is not None or getattr(message, "photo", None):
        edit = getattr(message, "edit_caption", None)
        if callable(edit):
            try:
                return await edit(text, parse_mode="HTML", reply_markup=keyboard)
            except Exception as exc:  # noqa: BLE001 — caption limit, old message…
                logger.debug(
                    "telegram.edit_caption_failed", extra=log_extra(error=str(exc)[:160])
                )

    answer = getattr(message, "answer", None)
    if callable(answer):  # pragma: no branch — aiogram Message always has it
        return await answer(text, parse_mode="HTML", reply_markup=keyboard)
    return None


__all__ = [
    "BACK_LABEL",
    "CANCEL_LABEL",
    "CLOSE_LABEL",
    "back_button",
    "cancel_button",
    "close_button",
    "edit_screen",
    "nav_row",
]

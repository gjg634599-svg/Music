"""Keyboards for the Now Playing control message and the queue view."""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.bot.keyboards.common import back_button
from app.utils import repeat_label


def now_playing_keyboard(
    *,
    paused: bool,
    liked: bool,
    group: bool = False,
    shuffle: bool = False,
    repeat_mode: str = "off",
) -> InlineKeyboardMarkup:
    """Transport controls for the Now Playing message (np: callbacks).

    Buttons reflect the *current* session state on their labels
    (``🔀 Shuffle: On``, ``🔁 Repeat: All``) — the stateful-toggle
    pattern used by established music bots, so users always see what
    a press will change without answering a modal first.
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="⏮️", callback_data="np:prev"),
                InlineKeyboardButton(
                    text="⏸ Pause" if not paused else "▶️ Resume",
                    callback_data="np:pause" if not paused else "np:resume",
                ),
                InlineKeyboardButton(text="⏭️", callback_data="np:next"),
            ],
            [
                InlineKeyboardButton(
                    text=f"🔀 Shuffle: {'On' if shuffle else 'Off'}",
                    callback_data="np:shuf",
                ),
                InlineKeyboardButton(
                    text=f"🔁 Repeat: {repeat_label(repeat_mode)}",
                    callback_data="np:rep",
                ),
            ],
            [
                InlineKeyboardButton(text="📋 Queue", callback_data="np:queue"),
                InlineKeyboardButton(
                    text="💔 Unlike" if liked else "❤️ Like",
                    callback_data="np:like",
                ),
                InlineKeyboardButton(text="🚫 Close", callback_data="np:close"),
            ],
        ]
    )


def queue_keyboard(
    *, shuffle: bool = False, repeat_mode: str = "off"
) -> InlineKeyboardMarkup:
    """Controls attached below the personal queue list (stateful toggles)."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="⏭️ Skip", callback_data="q:skip"),
                InlineKeyboardButton(
                    text=f"🔀 Shuffle: {'On' if shuffle else 'Off'}",
                    callback_data="q:shuf",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🔁 Repeat: {repeat_label(repeat_mode)}",
                    callback_data="q:rep",
                ),
                InlineKeyboardButton(text="🗑️ Clear", callback_data="q:clear"),
            ],
            [back_button("nav:home")],
        ]
    )


__all__ = ["now_playing_keyboard", "queue_keyboard"]

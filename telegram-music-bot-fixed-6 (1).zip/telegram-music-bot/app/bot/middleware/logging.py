"""Structured update logging middleware (message + callback_query)."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from time import monotonic
from typing import Any

from aiogram import BaseMiddleware

from app.logging import get_logger, log_extra

logger = get_logger(__name__)


def _event_type(event: Any) -> str:
    """Human name of the handled event object."""
    return type(event).__name__


def _chat_id(event: Any) -> int | None:
    """Best-effort chat id of the event (messages and callbacks)."""
    chat = getattr(event, "chat", None)
    if chat is not None:
        return getattr(chat, "id", None)
    message = getattr(event, "message", None)
    chat = getattr(message, "chat", None) if message is not None else None
    return getattr(chat, "id", None) if chat is not None else None


def _user_id(event: Any) -> int | None:
    """Best-effort sender id of the event."""
    user = getattr(event, "from_user", None)
    return getattr(user, "id", None) if user is not None else None


class LoggingMiddleware(BaseMiddleware):
    """Log every received update, its handling latency and handler errors.

    * ``bot.update_received`` (INFO) — event type, chat id, user id.
    * ``bot.update_processed`` (DEBUG) — latency in milliseconds.
    * ``bot.handler_error`` (ERROR) — the exception (re-raised afterwards).

    Register on both ``message`` and ``callback_query`` update types.
    """

    async def __call__(
        self,
        handler: Callable[[Any, dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: dict[str, Any],
    ) -> Any:
        started = monotonic()
        logger.info(
            "bot.update_received",
            extra=log_extra(
                event=_event_type(event),
                chat_id=_chat_id(event),
                user_id=_user_id(event),
            ),
        )
        try:
            result = await handler(event, data)
        except Exception as exc:  # noqa: BLE001 — log, then re-raise untouched
            logger.error(
                "bot.handler_error",
                extra=log_extra(
                    event=_event_type(event),
                    chat_id=_chat_id(event),
                    user_id=_user_id(event),
                    latency_ms=round((monotonic() - started) * 1000, 1),
                    error=type(exc).__name__,
                    detail=str(exc)[:200],
                ),
            )
            raise
        logger.debug(
            "bot.update_processed",
            extra=log_extra(
                event=_event_type(event),
                latency_ms=round((monotonic() - started) * 1000, 1),
            ),
        )
        return result


__all__ = ["LoggingMiddleware"]

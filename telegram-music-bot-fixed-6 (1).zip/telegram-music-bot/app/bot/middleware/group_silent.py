"""STRICT SILENT GROUP MODE — the middleware gate (binding, CONTRACTS §8).

In group/supergroup chats the bot processes a message **only** when it
carries a ``bot_command`` entity **addressed to this bot** (unqualified
commands like ``/play`` reach every bot in the chat and stay allowed;
``/play@SomeOtherBot`` is dropped). Everything else — plain chatter,
replies, service messages, media, mentions, commands for other bots — is
dropped *silently*: no answer, no logging side effects, nothing is ever
sent to the chat.

Private chats and channels always pass through.  Callback queries are not
touched by this middleware at all (they are explicit interactions).

The gate delegates the decision to the pure helpers in
:mod:`app.groups.silent_mode` and is kept tiny on purpose — it is the
single most important "never spam a group" guarantee of the platform.
"""

from __future__ import annotations

import contextlib
from collections.abc import Awaitable, Callable
from typing import Any

from aiogram import BaseMiddleware

from app.groups.silent_mode import (
    command_entity_texts,
    is_command_for_bot,
    should_process_group_message,
)
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Chat types the silent gate applies to.
GROUP_CHAT_TYPES = frozenset({"group", "supergroup"})


async def _bot_username(data: dict[str, Any]) -> str | None:
    """Best-effort this-bot username from the middleware workflow data.

    ``bot.me()`` is aiogram's *cached* getMe alias — the first call per bot
    instance performs one API request, every later call is local. When the
    username cannot be resolved the gate stays permissive for qualified
    commands (aiogram's own Command filters then reject mismatches).
    """
    bot = data.get("bot")
    if bot is None:
        return None
    with contextlib.suppress(Exception):
        me = await bot.me()
        return getattr(me, "username", None)
    return None


class GroupSilentMiddleware(BaseMiddleware):
    """Drop every group message that is not an explicit command for this bot.

    Register as an OUTER middleware on ``message`` updates (so it runs
    before filters and any other message middleware).
    """

    async def __call__(
        self,
        handler: Callable[[Any, dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: dict[str, Any],
    ) -> Any:
        chat = getattr(event, "chat", None)
        chat_type = getattr(chat, "type", None)
        if chat_type in GROUP_CHAT_TYPES:
            if not should_process_group_message(event):
                logger.debug(
                    "bot.group_silent_dropped",
                    extra=log_extra(
                        chat_id=getattr(chat, "id", None),
                        chat_type=chat_type,
                    ),
                )
                return None  # dropped — nothing is answered, nothing is sent
            # A bot_command entity exists — make sure it targets THIS bot.
            username = await _bot_username(data)
            if username is not None and not is_command_for_bot(
                command_entity_texts(event), username
            ):
                logger.debug(
                    "bot.group_silent_other_bot_command",
                    extra=log_extra(
                        chat_id=getattr(chat, "id", None),
                        chat_type=chat_type,
                    ),
                )
                return None
        return await handler(event, data)


__all__ = ["GROUP_CHAT_TYPES", "GroupSilentMiddleware"]

"""Authentication middlewares: maintenance gate and admin-panel guard.

* :class:`MaintenanceMiddleware` — registered for the ``message`` and
  ``callback_query`` observers. While global maintenance mode is on, only bot
  admins pass; group chats keep working while the ``groups_continue`` flag is
  set (group playback must not die mid-song). Everyone else is blocked:
  silently in groups (silent group mode — the bot never sends unsolicited
  group messages) and with a short notice in private chats.
* :class:`AdminGuardMiddleware` — registered for the ``callback_query``
  observer. Guards the ``adm:`` admin-panel callback namespace with a uniform
  denial message; it never reveals whether any other user is an admin.

Both middlewares read the service container from the aiogram workflow data
(``dispatcher["services"] = container``) and cache their database-backed
lookups in memory for a short TTL (60 seconds) so the hot path does not hit
the database on every single update.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from time import monotonic
from typing import Any

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from app.bot.services import ServiceContainer
from app.errors import AdminAccessDeniedError, MaintenanceError
from app.logging import get_logger, log_extra
from app.utils import is_group, safe_answer

logger = get_logger(__name__)

#: How long the maintenance state and admin-role lookups stay cached (seconds).
CACHE_TTL_SECONDS = 60.0

#: Uniform denial message for non-admins touching the admin panel.
ADMIN_PANEL_DENIED = AdminAccessDeniedError().user_message


class _TTLStore:
    """Minimal single-process TTL cache (no locks needed under asyncio)."""

    __slots__ = ("ttl", "_data")

    def __init__(self, ttl: float = CACHE_TTL_SECONDS) -> None:
        self.ttl = float(ttl)
        self._data: dict[Any, tuple[float, Any]] = {}

    def get(self, key: Any) -> Any | None:
        """Return the cached value for *key* or ``None`` when absent/expired."""
        entry = self._data.get(key)
        if entry is None:
            return None
        expires_at, value = entry
        if expires_at < monotonic():
            self._data.pop(key, None)
            return None
        return value

    def set(self, key: Any, value: Any) -> None:
        """Cache *value* for *key* using the store TTL."""
        self._data[key] = (monotonic() + self.ttl, value)


def _chat_type(event: TelegramObject) -> str | None:
    """Best-effort chat type of a message or callback query event."""
    if isinstance(event, Message):
        return getattr(event.chat, "type", None)
    if isinstance(event, CallbackQuery):
        message = event.message
        return getattr(getattr(message, "chat", None), "type", None)
    return None


def _user_id(event: TelegramObject) -> int | None:
    """Telegram id of the acting user (``None`` for channel/service events)."""
    user = getattr(event, "from_user", None)
    user_id = getattr(user, "id", None)
    return int(user_id) if isinstance(user_id, int) and user_id else None


class MaintenanceMiddleware(BaseMiddleware):
    """Global maintenance gate for messages and callback queries.

    Behaviour while maintenance mode is enabled:

    * bot admins (``services.admin.permissions.is_admin``) always pass;
    * group/supergroup updates pass while ``groups_continue`` is set
      (so ongoing group playback and its controls keep working);
    * everyone else is blocked — silently dropped in groups, a short
      :class:`~app.errors.MaintenanceError` notice in private chats, and a
      callback answer for callback queries.

    The maintenance state and the admin lookups are cached for
    :data:`CACHE_TTL_SECONDS` to avoid a database round trip per update.
    """

    def __init__(self, ttl: float = CACHE_TTL_SECONDS) -> None:
        super().__init__()
        self._ttl = float(ttl)
        self._maintenance: tuple[float, dict[str, bool]] | None = None
        self._admins = _TTLStore(self._ttl)

    # ------------------------------------------------------------------
    # Cached lookups
    # ------------------------------------------------------------------
    async def _maintenance_state(self, services: ServiceContainer) -> dict[str, bool]:
        """Return ``{'enabled': bool, 'groups_continue': bool}`` (TTL-cached)."""
        now = monotonic()
        if self._maintenance is None or self._maintenance[0] < now:
            try:
                state = await services.admin.settings.maintenance()
                clean = {
                    "enabled": bool(state.get("enabled", False)),
                    "groups_continue": bool(state.get("groups_continue", False)),
                }
            except Exception as exc:  # noqa: BLE001 — fail open, never crash updates
                logger.warning(
                    "auth.maintenance_lookup_failed",
                    extra=log_extra(error=str(exc)[:160]),
                )
                clean = {"enabled": False, "groups_continue": False}
            self._maintenance = (now + self._ttl, clean)
        return self._maintenance[1]

    async def _is_admin(self, services: ServiceContainer, user_id: int) -> bool:
        """Whether *user_id* holds a bot admin role (TTL-cached)."""
        cached = self._admins.get(user_id)
        if cached is not None:
            return bool(cached)
        try:
            result = bool(await services.admin.permissions.is_admin(int(user_id)))
        except Exception as exc:  # noqa: BLE001 — deny on lookup failures
            logger.warning(
                "auth.admin_lookup_failed",
                extra=log_extra(user_id=user_id, error=str(exc)[:160]),
            )
            result = False
        self._admins.set(user_id, result)
        return result

    # ------------------------------------------------------------------
    # Middleware entry point
    # ------------------------------------------------------------------
    async def __call__(
        self,
        handler: Callable[[TelegramObject], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        """Gate the update; return ``None`` (drop) or the handler result."""
        services = data.get("services")
        if services is None:
            # Container not wired — nothing this middleware can check.
            return await handler(event, data)

        user_id = _user_id(event)
        if user_id is None:
            # Channel posts / anonymous service events: no user to gate.
            return await handler(event, data)

        state = await self._maintenance_state(services)
        if not state.get("enabled"):
            return await handler(event, data)
        if await self._is_admin(services, user_id):
            return await handler(event, data)

        chat_type = _chat_type(event)
        if is_group(chat_type) and state.get("groups_continue"):
            # Group playback keeps running during maintenance.
            return await handler(event, data)

        # Blocked by maintenance.
        text = MaintenanceError().user_message
        if isinstance(event, CallbackQuery):
            await safe_answer(event, text)
            return None
        if is_group(chat_type):
            logger.info(
                "auth.maintenance_dropped_group_update",
                extra=log_extra(user_id=user_id, chat_type=chat_type),
            )
            return None  # silent group mode: never reply unsolicited
        try:
            await event.answer(text)
        except Exception as exc:  # noqa: BLE001 — user may have blocked the bot
            logger.debug(
                "auth.maintenance_notice_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
        return None


class AdminGuardMiddleware(BaseMiddleware):
    """Callback-level guard for the ``adm:`` admin-panel namespace.

    Non-admins pressing any ``adm:`` button receive a single uniform alert and
    the update is dropped. The message never reveals whether any other user is
    an admin. Registered on the ``callback_query`` observer; every other event
    type passes through untouched.
    """

    #: Callback-data namespace owned by the admin panel.
    ADMIN_PREFIX = "adm:"

    def __init__(self, ttl: float = CACHE_TTL_SECONDS) -> None:
        super().__init__()
        self._admins = _TTLStore(ttl)

    async def _is_admin(self, services: ServiceContainer, user_id: int) -> bool:
        """Whether *user_id* holds a bot admin role (TTL-cached)."""
        cached = self._admins.get(user_id)
        if cached is not None:
            return bool(cached)
        try:
            result = bool(await services.admin.permissions.is_admin(int(user_id)))
        except Exception as exc:  # noqa: BLE001 — fail closed
            logger.warning(
                "auth.admin_lookup_failed",
                extra=log_extra(user_id=user_id, error=str(exc)[:160]),
            )
            result = False
        self._admins.set(user_id, result)
        return result

    async def __call__(
        self,
        handler: Callable[[TelegramObject], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        """Drop ``adm:`` callbacks from non-admins; pass everything else."""
        if not isinstance(event, CallbackQuery):
            return await handler(event, data)
        raw = event.data or ""
        if not raw.startswith(self.ADMIN_PREFIX):
            return await handler(event, data)

        services = data.get("services")
        user_id = _user_id(event)
        if (
            services is not None
            and user_id is not None
            and await self._is_admin(services, user_id)
        ):
            return await handler(event, data)

        # Uniform denial — same answer for every non-admin (fail closed when
        # the container or the user is unknown).
        logger.info(
            "auth.admin_panel_denied",
            extra=log_extra(user_id=user_id),
        )
        await safe_answer(event, ADMIN_PANEL_DENIED, show_alert=True)
        return None


__all__ = [
    "ADMIN_PANEL_DENIED",
    "AdminGuardMiddleware",
    "CACHE_TTL_SECONDS",
    "MaintenanceMiddleware",
]

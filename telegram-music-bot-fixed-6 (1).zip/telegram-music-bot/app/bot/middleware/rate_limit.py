"""Rate limiting middleware for messages and callback queries.

Limits come from ``settings.rate_limits`` and are enforced through the
shared ``services.limiter`` fixed-window limiter:

* **commands** (messages carrying a bot command) — ``commands_per_minute``,
  bucket ``cmd:<user_id>``;
* **private non-command text** (i.e. search queries) — ``search_per_minute``,
  bucket ``search:<user_id>``;
* **other private messages** (uploads etc.) — ``heavy_per_minute``,
  bucket ``heavy:<user_id>``;
* **callback queries** (:class:`CallbackRateLimitMiddleware`) — the shared
  ``cmd:<user_id>`` bucket with ``commands_per_minute``.

Group behaviour: non-command group messages pass through uncounted — the
silent-group gate drops them anyway and this middleware must never answer a
message the bot is not allowed to see.

When limited, the middleware swallows the update and answers once with
:class:`app.errors.RateLimitedError`.user_message.  If the service
container is not available the middleware fails open (availability first).
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from aiogram import BaseMiddleware

from app.errors import RateLimitedError
from app.logging import get_logger, log_extra
from app.utils.telegram import safe_answer

logger = get_logger(__name__)

#: Chat types where non-command messages must never be answered here.
_GROUP_CHAT_TYPES = frozenset({"group", "supergroup"})

_RATE_LIMITED_TEXT = RateLimitedError().user_message


def _is_command(event: Any) -> bool:
    """True when the message carries a bot command (entity or leading slash)."""
    text = getattr(event, "text", None) or ""
    if text.startswith("/"):
        return True
    for container in (getattr(event, "entities", None), getattr(event, "caption_entities", None)):
        if not container:
            continue
        for entity in container:
            if getattr(entity, "type", None) == "bot_command":
                return True
    return False


class RateLimitMiddleware(BaseMiddleware):
    """Per-user rate limiting for ``message`` updates (outer middleware)."""

    async def __call__(
        self,
        handler: Callable[[Any, dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: dict[str, Any],
    ) -> Any:
        services = data.get("services")
        if services is None:  # fail open — never block on wiring problems
            return await handler(event, data)

        from_user = data.get("event_from_user") or getattr(event, "from_user", None)
        user_id = getattr(from_user, "id", None)
        if user_id is None:
            return await handler(event, data)

        limits = services.settings.rate_limits
        chat_type = getattr(getattr(event, "chat", None), "type", None)

        if chat_type in _GROUP_CHAT_TYPES and not _is_command(event):
            # The silent-group gate will drop it; never count or answer it.
            return await handler(event, data)

        if _is_command(event):
            kind, limit = "cmd", limits.commands_per_minute
        elif chat_type == "private" and getattr(event, "text", None):
            kind, limit = "search", limits.search_per_minute
        else:
            kind, limit = "heavy", limits.heavy_per_minute

        allowed = await services.limiter.check(f"{kind}:{user_id}", limit)
        if not allowed:
            logger.info(
                "bot.rate_limited",
                extra=log_extra(user_id=user_id, kind=kind, chat_type=chat_type),
            )
            answer = getattr(event, "answer", None)
            if callable(answer):
                try:
                    await answer(_RATE_LIMITED_TEXT)
                except Exception as exc:  # noqa: BLE001 — answering is best effort
                    logger.debug(
                        "bot.rate_limit_answer_failed",
                        extra=log_extra(error=str(exc)[:160]),
                    )
            return None
        return await handler(event, data)


class CallbackRateLimitMiddleware(BaseMiddleware):
    """Per-user rate limiting for ``callback_query`` updates.

    Callback taps share the ``cmd:<user_id>`` bucket with slash commands so
    a single budget covers all "explicit interactions".  When limited the
    callback is answered (non-alert toast) and dropped.
    """

    async def __call__(
        self,
        handler: Callable[[Any, dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: dict[str, Any],
    ) -> Any:
        services = data.get("services")
        if services is None:  # fail open
            return await handler(event, data)

        from_user = getattr(event, "from_user", None)
        user_id = getattr(from_user, "id", None)
        if user_id is None:
            return await handler(event, data)

        limit = services.settings.rate_limits.commands_per_minute
        allowed = await services.limiter.check(f"cmd:{user_id}", limit)
        if not allowed:
            logger.info(
                "bot.callback_rate_limited", extra=log_extra(user_id=user_id)
            )
            await safe_answer(event, _RATE_LIMITED_TEXT, show_alert=False)
            return None
        return await handler(event, data)


__all__ = [
    "CallbackRateLimitMiddleware",
    "RateLimitMiddleware",
]

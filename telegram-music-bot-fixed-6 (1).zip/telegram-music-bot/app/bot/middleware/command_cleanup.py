"""Best-effort deletion of recognized group command messages.

After a bot command addressed to THIS bot was handled in a group/supergroup
chat, the triggering message is deleted (when ``GROUP_COMMAND_AUTO_DELETE``
is enabled) so command noise disappears from the conversation — the pattern
established group music bots use to keep chats clean.

Hard safety rules:

* Only ``group``/``supergroup`` chats — private DM conversation messages
  are NEVER deleted (the DM flows are conversations, not commands).
* Only messages carrying a ``bot_command`` entity addressed to this bot
  (``/play`` or ``/play@ThisBot``; ``/play@OtherBot`` is left alone — the
  silent-mode gate already dropped it before the handler).
* Deletion is best-effort: missing ``delete_message`` permission, already
  deleted messages, Telegram API errors and handler exceptions never break
  command processing — the handler result is returned unchanged.
* Ordinary messages never reach this middleware's deletion path: it is an
  INNER middleware registered on ``message`` updates, and the group silent
  gate (outer) only lets addressed commands through in groups anyway.
"""

from __future__ import annotations

import contextlib
from collections.abc import Awaitable, Callable
from typing import Any

from aiogram import BaseMiddleware

from app.groups.silent_mode import command_entity_texts, is_command_for_bot
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Chat types where command auto-delete applies.
GROUP_CHAT_TYPES = frozenset({"group", "supergroup"})


def _command_targets_bot(event: Any, bot_username: str | None) -> bool:
    """True when the message's command entity is addressed to this bot.

    Unqualified commands (``/play``) target every bot in the chat and count
    as addressed; qualified commands must match this bot's username.
    """
    commands = command_entity_texts(event)
    if not commands:
        return False
    return is_command_for_bot(commands, bot_username)


class CommandAutoDeleteMiddleware(BaseMiddleware):
    """Delete recognized group command messages after they are handled.

    Register as an INNER middleware on ``message`` updates (it wraps the
    handler itself, running after the handler completes — success or
    exception alike — so cleanup never swallows results or errors).
    """

    async def __call__(
        self,
        handler: Callable[[Any, dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: dict[str, Any],
    ) -> Any:
        chat = getattr(event, "chat", None)
        chat_type = getattr(chat, "type", None)
        container = data.get("services")
        enabled = True
        if container is not None:
            enabled = bool(
                getattr(container.settings, "group_command_auto_delete", True)
            )
        eligible = chat_type in GROUP_CHAT_TYPES and enabled

        bot_username = None
        if eligible:
            bot = data.get("bot")
            if bot is not None:
                with contextlib.suppress(Exception):
                    me = await bot.me()
                    bot_username = getattr(me, "username", None)
            eligible = _command_targets_bot(event, bot_username)

        try:
            result = await handler(event, data)
        finally:
            if eligible:
                await self._delete_quietly(event, chat)
        return result

    @staticmethod
    async def _delete_quietly(event: Any, chat: Any) -> None:
        """Attempt ``delete_message``; every failure is swallowed silently."""
        message_id = getattr(event, "message_id", None)
        chat_id = getattr(chat, "id", None)
        if message_id is None or chat_id is None:
            return
        delete = getattr(event, "delete", None)
        try:
            if callable(delete):
                await delete()
            else:
                bot = getattr(event, "bot", None)
                if bot is None:
                    return
                await bot.delete_message(chat_id, message_id)
            logger.debug(
                "bot.command_deleted",
                extra=log_extra(chat_id=chat_id, message_id=message_id),
            )
        except Exception as exc:  # noqa: BLE001 — deletion must never break handling
            logger.debug(
                "bot.command_delete_failed",
                extra=log_extra(chat_id=chat_id, error=str(exc)[:160]),
            )


__all__ = ["CommandAutoDeleteMiddleware", "GROUP_CHAT_TYPES"]

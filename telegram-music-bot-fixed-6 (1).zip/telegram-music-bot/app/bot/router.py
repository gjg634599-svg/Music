"""Router aggregation — every handler module in registration order.

Order matters: private-chat handlers register specific filters, group
handlers are scoped to group chats, and the admin package is private-only.
Routers are included in one flat parent router which the dispatcher mounts.
"""

from __future__ import annotations

from aiogram import Router

from app.bot.callbacks import admin as admin_callbacks
from app.bot.callbacks import group as group_callbacks
from app.bot.callbacks import navigation
from app.bot.handlers import (
    account,
    commands,
    dm_play,
    group_private,
    groups,
    help as help_handlers,
    library,
    links,
    playback,
    playlists,
    search,
    start,
    stats,
    uploads,
)
from app.bot.handlers import admin as admin_handlers
from app.logging import get_logger

logger = get_logger(__name__)

_REGISTERED: list[str] = []
_SEEN_ROUTERS: set[int] = set()


def _include(parent: Router, module) -> None:
    """Include a module's router exactly once.

    Guards both module-name duplicates (re-export shims) and router-object
    duplicates (two module names pointing at the same router instance).
    """
    name = getattr(module, "__name__", str(module))
    router = getattr(module, "router", None)
    if name in _REGISTERED or (router is not None and id(router) in _SEEN_ROUTERS):
        return
    register = getattr(module, "register", None)
    if callable(register):
        register(parent)
    else:  # pragma: no cover - all modules expose register()
        parent.include_router(router)
    _REGISTERED.append(name)
    if router is not None:
        _SEEN_ROUTERS.add(id(router))


def build_router() -> Router:
    """Build the single parent router with every feature router attached.

    Safe to call repeatedly (e.g. from tests): the duplicate guard tracks
    registrations *within one build* — re-export shims can never register a
    router twice — while every new build assembles a fresh complete router.
    """
    global _REGISTERED, _SEEN_ROUTERS
    _REGISTERED = []
    _SEEN_ROUTERS = set()

    parent = Router(name="musicbot")

    # Personal core navigation.
    _include(parent, start)
    _include(parent, help_handlers)
    _include(parent, commands)
    _include(parent, navigation)

    # Personal music flows.
    _include(parent, search)
    _include(parent, uploads)
    _include(parent, links)
    _include(parent, dm_play)  # DM→group playback workflow (dm:/dmc:/trk:dest)
    _include(parent, playback)
    _include(parent, library)
    _include(parent, playlists)
    _include(parent, stats)
    _include(parent, account)

    # Group surface (commands + grp:* callbacks + silent membership sync).
    _include(parent, groups)
    _include(parent, group_callbacks)  # re-export guard: registers once
    _include(parent, group_private)

    # Admin panel (private chat only, guarded by middleware + /admin check).
    _include(parent, admin_handlers)
    _include(parent, admin_callbacks)  # re-export guard: registers once

    logger.info("bot.routers_registered", extra={"routers": len(_REGISTERED)})
    return parent

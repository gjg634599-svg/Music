"""Bot command registration (BotFather menu scopes).

Private chats and group chats get different command menus (CONTRACTS §8):
the personal menu is library/dashboard oriented, the group menu is the
voice-chat playback control set.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram import Bot
from aiogram.types import (
    BotCommand,
    BotCommandScopeAllGroupChats,
    BotCommandScopeDefault,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from aiogram.types import BotCommandScope


def private_commands() -> list[BotCommand]:
    """The command menu shown in private chats."""
    return [
        BotCommand(command="start", description="Dashboard — your music home"),
        BotCommand(command="search", description="Search for music"),
        BotCommand(command="playlists", description="Your playlists"),
        BotCommand(command="liked", description="Liked songs"),
        BotCommand(command="new", description="New releases"),
        BotCommand(command="history", description="Recently played"),
        BotCommand(command="mystats", description="Your listening stats"),
        BotCommand(command="settings", description="Playback preferences"),
        BotCommand(command="commands", description="All commands"),
        BotCommand(command="group", description="Add me to a group"),
        BotCommand(command="help", description="How it works"),
    ]


def group_commands() -> list[BotCommand]:
    """The command menu shown in group chats (voice-chat playback)."""
    return [
        BotCommand(command="play", description="Play a track in the voice chat"),
        BotCommand(command="search", description="Search for music"),
        BotCommand(command="new", description="Browse new releases, tap to queue"),
        BotCommand(command="queue", description="Show the group queue"),
        BotCommand(command="nowplaying", description="Now playing"),
        BotCommand(command="skip", description="Skip the current track"),
        BotCommand(command="pause", description="Pause playback"),
        BotCommand(command="resume", description="Resume playback"),
        BotCommand(command="stop", description="Stop and leave the voice chat"),
        BotCommand(command="shuffle", description="Toggle shuffle"),
        BotCommand(command="repeat", description="Cycle repeat mode"),
        BotCommand(command="volume", description="Set volume 0-100"),
        BotCommand(command="settings", description="Group music settings"),
        BotCommand(command="help", description="Group music help"),
    ]


def build_command_scopes() -> list[tuple[BotCommandScope, list[BotCommand]]]:
    """(scope, commands) pairs for :meth:`register_bot_commands`."""
    return [
        (BotCommandScopeDefault(), private_commands()),
        (BotCommandScopeAllGroupChats(), group_commands()),
    ]


async def register_bot_commands(bot: Bot) -> None:
    """Push the command menus to Telegram (default + all group chats)."""
    for scope, commands in build_command_scopes():
        await bot.set_my_commands(commands, scope=scope)


__all__ = [
    "build_command_scopes",
    "group_commands",
    "private_commands",
    "register_bot_commands",
]

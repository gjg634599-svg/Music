"""Animated private-chat search progress UX.

One status message per search, edited in place (never re-sent)::

    🔎 Searching Music
    Query: Bang bang
    ⏳ Finding matching tracks…
    Sources: Initializing

        ↓ spinner frames (same message, ~3 s apart)

    🔎 Searching Bang bang
    ◉ ○ ○ ○
    ✓ Local Library
    ◉ Checking remaining sources…

        ↓ after ~10 s (configurable text via bot message ``search_slow``)

    🎧 Still Searching…
    Query: Bang bang
    🥹 Babby, I'm trying hard!
    Some music sources are taking longer than usual.

        ↓ final (same message)

    🎵 Search Results … + the existing results keyboard

Design rules (master prompt §5):

* private-chat only — group searches never animate;
* the acknowledgement is sent immediately, before any provider call;
* only real provider states are shown — statuses update when the actual
  source operation completes, times out or fails; nothing is invented;
* no fake numeric progress — a lightweight spinner only;
* edits respect Telegram rate limits (``TelegramRetryAfter`` backs off)
  and are skipped when the rendered content has not changed;
* the animation task is tracked and always stopped on success, failure,
  timeout, cancellation or shutdown — no orphaned tasks;
* a new search from the same chat cancels the previous animation;
* user input is HTML-escaped (the bot's default parse mode).

The clock and sleeper are injectable so tests can verify the 10-second
escalation with a mocked clock instead of sleeping in real time.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from time import monotonic
from typing import Any

from app.logging import get_logger, log_extra
from app.utils.formatting import escape, truncate

logger = get_logger(__name__)

#: Spinner frames (music-themed, lightweight).
SPINNER_FRAMES = ("◉ ○ ○ ○", "○ ◉ ○ ○", "○ ○ ◉ ○", "○ ○ ○ ◉")

#: Default animation edit interval (seconds) — ~20 edits/minute stays well
#: inside Telegram's limits for a single chat.
DEFAULT_EDIT_INTERVAL = 3.0

#: Default delay before the "still searching" escalation (seconds).
DEFAULT_ESCALATION_AFTER = 10.0

#: Default slow-search text (admin-customizable via message key
#: ``search_slow`` — placeholders: none; the query is appended separately).
DEFAULT_ESCALATION_TEXT = (
    "🥹 Babby, I'm trying hard!\n\n"
    "Some music sources are taking longer than usual."
)

Clock = Callable[[], float]
Sleeper = Callable[[float], Awaitable[None]]

#: Active reporters per chat — a new search supersedes (cancels) an older
#: animation in the same chat so stale tasks can never overwrite newer ones.
_ACTIVE: dict[int, "SearchProgressReporter"] = {}


def cancel_active(chat_id: int) -> None:
    """Cancel the running animation for *chat_id* (new search supersedes)."""
    reporter = _ACTIVE.pop(int(chat_id), None)
    if reporter is not None:
        reporter.stop()


def _retry_after_of(exc: BaseException) -> float | None:
    """Extract ``retry_after`` from aiogram's TelegramRetryAfter-like errors."""
    value = getattr(exc, "retry_after", None)
    if isinstance(value, (int, float)) and value > 0:
        return float(value)
    return None


class SearchProgressReporter:
    """Edits one Telegram message through the phases of a music search."""

    def __init__(
        self,
        message: Any,
        query: str,
        *,
        source_names: list[str] | None = None,
        escalation_text: str = DEFAULT_ESCALATION_TEXT,
        edit_interval: float = DEFAULT_EDIT_INTERVAL,
        escalation_after: float = DEFAULT_ESCALATION_AFTER,
        clock: Clock = monotonic,
        sleeper: Sleeper = asyncio.sleep,
    ) -> None:
        self._message = message
        self._query = truncate(query.strip(), 80)
        self._source_names = list(source_names or [])
        self._escalation_text = escalation_text.strip() or DEFAULT_ESCALATION_TEXT
        self._edit_interval = max(0.5, float(edit_interval))
        self._escalation_after = max(0.0, float(escalation_after))
        self._clock = clock
        self._sleep = sleeper
        #: source name → "done" | "timeout" | "error"
        self._source_status: dict[str, str] = {}
        self._frame = 0
        self._escalated = False
        self._last_content: str | None = None
        self._task: asyncio.Task[None] | None = None
        self._status_message: Any = None
        self._stopped = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def start(self) -> Any:
        """Send the immediate acknowledgement and begin animating."""
        cancel_active(int(getattr(self._message.chat, "id", 0) or 0))
        self._status_message = await self._message.answer(
            self._ack_text(), parse_mode="HTML"
        )
        chat_id = int(getattr(self._message.chat, "id", 0) or 0)
        if chat_id:
            _ACTIVE[chat_id] = self
        self._task = asyncio.create_task(
            self._animate(), name=f"search-progress-{chat_id}"
        )
        logger.info(
            "bot.search.progress_started",
            extra=log_extra(chat_id=chat_id, query=self._query[:64]),
        )
        return self._status_message

    def stop(self) -> None:
        """Stop the animation (idempotent, never raises)."""
        self._stopped = True
        task, self._task = self._task, None
        if task is not None and not task.done():
            task.cancel()
        chat_id = int(getattr(self._message.chat, "id", 0) or 0)
        if _ACTIVE.get(chat_id) is self:
            _ACTIVE.pop(chat_id, None)

    @property
    def is_stopped(self) -> bool:
        return self._stopped

    @property
    def source_status(self) -> dict[str, str]:
        """Snapshot of the real per-source statuses seen so far."""
        return dict(self._source_status)

    @property
    def all_sources_failed(self) -> bool:
        """True when every source ended in error/timeout and none succeeded."""
        statuses = list(self._source_status.values())
        return bool(statuses) and all(
            status in ("error", "timeout") for status in statuses
        )

    # ------------------------------------------------------------------
    # Progress callback (wired to the SearchAggregator)
    # ------------------------------------------------------------------
    def on_progress(self, source_name: str, status: str, count: int) -> None:
        """Record a real source state change (called from the aggregator)."""
        self._source_status[source_name] = status

    # ------------------------------------------------------------------
    # Terminal states — always stop the animation first
    # ------------------------------------------------------------------
    async def finish_results(self, text: str, keyboard: Any) -> None:
        """Replace the progress message with the final results screen."""
        self.stop()
        await self._edit(text, keyboard)

    async def finish_empty(self, retry_keyboard: Any | None = None) -> None:
        """No tracks found (at least one source responded fine)."""
        self.stop()
        await self._edit(self._empty_text(), retry_keyboard)

    async def finish_error(self, retry_keyboard: Any | None = None) -> None:
        """All sources failed / timed out."""
        self.stop()
        await self._edit(self._error_text(), retry_keyboard)

    async def finish_exception(self, user_message: str) -> None:
        """Unexpected failure — friendly text, no internals leaked."""
        self.stop()
        await self._edit(f"⚠️ {escape(user_message)}", None)

    # ------------------------------------------------------------------
    # Animation loop
    # ------------------------------------------------------------------
    async def _animate(self) -> None:
        started = self._clock()
        try:
            while not self._stopped:
                now = self._clock()
                if self._escalated:
                    # Keep the “still searching” state, animate the spinner.
                    await self._edit(self._escalation_text_(spinner=True))
                elif now - started >= self._escalation_after:
                    self._escalated = True
                    await self._edit(self._escalation_text_())
                else:
                    await self._edit(self._spinner_text())
                await self._sleep(self._edit_interval)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 — animation must never crash search
            logger.debug(
                "bot.search.animation_failed",
                extra=log_extra(error=str(exc)[:120]),
            )

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------
    def _ack_text(self) -> str:
        lines = [
            "🔎 <b>Searching Music</b>",
            "",
            f"Query: {escape(self._query)}",
            "",
            "⏳ Finding matching tracks…",
            "",
            "Sources: Initializing",
        ]
        return "\n".join(lines)

    def _spinner_text(self) -> str:
        frame = SPINNER_FRAMES[self._frame % len(SPINNER_FRAMES)]
        self._frame += 1
        lines = [
            f"🔎 <b>Searching</b> {escape(self._query)}",
            frame,
        ]
        lines.extend(self._source_lines())
        return "\n".join(lines)

    def _escalation_text_(self, *, spinner: bool = False) -> str:
        lines = [
            "🎧 <b>Still Searching…</b>",
            "",
            f"Query: {escape(self._query)}",
            "",
            escape(self._escalation_text),
        ]
        if spinner:
            frame = SPINNER_FRAMES[self._frame % len(SPINNER_FRAMES)]
            self._frame += 1
            lines.append(frame)
        lines.extend(self._source_lines())
        return "\n".join(lines)

    def _source_lines(self) -> list[str]:
        """Provider-aware status block — real statuses only, never invented."""
        if not self._source_names:
            return []
        lines = [""]
        for name in self._source_names:
            status = self._source_status.get(name)
            if status == "done":
                lines.append(f"✓ {escape(name)}")
            elif status == "timeout":
                lines.append(f"⌛ {escape(name)} — timed out")
            elif status == "error":
                lines.append(f"✗ {escape(name)} — unavailable")
        reported = sum(1 for name in self._source_names if name in self._source_status)
        if reported < len(self._source_names):
            lines.append("◉ Checking remaining sources…")
        return lines

    def _empty_text(self) -> str:
        return (
            "🎵 <b>No Tracks Found</b>\n\n"
            f"Query: {escape(self._query)}\n\n"
            "Try another title, artist, or supported music source."
        )

    def _error_text(self) -> str:
        return (
            "⚠️ <b>Search Temporarily Unavailable</b>\n\n"
            "We couldn't reach the available music sources.\n\n"
            "Please try again shortly."
        )

    # ------------------------------------------------------------------
    # Editing (rate-limit aware, no-op when content unchanged)
    # ------------------------------------------------------------------
    async def _edit(self, text: str, keyboard: Any = None) -> None:
        if self._status_message is None or text == self._last_content:
            return
        self._last_content = text
        try:
            await self._status_message.edit_text(
                text, parse_mode="HTML", reply_markup=keyboard
            )
        except Exception as exc:  # noqa: BLE001 — Telegram edit errors are non-fatal
            retry_after = _retry_after_of(exc)
            if retry_after is not None and not self._stopped:
                try:
                    await self._sleep(min(retry_after, 15.0))
                    await self._status_message.edit_text(
                        text, parse_mode="HTML", reply_markup=keyboard
                    )
                except Exception:  # noqa: BLE001 — best effort only
                    pass
                return
            logger.debug(
                "bot.search.progress_edit_failed",
                extra=log_extra(error=str(exc)[:120]),
            )


__all__ = [
    "DEFAULT_EDIT_INTERVAL",
    "DEFAULT_ESCALATION_AFTER",
    "DEFAULT_ESCALATION_TEXT",
    "SPINNER_FRAMES",
    "SearchProgressReporter",
    "cancel_active",
]

"""Thin re-export of the admin router (structure compatibility layer).

Keeps the ``app/bot/callbacks/*`` package shape uniform: the router and its
``register`` helper live in ``app.bot.handlers.admin`` and are re-exported
here for callers that import from the callbacks package.
"""

from __future__ import annotations

from app.bot.handlers.admin import router, register

__all__ = ["router", "register"]

"""Group callback router — thin re-export (structure compatibility).

All group callbacks (``grp:*`` and the group-context ``trk:*`` buttons) live
in :mod:`app.bot.handlers.groups` on a single shared router. This module
re-exports that router so imports through the ``app.bot.callbacks`` package
keep working.

.. warning::
   This is the *same* router object as ``app.bot.handlers.groups.router`` —
   include it exactly once (``register`` is idempotent and safe to call from
   either module).
"""

from __future__ import annotations

from app.bot.handlers.groups import register, router

__all__ = ["register", "router"]

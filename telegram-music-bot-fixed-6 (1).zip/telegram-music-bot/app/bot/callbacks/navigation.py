"""Global navigation callbacks: home, cancel, help, commands.

``nav:home`` reconstructs the dashboard via
:func:`app.bot.handlers.start.render_dashboard` so every screen can return
"up" with a single callback.  ``nav:cancel`` additionally clears any
pending FSM state (search / playlist flows).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup

from app.bot.keyboards.common import back_button, edit_screen
from app.bot.handlers.start import render_dashboard
from app.utils import safe_answer

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer

router = Router(name="navigation")


async def _show_dashboard(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Edit the current message into the freshly rendered dashboard."""
    text, keyboard, _logo = await render_dashboard(
        services, callback.bot, callback.from_user
    )
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data == "nav:home")
async def on_nav_home(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Back to the dashboard."""
    await _show_dashboard(callback, services)


@router.callback_query(F.data == "nav:cancel")
async def on_nav_cancel(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Cancel any pending flow (FSM state + data) and return to the dashboard."""
    await state.clear()
    await _show_dashboard(callback, services)


@router.callback_query(F.data == "nav:help")
async def on_nav_help(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Help screen with a back-home button."""
    text = await services.admin.appearance.message("help")
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[back_button("nav:home")]])
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data == "nav:cmds")
async def on_nav_cmds(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Command reference screen with a back-home button."""
    text = await services.admin.appearance.message("commands")
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[back_button("nav:home")]])
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

"""Personal playback: Now Playing controls, queue view and track actions.

The Now Playing control message is owned by
:class:`app.playback.controller.PlaybackController` (it edits it on every
transport change).  The handlers here complement it:

* ``np:*`` callbacks — pause/resume/next/prev/shuffle/repeat/like/queue/close
  (the controller edits the message; these handlers answer the callback and,
  where the controller does not re-render, refresh the text themselves);
* ``q:*``   callbacks — the personal queue view (list, skip, shuffle, clear,
  remove item, paginate);
* ``trk:play/dl/share`` — start playback, download the file, share a deep
  link.  ``trk:like`` / ``trk:pl`` / ``trk:<id>`` / ``trk:back`` live in the
  search module (they are screen navigation, not transport).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiogram import F, Router
from aiogram.types import CallbackQuery, FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup

from app.bot.keyboards.common import back_button, edit_screen
from app.bot.keyboards.queue import now_playing_keyboard, queue_keyboard
from app.bot.keyboards.track import track_share_keyboard
from app.bot.handlers.search import artist_name
from app.errors import BotError, NothingPlayingError, RateLimitedError, TrackNotFoundError
from app.logging import get_logger, log_extra
from app.playback.queue import QueueOwner
from app.utils import (
    escape,
    format_duration,
    now_playing_text,
    queue_total_line,
    repeat_label,
    safe_answer,
    truncate,
    user_friendly_error,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer
    from app.database.models import Track

logger = get_logger(__name__)

#: Queue entries shown per page.
QUEUE_PAGE_SIZE = 8

#: Repeat-mode cycle order for np:rep.
_REPEAT_CYCLE = {"off": "all", "all": "one", "one": "off"}

router = Router(name="playback")


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
def _owner(callback: CallbackQuery) -> QueueOwner:
    """The personal queue owner of the callback sender."""
    return QueueOwner(kind="user", id=callback.from_user.id)


def _chat_id(callback: CallbackQuery) -> int:
    """Chat id the callback's message lives in (private chat)."""
    if callback.message is not None:
        return callback.message.chat.id
    return callback.from_user.id


def _np_text(payload: dict[str, Any], queue_size: int) -> str:
    """Render the Now Playing / Paused message body from a payload.

    Thin delegation to the ONE shared renderer — personal player, group
    control message and dashboard screen all share the same layout now.
    """
    track: "Track | None" = payload.get("track")
    if track is None or payload.get("status") not in ("playing", "paused"):
        return "ℹ️ Nothing is playing right now."
    return now_playing_text(
        track,
        position=int(payload.get("position_seconds") or 0),
        paused=payload.get("status") == "paused",
        session=_SessionBadges(payload),
        queue_size=queue_size,
    )


class _SessionBadges:
    """Duck-typed session view over a now-playing payload dict.

    Lets the shared :func:`now_playing_text` renderer read shuffle /
    repeat / autoplay badges straight from a payload without copying the
    dict into a session object.
    """

    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = payload

    @property
    def shuffle(self) -> bool:  # noqa: FBT001 — bool flag by design
        return bool(self._payload.get("shuffle"))

    @property
    def repeat_mode(self) -> str:
        return str(self._payload.get("repeat_mode") or "off")

    @property
    def autoplay(self) -> bool:  # noqa: FBT001 — bool flag by design
        return bool(self._payload.get("autoplay"))


async def _np_markup(
    services: "ServiceContainer", payload: dict[str, Any], tg_user_id: int
) -> InlineKeyboardMarkup:
    """Now Playing keyboard matching the current state (like included)."""
    track: "Track | None" = payload.get("track")
    liked = False
    if track is not None:
        liked = await services.library.is_liked(tg_user_id, track.id)
    return now_playing_keyboard(
        paused=payload.get("status") == "paused",
        liked=liked,
        group=False,
        shuffle=bool(payload.get("shuffle")),
        repeat_mode=str(payload.get("repeat_mode") or "off"),
    )


async def render_queue_view(
    services: "ServiceContainer", owner: QueueOwner, page: int = 1
) -> tuple[str, InlineKeyboardMarkup]:
    """The personal queue view: now playing + numbered up next + controls.

    UX details (mirroring the established chat-player patterns): every
    upcoming entry shows its duration, the footer totals the queue time
    (``5 in queue · ≈ 18 min``) and the toggles below carry their current
    state on the labels.
    """
    payload = await services.playback.now_playing(owner)
    items = await services.queue.get_queue(owner)
    total = len(items)
    total_pages = max(1, -(-total // QUEUE_PAGE_SIZE))
    page = max(1, min(page, total_pages))
    window = items[(page - 1) * QUEUE_PAGE_SIZE : page * QUEUE_PAGE_SIZE]

    # Resolve track rows for items whose relationship did not load.
    resolved: dict[int, "Track | None"] = {}
    for item in window:
        if getattr(item, "track", None) is None and item.track_id not in resolved:
            resolved[item.track_id] = await services.music.get_track(item.track_id)

    lines = ["📋 <b>YOUR QUEUE</b>", ""]
    track: "Track | None" = payload.get("track")
    durations: list[int | None] = []
    if track is not None and payload.get("status") in ("playing", "paused"):
        artist = artist_name(track)
        current = f"▶️ <b>{escape(track.title)}</b>"
        if artist:
            current += f" — {escape(artist)}"
        lines.append(current)
        lines.append("")

    if not window:
        lines.append("ℹ️ Queue is empty — add a track to keep going.")
    else:
        lines.append("⏭ <b>Up next</b>")
        for offset, item in enumerate(window):
            item_track = getattr(item, "track", None) or resolved.get(item.track_id)
            title = getattr(item_track, "title", None) or f"Track #{item.track_id}"
            artist = artist_name(item_track) if item_track is not None else ""
            duration = int(getattr(item_track, "duration_seconds", 0) or 0) if item_track is not None else 0
            durations.append(duration or None)
            line = f"{(page - 1) * QUEUE_PAGE_SIZE + offset + 1}. 🎵 <b>{escape(title)}</b>"
            if artist:
                line += f" — {escape(artist)}"
            if duration > 0:
                line += f" · {format_duration(duration)}"
            lines.append(line)
    lines.append("")
    lines.append(f"{queue_total_line(durations)} · Page {page}/{total_pages}")

    session = await services.sessions.get(owner)
    rows: list[list[InlineKeyboardButton]] = []
    for offset, item in enumerate(window):
        item_track = getattr(item, "track", None) or resolved.get(item.track_id)
        track_id = item.track_id
        title = getattr(item_track, "title", None) or f"Track #{track_id}"
        number = (page - 1) * QUEUE_PAGE_SIZE + offset + 1
        rows.append(
            [
                InlineKeyboardButton(
                    text=truncate(f"{number}. {title}", 40),
                    callback_data=f"trk:{track_id}",
                ),
                InlineKeyboardButton(
                    text="✖️", callback_data=f"q:rm:{item.id}"
                ),
            ]
        )
    markup = queue_keyboard(
        shuffle=bool(getattr(session, "shuffle", False)),
        repeat_mode=str(getattr(session, "repeat_mode", "off") or "off"),
    )
    if total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if page > 1:
            nav.append(
                InlineKeyboardButton(text="⬅️", callback_data=f"q:page:{page - 1}")
            )
        if page < total_pages:
            nav.append(
                InlineKeyboardButton(text="➡️", callback_data=f"q:page:{page + 1}")
            )
        if nav:
            markup.inline_keyboard.insert(0, nav)
    markup.inline_keyboard[0:0] = rows
    return "\n".join(lines), markup


async def _edit_queue_view(
    callback: CallbackQuery, services: "ServiceContainer", page: int = 1
) -> None:
    owner = _owner(callback)
    text, keyboard = await render_queue_view(services, owner, page)
    await edit_screen(callback.message, text, keyboard)


# ----------------------------------------------------------------------
# np: transport callbacks
# ----------------------------------------------------------------------
@router.callback_query(F.data == "np:pause")
async def on_np_pause(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Pause the personal session (the controller edits the message)."""
    try:
        await services.playback.pause(_owner(callback), callback.bot)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, "⏸ Paused")


@router.callback_query(F.data == "np:resume")
async def on_np_resume(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Resume the paused personal session."""
    try:
        await services.playback.resume(_owner(callback), _chat_id(callback), callback.bot)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, "▶️ Resumed")


@router.callback_query(F.data == "np:next")
async def on_np_next(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Skip to the next queued track (autoplay/finish handled by controller)."""
    try:
        await services.playback.next(
            _owner(callback), _chat_id(callback), callback.bot, manual=True, skip=True
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, "⏭ Skipped")


@router.callback_query(F.data == "np:prev")
async def on_np_prev(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Restart the current track from the beginning (honest prev)."""
    owner = _owner(callback)
    payload = await services.playback.now_playing(owner)
    track: "Track | None" = payload.get("track")
    if track is None or payload.get("status") not in ("playing", "paused"):
        await safe_answer(callback, NothingPlayingError().user_message)
        return
    try:
        await services.playback.play_now(
            owner,
            _chat_id(callback),
            callback.bot,
            track.id,
            callback.from_user.id,
            edit_message=callback.message,
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, "⏮ Restarted")


@router.callback_query(F.data == "np:shuf")
async def on_np_shuffle(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Toggle session shuffle and re-render the Now Playing message."""
    owner = _owner(callback)
    session = await services.sessions.get(owner)
    try:
        enabled = await services.playback.set_shuffle(owner, not session.shuffle)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    payload = await services.playback.now_playing(owner)
    text = _np_text(payload, int(payload.get("queue_size") or 0))
    markup = await _np_markup(services, payload, callback.from_user.id)
    await edit_screen(callback.message, text, markup)
    await safe_answer(callback, "🔀 Shuffle on" if enabled else "🔀 Shuffle off")


@router.callback_query(F.data == "np:rep")
async def on_np_repeat(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Cycle repeat off → all → one and re-render the Now Playing message."""
    owner = _owner(callback)
    session = await services.sessions.get(owner)
    mode = _REPEAT_CYCLE.get(session.repeat_mode or "off", "all")
    try:
        await services.playback.set_repeat(owner, mode)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    payload = await services.playback.now_playing(owner)
    text = _np_text(payload, int(payload.get("queue_size") or 0))
    markup = await _np_markup(services, payload, callback.from_user.id)
    await edit_screen(callback.message, text, markup)
    await safe_answer(callback, f"🔁 Repeat: {repeat_label(mode)}")


@router.callback_query(F.data == "np:like")
async def on_np_like(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Toggle the like state of the current track."""
    owner = _owner(callback)
    payload = await services.playback.now_playing(owner)
    track: "Track | None" = payload.get("track")
    if track is None:
        await safe_answer(callback, NothingPlayingError().user_message)
        return
    try:
        liked = await services.library.toggle_like(callback.from_user.id, track.id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    markup = now_playing_keyboard(
        paused=payload.get("status") == "paused", liked=liked, group=False
    )
    try:  # refresh just the keyboard — best effort
        if callback.message is not None:
            await callback.message.edit_reply_markup(reply_markup=markup)
    except Exception:  # noqa: BLE001 — old messages cannot be edited
        pass
    await safe_answer(callback, "❤️ Liked" if liked else "💔 Unliked")


@router.callback_query(F.data == "np:queue")
async def on_np_queue(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Switch the Now Playing message into the queue view."""
    await _edit_queue_view(callback, services)
    await safe_answer(callback)


@router.callback_query(F.data == "np:close")
async def on_np_close(callback: CallbackQuery) -> None:
    """Close (delete) the Now Playing message."""
    try:
        if callback.message is not None:
            await callback.message.delete()
    except Exception as exc:  # noqa: BLE001 — already deleted / too old
        logger.debug("bot.np_close_failed", extra=log_extra(error=str(exc)[:120]))
    await safe_answer(callback, "Closed")


# ----------------------------------------------------------------------
# q: queue view callbacks
# ----------------------------------------------------------------------
@router.callback_query(F.data == "q:home")
async def on_queue_home(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Open the personal queue view (first page)."""
    await _edit_queue_view(callback, services)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(r"^q:page:\d+$"))
async def on_queue_page(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Paginate the personal queue view."""
    page = int(str(callback.data).rsplit(":", 1)[1])
    await _edit_queue_view(callback, services, max(1, page))
    await safe_answer(callback)


@router.callback_query(F.data == "q:skip")
async def on_queue_skip(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Skip from the queue view; the controller re-renders the player."""
    owner = _owner(callback)
    try:
        await services.playback.next(
            owner, _chat_id(callback), callback.bot, manual=True, skip=True
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, "⏭ Skipped")


@router.callback_query(F.data == "q:shuf")
async def on_queue_shuffle(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Toggle shuffle and re-render the queue view."""
    owner = _owner(callback)
    session = await services.sessions.get(owner)
    try:
        enabled = await services.playback.set_shuffle(owner, not session.shuffle)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await _edit_queue_view(callback, services)
    await safe_answer(callback, "🔀 Shuffle on" if enabled else "🔀 Shuffle off")


@router.callback_query(F.data == "q:rep")
async def on_queue_repeat(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Cycle repeat off → all → one and re-render the queue view."""
    owner = _owner(callback)
    session = await services.sessions.get(owner)
    mode = _REPEAT_CYCLE.get(session.repeat_mode or "off", "all")
    try:
        await services.playback.set_repeat(owner, mode)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await _edit_queue_view(callback, services)
    await safe_answer(callback, f"🔁 Repeat: {repeat_label(mode)}")


@router.callback_query(F.data == "q:clear")
async def on_queue_clear(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Remove every queued (upcoming) track; playback keeps its current song."""
    owner = _owner(callback)
    removed = await services.queue.clear(owner)
    logger.info("bot.queue_cleared", extra=log_extra(user_id=owner.id, removed=removed))
    await edit_screen(callback.message, "📋 <b>Queue cleared.</b>")
    await safe_answer(callback, "📋 Queue cleared")


@router.callback_query(F.data.regexp(r"^q:rm:\d+$"))
async def on_queue_remove(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Remove one queued item and re-render the queue view."""
    owner = _owner(callback)
    item_id = int(str(callback.data).rsplit(":", 1)[1])
    removed = await services.queue.remove(owner, item_id)
    if not removed:
        await safe_answer(callback, "ℹ️ Item is no longer in the queue.")
    else:
        await safe_answer(callback, "✖️ Removed from queue")
    await _edit_queue_view(callback, services)


# ----------------------------------------------------------------------
# Dashboard entries (Now Playing / Queue)
# ----------------------------------------------------------------------
@router.callback_query(F.data == "dash:np", F.message.chat.type == "private")
async def on_dash_now_playing(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Dashboard → Now Playing: the user's personal session state."""
    owner = _owner(callback)
    try:
        payload = await services.playback.now_playing(owner)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    track: "Track | None" = payload.get("track")
    if track is None or payload.get("status") not in ("playing", "paused"):
        text = (
            "🎧 <b>NOW PLAYING</b>\n\n"
            "ℹ️ Nothing is playing right now.\n\n"
            "Search for a song and press <b>Play</b> — in a private chat you "
            "can play the audio file here, or route it to a group voice chat."
        )
        await edit_screen(
            callback.message,
            text,
            InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🔎 Search Music", callback_data="dash:search"
                        ),
                        back_button("nav:home"),
                    ]
                ]
            ),
        )
        await safe_answer(callback)
        return
    queue_size = int(payload.get("queue_size") or 0)
    text = _np_text(payload, queue_size)
    markup = await _np_markup(services, payload, callback.from_user.id)
    await edit_screen(callback.message, text, markup)
    await safe_answer(callback)


@router.callback_query(F.data == "dash:queue", F.message.chat.type == "private")
async def on_dash_queue(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Dashboard → the personal queue view."""
    await _edit_queue_view(callback, services)
    await safe_answer(callback)


# ----------------------------------------------------------------------
# Track actions
# ----------------------------------------------------------------------
async def _get_track(
    callback: CallbackQuery, services: "ServiceContainer", track_id: int
) -> "Track | None":
    try:
        return await services.music.get_track(track_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return None


@router.callback_query(
    F.data.regexp(r"^trk:play:\d+$"), F.message.chat.type == "private"
)
async def on_track_play(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Play now (idle) or enqueue at the end of the personal queue.

    Private-chat scope ONLY: group-context ``trk:play`` buttons are owned
    by the groups router (voice-chat playback). Without this filter the
    personal handler swallowed group button presses first (router
    registration order) and played into the wrong target.
    """
    track_id = int(str(callback.data).rsplit(":", 1)[1])
    track = await _get_track(callback, services, track_id)
    if track is None:
        await safe_answer(callback, TrackNotFoundError().user_message)
        return
    owner = _owner(callback)
    chat_id = _chat_id(callback)
    try:
        session = await services.sessions.get(owner)
        size = await services.queue.size(owner)
        if session.status in ("idle", "stopped") and size == 0:
            await services.playback.play_now(
                owner,
                chat_id,
                callback.bot,
                track.id,
                callback.from_user.id,
                edit_message=callback.message,
            )
            await safe_answer(callback, "▶️ Now playing")
            return
        position = await services.playback.enqueue(
            owner, chat_id, callback.bot, track.id, callback.from_user.id
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, f"➕ Added — position #{position}")


@router.callback_query(
    F.data.regexp(r"^trk:dl:\d+$"), F.message.chat.type == "private"
)
async def on_track_download(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Send the track's audio file to the chat (heavy-limited inline)."""
    track_id = int(str(callback.data).rsplit(":", 1)[1])
    limit = services.settings.rate_limits.heavy_per_minute
    allowed = await services.limiter.check(f"dl:{callback.from_user.id}", limit)
    if not allowed:
        await safe_answer(callback, RateLimitedError().user_message)
        return
    track = await _get_track(callback, services, track_id)
    if track is None:
        await safe_answer(callback, TrackNotFoundError().user_message)
        return
    await safe_answer(callback, "⬇️ Sending…")

    chat_id = _chat_id(callback)
    try:
        if track.audio_file_id:
            sent = await callback.bot.send_audio(chat_id, audio=track.audio_file_id)
        else:
            path = await services.music.get_playable_path(track)
            sent = await callback.bot.send_audio(
                chat_id,
                audio=FSInputFile(str(path)),
                title=truncate(track.title, 64) or None,
                performer=truncate(artist_name(track), 64) or None,
                duration=int(track.duration_seconds or 0) or None,
            )
            await services.music.ensure_audio_file_id(track, callback.bot, sent)
    except Exception as exc:  # noqa: BLE001 — surface a friendly error
        logger.warning(
            "bot.download_failed",
            extra=log_extra(track_id=track.id, error=str(exc)[:160]),
        )
        if callback.message is not None:
            await callback.message.answer(
                user_friendly_error(exc), parse_mode="HTML"
            )
        return
    logger.info("bot.track_downloaded", extra=log_extra(track_id=track.id))


@router.callback_query(
    F.data.regexp(r"^trk:share:\d+$"), F.message.chat.type == "private"
)
async def on_track_share(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Send a shareable deep link for the track."""
    track_id = int(str(callback.data).rsplit(":", 1)[1])
    track = await _get_track(callback, services, track_id)
    if track is None:
        await safe_answer(callback, TrackNotFoundError().user_message)
        return
    me = await callback.bot.me()
    username = (me.username or "").lstrip("@")
    link = f"https://t.me/{username}?start=track_{track.id}"
    text = (
        "📤 <b>SHARE TRACK</b>\n\n"
        f"🎵 <b>{escape(track.title)}</b>\n"
    )
    artist = artist_name(track)
    if artist:
        text += f"🎤 {escape(artist)}\n"
    text += f"\n{escape(link)}"
    keyboard = track_share_keyboard(link)
    if callback.message is not None:
        await callback.message.answer(text, parse_mode="HTML", reply_markup=keyboard)
    await safe_answer(callback)


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

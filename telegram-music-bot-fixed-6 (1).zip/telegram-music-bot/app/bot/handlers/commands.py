"""/commands — the customizable command list (private chats)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import Message

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer

router = Router(name="commands")


@router.message(Command("commands"), F.chat.type == "private")
async def cmd_commands(message: Message, services: ServiceContainer) -> None:
    """/commands — show the full command reference."""
    text = await services.admin.appearance.message("commands")
    await message.answer(text, parse_mode="HTML")


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

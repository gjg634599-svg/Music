"""Private audio uploads: validate → download → register in the catalog.

Security notes:

* uploads are validated with
  :func:`app.security.validation.validate_audio_upload` (mime, extension,
  size) before anything is fetched;
* the Telegram file is streamed through the bot's own aiohttp session with
  a hard byte cap; the download URL embeds the bot token and is **never**
  logged;
* the file lands in the storage ``tmp/`` directory under a sanitized unique
  name and is moved into ``music/`` by ``MusicService.register_upload``;
* the temporary copy is always removed, even when registration fails.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import aiohttp
from aiogram import F, Router
from aiogram.types import Message

from app.bot.keyboards.track import track_page_keyboard
from app.errors import BotError, FileTooLargeError
from app.logging import get_logger, log_extra
from app.music.models import AudioMetadata
from app.music.sources.url_resolver import stream_download
from app.security.validation import validate_audio_upload
from app.utils import escape, truncate, user_friendly_error

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer

logger = get_logger(__name__)

router = Router(name="uploads")


async def _download_telegram_file(
    bot: Any, file_path: str, target: Path, max_bytes: int, timeout_seconds: int
) -> None:
    """Stream a Telegram file to *target* enforcing the size cap.

    The URL (which embeds the bot token) is built inside this function and
    deliberately never logged or included in exceptions.
    """
    session = getattr(bot, "session", None)
    create_session = getattr(session, "create_session", None)
    file_url = getattr(getattr(session, "api", None), "file_url", None)
    if session is not None and callable(create_session) and callable(file_url):
        url = file_url(bot.token, file_path)  # noqa: S106 — must stay unlogged
        http = await create_session()
        timeout = aiohttp.ClientTimeout(total=max(60, timeout_seconds * 3))
        await stream_download(url, http, timeout, target, max_bytes)
        return

    # Fallback for custom session implementations: aiogram's own downloader
    # (no streaming cap — enforce the limit on the finished file instead).
    await bot.download_file(file_path, destination=target, timeout=timeout_seconds)
    if target.stat().st_size > max_bytes:
        target.unlink(missing_ok=True)
        raise FileTooLargeError("Uploaded file exceeds the configured size cap")


@router.message(
    F.chat.type == "private",
    F.audio | (F.document & F.document.mime_type.startswith("audio/")),
)
async def on_audio_upload(message: Message, services: ServiceContainer) -> None:
    """Handle a private audio file upload (``audio`` or audio document)."""
    tg_user_id = message.from_user.id if message.from_user else 0
    media = message.audio or message.document
    file_name = (getattr(media, "file_name", None) or "upload.mp3").strip() or "upload.mp3"
    mime_type = getattr(media, "mime_type", None)
    size = int(getattr(media, "file_size", 0) or 0)
    max_bytes = services.settings.max_audio_size_mb * 1024 * 1024

    try:
        validate_audio_upload(
            mime_type=mime_type,
            file_name=file_name,
            size=size,
            max_size_bytes=max_bytes,
        )
    except BotError as exc:
        await message.answer(exc.user_message, parse_mode="HTML")
        return

    target = services.storage.tmp_dir() / services.storage.unique_name(
        file_name, prefix="upload-"
    )
    try:
        file = await message.bot.get_file(media.file_id)
        await _download_telegram_file(
            message.bot,
            file.file_path,
            target,
            max_bytes,
            services.settings.http_timeout,
        )

        if message.audio is not None:
            meta = AudioMetadata(
                title=truncate(message.audio.title or "", 256) or None,
                artist=truncate(message.audio.performer or "", 256) or None,
                duration_seconds=int(message.audio.duration or 0),
            )
        else:
            meta = AudioMetadata()

        track = await services.music.register_upload(
            tg_user_id, str(target), file_name, meta
        )
    except BotError as exc:
        logger.warning(
            "bot.upload_failed",
            extra=log_extra(user_id=tg_user_id, error=str(exc)[:160]),
        )
        await message.answer(exc.user_message, parse_mode="HTML")
        return
    except Exception as exc:  # noqa: BLE001 — network / Telegram failures
        logger.error(
            "bot.upload_error",
            extra=log_extra(user_id=tg_user_id, error=str(exc)[:200]),
        )
        await message.answer(user_friendly_error(exc), parse_mode="HTML")
        return
    finally:
        target.unlink(missing_ok=True)

    await services.analytics.track(
        "upload_received",
        user_id=tg_user_id,
        track_id=track.id,
        payload={"bytes": size, "mime": mime_type or ""},
    )
    from app.bot.handlers.search import artist_name

    text = "✅ <b>MUSIC RECEIVED</b>\n\n"
    text += f"🎵 <b>{escape(track.title)}</b>\n"
    artist = artist_name(track)
    if artist:
        text += f"🎤 {escape(artist)}"
    keyboard = track_page_keyboard(track.id, liked=False)
    await message.answer(text.strip(), parse_mode="HTML", reply_markup=keyboard)
    logger.info(
        "bot.upload_registered", extra=log_extra(track_id=track.id, user_id=tg_user_id)
    )


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

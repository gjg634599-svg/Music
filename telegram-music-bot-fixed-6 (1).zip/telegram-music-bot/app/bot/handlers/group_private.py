"""Private-chat group onboarding: the ``/group`` command and its callbacks.

This is the target of the ``dash:group`` dashboard button (Task 3-a) and the
``add:group`` URL-button namespace. The screen explains how to add the bot to
a group and what a voice chat is needed for; it never sends anything to
groups itself.
"""

from __future__ import annotations

from typing import Any

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.logging import get_logger, log_extra
from app.utils import safe_answer

logger = get_logger(__name__)

router = Router(name="group_private")

#: Onboarding instructions (HTML).
GROUP_ADD_TEXT = (
    "➕ <b>ADD ME TO A GROUP</b>\n\n"
    "1️⃣ Tap <b>Add Me to Group</b> below and pick a group.\n"
    "2️⃣ Start a voice chat in that group (🎙️).\n"
    "3️⃣ Use /play &lt;song&gt; in the group — I'll join the voice chat and "
    "stream the music for everyone.\n\n"
    "🎛️ Playback is controlled with /skip, /pause, /resume, /queue and /stop.\n"
    "🔇 Silent mode keeps the chat clean — I only answer commands and buttons, "
    "never spam.\n\n"
    "🎙️ <b>Note:</b> music plays in the group voice chat — start one before "
    "/play."
)


def _add_group_keyboard(bot_username: str | None) -> InlineKeyboardMarkup:
    """Inline keyboard with the deep-link "add me" button."""
    builder = InlineKeyboardBuilder()
    username = (bot_username or "").strip().lstrip("@")
    if username:
        builder.button(
            text="➕ Add Me to Group",
            url=f"https://t.me/{username}?startgroup=true",
        )
    return builder.as_markup()


async def _edit_screen(callback: CallbackQuery) -> None:
    """Answer the callback and edit its message to the onboarding screen."""
    await safe_answer(callback)
    try:
        me = await callback.bot.me()
    except Exception as exc:  # noqa: BLE001 — fall back without the button
        logger.warning(
            "group_private.get_me_failed",
            extra=log_extra(error=str(exc)[:160]),
        )
        me = None
    message: Any = callback.message
    if message is None:
        return
    try:
        await message.edit_text(
            GROUP_ADD_TEXT,
            parse_mode="HTML",
            reply_markup=_add_group_keyboard(getattr(me, "username", None)),
        )
    except Exception as exc:  # noqa: BLE001 — old/unreadable messages
        logger.debug(
            "group_private.edit_failed",
            extra=log_extra(error=str(exc)[:160]),
        )


@router.message(Command("group"), F.chat.type == "private")
async def cmd_group(message: Message) -> None:
    """Handle ``/group`` in private chats — add-to-group instructions."""
    try:
        me = await message.bot.me()
        username = getattr(me, "username", None)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "group_private.get_me_failed",
            extra=log_extra(error=str(exc)[:160]),
        )
        username = None
    try:
        await message.answer(
            GROUP_ADD_TEXT,
            parse_mode="HTML",
            reply_markup=_add_group_keyboard(username),
        )
    except Exception as exc:  # noqa: BLE001 — the user may have blocked the bot
        logger.warning(
            "group_private.send_failed",
            extra=log_extra(error=str(exc)[:160]),
        )


@router.callback_query(F.data == "add:group", F.message.chat.type == "private")
async def cb_add_group(callback: CallbackQuery) -> None:
    """``add:group`` — edit to the onboarding screen (private chats only)."""
    await _edit_screen(callback)


@router.callback_query(F.data == "dash:group", F.message.chat.type == "private")
async def cb_dash_group(callback: CallbackQuery) -> None:
    """``dash:group`` — dashboard entry point to the onboarding screen."""
    await _edit_screen(callback)


def register(parent: Router) -> None:
    """Include this module's router exactly once (idempotent)."""
    if router not in parent.sub_routers:
        parent.include_router(router)


__all__ = ["GROUP_ADD_TEXT", "register", "router"]

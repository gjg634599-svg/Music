"""Private link processing: resolve a music URL into a track page.

Only the first URL entity of the message is processed.  The flow respects
the ``url_processing`` feature flag (admin settings) and maps resolver
errors to their user-friendly messages:

* ``ValidationError``        → "Invalid link" (SSRF guard, malformed URL),
* ``UnsupportedUrlError``    → unsupported source,
* ``UnauthorizedSourceError``→ DRM-protected source,
* other ``BotError``         → download/size failures.

**State exclusion (DM→group workflow):** while the user is answering the
bot's "send the group link" prompt (``DmPlayFSM.waiting_link``), any link
they send is a GROUP DESTINATION — not a music-source URL.  The handler
therefore excludes that state so the DM-play router receives the message;
without it the music resolver used to intercept e.g. ``t.me/call/...``
and answer "only links from authorized music sources are supported",
which is wrong for that step of the conversation.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from urllib.parse import urlparse

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.types import Message

from app.bot.handlers.dm_play import DmPlayFSM
from app.bot.handlers.search import first_url_entity, render_track_page
from app.errors import BotError, ValidationError
from app.logging import get_logger, log_extra
from app.utils import user_friendly_error

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer

logger = get_logger(__name__)

#: Feature flag guarding this flow.
FEATURE_KEY = "url_processing"

#: Human text when the feature is switched off by an admin.
_DISABLED_TEXT = "🔗 Link processing is currently disabled."

#: Text for links the SSRF/URL validator rejects.
_INVALID_LINK_TEXT = "❌ Invalid link."

router = Router(name="links")


def has_link_entity(message: Message) -> bool:
    """Filter: the message text contains a url / text_link entity."""
    return first_url_entity(message) is not None


@router.message(
    F.chat.type == "private",
    F.text,
    ~F.text.startswith("/"),
    ~StateFilter(DmPlayFSM.waiting_link),
    has_link_entity,
)
async def on_link_message(message: Message, services: ServiceContainer) -> None:
    """Resolve the first URL of the message and show the track page.

    Skipped entirely while the DM→group workflow waits for a group
    destination link (see the module docstring's state-exclusion note).
    """
    tg_user_id = message.from_user.id if message.from_user else 0
    url = first_url_entity(message) or ""
    flags = await services.admin.settings.feature_flags()
    if not flags.get(FEATURE_KEY, True):
        await message.answer(_DISABLED_TEXT, parse_mode="HTML")
        return

    try:
        track = await services.music.resolve_url(url)
    except ValidationError:
        await message.answer(_INVALID_LINK_TEXT, parse_mode="HTML")
        return
    except BotError as exc:
        await message.answer(exc.user_message, parse_mode="HTML")
        return
    except Exception as exc:  # noqa: BLE001 — resolver/network failures
        logger.warning(
            "bot.link_resolve_failed", extra=log_extra(error=str(exc)[:160])
        )
        await message.answer(user_friendly_error(exc), parse_mode="HTML")
        return

    host = urlparse(url).hostname or ""
    await services.analytics.track(
        "url_resolve", user_id=tg_user_id, track_id=track.id, payload={"host": host}
    )
    text, keyboard = await render_track_page(services, tg_user_id, track)
    text = "🎵 <b>TRACK FOUND</b>\n\n" + text
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)
    logger.info(
        "bot.link_resolved", extra=log_extra(track_id=track.id, host=host)
    )


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

"""Private search flow: query → numbered results → track pages.

This module also owns the shared track-page rendering used by the upload,
link and deep-link flows, plus the :class:`SearchFSM` state group.

FSM data keys (JSON-serializable, works with every aiogram storage):

* ``search_ids``   — list[int] track ids of the last search,
* ``search_query`` — the raw query text,
* ``search_page``  — current 0-based results page,
* ``mode``         — ``"playlist_add"`` when results taps add to a playlist,
* ``playlist_id``  — target playlist for ``playlist_add`` mode.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiogram import F, Router
from aiogram.filters import Command, CommandObject, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message

from app.bot.keyboards.common import edit_screen
from app.bot.keyboards.start import search_prompt_keyboard
from app.bot.keyboards.track import (
    SEARCH_PAGE_SIZE,
    search_results_keyboard,
    track_page_keyboard,
)
from app.bot.search_progress import SearchProgressReporter, cancel_active
from app.errors import BotError, TrackNotFoundError
from app.logging import get_logger, log_extra
from app.utils import (
    escape,
    format_duration,
    paginate,
    safe_answer,
    track_line,
    truncate,
    user_friendly_error,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer
    from app.database.models import Track

logger = get_logger(__name__)

#: Maximum accepted query length (characters).
SEARCH_QUERY_LIMIT = 256

#: Tracks fetched per search (2 pages of SEARCH_PAGE_SIZE).
SEARCH_RESULTS_LIMIT = 10

#: Entity types treated as "this message is a link".
_LINK_ENTITY_TYPES = frozenset({"url", "text_link"})


class SearchFSM(StatesGroup):
    """States of the private search conversation."""

    query = State()


router = Router(name="search")


# ----------------------------------------------------------------------
# Shared helpers (used by uploads / links / start / playback)
# ----------------------------------------------------------------------
def first_url_entity(message: Any) -> str | None:
    """Return the first URL contained in *message*'s entities (or None).

    ``url`` entities are extracted from the text at the entity offset;
    ``text_link`` entities (markdown links) carry the URL on the entity.
    """
    for entity in getattr(message, "entities", None) or []:
        if getattr(entity, "type", None) == "url":
            text = getattr(message, "text", "") or ""
            offset = getattr(entity, "offset", 0)
            length = getattr(entity, "length", 0)
            url = text[offset : offset + length].strip()
            if url:
                return url
        elif getattr(entity, "type", None) == "text_link":
            url = (getattr(entity, "url", None) or "").strip()
            if url:
                return url
    return None


def artist_name(track: Any) -> str:
    """Best-effort artist name (detached ORM rows must never crash us)."""
    try:
        artist = getattr(track, "artist", None)
    except Exception:  # noqa: BLE001 — DetachedInstanceError and friends
        return ""
    return (getattr(artist, "name", None) or "") if artist is not None else ""


def track_page_text(track: "Track") -> str:
    """The track detail body (HTML, fully escaped)."""
    lines = [f"🎵 <b>{escape(track.title)}</b>"]
    artist = artist_name(track)
    if artist:
        lines.append(f"🎤 {escape(artist)}")
    album = getattr(getattr(track, "album", None), "title", None)
    if album:
        lines.append(f"💿 {escape(album)}")
    duration = int(getattr(track, "duration_seconds", 0) or 0)
    from app.utils import provider_label

    label = provider_label(getattr(track, "source", None))
    meta: list[str] = []
    if duration > 0:
        meta.append(f"⏱ {format_duration(duration)}")
    if label:
        meta.append(f"🎼 {escape(label)}")
    if meta:
        lines.append(" · ".join(meta))
    return "\n".join(lines)


async def render_track_page(
    services: "ServiceContainer",
    tg_user_id: int,
    track: "Track",
    *,
    page: int = 0,
) -> tuple[str, InlineKeyboardMarkup]:
    """Build the full track page (text + keyboard) for a private user."""
    liked = await services.library.is_liked(tg_user_id, track.id)
    return track_page_text(track), track_page_keyboard(
        track.id, liked=liked, page=page
    )


async def render_search_prompt(
    services: "ServiceContainer",
) -> tuple[str, InlineKeyboardMarkup]:
    """The 'send me a song name' prompt."""
    text = await services.admin.appearance.message("search_prompt")
    return text, search_prompt_keyboard()


async def enter_search_state(state: FSMContext, *, reset_mode: bool = True) -> None:
    """Put the user into the search state with a clean context."""
    await state.set_state(SearchFSM.query)
    if reset_mode:
        await state.update_data(
            search_ids=[], search_query="", search_page=0, mode=None, playlist_id=None
        )


def is_searchable_text(message: Any) -> bool:
    """Filter: private non-command text without a link entity."""
    text = (getattr(message, "text", None) or "").strip()
    if not text or text.startswith("/"):
        return False
    return first_url_entity(message) is None


def results_page_text(
    query: str, tracks: "list[Track]", page: int, total_pages: int
) -> str:
    """Render one page of numbered search results."""
    lines = [f"🔎 <b>Results for</b> {escape(truncate(query, 80))}", ""]
    for offset, track in enumerate(tracks):
        lines.append(
            track_line(
                page * SEARCH_PAGE_SIZE + offset + 1,
                track.title,
                artist_name(track),
                duration=int(getattr(track, "duration_seconds", 0) or 0) or None,
                source=getattr(track, "source", None),
            )
        )
    if total_pages > 1:
        lines.append("")
        lines.append(f"📄 Page {page + 1} of {total_pages}")
    return "\n".join(lines)


async def _tracks_by_ids(
    services: "ServiceContainer", track_ids: "list[int]"
) -> "list[Track]":
    """Fetch catalog tracks by id, skipping rows that disappeared."""
    tracks: "list[Track]" = []
    for track_id in track_ids:
        track = await services.music.get_track(int(track_id))
        if track is not None:
            tracks.append(track)
    return tracks


async def _render_results(
    services: "ServiceContainer",
    data: dict[str, Any],
    page: int,
) -> tuple[str, InlineKeyboardMarkup] | None:
    """Render the stored search results at *page* (None when expired)."""
    track_ids = [int(tid) for tid in (data.get("search_ids") or [])]
    if not track_ids:
        return None
    query = str(data.get("search_query") or "")
    total_pages = max(1, -(-len(track_ids) // SEARCH_PAGE_SIZE))
    page = max(0, min(page, total_pages - 1))
    tracks = await _tracks_by_ids(services, track_ids)
    window = paginate(tracks, page + 1, SEARCH_PAGE_SIZE)
    text = results_page_text(query, list(window.items), window.page - 1, total_pages)
    page_ids = [track.id for track in window.items]
    return text, search_results_keyboard(window.page - 1, total_pages, page_ids)


async def run_search(
    message: Message,
    services: "ServiceContainer",
    state: FSMContext,
    query: str,
) -> None:
    """Execute an animated private search: one progress message, edited live.

    The acknowledgement is sent immediately; the spinner / escalation /
    provider statuses update the SAME message; the final results (or the
    empty / error screens) replace it. Group searches never animate — this
    flow is only reachable from private chat handlers.
    """
    tg_user_id = message.from_user.id if message.from_user else 0
    query = query.strip()[:SEARCH_QUERY_LIMIT]
    if not query:
        text, keyboard = await render_search_prompt(services)
        await message.answer(text, parse_mode="HTML", reply_markup=keyboard)
        return

    # A new search supersedes any older animation in this chat.
    cancel_active(message.chat.id)

    reporter = SearchProgressReporter(
        message,
        query,
        source_names=await _configured_source_names(services),
        escalation_text=await _slow_search_text(services),
    )
    try:
        await reporter.start()
        try:
            results = await services.music.search(
                query, limit=SEARCH_RESULTS_LIMIT, on_progress=reporter.on_progress
            )
        except Exception as exc:  # noqa: BLE001 — search failures must stay friendly
            logger.warning(
                "bot.search_failed", extra=log_extra(error=str(exc)[:160])
            )
            await reporter.finish_exception(user_friendly_error(exc))
            return

        try:
            await services.history.record_search(tg_user_id, query, len(results))
        except Exception as exc:  # noqa: BLE001 — history must never break search
            logger.warning(
                "bot.search_history_failed", extra=log_extra(error=str(exc)[:160])
            )

        if not results:
            if reporter.all_sources_failed:
                await reporter.finish_error(_retry_keyboard())
            else:
                await reporter.finish_empty(_retry_keyboard())
            return

        await state.set_state(SearchFSM.query)
        await state.update_data(
            search_ids=[track.id for track in results],
            search_query=query,
            search_page=0,
        )
        total_pages = max(1, -(-len(results) // SEARCH_PAGE_SIZE))
        text = _results_header_text(query, len(results))
        text += "\n" + _results_body(results, 0)
        keyboard = search_results_keyboard(0, total_pages, [t.id for t in results])
        await reporter.finish_results(text, keyboard)
        logger.info(
            "bot.search", extra=log_extra(results=len(results), query=query[:64])
        )
    finally:
        reporter.stop()


async def _configured_source_names(services: "ServiceContainer") -> list[str]:
    """Display names of the actually-configured music sources."""
    try:
        sources = getattr(services.music, "_sources", None) or []
        return [s.name for s in sources if getattr(s, "is_configured", lambda: False)()]
    except Exception:  # noqa: BLE001 — cosmetic only
        return []


async def _slow_search_text(services: "ServiceContainer") -> str:
    """Admin-customizable escalation text (message key ``search_slow``)."""
    from app.bot.search_progress import DEFAULT_ESCALATION_TEXT

    try:
        text = await services.admin.appearance.message("search_slow")
        return text or DEFAULT_ESCALATION_TEXT
    except Exception:  # noqa: BLE001 — cosmetic only
        return DEFAULT_ESCALATION_TEXT


def _retry_keyboard() -> InlineKeyboardMarkup:
    """Retry action for the empty / error screens."""
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔄 Search Again", callback_data="sch:retry")]
        ]
    )


def _results_header_text(query: str, found: int) -> str:
    """Final header shown on the (former) progress message."""
    return (
        "🎵 <b>Search Results</b>\n"
        f"Query: {escape(truncate(query, 80))}\n"
        f"Found: {found} track{'s' if found != 1 else ''}\n\n"
        "Choose a track below:"
    )


def _results_body(tracks: "list[Track]", page: int) -> str:
    """Numbered results list body (same rendering as before)."""
    lines: list[str] = [""]
    for offset, track in enumerate(tracks):
        lines.append(
            track_line(
                page * SEARCH_PAGE_SIZE + offset + 1,
                track.title,
                artist_name(track),
                duration=int(getattr(track, "duration_seconds", 0) or 0) or None,
                source=getattr(track, "source", None),
            )
        )
    return "\n".join(lines)


# ----------------------------------------------------------------------
# Handlers
# ----------------------------------------------------------------------
@router.message(Command("search"), F.chat.type == "private")
async def cmd_search(
    message: Message,
    command: CommandObject,
    services: ServiceContainer,
    state: FSMContext,
) -> None:
    """/search — open the prompt, or search directly when arguments given."""
    args = (command.args or "").strip()
    if args:
        await run_search(message, services, state, args)
        return
    text, keyboard = await render_search_prompt(services)
    await enter_search_state(state)
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


@router.message(
    F.chat.type == "private",
    StateFilter(None, SearchFSM.query),
    is_searchable_text,
)
async def on_search_text(
    message: Message, services: ServiceContainer, state: FSMContext
) -> None:
    """Any private non-command text is treated as a search query."""
    await run_search(message, services, state, message.text or "")


@router.callback_query(F.data.regexp(r"^sch:retry$"))
async def on_search_retry(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Retry the last search from the empty / error screens."""
    data = await state.get_data()
    query = str(data.get("search_query") or "").strip()
    await safe_answer(callback)
    if not query:
        text, keyboard = await render_search_prompt(services)
        await callback.message.answer(text, parse_mode="HTML", reply_markup=keyboard)
        return
    await run_search(callback.message, services, state, query)


@router.callback_query(F.data.regexp(r"^sch:pg:\d+$"))
async def on_results_page(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Page through the stored search results."""
    page = int(str(callback.data).rsplit(":", 1)[1])
    data = await state.get_data()
    rendered = await _render_results(services, data, page)
    if rendered is None:
        await safe_answer(callback, "🔎 Search expired — send a new query.")
        return
    text, keyboard = rendered
    await state.update_data(search_page=page)
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(
    F.data.regexp(r"^trk:\d+$"), F.message.chat.type == "private"
)
async def on_track_button(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Open a track page — or, in playlist-add mode, add the track instead.

    Private-chat scope: group-context ``trk:<id>`` buttons are owned by
    the groups router's own handler (router-order safety).
    """
    track_id = int(str(callback.data).split(":", 1)[1])
    try:
        track = await services.music.get_track(track_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    if track is None:
        await safe_answer(callback, TrackNotFoundError().user_message)
        return

    data = await state.get_data()
    if data.get("mode") == "playlist_add" and data.get("playlist_id"):
        playlist_id = int(data["playlist_id"])
        try:
            added = await services.playlists.add_track(
                playlist_id, track.id, added_by=callback.from_user.id
            )
        except BotError as exc:
            await safe_answer(callback, exc.user_message)
            return
        playlist = await services.playlists.get(playlist_id)
        title = playlist.title if playlist is not None else "playlist"
        await safe_answer(
            callback,
            f"✅ Added to {title}" if added else "ℹ️ Already in this playlist.",
        )
        rendered = await _render_results(services, data, int(data.get("search_page") or 0))
        if rendered is not None:
            text, keyboard = rendered
            await edit_screen(callback.message, text, keyboard)
        return

    page = int(data.get("search_page") or 0)
    text, keyboard = await render_track_page(
        services, callback.from_user.id, track, page=page
    )
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(
    F.data.regexp(r"^trk:back:\d+$"), F.message.chat.type == "private"
)
async def on_track_back(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Back from a track page to the search results (or the library hub)."""
    page = int(str(callback.data).rsplit(":", 1)[1])
    data = await state.get_data()
    rendered = await _render_results(services, data, page)
    if rendered is not None:
        text, keyboard = rendered
        await state.update_data(search_page=page)
        await edit_screen(callback.message, text, keyboard)
        await safe_answer(callback)
        return

    # No stored results (track was opened from the library) — library hub.
    from app.bot.handlers.library import render_library_home

    text, keyboard = render_library_home()
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

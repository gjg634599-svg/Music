"""Private help and about commands (admin-customizable texts)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import Message

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer

router = Router(name="help")


@router.message(Command("help"), F.chat.type == "private")
async def cmd_help(message: Message, services: ServiceContainer) -> None:
    """/help — the customizable help text."""
    text = await services.admin.appearance.message("help")
    await message.answer(text, parse_mode="HTML")


@router.message(Command("about"), F.chat.type == "private")
async def cmd_about(message: Message, services: ServiceContainer) -> None:
    """/about — the customizable about text."""
    text = await services.admin.appearance.message("about")
    await message.answer(text, parse_mode="HTML")


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

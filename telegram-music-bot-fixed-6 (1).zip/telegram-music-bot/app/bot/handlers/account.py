"""My Account screens: profile summary and connected groups."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from app.bot.keyboards.common import back_button, edit_screen
from app.errors import BotError
from app.logging import get_logger, log_extra
from app.playback.queue import QueueOwner
from app.utils import escape, safe_answer

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer

logger = get_logger(__name__)

router = Router(name="account")


# ----------------------------------------------------------------------
# Screen renderers
# ----------------------------------------------------------------------
async def render_account_screen(
    services: "ServiceContainer", tg_user_id: int
) -> tuple[str, InlineKeyboardMarkup]:
    """The profile summary screen (plays, likes, playlists, groups).

    Raises:
        app.errors.ValidationError: when the user is unknown (press /start).
    """
    summary = await services.users.account_summary(tg_user_id)
    user = summary["user"]

    is_admin = False
    try:
        is_admin = await services.admin.is_admin(tg_user_id)
    except Exception as exc:  # noqa: BLE001 — the badge must never break the screen
        logger.debug("bot.admin_check_failed", extra=log_extra(error=str(exc)[:120]))

    username = getattr(user, "username", None)
    status = "🔴 Blocked" if user.is_blocked else "🟢 Active"
    lines = [
        "👤 <b>MY ACCOUNT</b>",
        "",
        f"Name: {escape(user.first_name or '—')}",
        f"Username: {('@' + username) if username else '—'}",
        f"Telegram ID: <code>{user.telegram_id}</code>",
        f"Status: {status}",
    ]
    if is_admin:
        lines.append("Role: 👑 Admin")
    lines += [
        "",
        "🎵 <b>Music</b>",
        f"Plays: {summary['plays']} · Likes: {summary['likes']}",
        f"Playlists: {summary['playlists']}",
        "",
        f"👥 Groups: {summary['groups']} connected",
    ]

    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(text="👥 My Groups", callback_data="acct:groups")],
        [InlineKeyboardButton(text="❤️ My Library", callback_data="lib:home")],
        [InlineKeyboardButton(text="⚙️ Settings", callback_data="dash:settings")],
    ]
    if is_admin:
        rows.append(
            [InlineKeyboardButton(text="🎛️ Admin Panel", callback_data="adm:home")]
        )
    rows.append([back_button("nav:home")])
    return "\n".join(lines), InlineKeyboardMarkup(inline_keyboard=rows)


async def render_groups_screen(
    services: "ServiceContainer", tg_user_id: int
) -> tuple[str, InlineKeyboardMarkup]:
    """The connected groups screen (inline info, no per-group buttons)."""
    entries: list[dict[str, Any]] = await services.users.my_groups(tg_user_id)
    lines = ["👥 <b>MY GROUPS</b>", ""]
    if not entries:
        lines.append("ℹ️ No groups yet — add me with /group!")
    for index, entry in enumerate(entries, start=1):
        group = entry["group"]
        active = bool(getattr(group, "bot_in_chat", False)) and bool(
            getattr(group, "is_active", False)
        )
        voice = await _group_has_live_session(services, group.telegram_id)
        queue_size = int(entry.get("queue_size") or 0)
        lines.append(
            f"{index}. 🎵 {escape(group.title)} "
            f"{'🟢' if active else '🔴'} "
            f"{'🎙️' if voice else '⚪️'}"
            + (f" · {queue_size} queued" if queue_size else "")
        )
    lines += [
        "",
        "ℹ️ Group status is based on the bot's access.",
    ]
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [back_button("acct:home")],
        ]
    )
    return "\n".join(lines), keyboard


async def _group_has_live_session(
    services: "ServiceContainer", group_tg_id: int
) -> bool:
    """True while the group session is actively playing (voice chat live)."""
    try:
        session = await services.sessions.get(
            QueueOwner(kind="group", id=group_tg_id)
        )
        return session.status == "playing"
    except Exception as exc:  # noqa: BLE001 — status hint only
        logger.debug(
            "bot.group_session_check_failed", extra=log_extra(error=str(exc)[:120])
        )
        return False


# ----------------------------------------------------------------------
# Callbacks
# ----------------------------------------------------------------------
@router.callback_query(F.data == "acct:home")
async def on_account_home(callback: CallbackQuery, services: ServiceContainer) -> None:
    """My Account screen."""
    try:
        text, keyboard = await render_account_screen(services, callback.from_user.id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data == "acct:groups")
async def on_account_groups(callback: CallbackQuery, services: ServiceContainer) -> None:
    """My connected groups screen."""
    text, keyboard = await render_groups_screen(services, callback.from_user.id)
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

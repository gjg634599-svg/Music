"""Admin panel entry points: the ``/admin`` command and the ``adm:home`` view.

Defense in depth: even though ``AdminGuardMiddleware`` (3-b) already drops
``adm:`` callbacks from non-admins, the ``/admin`` command re-verifies the
caller here.  Denials never reveal who *is* an admin.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.admin.permissions import Role
from app.bot.keyboards.admin import admin_home_keyboard
from app.bot.services import ServiceContainer
from app.utils.telegram import safe_answer, safe_edit

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.admin.permissions import PermissionService

router = Router(name="admin_panel")

#: Exact denial text — deliberately identical for every non-admin.
DENIED_TEXT = "❌ You don't have permission to access the admin panel."


def _role_name(role: Role | None) -> str:
    """Pretty-print a role value (``super_admin`` → ``Super Admin``)."""
    if role is None:
        return "Unknown"
    return " ".join(part.capitalize() for part in role.value.split("_"))


def _home_text(role: Role | None) -> str:
    """Render the admin panel home text."""
    return f"🎛️ <b>ADMIN PANEL</b>\n\n👑 Role: {_role_name(role)}"


async def _render_home(
    target: Message, services: ServiceContainer, tg_id: int, *, edit: bool
) -> Role | None:
    """Render the home screen on *target* (edit when possible, else send)."""
    permissions: PermissionService = services.admin.permissions
    role = await permissions.role_of(tg_id)
    keyboard = admin_home_keyboard(permissions.role_icon(role))
    text = _home_text(role)
    if edit:
        await safe_edit(target, text, keyboard)
    else:
        await target.answer(text, reply_markup=keyboard, parse_mode="HTML")
    return role


@router.message(Command("admin"))
async def admin_command(message: Message, services: ServiceContainer, state: FSMContext) -> None:
    """Open the admin panel (private chat, admins only)."""
    if message.from_user is None or message.chat is None:
        return
    await state.clear()
    tg_id = message.from_user.id
    if not await services.admin.permissions.is_admin(tg_id):
        # Never reveal who has access — the same text for every non-admin.
        await message.answer(DENIED_TEXT)
        return
    await _render_home(message, services, tg_id, edit=False)
    await services.admin.audit.log(tg_id, "panel.open", target_type="panel")


@router.callback_query(F.data == "adm:home")
async def admin_home(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Navigate back to the admin panel home (edits the message)."""
    await state.clear()
    if callback.message is not None:
        await _render_home(callback.message, services, callback.from_user.id, edit=True)
    await safe_answer(callback)


__all__ = ["router", "admin_command", "admin_home", "DENIED_TEXT", "_home_text"]

"""Admin groups screens: paginated list and read-only group detail."""

from __future__ import annotations

import re

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.bot.keyboards.admin import (
    PAGE_SIZE,
    admin_group_detail_keyboard,
    admin_groups_keyboard,
)
from app.bot.services import ServiceContainer
from app.errors import ValidationError
from app.utils.formatting import escape
from app.utils.telegram import safe_answer, safe_edit

router = Router(name="admin_groups")

_GROUPS_PAGE_RE = re.compile(r"^adm:groups:(\d+)$")
_GROUP_DETAIL_RE = re.compile(r"^adm:group:(-?\d+)$")


async def _render_list(callback: CallbackQuery, services: ServiceContainer, page: int) -> None:
    """Render one page of the groups list (10 per page)."""
    page = max(0, page)
    rows, total = await services.groups.groups.list_page(PAGE_SIZE, page * PAGE_SIZE)
    active_total = await services.groups.groups.count_active()

    lines = [
        "👥 <b>GROUPS</b>\n",
        f"Total: {total} | Active: {active_total}",
    ]
    if not rows:
        lines.append("\nNo groups yet.")
    for index, group in enumerate(rows, start=page * PAGE_SIZE + 1):
        status = "🟢" if group.is_active and group.bot_in_chat else "🔴"
        title = escape(group.title or f"Chat {group.telegram_id}")
        lines.append(f"{index}. {title} — {status} — {group.member_count} members")

    await safe_edit(callback.message, "\n".join(lines), admin_groups_keyboard(page, total))


async def _render_detail(callback: CallbackQuery, services: ServiceContainer, tg_id: int) -> None:
    """Render the read-only group detail screen."""
    try:
        summary = await services.groups.status_summary(tg_id)
    except ValidationError:
        await safe_answer(callback, "ℹ️ Group not found.")
        return

    group = summary["group"]
    settings = summary["settings"]
    queue_size = summary["queue_size"]
    status = "🟢 Active" if group.is_active and group.bot_in_chat else "🔴 Inactive"
    text = (
        "👥 <b>GROUP</b>\n\n"
        f"Title: {escape(group.title or '—')}\n"
        f"ID: <code>{group.telegram_id}</code>\n"
        f"Status: {status}\n"
        f"Members: {group.member_count}\n\n"
        f"🎵 Queue size: {queue_size}\n"
        f"🤖 Autoplay: {'✅ On' if settings.autoplay_enabled else '❌ Off'}\n"
        f"🎛️ Permission mode: {escape(settings.permission_mode)}"
    )
    await safe_edit(callback.message, text, admin_group_detail_keyboard())


@router.callback_query(F.data == "adm:groups")
async def groups_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Open the groups list (first page)."""
    await _render_list(callback, services, 0)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_GROUPS_PAGE_RE.pattern))
async def groups_page(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Paginate the groups list."""
    match = _GROUPS_PAGE_RE.match(callback.data or "")
    page = int(match.group(1)) if match else 0
    await _render_list(callback, services, page)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_GROUP_DETAIL_RE.pattern))
async def group_detail(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Open a single group's read-only detail view."""
    match = _GROUP_DETAIL_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback, "ℹ️ Unknown group.")
        return
    await _render_detail(callback, services, int(match.group(1)))
    await safe_answer(callback)


__all__ = ["router"]

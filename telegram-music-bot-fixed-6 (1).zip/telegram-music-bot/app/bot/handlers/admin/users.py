"""Admin users screens: paginated list, detail view and block/unblock.

User data is read through ``services.users`` (the ``UserService`` facade and
its public ``UserRepository``).  Blocking a user is a two-step action and
every mutation is audited.
"""

from __future__ import annotations

import re

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.bot.keyboards.admin import (
    PAGE_SIZE,
    admin_user_block_confirm_keyboard,
    admin_user_detail_keyboard,
    admin_users_keyboard,
)
from app.bot.services import ServiceContainer
from app.errors import ValidationError
from app.utils.formatting import escape
from app.utils.telegram import safe_answer, safe_edit

router = Router(name="admin_users")

_USER_PAGE_RE = re.compile(r"^adm:users:(\d+)$")
_USER_DETAIL_RE = re.compile(r"^adm:user:(-?\d+)$")
_USER_BLOCK_RE = re.compile(r"^adm:user:(-?\d+):block$")
_USER_BLOCK_YES_RE = re.compile(r"^adm:user:(-?\d+):block:yes$")
_USER_UNBLOCK_RE = re.compile(r"^adm:user:(-?\d+):unblock$")


async def _guard(callback: CallbackQuery, services: ServiceContainer, permission: str) -> bool:
    """Return True when the acting admin holds *permission*; else answer."""
    if await services.admin.permissions.has(callback.from_user.id, permission):
        return True
    await safe_answer(callback, "❌ You don't have permission to do that.", show_alert=True)
    return False


async def _render_list(callback: CallbackQuery, services: ServiceContainer, page: int) -> None:
    """Render one page of the users list (10 per page)."""
    repo = services.users.users
    page = max(0, page)
    rows, total = await repo.list_page(PAGE_SIZE, page * PAGE_SIZE)
    active = await repo.count_active(30)
    blocked = await repo.count_blocked()

    lines = [
        "👥 <b>USERS</b>\n",
        f"Total: {total} | Active: {active} | Blocked: {blocked}",
    ]
    if not rows:
        lines.append("\nNo users yet.")
    for index, user in enumerate(rows, start=page * PAGE_SIZE + 1):
        name = escape(user.first_name or "—")
        username = f" @{escape(user.username)}" if user.username else ""
        flag = " 🚫" if user.is_blocked else ""
        lines.append(f"{index}. {name}{username} — plays {user.play_count}{flag}")

    await safe_edit(callback.message, "\n".join(lines), admin_users_keyboard(page, total))


async def _render_detail(
    callback: CallbackQuery, services: ServiceContainer, tg_id: int, *, note: str = ""
) -> None:
    """Render the user detail screen (prefixed by an optional ✅/ℹ️ note)."""
    try:
        summary = await services.users.account_summary(tg_id)
    except ValidationError:
        await safe_answer(callback, "ℹ️ User not found.")
        return

    user = summary["user"]
    status = "🚫 Blocked" if user.is_blocked else "🟢 Active"
    username = f"@{escape(user.username)}" if user.username else "—"
    text = (
        f"{note}"
        "👤 <b>USER</b>\n\n"
        f"Name: {escape(user.first_name or '—')}\n"
        f"Username: {username}\n"
        f"ID: <code>{user.telegram_id}</code>\n"
        f"Status: {status}\n\n"
        f"▶️ Plays: {summary['plays']}\n"
        f"❤️ Likes: {summary['likes']}\n"
        f"📋 Playlists: {summary['playlists']}\n"
        f"👥 Groups: {summary['groups']}"
    )
    await safe_edit(
        callback.message, text, admin_user_detail_keyboard(user.telegram_id, user.is_blocked)
    )


@router.callback_query(F.data == "adm:users")
async def users_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Open the users list (first page)."""
    await _render_list(callback, services, 0)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_USER_PAGE_RE.pattern))
async def users_page(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Paginate the users list."""
    match = _USER_PAGE_RE.match(callback.data or "")
    page = int(match.group(1)) if match else 0
    await _render_list(callback, services, page)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_USER_DETAIL_RE.pattern))
async def user_detail(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Open a single user's detail view."""
    match = _USER_DETAIL_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback, "ℹ️ Unknown user.")
        return
    await _render_detail(callback, services, int(match.group(1)))
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_USER_BLOCK_RE.pattern))
async def user_block_confirm(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Ask for confirmation before blocking a user."""
    if not await _guard(callback, services, "users"):
        return
    match = _USER_BLOCK_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    tg_id = int(match.group(1))
    text = (
        "🚫 <b>BLOCK USER</b>\n\n"
        f"User <code>{tg_id}</code> will lose access to the bot "
        "until unblocked.\n\nBlock this user?"
    )
    await safe_edit(callback.message, text, admin_user_block_confirm_keyboard(tg_id))
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_USER_BLOCK_YES_RE.pattern))
async def user_block(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Block the user after confirmation (audited)."""
    if not await _guard(callback, services, "users"):
        return
    match = _USER_BLOCK_YES_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    tg_id = int(match.group(1))
    updated = await services.users.set_blocked(tg_id, True)
    await services.admin.audit.log(
        callback.from_user.id,
        "users.block",
        target_type="user",
        target_id=tg_id,
        result="ok" if updated else "noop",
    )
    await _render_detail(callback, services, tg_id, note="✅ User blocked.\n\n")
    await safe_answer(callback, "🚫 User blocked.")


@router.callback_query(F.data.regexp(_USER_UNBLOCK_RE.pattern))
async def user_unblock(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Unblock a user (audited)."""
    if not await _guard(callback, services, "users"):
        return
    match = _USER_UNBLOCK_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    tg_id = int(match.group(1))
    updated = await services.users.set_blocked(tg_id, False)
    await services.admin.audit.log(
        callback.from_user.id,
        "users.unblock",
        target_type="user",
        target_id=tg_id,
        result="ok" if updated else "noop",
    )
    await _render_detail(callback, services, tg_id, note="✅ User unblocked.\n\n")
    await safe_answer(callback, "✅ User unblocked.")


__all__ = ["router"]

"""Admin appearance screens: message templates and the logo asset.

Message templates support ``str.format`` placeholders; the current text is
always shown HTML-escaped inside a ``<pre>`` block so admins see the raw
template (including its HTML tags) exactly as stored.
"""

from __future__ import annotations

import re

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.admin.appearance import MAX_MESSAGE_LENGTH
from app.bot.handlers.admin.states import AdminFSM
from app.bot.keyboards.admin import (
    admin_appearance_keyboard,
    admin_logo_keyboard,
    admin_message_keyboard,
)
from app.bot.services import ServiceContainer
from app.errors import BotError
from app.utils.formatting import escape
from app.utils.telegram import safe_answer, safe_edit

router = Router(name="admin_appearance")

_MSG_RE = re.compile(r"^adm:app:msg:([a-z0-9_]+)$")
_MSG_EDIT_RE = re.compile(r"^adm:app:msg:([a-z0-9_]+):edit$")
_MSG_RESET_RE = re.compile(r"^adm:app:msg:([a-z0-9_]+):reset$")
_MSG_PREVIEW_RE = re.compile(r"^adm:app:msg:([a-z0-9_]+):preview$")

#: Maximum accepted logo size (Telegram photos are far below this).
_LOGO_MAX_BYTES = 5 * 1024 * 1024

#: Sample placeholder values used by the "preview" action.
_SAMPLE_PLACEHOLDERS: dict[str, str] = {
    "name": "Alex",
    "username": "alex",
    "bot_name": "Music Bot",
    "title": "Demo Track",
    "artist": "Demo Artist",
}


async def _guard(callback: CallbackQuery, services: ServiceContainer, permission: str) -> bool:
    """Return True when the acting admin holds *permission*; else answer."""
    if await services.admin.permissions.has(callback.from_user.id, permission):
        return True
    await safe_answer(callback, "❌ You don't have permission to do that.", show_alert=True)
    return False


async def _render_message_screen(
    callback: CallbackQuery, services: ServiceContainer, key: str, *, note: str = ""
) -> bool:
    """Render the "current text" screen of one message template."""
    appearance = services.admin.appearance
    valid_keys = {valid_key for valid_key, _ in appearance.keys()}
    if key not in valid_keys:
        await safe_answer(callback, "ℹ️ Unknown message key.")
        return False
    template = await appearance.message(key)
    title = dict(appearance.keys()).get(key, key)
    text = (
        f"{note}"
        f"📝 <b>MESSAGE: {escape(title)}</b>\n\n"
        f"Current text:\n<pre>{escape(template)}</pre>"
    )
    await safe_edit(callback.message, text, admin_message_keyboard(key))
    return True


async def _render_logo_screen(
    callback: CallbackQuery, services: ServiceContainer, *, note: str = ""
) -> None:
    """Render the logo manager screen."""
    logo = await services.admin.appearance.logo()
    if logo is None:
        status = "❌ Not set"
    else:
        status = f"✅ Set (asset #{logo.id})"
    text = f"{note}🖼️ <b>LOGO</b>\n\nStatus: {status}"
    await safe_edit(callback.message, text, admin_logo_keyboard())


# ----------------------------------------------------------------------
# Screens
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:app")
async def appearance_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Appearance menu: logo entry + one button per message template."""
    keys = services.admin.appearance.keys()
    text = (
        "🎨 <b>APPEARANCE</b>\n\n"
        f"Messages: {len(keys)} customizable templates\n"
        "Tap a message to view and edit it."
    )
    await safe_edit(callback.message, text, admin_appearance_keyboard(keys))
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_MSG_RE.pattern))
async def message_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Show the current text of one message template (escaped)."""
    match = _MSG_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    await _render_message_screen(callback, services, match.group(1))
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_MSG_EDIT_RE.pattern))
async def message_edit_prompt(
    callback: CallbackQuery, state: FSMContext, services: ServiceContainer
) -> None:
    """Start editing a message template (FSM)."""
    if not await _guard(callback, services, "appearance"):
        return
    match = _MSG_EDIT_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    key = match.group(1)
    await state.update_data(msg_key=key)
    await state.set_state(AdminFSM.edit_message)
    if callback.message is not None:
        await callback.message.answer(
            "📝 Send the new message text (HTML allowed, "
            f"max {MAX_MESSAGE_LENGTH} chars).\n\n/cancel — abort"
        )
    await safe_answer(callback)


@router.message(AdminFSM.edit_message, F.text)
async def message_edit_input(message: Message, state: FSMContext, services: ServiceContainer) -> None:
    """Receive the new template text, validate, persist and audit."""
    text = (message.text or "").strip()
    if text.startswith("/cancel"):
        await state.clear()
        await message.answer("ℹ️ Edit cancelled.")
        return
    if not text:
        await message.answer("❌ Message text cannot be empty. Try again or /cancel.")
        return
    if len(text) > MAX_MESSAGE_LENGTH:
        await message.answer(
            f"❌ Too long ({len(text)} > {MAX_MESSAGE_LENGTH} chars). Try again or /cancel."
        )
        return

    data = await state.get_data()
    key = str(data.get("msg_key") or "")
    await state.clear()
    if not key:
        await message.answer("ℹ️ Edit cancelled.")
        return
    try:
        await services.admin.appearance.set_message(key, text, message.from_user.id)
    except BotError as exc:
        await message.answer(exc.user_message)
        return
    await services.admin.audit.log(
        message.from_user.id,
        "appearance.set_message",
        target_type="message",
        target_id=key,
        details={"length": len(text)},
    )
    # The FSM prompt cannot be edited into this screen — send the refreshed one.
    title = dict(services.admin.appearance.keys()).get(key, key)
    await message.answer(
        "✅ Message updated.\n\n"
        f"📝 <b>MESSAGE: {escape(title)}</b>\n\n"
        f"Current text:\n<pre>{escape(text)}</pre>",
        reply_markup=admin_message_keyboard(key),
        parse_mode="HTML",
    )


@router.callback_query(F.data.regexp(_MSG_RESET_RE.pattern))
async def message_reset(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Reset one template to its built-in default (audited)."""
    if not await _guard(callback, services, "appearance"):
        return
    match = _MSG_RESET_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    key = match.group(1)
    reset = await services.admin.appearance.reset_message(key)
    await services.admin.audit.log(
        callback.from_user.id,
        "appearance.reset_message",
        target_type="message",
        target_id=key,
        result="ok" if reset else "noop",
    )
    await _render_message_screen(
        callback, services, key, note="✅ Reset to default.\n\n" if reset else ""
    )
    await safe_answer(callback, "↩️ Reset to default." if reset else "ℹ️ Already default.")


@router.callback_query(F.data.regexp(_MSG_PREVIEW_RE.pattern))
async def message_preview(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Send the template as users would see it (sample placeholders)."""
    match = _MSG_PREVIEW_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    key = match.group(1)
    rendered = await services.admin.appearance.message(key, **_SAMPLE_PLACEHOLDERS)
    if callback.message is not None:
        await callback.message.answer(rendered, parse_mode="HTML")
    await safe_answer(callback, "👁️ Preview sent below.")


# ----------------------------------------------------------------------
# Logo
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:app:logo")
async def logo_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Logo manager screen."""
    await _render_logo_screen(callback, services)
    await safe_answer(callback)


@router.callback_query(F.data == "adm:app:logo:change")
async def logo_change_prompt(
    callback: CallbackQuery, state: FSMContext, services: ServiceContainer
) -> None:
    """Ask for the new logo photo (FSM)."""
    if not await _guard(callback, services, "appearance"):
        return
    await state.set_state(AdminFSM.logo)
    if callback.message is not None:
        await callback.message.answer(
            "🖼️ Send the new logo now (square, high quality).\n\n/cancel — abort"
        )
    await safe_answer(callback)


@router.message(AdminFSM.logo, F.photo)
async def logo_input(message: Message, state: FSMContext, services: ServiceContainer) -> None:
    """Receive the new logo photo, validate, persist and audit."""
    photo = message.photo[-1]
    if photo.file_size is not None and photo.file_size > _LOGO_MAX_BYTES:
        await message.answer("❌ Logo too large (max 5 MB). Send a smaller photo or /cancel.")
        return
    await state.clear()
    try:
        await services.admin.appearance.set_logo(
            photo.file_id, photo.file_unique_id, message.from_user.id
        )
    except BotError as exc:
        await message.answer(exc.user_message)
        return
    await services.admin.audit.log(
        message.from_user.id, "appearance.set_logo", target_type="asset", target_id="logo"
    )
    await message.answer(
        "✅ Logo updated.\n\n🖼️ <b>LOGO</b>\n\nStatus: ✅ Set",
        reply_markup=admin_logo_keyboard(),
        parse_mode="HTML",
    )


@router.message(AdminFSM.logo)
async def logo_invalid_input(message: Message, state: FSMContext) -> None:
    """Non-photo input during the logo FSM — re-ask."""
    if (message.text or "").startswith("/cancel"):
        await state.clear()
        await message.answer("ℹ️ Logo change cancelled.")
        return
    await message.answer("❌ Please send a photo, or /cancel.")


@router.callback_query(F.data == "adm:app:logo:preview")
async def logo_preview(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Send the current logo (or a note when none is set)."""
    logo = await services.admin.appearance.logo()
    if logo is None:
        await safe_answer(callback, "ℹ️ No logo set.")
        return
    if callback.message is not None:
        await callback.message.answer_photo(logo.file_id, caption="🖼️ Current logo")
    await safe_answer(callback)


@router.callback_query(F.data == "adm:app:logo:del")
async def logo_delete(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Remove the stored logo (audited)."""
    if not await _guard(callback, services, "appearance"):
        return
    removed = await services.admin.appearance.remove_logo()
    await services.admin.audit.log(
        callback.from_user.id,
        "appearance.remove_logo",
        target_type="asset",
        target_id="logo",
        result="ok" if removed else "noop",
    )
    await _render_logo_screen(
        callback, services, note="✅ Logo removed.\n\n" if removed else ""
    )
    await safe_answer(callback, "🗑️ Logo removed." if removed else "ℹ️ No logo set.")


__all__ = ["router"]

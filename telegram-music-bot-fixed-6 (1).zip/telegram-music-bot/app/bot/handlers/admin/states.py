"""FSM states for the admin panel conversation flows (Task 3-c).

Every state is only reachable in private chat (the admin router applies a
private-chat filter to all of its sub-routers).  All intermediate data
(broadcast drafts, message keys, button ids...) lives in the per-user FSM
storage, never in module globals.
"""

from __future__ import annotations

from aiogram.fsm.state import State, StatesGroup


class AdminFSM(StatesGroup):
    """All admin-panel conversation states.

    States:
        edit_message: waiting for a new text for a customizable message.
        logo: waiting for the new logo photo.
        btn_label: waiting for a dynamic-button label (create or edit).
        btn_url: waiting for a dynamic-button URL (create or edit).
        bc_text: waiting for the broadcast text.
        bc_media: waiting for a single media item (broadcast composer).
        bc_caption: waiting for a media caption (or ``/skip``).
        bc_copy: waiting for the message to copy-broadcast.
        bc_btn_label: waiting for a broadcast URL-button label.
        bc_btn_url: waiting for a broadcast URL-button URL.
        specific_ids: waiting for comma-separated Telegram ids (targets).
        album_collect: collecting a media-group album for broadcasting.
    """

    # Appearance ---------------------------------------------------------
    edit_message = State()
    logo = State()

    # Dynamic buttons ------------------------------------------------------
    btn_label = State()
    btn_url = State()

    # Broadcast composer ---------------------------------------------------
    bc_text = State()
    bc_media = State()
    bc_caption = State()
    bc_copy = State()
    bc_btn_label = State()
    bc_btn_url = State()
    specific_ids = State()
    album_collect = State()


class VoiceLoginFSM(StatesGroup):
    """Voice-account login wizard states (see app.voice.login).

    A separate group so the wizard never collides with other admin
    conversation flows; every step re-validates the ``voice`` permission
    and the owner of the active login session.
    """

    phone = State()
    code = State()
    password = State()


class VoiceAccessFSM(StatesGroup):
    """Voice-account group-access check (see app.voice.group_access).

    Admin supplies a Telegram group id; the account's membership (and the
    automatic-join state) is then reported. Single-step, permission-checked.
    """

    waiting_group_id = State()


__all__ = ["AdminFSM", "VoiceAccessFSM", "VoiceLoginFSM"]

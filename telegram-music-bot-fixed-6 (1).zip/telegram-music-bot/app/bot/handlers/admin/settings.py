"""Admin settings screens: autoplay toggle, maintenance mode, broadcast limits."""

from __future__ import annotations

import re

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.bot.keyboards.admin import (
    admin_back_keyboard,
    admin_maintenance_keyboard,
    admin_settings_keyboard,
)
from app.bot.services import ServiceContainer
from app.utils.telegram import safe_answer, safe_edit

router = Router(name="admin_settings")

_AUTO_RE = re.compile(r"^adm:set:auto:([01])$")
_MAINT_ON_RE = re.compile(r"^adm:set:maintenance:1:on$")
_MAINT_OFF_RE = re.compile(r"^adm:set:maintenance:0:off$")
_MAINT_GROUPS_RE = re.compile(r"^adm:set:maintenance:groups:([01])$")


async def _guard(callback: CallbackQuery, services: ServiceContainer, permission: str) -> bool:
    """Return True when the acting admin holds *permission*; else answer."""
    if await services.admin.permissions.has(callback.from_user.id, permission):
        return True
    await safe_answer(callback, "❌ You don't have permission to do that.", show_alert=True)
    return False


async def _render_settings(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Render the settings home screen."""
    autoplay = await services.admin.settings.autoplay_enabled()
    maintenance = await services.admin.settings.maintenance()
    text = (
        "⚙️ <b>SETTINGS</b>\n\n"
        f"🤖 Autoplay: {'✅ On' if autoplay else '❌ Off'}\n"
        f"🚧 Maintenance: {'✅ On' if maintenance['enabled'] else '❌ Off'}"
    )
    await safe_edit(callback.message, text, admin_settings_keyboard(autoplay))


# ----------------------------------------------------------------------
# Screens
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:set")
async def settings_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Settings home."""
    await _render_settings(callback, services)
    await safe_answer(callback)


@router.callback_query(F.data == "adm:set:auto")
async def settings_autoplay_screen(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Autoplay entry from the panel home — same screen as adm:set."""
    await _render_settings(callback, services)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_AUTO_RE.pattern))
async def settings_autoplay_toggle(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Toggle global autoplay (audited)."""
    if not await _guard(callback, services, "settings"):
        return
    match = _AUTO_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    enabled = match.group(1) == "1"
    await services.admin.settings.set_autoplay(enabled, callback.from_user.id)
    await services.admin.audit.log(
        callback.from_user.id,
        "settings.autoplay",
        target_type="setting",
        target_id="autoplay",
        details={"enabled": enabled},
    )
    await _render_settings(callback, services)
    await safe_answer(callback, "🤖 Autoplay on." if enabled else "🤖 Autoplay off.")


@router.callback_query(F.data == "adm:set:maintenance")
async def maintenance_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Maintenance mode screen (toggle + groups-continue option)."""
    maintenance = await services.admin.settings.maintenance()
    enabled = bool(maintenance["enabled"])
    groups_continue = bool(maintenance["groups_continue"])
    text = (
        "🚧 <b>MAINTENANCE MODE</b>\n\n"
        f"Status: {'✅ On' if enabled else '❌ Off'}\n"
        f"Groups continue: {'✅ On' if groups_continue else '❌ Off'}\n\n"
        "When enabled users see a maintenance notice; admins keep access."
    )
    await safe_edit(
        callback.message, text, admin_maintenance_keyboard(enabled, groups_continue)
    )
    await safe_answer(callback)


async def _set_maintenance(
    callback: CallbackQuery,
    services: ServiceContainer,
    *,
    enabled: bool | None,
    groups_continue: bool | None,
) -> None:
    """Apply a maintenance change (super-admin only) and audit it."""
    if not await _guard(callback, services, "maintenance"):
        return
    current = await services.admin.settings.maintenance()
    new_enabled = current["enabled"] if enabled is None else enabled
    new_groups = current["groups_continue"] if groups_continue is None else groups_continue
    await services.admin.settings.set_maintenance(
        new_enabled, new_groups, callback.from_user.id
    )
    await services.admin.audit.log(
        callback.from_user.id,
        "settings.maintenance",
        target_type="setting",
        target_id="maintenance",
        details={"enabled": new_enabled, "groups_continue": new_groups},
    )
    await maintenance_screen(callback, services)


@router.callback_query(F.data.regexp(_MAINT_ON_RE.pattern))
async def maintenance_enable(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Enable maintenance mode (audited)."""
    await _set_maintenance(callback, services, enabled=True, groups_continue=None)


@router.callback_query(F.data.regexp(_MAINT_OFF_RE.pattern))
async def maintenance_disable(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Disable maintenance mode (audited)."""
    await _set_maintenance(callback, services, enabled=False, groups_continue=None)


@router.callback_query(F.data.regexp(_MAINT_GROUPS_RE.pattern))
async def maintenance_groups_toggle(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Toggle "groups continue playing" during maintenance (audited)."""
    match = _MAINT_GROUPS_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    await _set_maintenance(
        callback, services, enabled=None, groups_continue=match.group(1) == "1"
    )


@router.callback_query(F.data == "adm:set:broadcast")
async def broadcast_limits_screen(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Read-only view of the broadcast engine limits."""
    limits = await services.admin.settings.broadcast_limits()
    text = (
        "📢 <b>BROADCAST LIMITS</b>\n\n"
        f"Rate: {limits.get('rate_per_second', '—')} msg/s\n"
        f"Concurrency: {limits.get('worker_concurrency', '—')} workers\n"
        f"Retries: {limits.get('max_retries', '—')}\n\n"
        "<i>Managed via environment variables / bot settings.</i>"
    )
    await safe_edit(callback.message, text, admin_back_keyboard("adm:set"))
    await safe_answer(callback)


__all__ = ["router"]

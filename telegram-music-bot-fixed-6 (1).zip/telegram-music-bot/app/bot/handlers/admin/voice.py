"""Admin voice-engine screens: dashboard, accounts, sessions, health.

Account enable/disable/delete goes through :class:`VoiceRepository`
(constructed from the container's session factory — repositories are
importable everywhere) followed by ``VoiceManager.reload_accounts`` so the
in-memory pool matches the database.  Session strings and phone numbers are
never displayed (``phone_hint`` is stored pre-masked).
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.bot.handlers.admin.states import VoiceAccessFSM
from app.bot.keyboards.admin import (
    admin_back_keyboard,
    admin_voice_account_delete_confirm_keyboard,
    admin_voice_account_keyboard,
    admin_voice_accounts_keyboard,
    admin_voice_keyboard,
    admin_voice_session_keyboard,
    admin_voice_sessions_keyboard,
)
from app.bot.services import ServiceContainer
from app.database.repositories.voice import VoiceRepository
from app.errors import BotError
from app.playback.queue import QueueOwner
from app.utils.formatting import escape
from app.utils.telegram import safe_answer, safe_edit
from app.utils.time import human_delta

router = Router(name="admin_voice")

_ACC_RE = re.compile(r"^adm:vc:acc:(\d+)$")
_ACC_TOGGLE_RE = re.compile(r"^adm:vc:acc:(\d+):toggle$")
_ACC_RECONNECT_RE = re.compile(r"^adm:vc:acc:(\d+):reconnect$")
_ACC_DEL_RE = re.compile(r"^adm:vc:acc:(\d+):del$")
_ACC_DEL_YES_RE = re.compile(r"^adm:vc:acc:(\d+):del:yes$")
_ACC_HEALTH_RE = re.compile(r"^adm:vc:acc:(\d+):health$")
_SES_RE = re.compile(r"^adm:vc:ses:(\d+)$")
_SES_ACTION_RE = re.compile(r"^adm:vc:ses:(\d+):(skip|pause|stop)$")

_STATUS_ICONS: dict[str, str] = {
    "healthy": "🟢",
    "degraded": "🟡",
    "offline": "🔴",
    "disabled": "⛔",
    "auth_required": "🔑",
}


def _voice_repo(services: ServiceContainer) -> VoiceRepository:
    """Build a VoiceRepository on the container's session factory."""
    return VoiceRepository(services.db.sessionmaker())


async def _guard(callback: CallbackQuery, services: ServiceContainer, permission: str) -> bool:
    """Return True when the acting admin holds *permission*; else answer."""
    if await services.admin.permissions.has(callback.from_user.id, permission):
        return True
    await safe_answer(callback, "❌ You don't have permission to do that.", show_alert=True)
    return False


def _status_icon(status: str | None) -> str:
    """Icon for a voice account status."""
    return _STATUS_ICONS.get(str(status or "offline"), "🔴")


def _parse_iso(value: Any) -> datetime | None:
    """Parse an ISO timestamp defensively."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        return None


# ----------------------------------------------------------------------
# Dashboard
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:vc")
async def voice_dashboard(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Voice engine overview."""
    status = await services.voice.status()
    sessions = await services.voice.list_active_sessions()
    enabled = await services.voice.is_voice_enabled()
    if not enabled:
        engine = "🔴 Not configured"
    elif status.total_accounts == 0:
        engine = "🟡 Configured, no accounts"
    else:
        engine = "🟢 Running"
    text = (
        "🎙️ <b>VOICE ENGINE</b>\n\n"
        f"Accounts: {status.total_accounts}\n"
        f"Healthy: {status.healthy_accounts}\n"
        f"Active VC sessions: {len(sessions)}\n"
        f"Engine: {engine}"
    )
    await safe_edit(callback.message, text, admin_voice_keyboard())
    await safe_answer(callback)


# ----------------------------------------------------------------------
# Accounts
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:vc:acc")
async def voice_accounts(callback: CallbackQuery, services: ServiceContainer) -> None:
    """All voice accounts (disabled included) with live session counts."""
    repo = _voice_repo(services)
    try:
        accounts = await repo.list_accounts(include_disabled=True)
    except Exception as exc:  # noqa: BLE001 — admin screen must never crash
        await safe_answer(callback, f"ℹ️ Could not load accounts ({exc.__class__.__name__}).")
        return
    live = {item.account_id: item for item in (await services.voice.status()).accounts}
    lines = ["👤 <b>VOICE ACCOUNTS</b>\n"]
    if not accounts:
        lines.append("No accounts yet — add one with ➕ Add Account.")
    for index, account in enumerate(accounts, start=1):
        summary = live.get(account.id)
        active = summary.active_sessions if summary else 0
        icon = _status_icon(account.status)
        lines.append(
            f"Account #{index} — {icon} {escape(account.status or 'offline')} — "
            f"Active: {active}/{account.max_sessions}"
        )
    keyboard = admin_voice_accounts_keyboard(accounts)
    await safe_edit(callback.message, "\n".join(lines), keyboard)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_ACC_RE.pattern))
async def voice_account_detail(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """One account's detail view (manager info or DB fallback)."""
    match = _ACC_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    acc_id = int(match.group(1))
    info = await services.voice.account_info(acc_id)
    if info is not None:
        last_check = _parse_iso(info.get("last_health_check_at"))
        text = (
            "🎙️ <b>VOICE ACCOUNT</b>\n\n"
            f"Label: {escape(str(info.get('label') or '—'))}\n"
            f"Telegram ID: <code>{info.get('telegram_id') or '—'}</code>\n"
            f"Username: {escape(str(info.get('username') or '—'))}\n"
            f"Status: {_status_icon(info.get('status'))} {escape(str(info.get('status')))}\n"
            f"Sessions: {info.get('active_sessions')}/{info.get('max_sessions')}\n"
            f"Last health check: {human_delta(last_check)}\n"
        )
        recent = info.get("recent_health") or []
        if recent:
            text += "\n<b>Recent checks</b>\n"
            for row in recent[:5]:
                checked = _parse_iso(row.get("checked_at"))
                latency = row.get("latency_ms")
                latency_text = f" — {latency} ms" if latency is not None else ""
                text += (
                    f"• {_status_icon(row.get('status'))} {escape(str(row.get('status')))}"
                    f"{latency_text} — {human_delta(checked)}\n"
                )
        keyboard = admin_voice_account_keyboard(acc_id, is_disabled=info.get("status") == "disabled")
    else:
        row = await _voice_repo(services).get(acc_id)
        if row is None:
            await safe_answer(callback, "ℹ️ Account not found.")
            return
        last_check = row.last_health_check_at
        text = (
            "🎙️ <b>VOICE ACCOUNT</b>\n\n"
            f"Label: {escape(row.label)}\n"
            f"Status: {_status_icon(row.status)} {escape(row.status or 'offline')}\n"
            f"Phone: {escape(row.phone_hint or '—')}\n"
            f"Sessions: 0/{row.max_sessions}\n"
            f"Last health check: {human_delta(last_check)}\n\n"
            "<i>Not in the active pool (disabled or not loaded).</i>"
        )
        keyboard = admin_voice_account_keyboard(acc_id, is_disabled=row.status == "disabled")
    await safe_edit(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_ACC_TOGGLE_RE.pattern))
async def voice_account_toggle(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Enable/disable an account, reload the pool (audited)."""
    if not await _guard(callback, services, "voice"):
        return
    match = _ACC_TOGGLE_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    acc_id = int(match.group(1))
    repo = _voice_repo(services)
    row = await repo.get(acc_id)
    if row is None:
        await safe_answer(callback, "ℹ️ Account not found.")
        return
    disable = row.status != "disabled"
    await repo.update(acc_id, status="disabled" if disable else "offline")
    try:
        await services.voice.reload_accounts()
    except Exception as exc:  # noqa: BLE001 — reload is best-effort
        await safe_answer(callback, f"⚠️ Reload failed: {exc.__class__.__name__}")
    await services.admin.audit.log(
        callback.from_user.id,
        "voice.account_toggle",
        target_type="voice_account",
        target_id=acc_id,
        details={"enabled": not disable},
    )
    await voice_account_detail(callback, services)
    await safe_answer(callback, "⏸️ Account disabled." if disable else "▶️ Account enabled.")


@router.callback_query(F.data.regexp(_ACC_RECONNECT_RE.pattern))
async def voice_account_reconnect(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Reload the pool and health-check (audited)."""
    if not await _guard(callback, services, "voice"):
        return
    match = _ACC_RECONNECT_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    acc_id = int(match.group(1))
    repo = _voice_repo(services)
    row = await repo.get(acc_id)
    if row is None:
        await safe_answer(callback, "ℹ️ Account not found.")
        return
    if row.status == "disabled":
        await safe_answer(callback, "ℹ️ Enable the account first.")
        return
    try:
        await services.voice.reload_accounts()
        results = await services.voice.run_health_checks()
    except Exception as exc:  # noqa: BLE001 — reconnect is best-effort
        await safe_answer(callback, f"⚠️ Reconnect failed: {exc.__class__.__name__}")
        return
    await services.admin.audit.log(
        callback.from_user.id,
        "voice.account_reconnect",
        target_type="voice_account",
        target_id=acc_id,
    )
    result = results.get(acc_id, "unknown")
    await safe_answer(callback, f"🔄 Reconnected — health: {result}.")
    await voice_account_detail(callback, services)


@router.callback_query(F.data.regexp(_ACC_DEL_RE.pattern))
async def voice_account_delete_confirm(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Two-step confirmation before removing an account."""
    if not await _guard(callback, services, "voice"):
        return
    match = _ACC_DEL_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    acc_id = int(match.group(1))
    text = (
        "⚠️ <b>REMOVE VOICE ACCOUNT</b>\n\n"
        f"Remove account <code>{acc_id}</code>?\n\n"
        "This will disconnect active sessions served by it. "
        "This cannot be undone."
    )
    await safe_edit(
        callback.message, text, admin_voice_account_delete_confirm_keyboard(acc_id)
    )
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_ACC_DEL_YES_RE.pattern))
async def voice_account_delete(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Delete the account after confirmation (audited)."""
    if not await _guard(callback, services, "voice"):
        return
    match = _ACC_DEL_YES_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    acc_id = int(match.group(1))
    deleted = await _voice_repo(services).delete(acc_id)
    if not deleted:
        await safe_answer(callback, "ℹ️ Account not found.")
        return
    try:
        await services.voice.reload_accounts()
    except Exception:  # noqa: BLE001 — reload is best-effort
        pass
    await services.admin.audit.log(
        callback.from_user.id,
        "voice.account_delete",
        target_type="voice_account",
        target_id=acc_id,
    )
    await voice_accounts(callback, services)
    await safe_answer(callback, "🗑️ Account removed.")


@router.callback_query(F.data.regexp(_ACC_HEALTH_RE.pattern))
async def voice_account_health(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Run health checks and show this account's result + history."""
    if not await _guard(callback, services, "voice"):
        return
    match = _ACC_HEALTH_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    acc_id = int(match.group(1))
    try:
        results = await services.voice.run_health_checks()
    except Exception as exc:  # noqa: BLE001 — health checks are best-effort
        await safe_answer(callback, f"⚠️ Health check failed: {exc.__class__.__name__}")
        return
    result = results.get(acc_id)
    if result is None:
        await safe_answer(callback, "ℹ️ Account is not in the active pool (disabled?).")
        return
    await safe_answer(callback, f"🩺 Health: {result}")
    await voice_account_detail(callback, services)


# ----------------------------------------------------------------------
# Sessions
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:vc:ses")
async def voice_sessions(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Active voice sessions (group, account, track, status)."""
    sessions = await services.voice.list_active_sessions()
    accounts = {row.id: row.label for row in await _voice_repo(services).list_accounts(include_disabled=True)}
    lines = ["🎵 <b>ACTIVE SESSIONS</b>\n"]
    if not sessions:
        lines.append("No active sessions.")
    for session in sessions:
        title = "—"
        if session.current_track_id is not None:
            try:
                track = await services.music.get_track(session.current_track_id)
                title = track.title if track else f"track #{session.current_track_id}"
            except Exception:  # noqa: BLE001 — title lookup is cosmetic
                title = f"track #{session.current_track_id}"
        lines.append(
            f"#{session.id} — group <code>{session.group_id}</code> — "
            f"{escape(str(accounts.get(session.account_id, session.account_id)))} — "
            f"{escape(session.status)} — 🎵 {escape(str(title))}"
        )
    keyboard = admin_voice_sessions_keyboard(sessions)
    await safe_edit(callback.message, "\n".join(lines), keyboard)
    await safe_answer(callback)


async def _find_session(
    services: ServiceContainer, ses_id: int
) -> Any | None:
    """Find an active voice session row by id."""
    for session in await services.voice.list_active_sessions():
        if session.id == ses_id:
            return session
    return None


@router.callback_query(F.data.regexp(_SES_RE.pattern))
async def voice_session_detail(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """One session's detail view with playback controls."""
    match = _SES_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    ses_id = int(match.group(1))
    session = await _find_session(services, ses_id)
    if session is None:
        await safe_answer(callback, "ℹ️ Session not found or already ended.")
        return
    text = (
        f"🎵 <b>SESSION #{session.id}</b>\n\n"
        f"Group: <code>{session.group_id}</code>\n"
        f"Account: <code>{session.account_id}</code>\n"
        f"Status: {escape(session.status)}\n"
        f"Started: {human_delta(session.started_at)}\n"
        f"Heartbeat: {human_delta(session.last_heartbeat)}"
    )
    await safe_edit(callback.message, text, admin_voice_session_keyboard(ses_id))
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_SES_ACTION_RE.pattern))
async def voice_session_action(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Skip / pause / stop the playback of a session's group (audited)."""
    if not await _guard(callback, services, "voice"):
        return
    match = _SES_ACTION_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    ses_id, action = int(match.group(1)), match.group(2)
    session = await _find_session(services, ses_id)
    if session is None:
        await safe_answer(callback, "ℹ️ Session not found or already ended.")
        return
    group_id = int(session.group_id)
    try:
        if action == "skip":
            owner = QueueOwner(kind="group", id=group_id)
            await services.playback.next(
                owner, chat_id=group_id, bot=callback.bot, manual=True, skip=True
            )
            reply = "⏭️ Skipped."
        elif action == "pause":
            await services.voice.pause(group_id)
            reply = "⏸️ Paused."
        else:
            await services.voice.stop(group_id)
            reply = "🛑 Stopped."
    except BotError as exc:
        await safe_answer(callback, exc.user_message, show_alert=True)
        return
    except Exception as exc:  # noqa: BLE001 — control surface must not crash
        await safe_answer(callback, f"⚠️ Action failed: {exc.__class__.__name__}")
        return
    await services.admin.audit.log(
        callback.from_user.id,
        f"voice.session_{action}",
        target_type="voice_session",
        target_id=ses_id,
        details={"group_id": group_id},
    )
    await safe_answer(callback, reply)
    await voice_session_detail(callback, services)


# ----------------------------------------------------------------------
# Health / reload / add
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:vc:health")
async def voice_health(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Run health checks across the pool and show the results."""
    try:
        results = await services.voice.run_health_checks()
    except Exception as exc:  # noqa: BLE001 — best-effort
        await safe_answer(callback, f"⚠️ Health check failed: {exc.__class__.__name__}")
        return
    lines = ["🩺 <b>HEALTH CHECK</b>\n"]
    if not results:
        lines.append("No accounts to check.")
    for acc_id, status in sorted(results.items()):
        lines.append(f"#{acc_id} → {_status_icon(status)} {escape(str(status))}")
    await safe_edit(callback.message, "\n".join(lines), admin_back_keyboard("adm:vc"))
    await safe_answer(callback)


@router.callback_query(F.data == "adm:vc:reload")
async def voice_reload(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Reload the account pool (audited)."""
    if not await _guard(callback, services, "voice"):
        return
    try:
        await services.voice.reload_accounts()
    except Exception as exc:  # noqa: BLE001 — best-effort
        await safe_answer(callback, f"⚠️ Reload failed: {exc.__class__.__name__}")
        return
    status = await services.voice.status()
    await services.admin.audit.log(
        callback.from_user.id, "voice.reload", target_type="voice_engine"
    )
    await safe_answer(callback, f"🔄 Reloaded ({status.total_accounts} accounts).")
    await voice_dashboard(callback, services)


# NOTE: the "adm:vc:add" screen (Add Voice Account) now opens the secure
# login wizard implemented in app.bot.handlers.admin.voice_login — the
# CLI script remains available as a server-side fallback.


# ----------------------------------------------------------------------
# Group-access check (private-group membership / auto-join state)
# ----------------------------------------------------------------------
_ACC_ACCESS_RE = re.compile(r"^adm:vc:acc:(\d+):access$")

_MEMBERSHIP_ICONS: dict[str, str] = {
    "member": "🟢",
    "not_member": "🔴",
    "unknown": "🟡",
    "offline": "⚫",
}

_MEMBERSHIP_TEXT: dict[str, str] = {
    "member": "Member — the account can access this group.",
    "not_member": (
        "Not a member — automatic joining will be attempted on the next "
        "playback if enabled (bot needs invite-export rights)."
    ),
    "unknown": (
        "Unknown — the account never interacted with this group; treat as "
        "not a member (auto-join will be attempted when enabled)."
    ),
    "offline": "Account is offline — connect it before checking access.",
}


@router.callback_query(F.data.regexp(_ACC_ACCESS_RE.pattern))
async def voice_account_access_prompt(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Ask the admin for the group id to check membership against."""
    if not await _guard(callback, services, "voice"):
        return
    match = _ACC_ACCESS_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    acc_id = int(match.group(1))
    await state.update_data(access_account_id=acc_id)
    await state.set_state(VoiceAccessFSM.waiting_group_id)
    await safe_edit(
        callback.message,
        "🚪 <b>GROUP ACCESS CHECK</b>\n\n"
        "Send the Telegram <b>group id</b> to check this voice account's "
        "membership against (e.g. <code>-1001234567890</code>).\n\n"
        "<i>Send /cancel to abort.</i>",
        admin_back_keyboard(f"adm:vc:acc:{acc_id}"),
    )
    await safe_answer(callback)


@router.message(StateFilter(VoiceAccessFSM.waiting_group_id), F.text)
async def voice_account_access_check(
    message: Message, services: ServiceContainer, state: FSMContext
) -> None:
    """Perform the membership check for the supplied group id."""
    if not await services.admin.permissions.has(
        message.from_user.id if message.from_user else 0, "voice"
    ):
        await state.clear()
        return
    data = await state.get_data()
    acc_id = int(data.get("access_account_id") or 0)
    await state.clear()
    if acc_id <= 0:
        await message.answer("ℹ️ Access check expired — start again from the account screen.")
        return

    text = (message.text or "").strip()
    if text.casefold() in ("/cancel", "cancel"):
        await message.answer("⛔ Access check cancelled.")
        return
    cleaned = text.removeprefix("-").replace(" ", "")
    if not cleaned.isdigit() or len(cleaned) > 15:
        await message.answer(
            "❌ That doesn't look like a Telegram group id "
            "(example: <code>-1001234567890</code>)."
        )
        return
    group_id = int(text)

    try:
        info = await services.voice.check_account_group_access(acc_id, group_id)
    except Exception as exc:  # noqa: BLE001 — admin screens never crash
        await message.answer(f"⚠️ Check failed: {exc.__class__.__name__}")
        return
    if info is None:
        await message.answer("ℹ️ Account not found (not in the active pool).")
        return
    membership = str(info.get("membership"))
    icon = _MEMBERSHIP_ICONS.get(membership, "🟡")
    auto_join = "on" if info.get("auto_join_enabled") else "off"
    cooldown = int(info.get("cooldown_seconds") or 0)
    cooldown_text = f"\nAuto-join cooldown: {cooldown}s" if cooldown > 0 else ""
    await services.admin.audit.log(
        message.from_user.id if message.from_user else 0,
        "voice.group_access_check",
        target_type="voice_account",
        target_id=acc_id,
        details={"group_id": group_id, "membership": membership},
    )
    await message.answer(
        f"🚪 <b>GROUP ACCESS</b>\n\n"
        f"Account: <b>#{info.get('account_id')} · {escape(str(info.get('label')))}</b>\n"
        f"Group: <code>{info.get('group_id')}</code>\n"
        f"Membership: {icon} {escape(membership)}\n"
        f"Auto-join: {'✅' if info.get('auto_join_enabled') else '⛔'} {auto_join}"
        f"{cooldown_text}\n\n"
        f"<i>{_MEMBERSHIP_TEXT.get(membership, '')}</i>",
        parse_mode="HTML",
    )


__all__ = ["router"]

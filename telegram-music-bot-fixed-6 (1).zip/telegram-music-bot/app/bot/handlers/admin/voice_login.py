"""Admin voice-account login wizard — the Telegram UI.

Private-chat-only interactive flow (see ``app.voice.login`` for the state
machine and security properties)::

    Admin Panel → Voice Engine → Voice Accounts → Add Voice Account
        → [Connect Account] → phone → code → (2FA) → connected

Every callback and every message re-validates the ``voice`` admin
permission and binds to the admin who started the flow; sensitive input
messages (phone / code / password) are deleted where permitted and are
never echoed back.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.bot.handlers.admin.states import VoiceLoginFSM
from app.bot.keyboards.admin import (
    admin_back_keyboard,
    admin_voice_login_intro_keyboard,
    admin_voice_login_step_keyboard,
    admin_voice_login_success_keyboard,
)
from app.bot.services import ServiceContainer
from app.logging import get_logger, log_extra
from app.utils.formatting import escape
from app.utils.telegram import safe_answer, safe_edit

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.voice.login import LoginResult

router = Router(name="admin_voice_login")

logger = get_logger(__name__)

#: Wizard conversation screens are short-lived; 4 minutes per step is plenty
#: for a human, the service-side idle timeout (10 min) is the hard limit.


# ----------------------------------------------------------------------
# Guards
# ----------------------------------------------------------------------
async def _guard(callback: CallbackQuery, services: ServiceContainer) -> bool:
    """Re-validate the ``voice`` permission on every wizard callback."""
    if await services.admin.permissions.has(callback.from_user.id, "voice"):
        return True
    await safe_answer(callback, "❌ You don't have permission to do that.", show_alert=True)
    return False


async def _message_guard(message: Message, services: ServiceContainer) -> bool:
    """Re-validate the ``voice`` permission on every wizard message."""
    return await services.admin.permissions.has(
        message.from_user.id if message.from_user else 0, "voice"
    )


async def _delete_input(message: Message) -> None:
    """Best-effort deletion of a sensitive input message."""
    try:
        await message.delete()
    except Exception:  # noqa: BLE001 — deletion is best-effort only
        pass


# ----------------------------------------------------------------------
# Step A — introduction
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:vc:add")
async def voice_login_intro(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Wizard introduction screen (replaces the old CLI-only instructions)."""
    if not await _guard(callback, services):
        return
    text = (
        "🎙 <b>ADD VOICE ACCOUNT</b>\n\n"
        "Connect a Telegram <b>user</b> account to enable group "
        "voice-chat playback.\n\n"
        "This account is <i>separate from the bot itself</i>.\n"
        "Only connect an account you control.\n\n"
        "You will need:\n"
        "• the account's phone number\n"
        "• the login code Telegram sends it\n"
        "• its 2FA password (when enabled)\n\n"
        "<i>The session is encrypted at rest. Codes and passwords are "
        "never logged or echoed.</i>"
    )
    await safe_edit(callback.message, text, admin_voice_login_intro_keyboard())
    await safe_answer(callback)


# ----------------------------------------------------------------------
# Step B — start the wizard, wait for the phone number
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:vc:add:start")
async def voice_login_start(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """[Connect Account] — begin the login flow for this admin."""
    if not await _guard(callback, services):
        return
    login = services.voice_login
    result = await login.begin(callback.from_user.id)
    if not result.ok:
        await safe_edit(callback.message, _failure_text(result.message), admin_back_keyboard("adm:vc"))
        await safe_answer(callback)
        return
    await state.set_state(VoiceLoginFSM.phone)
    text = (
        "📞 <b>PHONE NUMBER</b>\n\n"
        "Send the Telegram <b>user</b> account's phone number in "
        "international format, e.g. <code>+989123456789</code>.\n\n"
        "<i>I'll delete your message after reading it.</i>"
    )
    await safe_edit(callback.message, text, admin_voice_login_step_keyboard("phone"))
    await safe_answer(callback)
    logger.info(
        "bot.voice_login_started", extra=log_extra(admin_id=callback.from_user.id)
    )


@router.message(
    VoiceLoginFSM.phone,
    F.chat.type == "private",
    F.text,
)
async def voice_login_phone(
    message: Message, services: ServiceContainer, state: FSMContext
) -> None:
    """Receive the phone number, request the login code."""
    if not await _message_guard(message, services):
        await state.clear()
        await services.voice_login.cancel(message.from_user.id)
        return
    await _delete_input(message)
    result = await services.voice_login.submit_phone(
        message.from_user.id, (message.text or "").strip()
    )
    if not result.ok and not result.retry:
        await state.clear()
        await _reply_failure(message, result)
        return
    if not result.ok:
        await message.answer(
            f"⚠️ {escape(result.message)}\n\nTry again — send the phone number "
            "in international format, e.g. <code>+989123456789</code>.",
            parse_mode="HTML",
        )
        return
    await state.set_state(VoiceLoginFSM.code)
    await message.answer(
        "✉️ <b>LOGIN CODE</b>\n\n"
        "Telegram sent a login code to the account "
        "(check its Telegram app — SMS or in-app message).\n\n"
        "Send me the code here. <i>Your message will be deleted after "
        "reading.</i>",
        parse_mode="HTML",
        reply_markup=admin_voice_login_step_keyboard("code"),
    )


# ----------------------------------------------------------------------
# Step C — login code
# ----------------------------------------------------------------------
@router.message(
    VoiceLoginFSM.code,
    F.chat.type == "private",
    F.text,
)
async def voice_login_code(
    message: Message, services: ServiceContainer, state: FSMContext
) -> None:
    """Receive the login code; continue to 2FA or finish."""
    if not await _message_guard(message, services):
        await state.clear()
        await services.voice_login.cancel(message.from_user.id)
        return
    await _delete_input(message)
    result = await services.voice_login.submit_code(message.from_user.id, message.text or "")
    await _handle_code_result(message, state, services, result)


async def _handle_code_result(
    message: Message,
    state: FSMContext,
    services: ServiceContainer,
    result: "LoginResult",
) -> None:
    """Shared continuation for code / password / resend results."""
    from app.voice.login import LoginState

    if result.state is LoginState.WAITING_FOR_2FA:
        await state.set_state(VoiceLoginFSM.password)
        await message.answer(
            "🔐 <b>TWO-STEP VERIFICATION</b>\n\n"
            "This account has 2FA enabled. Send me its password.\n\n"
            "<i>Your message will be deleted after reading.</i>",
            parse_mode="HTML",
            reply_markup=admin_voice_login_step_keyboard("password"),
        )
        return
    if result.state is LoginState.COMPLETED:
        await state.clear()
        await message.answer(
            _success_text(result), parse_mode="HTML",
            reply_markup=admin_voice_login_success_keyboard(),
        )
        logger.info(
            "bot.voice_login_completed",
            extra=log_extra(
                admin_id=message.from_user.id,
                account_id=result.account_id,
            ),
        )
        return
    if result.retry:
        await message.answer(f"⚠️ {escape(result.message)}", parse_mode="HTML")
        return
    await state.clear()
    await _reply_failure(message, result)


# ----------------------------------------------------------------------
# Step D — two-step verification password
# ----------------------------------------------------------------------
@router.message(
    VoiceLoginFSM.password,
    F.chat.type == "private",
    F.text,
)
async def voice_login_password(
    message: Message, services: ServiceContainer, state: FSMContext
) -> None:
    """Receive the 2FA password and finish the login."""
    if not await _message_guard(message, services):
        await state.clear()
        await services.voice_login.cancel(message.from_user.id)
        return
    await _delete_input(message)
    result = await services.voice_login.submit_password(
        message.from_user.id, message.text or ""
    )
    await _handle_code_result(message, state, services, result)


# ----------------------------------------------------------------------
# Wizard callbacks: resend / cancel / post-connect health check
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:vc:add:resend")
async def voice_login_resend(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """[Resend Code] — ask Telegram for a fresh code."""
    if not await _guard(callback, services):
        return
    result = await services.voice_login.resend_code(callback.from_user.id)
    await safe_answer(
        callback, result.message if result.ok else f"⚠️ {result.message}"
    )


@router.callback_query(F.data == "adm:vc:add:cancel")
async def voice_login_cancel(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """[Cancel] — abort the flow and clean up (audited)."""
    if not await _guard(callback, services):
        return
    result = await services.voice_login.cancel(callback.from_user.id)
    await state.clear()
    await services.admin.audit.log(
        callback.from_user.id, "voice.login_cancelled", target_type="voice_engine"
    )
    await safe_edit(
        callback.message,
        "❌ <b>LOGIN CANCELLED</b>\n\nNo account was added.",
        admin_back_keyboard("adm:vc"),
    )
    await safe_answer(callback, "Login cancelled.")


@router.callback_query(F.data == "adm:vc:add:check")
async def voice_login_check(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """[Run Health Check] — reload the pool and verify the new account."""
    if not await _guard(callback, services):
        return
    try:
        await services.voice.reload_accounts()
        results = await services.voice.run_health_checks()
    except Exception as exc:  # noqa: BLE001 — best-effort check
        await safe_answer(
            callback, f"⚠️ Health check failed: {type(exc).__name__}", show_alert=True
        )
        return
    total = len(results)
    healthy = sum(1 for value in results.values() if value == "healthy")
    text = (
        "🩺 <b>VOICE ENGINE HEALTH</b>\n\n"
        f"Accounts checked: {total}\n"
        f"Healthy: {healthy}\n\n"
        "Authentication ✔ does not alone guarantee voice-chat playback — "
        "use /play in a group voice chat to verify end-to-end streaming."
    )
    await safe_edit(callback.message, text, admin_back_keyboard("adm:vc"))
    await safe_answer(callback, "🩺 Health check finished.")


# ----------------------------------------------------------------------
# Text helpers
# ----------------------------------------------------------------------
def _success_text(result: "LoginResult") -> str:
    username = escape(result.username) if result.username else "—"
    return (
        "✅ <b>VOICE ACCOUNT CONNECTED</b>\n\n"
        f"Username: {username}\n"
        f"Telegram ID: <code>{result.telegram_id or '—'}</code>\n"
        "Authentication: Verified\n"
        "Session: Encrypted and saved\n"
        "Voice readiness: Checking…\n\n"
        "<i>Login success does not by itself prove voice-chat playback — "
        "run a health check, then try /play in a group voice chat.</i>"
    )


def _failure_text(message: str) -> str:
    return f"❌ <b>LOGIN FAILED</b>\n\n{escape(message)}"


async def _reply_failure(message: Message, result: "LoginResult") -> None:
    await message.answer(_failure_text(result.message), parse_mode="HTML")


__all__ = ["router"]

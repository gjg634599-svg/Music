"""The admin's own account screens: profile, groups, recent activity."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.admin.permissions import Role
from app.bot.keyboards.admin import admin_back_keyboard, admin_me_keyboard
from app.bot.services import ServiceContainer
from app.utils.formatting import escape
from app.utils.telegram import safe_answer, safe_edit
from app.utils.time import human_delta

router = Router(name="admin_account")


def _role_name(role: Role | None) -> str:
    """Pretty-print a role value (``super_admin`` → ``Super Admin``)."""
    if role is None:
        return "Unknown"
    return " ".join(part.capitalize() for part in role.value.split("_"))


@router.callback_query(F.data == "adm:me")
async def me_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """The admin's own profile — identified from the callback sender."""
    user = callback.from_user
    permissions = services.admin.permissions
    role = await permissions.role_of(user.id)
    icon = permissions.role_icon(role)
    username = f"@{escape(user.username)}" if user.username else "—"
    text = (
        "👑 <b>ADMIN ACCOUNT</b>\n\n"
        f"Name: {escape(user.first_name or '—')}\n"
        f"Username: {username}\n"
        f"Telegram ID: <code>{user.id}</code>\n"
        f"Role: {icon} {_role_name(role)}\n"
        "Bot: 🟢 Online"
    )
    await safe_edit(
        callback.message, text, admin_me_keyboard(is_super=role == Role.SUPER_ADMIN)
    )
    await safe_answer(callback)


@router.callback_query(F.data == "adm:me:groups")
async def me_groups(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Groups where this admin is a member together with the bot."""
    entries = await services.users.my_groups(callback.from_user.id)
    lines = ["👥 <b>MY GROUPS</b>\n"]
    if not entries:
        lines.append("You're not in any group with the bot yet.")
    for entry in entries:
        group = entry["group"]
        queue_size = entry.get("queue_size", 0)
        status = "🟢" if group.is_active and group.bot_in_chat else "🔴"
        lines.append(
            f"{status} {escape(group.title or '—')} — 🎵 {queue_size} in queue"
        )
    await safe_edit(callback.message, "\n".join(lines), admin_back_keyboard("adm:me"))
    await safe_answer(callback)


@router.callback_query(F.data == "adm:me:activity")
async def me_activity(callback: CallbackQuery, services: ServiceContainer) -> None:
    """This admin's recent audit trail (filtered client-side)."""
    rows = await services.admin.audit.recent(50)
    mine = [row for row in rows if row.admin_id == callback.from_user.id][:10]
    lines = ["📊 <b>MY ACTIVITY</b>\n"]
    if not mine:
        lines.append("No admin activity recorded yet.")
    for row in mine:
        target = ""
        if row.target_type or row.target_id is not None:
            target = f" → {escape(str(row.target_type or ''))} {escape(str(row.target_id))}".rstrip()
        lines.append(
            f"• {escape(row.action)}{target} — {human_delta(row.created_at)}"
        )
    await safe_edit(callback.message, "\n".join(lines), admin_back_keyboard("adm:me"))
    await safe_answer(callback)


__all__ = ["router"]

"""Admin panel router package (Task 3-c).

Aggregates every admin sub-router (panel, users, groups, appearance, buttons,
broadcast, voice, settings, statistics, account) behind a single ``router``
and enforces the private-chat-only rule for the whole admin surface.

Usage::

    from app.bot.handlers.admin import register
    register(dp)  # or any parent Router
"""

from __future__ import annotations

from types import ModuleType
from typing import TYPE_CHECKING

from aiogram import F, Router

from app.bot.handlers.admin import (
    account,
    appearance,
    broadcast,
    buttons,
    groups,
    panel,
    settings,
    statistics,
    users,
    voice,
    voice_login,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from aiogram import Router as AiogramRouter

#: Sub-router modules in registration order (panel first so /admin wins).
_MODULES: tuple[ModuleType, ...] = (
    panel,
    users,
    groups,
    appearance,
    buttons,
    broadcast,
    voice,
    voice_login,
    settings,
    statistics,
    account,
)

router = Router(name="admin")


def register(parent: AiogramRouter) -> None:
    """Include the admin router (with all sub-routers) into *parent*.

    Every sub-router gets a private-chat filter for both messages and
    callback queries — the admin panel never operates in groups.
    """
    for module in _MODULES:
        sub: Router = module.router
        sub.message.filter(F.chat.type == "private")
        sub.callback_query.filter(F.message.chat.type == "private")
        router.include_router(sub)
    parent.include_router(router)


__all__ = ["router", "register"]

"""Admin dynamic-button screens: list, create, edit, reorder, delete, preview.

Buttons live in ``bot_buttons`` (via ``services.admin.buttons``).  Creating a
``callback`` button walks the admin through the KNOWN_ACTIONS picker; ``url``
buttons collect an https link; ``add_group`` buttons are created immediately.
"""

from __future__ import annotations

import re
from urllib.parse import urlparse

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message

from app.admin.buttons import KNOWN_ACTIONS
from app.bot.handlers.admin.states import AdminFSM
from app.bot.keyboards.admin import (
    admin_add_button_type_keyboard,
    admin_button_action_picker_keyboard,
    admin_button_delete_confirm_keyboard,
    admin_button_edit_keyboard,
    admin_buttons_keyboard,
)
from app.bot.services import ServiceContainer
from app.errors import BotError
from app.utils.formatting import escape
from app.utils.telegram import safe_answer, safe_edit

router = Router(name="admin_buttons")

_BTN_EDIT_RE = re.compile(r"^adm:btn:(\d+):edit$")
_BTN_EDIT_LABEL_RE = re.compile(r"^adm:btn:(\d+):edit:label$")
_BTN_EDIT_URL_RE = re.compile(r"^adm:btn:(\d+):edit:url$")
_BTN_MOVE_RE = re.compile(r"^adm:btn:(\d+):(up|down)$")
_BTN_TOGGLE_RE = re.compile(r"^adm:btn:(\d+):toggle$")
_BTN_DEL_RE = re.compile(r"^adm:btn:(\d+):del$")
_BTN_DEL_YES_RE = re.compile(r"^adm:btn:(\d+):del:yes$")
_BTN_NEW_RE = re.compile(r"^adm:btn:new:(callback|url|add_group)$")
_BTN_ACTION_RE = re.compile(r"^adm:btn:action:(.+)$")

_MAX_LABEL = 64

_TYPE_LABELS = {"callback": "🔄 Callback", "url": "🔗 URL", "add_group": "👥 Add to Group"}


async def _guard(callback: CallbackQuery, services: ServiceContainer, permission: str) -> bool:
    """Return True when the acting admin holds *permission*; else answer."""
    if await services.admin.permissions.has(callback.from_user.id, permission):
        return True
    await safe_answer(callback, "❌ You don't have permission to do that.", show_alert=True)
    return False


async def _render_list(
    callback: CallbackQuery, services: ServiceContainer, *, note: str = ""
) -> None:
    """Render the buttons list screen."""
    buttons = await services.admin.buttons.list_buttons()
    lines = [
        f"{note}🔘 <b>BUTTONS</b>\n",
        f"{len(buttons)} button(s) configured — shown on the start screen.",
    ]
    await safe_edit(callback.message, "\n".join(lines), admin_buttons_keyboard(buttons))


async def _render_edit(
    callback: CallbackQuery, services: ServiceContainer, button_id: int, *, note: str = ""
) -> bool:
    """Render the edit screen of one button; False when it no longer exists."""
    button = await services.admin.buttons.get(button_id)
    if button is None:
        await safe_answer(callback, "ℹ️ Button not found.")
        return False
    status = "✅ Enabled" if button.is_enabled else "❌ Disabled"
    url_line = f"🔗 URL: {escape(button.url)}\n" if button.button_type == "url" else ""
    text = (
        f"{note}🔘 <b>BUTTON</b>\n\n"
        f"Label: {escape(button.label)}\n"
        f"Type: {_TYPE_LABELS.get(button.button_type, escape(button.button_type))}\n"
        f"{url_line}"
        f"Action: <code>{escape(button.action)}</code>\n"
        f"Status: {status}"
    )
    await safe_edit(
        callback.message,
        text,
        admin_button_edit_keyboard(button.id, is_url=button.button_type == "url"),
    )
    return True


async def _create_button(
    message: Message | None,
    services: ServiceContainer,
    admin_id: int,
    *,
    label: str,
    action: str,
    button_type: str,
    url: str | None,
) -> None:
    """Create a validated button, audit it and reply with the list screen."""
    button = await services.admin.buttons.create(
        label, action, button_type=button_type, url=url
    )
    await services.admin.audit.log(
        admin_id,
        "buttons.create",
        target_type="button",
        target_id=button.id,
        details={"button_type": button_type, "action": action},
    )
    buttons = await services.admin.buttons.list_buttons()
    if message is None:
        return
    await message.answer(
        f"✅ Button created: {escape(button.label)}\n\n"
        f"🔘 <b>BUTTONS</b>\n\n{len(buttons)} button(s) configured.",
        reply_markup=admin_buttons_keyboard(buttons),
        parse_mode="HTML",
    )


def _valid_https_url(url: str) -> bool:
    """True for clean ``https://`` links only."""
    parsed = urlparse(url.strip())
    return parsed.scheme.lower() == "https" and bool(parsed.hostname)


# ----------------------------------------------------------------------
# Screens
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:btn")
async def buttons_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Buttons manager list."""
    await _render_list(callback, services)
    await safe_answer(callback)


@router.callback_query(F.data == "adm:btn:add")
async def button_add_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """New-button type picker."""
    if not await _guard(callback, services, "buttons"):
        return
    text = "➕ <b>ADD BUTTON</b>\n\nChoose the button type."
    await safe_edit(callback.message, text, admin_add_button_type_keyboard())
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_BTN_NEW_RE.pattern))
async def button_new_type(
    callback: CallbackQuery, state: FSMContext, services: ServiceContainer
) -> None:
    """Start creating a button of the chosen type (label FSM)."""
    if not await _guard(callback, services, "buttons"):
        return
    match = _BTN_NEW_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    button_type = match.group(1)
    await state.update_data(btn_type=button_type)
    await state.set_state(AdminFSM.btn_label)
    if callback.message is not None:
        await callback.message.answer(
            "🔘 Send the button label (max 64 chars).\n\n/cancel — abort"
        )
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_BTN_ACTION_RE.pattern))
async def button_pick_action(
    callback: CallbackQuery, state: FSMContext, services: ServiceContainer
) -> None:
    """Create a callback button for the chosen KNOWN_ACTION."""
    if not await _guard(callback, services, "buttons"):
        return
    match = _BTN_ACTION_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    action = match.group(1)
    if action not in KNOWN_ACTIONS:
        await safe_answer(callback, "ℹ️ Unknown action.")
        return
    data = await state.get_data()
    label = str(data.get("btn_label") or "")
    await state.clear()
    if not label:
        await safe_answer(callback, "ℹ️ Session expired — start again.", show_alert=True)
        return
    try:
        await _create_button(
            callback.message,
            services,
            callback.from_user.id,
            label=label,
            action=action,
            button_type="callback",
            url=None,
        )
    except BotError as exc:
        if callback.message is not None:
            await callback.message.answer(exc.user_message)
    await safe_answer(callback, "✅ Button created.")


# ----------------------------------------------------------------------
# FSM: label / url
# ----------------------------------------------------------------------
@router.message(AdminFSM.btn_label, F.text)
async def button_label_input(
    message: Message, state: FSMContext, services: ServiceContainer
) -> None:
    """Receive the button label — create mode continues, edit mode updates."""
    text = (message.text or "").strip()
    if text.startswith("/cancel"):
        await state.clear()
        await message.answer("ℹ️ Cancelled.")
        return
    if not text or len(text) > _MAX_LABEL:
        await message.answer(f"❌ Label must be 1–{_MAX_LABEL} chars. Try again or /cancel.")
        return

    data = await state.get_data()
    if "edit_button_id" in data:  # edit mode
        button_id = int(data["edit_button_id"])
        await state.clear()
        try:
            await services.admin.buttons.update(button_id, label=text)
        except BotError as exc:
            await message.answer(exc.user_message)
            return
        await services.admin.audit.log(
            message.from_user.id,
            "buttons.update",
            target_type="button",
            target_id=button_id,
            details={"field": "label"},
        )
        button = await services.admin.buttons.get(button_id)
        await message.answer(
            "✅ Label updated.\n\n"
            f"🔘 <b>BUTTON</b>\n\nLabel: {escape(text)}\n"
            f"Type: {_TYPE_LABELS.get(button.button_type, escape(button.button_type))}",
            reply_markup=admin_button_edit_keyboard(
                button_id, is_url=button.button_type == "url"
            ),
            parse_mode="HTML",
        )
        return

    button_type = str(data.get("btn_type") or "")
    if button_type == "url":
        await state.update_data(btn_label=text)
        await state.set_state(AdminFSM.btn_url)
        await message.answer("🔗 Send the URL (https:// only).\n\n/cancel — abort")
        return
    if button_type == "callback":
        await state.update_data(btn_label=text)
        await message.answer(
            "🔘 Choose the action for this button:",
            reply_markup=admin_button_action_picker_keyboard(),
        )
        return
    if button_type == "add_group":
        await state.clear()
        try:
            await _create_button(
                message,
                services,
                message.from_user.id,
                label=text,
                action="add_group",
                button_type="add_group",
                url=None,
            )
        except BotError as exc:
            await message.answer(exc.user_message)
        return
    await state.clear()
    await message.answer("ℹ️ Session expired — start again from 🔘 Buttons.")


@router.message(AdminFSM.btn_url, F.text)
async def button_url_input(
    message: Message, state: FSMContext, services: ServiceContainer
) -> None:
    """Receive the URL — create mode creates the button, edit mode updates."""
    text = (message.text or "").strip()
    if text.startswith("/cancel"):
        await state.clear()
        await message.answer("ℹ️ Cancelled.")
        return
    if not _valid_https_url(text):
        await message.answer("❌ Button URL must be a valid https:// link. Try again or /cancel.")
        return

    data = await state.get_data()
    if "edit_button_id" in data:  # edit mode
        button_id = int(data["edit_button_id"])
        await state.clear()
        try:
            await services.admin.buttons.update(button_id, url=text)
        except BotError as exc:
            await message.answer(exc.user_message)
            return
        await services.admin.audit.log(
            message.from_user.id,
            "buttons.update",
            target_type="button",
            target_id=button_id,
            details={"field": "url"},
        )
        button = await services.admin.buttons.get(button_id)
        await message.answer(
            "✅ URL updated.\n\n🔘 <b>BUTTON</b>\n\n"
            f"Label: {escape(button.label)}\n🔗 URL: {escape(text)}",
            reply_markup=admin_button_edit_keyboard(button_id, is_url=True),
            parse_mode="HTML",
        )
        return

    label = str(data.get("btn_label") or "")
    await state.clear()
    if not label:
        await message.answer("ℹ️ Session expired — start again from 🔘 Buttons.")
        return
    try:
        await _create_button(
            message,
            services,
            message.from_user.id,
            label=label,
            action="url",
            button_type="url",
            url=text,
        )
    except BotError as exc:
        await message.answer(exc.user_message)


# ----------------------------------------------------------------------
# Edit / reorder / toggle / delete
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(_BTN_EDIT_RE.pattern))
async def button_edit_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Open one button's edit screen."""
    match = _BTN_EDIT_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    await _render_edit(callback, services, int(match.group(1)))
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_BTN_EDIT_LABEL_RE.pattern))
async def button_edit_label_prompt(
    callback: CallbackQuery, state: FSMContext, services: ServiceContainer
) -> None:
    """FSM: new label for an existing button."""
    if not await _guard(callback, services, "buttons"):
        return
    match = _BTN_EDIT_LABEL_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    await state.update_data(edit_button_id=int(match.group(1)))
    await state.set_state(AdminFSM.btn_label)
    if callback.message is not None:
        await callback.message.answer("🔘 Send the new label (max 64 chars).\n\n/cancel — abort")
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_BTN_EDIT_URL_RE.pattern))
async def button_edit_url_prompt(
    callback: CallbackQuery, state: FSMContext, services: ServiceContainer
) -> None:
    """FSM: new https URL for an existing url-type button."""
    if not await _guard(callback, services, "buttons"):
        return
    match = _BTN_EDIT_URL_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    button = await services.admin.buttons.get(int(match.group(1)))
    if button is None or button.button_type != "url":
        await safe_answer(callback, "ℹ️ Only URL buttons have a URL.")
        return
    await state.update_data(edit_button_id=button.id)
    await state.set_state(AdminFSM.btn_url)
    if callback.message is not None:
        await callback.message.answer("🔗 Send the new URL (https:// only).\n\n/cancel — abort")
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_BTN_MOVE_RE.pattern))
async def button_move(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Move a button up/down one slot (audited)."""
    if not await _guard(callback, services, "buttons"):
        return
    match = _BTN_MOVE_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    button_id = int(match.group(1))
    direction = -1 if match.group(2) == "up" else 1
    moved = await services.admin.buttons.move(button_id, direction)
    if moved is None:
        await safe_answer(callback, "ℹ️ Button not found.")
        return
    await services.admin.audit.log(
        callback.from_user.id,
        "buttons.move",
        target_type="button",
        target_id=button_id,
        details={"direction": match.group(2)},
    )
    await _render_list(callback, services)
    await safe_answer(callback, "⬆️ Moved up." if direction < 0 else "⬇️ Moved down.")


@router.callback_query(F.data.regexp(_BTN_TOGGLE_RE.pattern))
async def button_toggle(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Enable/disable a button (audited)."""
    if not await _guard(callback, services, "buttons"):
        return
    match = _BTN_TOGGLE_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    button_id = int(match.group(1))
    button = await services.admin.buttons.get(button_id)
    if button is None:
        await safe_answer(callback, "ℹ️ Button not found.")
        return
    enabled = not button.is_enabled
    await services.admin.buttons.toggle(button_id, enabled)
    await services.admin.audit.log(
        callback.from_user.id,
        "buttons.toggle",
        target_type="button",
        target_id=button_id,
        details={"enabled": enabled},
    )
    await _render_edit(callback, services, button_id)
    await safe_answer(callback, "✅ Enabled." if enabled else "⏸️ Disabled.")


@router.callback_query(F.data.regexp(_BTN_DEL_RE.pattern))
async def button_delete_confirm(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Ask for confirmation before deleting a button."""
    if not await _guard(callback, services, "buttons"):
        return
    match = _BTN_DEL_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    button_id = int(match.group(1))
    button = await services.admin.buttons.get(button_id)
    if button is None:
        await safe_answer(callback, "ℹ️ Button not found.")
        return
    text = (
        "🗑️ <b>DELETE BUTTON</b>\n\n"
        f"Delete “{escape(button.label)}”?\n\nThis cannot be undone."
    )
    await safe_edit(
        callback.message, text, admin_button_delete_confirm_keyboard(button_id)
    )
    await safe_answer(callback)


@router.callback_query(F.data.regexp(_BTN_DEL_YES_RE.pattern))
async def button_delete(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Delete the button after confirmation (audited)."""
    if not await _guard(callback, services, "buttons"):
        return
    match = _BTN_DEL_YES_RE.match(callback.data or "")
    if match is None:
        await safe_answer(callback)
        return
    button_id = int(match.group(1))
    deleted = await services.admin.buttons.delete(button_id)
    await services.admin.audit.log(
        callback.from_user.id,
        "buttons.delete",
        target_type="button",
        target_id=button_id,
        result="ok" if deleted else "noop",
    )
    await _render_list(callback, services, note="🗑️ Button deleted.\n\n" if deleted else "")
    await safe_answer(callback, "🗑️ Deleted." if deleted else "ℹ️ Button not found.")


# ----------------------------------------------------------------------
# Preview
# ----------------------------------------------------------------------
@router.callback_query(F.data == "adm:btn:preview")
async def button_preview(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Send an exact start-screen preview (message + rendered keyboard)."""
    bot = callback.bot
    username = getattr(bot, "username", None) or ""
    if not username:
        try:
            username = (await bot.get_me()).username or ""
        except Exception:  # noqa: BLE001 — preview must never crash
            username = ""
    name = callback.from_user.first_name or "there"
    text = await services.admin.appearance.message("start", name=name, bot_name=username or "bot")
    keyboard: InlineKeyboardMarkup | None
    if username:
        keyboard = await services.admin.buttons.render_keyboard(username)
    else:
        keyboard = None
    text = (
        f"{text}\n\n<i>👁️ Preview only — buttons won't act."
        + ("" if keyboard else " (bot username unavailable)")
        + "</i>"
    )
    if callback.message is not None:
        await callback.message.answer(text, reply_markup=keyboard, parse_mode="HTML")
    await safe_answer(callback, "👁️ Preview sent below.")


__all__ = ["router"]

"""Admin statistics and system health screens."""

from __future__ import annotations

from typing import Any

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.bot.keyboards.admin import admin_stats_keyboard
from app.bot.services import ServiceContainer
from app.utils.formatting import human_count
from app.utils.telegram import safe_answer, safe_edit

router = Router(name="admin_statistics")

_STATUS_ICONS: dict[str, str] = {
    "completed": "✅",
    "cancelled": "⛔",
    "failed": "❌",
    "sending": "📤",
    "pending": "⏳",
    "paused": "⏸️",
    "draft": "📝",
}


def _ok(flag: bool) -> str:
    """🟢/🔴 for a boolean subsystem state."""
    return "🟢" if flag else "🔴"


def _broadcast_summary(by_status: dict[str, int]) -> str:
    """'7 total (✅ 5 ⛔ 1 ⏳ 1)' — counts per status with icons."""
    total = sum(value for value in by_status.values() if isinstance(value, int))
    parts = " ".join(
        f"{_STATUS_ICONS.get(status, '•')} {count}"
        for status, count in sorted(by_status.items())
        if isinstance(count, int)
    )
    return f"{total} total" + (f" ({parts})" if parts else "")


@router.callback_query(F.data == "adm:stats")
async def statistics_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Platform overview (cached ~60s inside the statistics service)."""
    overview: dict[str, Any] = await services.admin.statistics.overview()
    users = overview.get("users", {})
    groups = overview.get("groups", {})
    tracks = overview.get("tracks", {})
    plays = overview.get("plays", {})
    likes = overview.get("likes", {})
    autoplay = overview.get("autoplay", {})
    broadcasts = overview.get("broadcasts", {})

    text = (
        "📊 <b>STATISTICS</b>\n\n"
        f"👤 Users: {human_count(int(users.get('total', 0)))} total | "
        f"{human_count(int(users.get('active', 0)))} active | "
        f"{human_count(int(users.get('new_week', 0)))} new this week\n"
        f"👥 Groups: {human_count(int(groups.get('total', 0)))} total | "
        f"{human_count(int(groups.get('active', 0)))} active\n"
        f"🎵 Tracks: {human_count(int(tracks.get('total', 0)))}\n\n"
        f"▶️ Plays (24h): {human_count(int(plays.get('24h', 0)))}\n"
        f"❤️ Likes (24h): {human_count(int(likes.get('count', 0)))}\n"
        f"🤖 Autoplay picks (24h): {human_count(int(autoplay.get('selections', 0)))}\n"
        f"📢 Broadcasts: {_broadcast_summary(broadcasts.get('by_status', {}))}"
    )
    await safe_edit(callback.message, text, admin_stats_keyboard())
    await safe_answer(callback)


@router.callback_query(F.data == "adm:sys")
async def system_screen(callback: CallbackQuery, services: ServiceContainer) -> None:
    """System health: database, cache, workers, voice engine, maintenance."""
    db_ok = await services.db.ping()
    cache_ok = await services.cache.ping()
    # Workers are healthy unless the manager reports itself stopped.
    workers_ok = not bool(getattr(services.workers, "_stopped", False))

    voice_enabled = await services.voice.is_voice_enabled()
    if not voice_enabled:
        voice_status = "not_configured"
    else:
        status = await services.voice.status()
        if status.healthy_accounts:
            voice_status = "healthy"
        elif status.total_accounts:
            voice_status = "degraded"
        else:
            voice_status = "not_configured"

    maintenance = await services.admin.settings.maintenance()
    health = await services.admin.statistics.system_health(
        db_ok=db_ok,
        cache_ok=cache_ok,
        workers_ok=workers_ok,
        voice_status=voice_status,
        maintenance=maintenance,
    )

    overall = {"ok": "🟢", "degraded": "🟡", "down": "🔴"}.get(
        str(health.get("status")), "🔴"
    )
    voice = health.get("voice", {})
    text = (
        "🩺 <b>SYSTEM HEALTH</b>\n\n"
        f"Overall: {overall} {health.get('status')}\n\n"
        f"Database: {_ok(bool(health.get('database')))}\n"
        f"Cache: {_ok(bool(health.get('cache')))}\n"
        f"Workers: {_ok(bool(health.get('workers')))}\n"
        f"Voice: {_ok(bool(voice.get('ok')))} ({voice.get('status')})\n"
        f"Maintenance: {'✅ On' if maintenance['enabled'] else '❌ Off'}"
    )
    await safe_edit(callback.message, text, admin_stats_keyboard())
    await safe_answer(callback)


__all__ = ["router"]

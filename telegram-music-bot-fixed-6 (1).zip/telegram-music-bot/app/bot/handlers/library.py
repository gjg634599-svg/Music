"""Personal library screens: hub, liked songs, recently played, settings.

Navigation conventions (CONTRACTS §8): every screen edits the existing
message via :func:`app.bot.keyboards.common.edit_screen`, always carries a
Back button and every callback is answered.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.bot.keyboards.common import edit_screen
from app.bot.keyboards.library import (
    LIKED_PAGE_SIZE,
    NEW_PAGE_SIZE,
    library_home_keyboard,
    liked_keyboard,
    new_releases_keyboard,
    settings_keyboard,
)
from app.errors import BotError
from app.logging import get_logger, log_extra
from app.playback.queue import QueueOwner
from app.utils import paginate, safe_answer, track_line

from app.bot.handlers.search import artist_name

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer
    from app.database.models import Track

logger = get_logger(__name__)

#: Recently played tracks shown (single page).
RECENT_LIMIT = 8

#: Repeat-mode cycle order for the settings toggle.
_REPEAT_CYCLE = {"off": "all", "all": "one", "one": "off"}

router = Router(name="library")


# ----------------------------------------------------------------------
# Screen renderers (imported by the dashboard dispatcher in start.py)
# ----------------------------------------------------------------------
def render_library_home() -> tuple[str, InlineKeyboardMarkup]:
    """The My Library hub screen."""
    text = "📚 <b>MY LIBRARY</b>\n\nYour music in one place."
    return text, library_home_keyboard()


async def _render_liked(
    services: "ServiceContainer", tg_user_id: int, page: int
) -> tuple[str, InlineKeyboardMarkup]:
    """One page of liked songs."""
    tracks: "list[Track]" = await services.library.liked_tracks(
        tg_user_id, limit=LIKED_PAGE_SIZE * 10
    )
    window = paginate(tracks, page, LIKED_PAGE_SIZE)
    lines = [f"❤️ <b>LIKED SONGS</b> · {len(tracks)}", ""]
    if not window.items:
        lines.append("ℹ️ No liked songs yet — tap ❤️ on any track.")
    else:
        for offset, track in enumerate(window.items):
            lines.append(
                track_line(
                    (window.page - 1) * LIKED_PAGE_SIZE + offset + 1,
                    track.title,
                    artist_name(track),
                )
            )
    text = "\n".join(lines)
    page_ids = [track.id for track in window.items]
    keyboard = liked_keyboard(window.page, window.total_pages, page_ids)
    return text, keyboard


async def _render_recent(
    services: "ServiceContainer", tg_user_id: int
) -> tuple[str, InlineKeyboardMarkup]:
    """Recently played tracks (single page)."""
    tracks: "list[Track]" = await services.library.recent_tracks(
        tg_user_id, limit=RECENT_LIMIT
    )
    lines = ["🕘 <b>RECENTLY PLAYED</b>", ""]
    if not tracks:
        lines.append("ℹ️ Nothing played yet — search for a song!")
    else:
        for index, track in enumerate(tracks, start=1):
            lines.append(track_line(index, track.title, artist_name(track)))
    rows: list[list[InlineKeyboardButton]] = []
    row: list[InlineKeyboardButton] = []
    for index, track in enumerate(tracks, start=1):
        row.append(InlineKeyboardButton(text=str(index), callback_data=f"trk:{track.id}"))
        if len(row) >= 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton(text="🔙 Back", callback_data="lib:home")])
    return "\n".join(lines), InlineKeyboardMarkup(inline_keyboard=rows)


async def _render_new(
    services: "ServiceContainer", page: int
) -> tuple[str, InlineKeyboardMarkup]:
    """One page of the newest playable catalog tracks (``/new`` browse)."""
    page = max(1, int(page))
    tracks, total = await services.music.new_releases(
        limit=NEW_PAGE_SIZE, offset=(page - 1) * NEW_PAGE_SIZE
    )
    total_pages = max(1, -(-total // NEW_PAGE_SIZE))
    if page > total_pages:
        # Stale keyboard / out-of-range page — jump to the last real page
        # instead of rendering an empty screen for a non-empty catalog.
        page = total_pages
        tracks, _ = await services.music.new_releases(
            limit=NEW_PAGE_SIZE, offset=(page - 1) * NEW_PAGE_SIZE
        )
    lines = [f"🆕 <b>NEW RELEASES</b> · {total} tracks", ""]
    if not tracks:
        lines.append("ℹ️ The catalog is empty — send me an audio file to add the first track!")
    else:
        for offset, track in enumerate(tracks):
            lines.append(
                track_line(
                    (page - 1) * NEW_PAGE_SIZE + offset + 1,
                    track.title,
                    artist_name(track),
                )
            )
        if total_pages > 1:
            lines.append("")
            lines.append(f"📄 Page {page} of {total_pages} — freshest first")
    text = "\n".join(lines)
    keyboard = new_releases_keyboard(page, total_pages, [t.id for t in tracks])
    return text, keyboard


async def render_settings(
    services: "ServiceContainer", tg_user_id: int
) -> tuple[str, InlineKeyboardMarkup]:
    """The playback preferences screen (session-level preferences)."""
    owner = QueueOwner(kind="user", id=tg_user_id)
    session = await services.sessions.get(owner)
    user = await services.users.get(tg_user_id)
    language = getattr(getattr(user, "preferences", None), "language", "en") or "en"
    text = (
        "⚙️ <b>SETTINGS</b>\n\n"
        "Playback preferences apply to your personal queue.\n\n"
        "🤖 Autoplay — keep music going when the queue runs dry\n"
        "🔀 Shuffle — randomize upcoming tracks\n"
        "🔁 Repeat — off · all · one"
    )
    keyboard = settings_keyboard(
        autoplay=bool(session.autoplay),
        shuffle=bool(session.shuffle),
        repeat=session.repeat_mode or "off",
        language=language,
    )
    return text, keyboard


# ----------------------------------------------------------------------
# Library navigation callbacks
# ----------------------------------------------------------------------
async def _clear_playlist_add_mode(state: FSMContext) -> None:
    """Drop a stale playlist-add context when the user navigates away."""
    data = await state.get_data()
    if data.get("mode") == "playlist_add":
        await state.update_data(mode=None, playlist_id=None)


@router.callback_query(F.data == "lib:home")
async def on_library_home(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """My Library hub."""
    await _clear_playlist_add_mode(state)
    text, keyboard = render_library_home()
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data == "lib:liked")
async def on_liked(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Liked songs, first page."""
    await _clear_playlist_add_mode(state)
    text, keyboard = await _render_liked(services, callback.from_user.id, 1)
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(r"^lib:liked:\d+$"))
async def on_liked_page(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Liked songs, page N (1-based)."""
    page = int(str(callback.data).rsplit(":", 1)[1])
    text, keyboard = await _render_liked(services, callback.from_user.id, max(1, page))
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data == "lib:recent")
async def on_recent(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Recently played tracks."""
    await _clear_playlist_add_mode(state)
    text, keyboard = await _render_recent(services, callback.from_user.id)
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data == "lib:new")
async def on_new_releases(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """New releases browse, first page."""
    await _clear_playlist_add_mode(state)
    text, keyboard = await _render_new(services, 1)
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(r"^lib:new:\d+$"))
async def on_new_releases_page(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """New releases browse, page N (1-based)."""
    page = int(str(callback.data).rsplit(":", 1)[1])
    text, keyboard = await _render_new(services, max(1, page))
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


# ----------------------------------------------------------------------
# Settings toggles (session-level playback preferences)
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(r"^set:(autoplay|shuffle|repeat)$"))
async def on_setting_toggle(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Toggle autoplay/shuffle or cycle the repeat mode for this session."""
    owner = QueueOwner(kind="user", id=callback.from_user.id)
    session = await services.sessions.get(owner)
    key = str(callback.data).split(":", 1)[1]
    try:
        if key == "autoplay":
            enabled = await services.playback.set_autoplay(owner, not session.autoplay)
            toast = f"🤖 Autoplay: {'on' if enabled else 'off'}"
        elif key == "shuffle":
            enabled = await services.playback.set_shuffle(owner, not session.shuffle)
            toast = f"🔀 Shuffle: {'on' if enabled else 'off'}"
        else:
            mode = _REPEAT_CYCLE.get(session.repeat_mode or "off", "all")
            await services.playback.set_repeat(owner, mode)
            toast = f"🔁 Repeat: {mode}"
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    logger.info(
        "bot.settings_toggled", extra=log_extra(key=key, user_id=owner.id)
    )
    text, keyboard = await render_settings(services, callback.from_user.id)
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback, toast)


# ----------------------------------------------------------------------
# Private commands mirroring the screens
# ----------------------------------------------------------------------
@router.message(Command("liked"), F.chat.type == "private")
async def cmd_liked(message: Message, services: ServiceContainer) -> None:
    """/liked — liked songs as a fresh message."""
    text, keyboard = await _render_liked(services, message.from_user.id, 1)
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


@router.message(Command("history"), F.chat.type == "private")
async def cmd_history(message: Message, services: ServiceContainer) -> None:
    """/history — recently played as a fresh message."""
    text, keyboard = await _render_recent(services, message.from_user.id)
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


@router.message(Command("new"), F.chat.type == "private")
async def cmd_new(message: Message, services: ServiceContainer) -> None:
    """/new — the newest catalog tracks as a fresh message."""
    text, keyboard = await _render_new(services, 1)
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)
    logger.info(
        "bot.new_releases",
        extra=log_extra(user_id=message.from_user.id if message.from_user else 0),
    )


@router.message(Command("settings"), F.chat.type == "private")
async def cmd_settings(message: Message, services: ServiceContainer) -> None:
    """/settings — playback preferences as a fresh message."""
    text, keyboard = await render_settings(services, message.from_user.id)
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

"""/mystats — the personal listening statistics screen.

Two entry points share one renderer (CONTRACTS §8 navigation rules):
the ``/mystats`` command in private chats and the ``dash:stats``
dashboard button action (dispatched from ``start.py``). Every screen edit
follows :func:`app.bot.keyboards.common.edit_screen` conventions and
always carries a Back button.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message

from app.bot.keyboards.common import back_button, edit_screen
from app.errors import BotError
from app.logging import get_logger, log_extra
from app.utils import safe_answer

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer

logger = get_logger(__name__)

router = Router(name="stats")


async def render_stats_screen(
    services: "ServiceContainer", tg_user_id: int
) -> tuple[str, InlineKeyboardMarkup]:
    """The /mystats screen (aggregates listening history + likes)."""
    text = await services.stats.render(tg_user_id)
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[[back_button("nav:home")]]
    )
    return text, keyboard


@router.message(Command("mystats"), F.chat.type == "private")
async def cmd_mystats(message: Message, services: ServiceContainer) -> None:
    """/mystats — show personal listening statistics."""
    tg_user_id = message.from_user.id if message.from_user else 0
    logger.info(
        "bot.mystats", extra=log_extra(user_id=tg_user_id)
    )
    try:
        text, keyboard = await render_stats_screen(services, tg_user_id)
    except BotError as exc:
        await message.answer(exc.user_message)
        return
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


@router.callback_query(F.data == "dash:stats")
async def on_dash_stats(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Dashboard 'My Stats' button — edit into the stats screen."""
    try:
        text, keyboard = await render_stats_screen(services, callback.from_user.id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

"""Personal playlists: list, page, create, rename, delete, queue, add songs.

The "add songs" flow reuses :class:`~app.bot.handlers.search.SearchFSM`:
the search prompt is entered with ``mode='playlist_add'`` and the target
``playlist_id`` stored in FSM data, so tapping a search result
(``trk:<id>``) adds the track to the playlist instead of opening the track
page (handled in ``app.bot.handlers.search.on_track_button``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiogram import F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.bot.keyboards.common import cancel_button, edit_screen
from app.bot.keyboards.library import playlist_page_keyboard, playlists_keyboard
from app.bot.handlers.search import SearchFSM, artist_name
from app.errors import BotError, ValidationError
from app.logging import get_logger, log_extra
from app.playback.queue import QueueOwner
from app.utils import escape, paginate, safe_answer, track_line, truncate

if TYPE_CHECKING:  # pragma: no cover - typing only
    from app.bot.services import ServiceContainer
    from app.database.models import Playlist, Track

logger = get_logger(__name__)

#: Playlist tracks shown per page.
PLAYLIST_PAGE_SIZE = 8

#: Maximum playlist title length.
MAX_TITLE_LENGTH = 128


class PlaylistFSM(StatesGroup):
    """States of the create/rename/import playlist conversations."""

    title = State()
    rename = State()
    importing = State()


router = Router(name="playlists")


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
async def _user_db_id(services: "ServiceContainer", tg_user_id: int) -> int:
    """Resolve the DB user id, raising a friendly error for unknown users."""
    user = await services.users.get(tg_user_id)
    if user is None:
        raise ValidationError(
            f"Unknown user {tg_user_id}", user_message="ℹ️ Please press /start to begin."
        )
    return int(user.id)


def _owned_playlist(playlist: "Playlist | None", user_db_id: int) -> "Playlist":
    """Validate ownership of a fetched playlist."""
    if playlist is None:
        raise ValidationError(
            "Playlist not found", user_message="❌ Playlist not found."
        )
    if playlist.user_id != user_db_id:
        raise ValidationError(
            f"Playlist {playlist.id} belongs to another user",
            user_message="❌ You can only edit your own playlists.",
        )
    return playlist


async def render_playlists_list(
    services: "ServiceContainer", user_db_id: int
) -> tuple[str, InlineKeyboardMarkup]:
    """The playlist list screen."""
    playlists: "list[Playlist]" = await services.playlists.my_playlists(user_db_id)
    if playlists:
        text = f"📋 <b>MY PLAYLISTS</b> · {len(playlists)}"
    else:
        text = "📋 <b>MY PLAYLISTS</b>\n\nNo playlists yet — create your first one!"
    return text, playlists_keyboard(playlists)


async def render_playlist_page(
    services: "ServiceContainer",
    user_db_id: int,
    playlist_id: int,
    page: int = 1,
) -> tuple[str, InlineKeyboardMarkup]:
    """One playlist page: numbered tracks + remove buttons + actions.

    Raises:
        ValidationError: unknown playlist or foreign owner.
    """
    playlist = await services.playlists.get(playlist_id)
    _owned_playlist(playlist, user_db_id)
    tracks: "list[Track]" = [
        item.track for item in playlist.items if item.track is not None
    ]
    window = paginate(tracks, page, PLAYLIST_PAGE_SIZE)

    lines = [
        f"📋 <b>{escape(playlist.title)}</b> · {len(tracks)} tracks",
        "",
    ]
    if not window.items:
        lines.append("ℹ️ Empty playlist — add some songs!")
    else:
        for offset, track in enumerate(window.items):
            lines.append(
                track_line(
                    (window.page - 1) * PLAYLIST_PAGE_SIZE + offset + 1,
                    track.title,
                    artist_name(track),
                )
            )

    rows: list[list[InlineKeyboardButton]] = []
    for offset, track in enumerate(window.items):
        number = (window.page - 1) * PLAYLIST_PAGE_SIZE + offset + 1
        rows.append(
            [
                InlineKeyboardButton(
                    text=truncate(f"{number}. {track.title}", 40),
                    callback_data=f"trk:{track.id}",
                ),
                InlineKeyboardButton(
                    text="✖️",
                    callback_data=f"pl:trk:{playlist.id}:{track.id}",
                ),
            ]
        )
    markup = playlist_page_keyboard(playlist.id)
    if window.total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if window.has_prev:
            nav.append(
                InlineKeyboardButton(
                    text="⬅️", callback_data=f"pl:page:{playlist.id}:{window.prev_page}"
                )
            )
        if window.has_next:
            nav.append(
                InlineKeyboardButton(
                    text="➡️", callback_data=f"pl:page:{playlist.id}:{window.next_page}"
                )
            )
        if nav:
            markup.inline_keyboard.insert(0, nav)
    markup.inline_keyboard[0:0] = rows  # track rows first
    return "\n".join(lines), markup


async def _edit_playlist_list(
    callback: CallbackQuery, services: "ServiceContainer"
) -> None:
    user_db_id = await _user_db_id(services, callback.from_user.id)
    text, keyboard = await render_playlists_list(services, user_db_id)
    await edit_screen(callback.message, text, keyboard)


# ----------------------------------------------------------------------
# Navigation callbacks
# ----------------------------------------------------------------------
@router.callback_query(F.data == "lib:pl")
async def on_playlist_list(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """My playlists list."""
    await state.update_data(mode=None, playlist_id=None)
    try:
        await _edit_playlist_list(callback, services)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback)


@router.callback_query(F.data.regexp(r"^pl:page:\d+:\d+$"))
async def on_playlist_page_nav(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Paginate inside one playlist."""
    _, _, raw_id, raw_page = str(callback.data).split(":")
    try:
        user_db_id = await _user_db_id(services, callback.from_user.id)
        text, keyboard = await render_playlist_page(
            services, user_db_id, int(raw_id), max(1, int(raw_page))
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(r"^pl:\d+$"))
async def on_playlist_open(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Open one playlist page."""
    playlist_id = int(str(callback.data).split(":", 1)[1])
    try:
        user_db_id = await _user_db_id(services, callback.from_user.id)
        text, keyboard = await render_playlist_page(
            services, user_db_id, playlist_id
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


# ----------------------------------------------------------------------
# Create / rename FSM flows
# ----------------------------------------------------------------------
@router.callback_query(F.data == "pl:new")
async def on_playlist_new(
    callback: CallbackQuery, state: FSMContext
) -> None:
    """Start the create-playlist flow (ask for a title)."""
    await state.set_state(PlaylistFSM.title)
    await state.update_data(playlist_id=None)
    text = "➕ <b>NEW PLAYLIST</b>\n\nSend me a title for your playlist."
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[cancel_button()]])
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(r"^pl:ren:\d+$"))
async def on_playlist_rename(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Start the rename flow (ask for a new title)."""
    playlist_id = int(str(callback.data).rsplit(":", 1)[1])
    try:
        user_db_id = await _user_db_id(services, callback.from_user.id)
        playlist = await services.playlists.get(playlist_id)
        _owned_playlist(playlist, user_db_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await state.set_state(PlaylistFSM.rename)
    await state.update_data(playlist_id=playlist_id)
    text = (
        f"✏️ <b>RENAME PLAYLIST</b>\n\n{escape(playlist.title)}\n\n"
        "Send me a new title."
    )
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[cancel_button()]])
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.message(
    F.chat.type == "private", StateFilter(PlaylistFSM.title), F.text
)
async def on_playlist_title(
    message: Message, services: ServiceContainer, state: FSMContext
) -> None:
    """Receive the title and create the playlist."""
    title = (message.text or "").strip()[:MAX_TITLE_LENGTH]
    if not title:
        await message.answer("❌ Title cannot be empty — try again.")
        return
    try:
        user_db_id = await _user_db_id(services, message.from_user.id)
        playlist = await services.playlists.create(user_db_id, title)
    except BotError as exc:
        await message.answer(exc.user_message, parse_mode="HTML")
        return
    await state.clear()
    logger.info("bot.playlist_created", extra=log_extra(playlist_id=playlist.id))
    text, keyboard = await render_playlist_page(services, user_db_id, playlist.id)
    await message.answer(f"✅ Playlist <b>{escape(title)}</b> created.", parse_mode="HTML")
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


@router.message(
    F.chat.type == "private", StateFilter(PlaylistFSM.rename), F.text
)
async def on_playlist_rename_title(
    message: Message, services: ServiceContainer, state: FSMContext
) -> None:
    """Receive the new title and rename the playlist."""
    title = (message.text or "").strip()[:MAX_TITLE_LENGTH]
    if not title:
        await message.answer("❌ Title cannot be empty — try again.")
        return
    data = await state.get_data()
    playlist_id = int(data.get("playlist_id") or 0)
    try:
        user_db_id = await _user_db_id(services, message.from_user.id)
        playlist = await services.playlists.rename(playlist_id, user_db_id, title)
        if playlist is None:
            raise ValidationError(
                "Playlist not found", user_message="❌ Playlist not found."
            )
    except BotError as exc:
        await message.answer(exc.user_message, parse_mode="HTML")
        return
    await state.clear()
    logger.info("bot.playlist_renamed", extra=log_extra(playlist_id=playlist_id))
    text, keyboard = await render_playlist_page(services, user_db_id, playlist.id)
    await message.answer("✅ Playlist renamed.", parse_mode="HTML")
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


# ----------------------------------------------------------------------
# Delete (two-step confirm)
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(r"^pl:del:\d+$"))
async def on_playlist_delete(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Step one of deletion: ask for confirmation."""
    playlist_id = int(str(callback.data).rsplit(":", 1)[1])
    try:
        user_db_id = await _user_db_id(services, callback.from_user.id)
        playlist = await services.playlists.get(playlist_id)
        _owned_playlist(playlist, user_db_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    text = (
        f"🗑 <b>DELETE PLAYLIST?</b>\n\n{escape(playlist.title)}\n\n"
        "This cannot be undone."
    )
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Confirm", callback_data=f"pl:del:{playlist_id}:yes"
                ),
                InlineKeyboardButton(text="❌ Cancel", callback_data="lib:pl"),
            ]
        ]
    )
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.callback_query(F.data.regexp(r"^pl:del:\d+:yes$"))
async def on_playlist_delete_confirm(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Step two of deletion: actually remove the playlist."""
    playlist_id = int(str(callback.data).split(":")[2])
    try:
        user_db_id = await _user_db_id(services, callback.from_user.id)
        await services.playlists.delete(playlist_id, user_db_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    logger.info("bot.playlist_deleted", extra=log_extra(playlist_id=playlist_id))
    await safe_answer(callback, "🗑 Playlist deleted.")
    await _edit_playlist_list(callback, services)


# ----------------------------------------------------------------------
# Track rows inside a playlist
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(r"^pl:trk:\d+:\d+$"))
async def on_playlist_track_remove(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Remove one track from its playlist and re-render the page."""
    _, _, raw_playlist, raw_track = str(callback.data).split(":")
    playlist_id, track_id = int(raw_playlist), int(raw_track)
    try:
        user_db_id = await _user_db_id(services, callback.from_user.id)
        playlist = await services.playlists.get(playlist_id)
        _owned_playlist(playlist, user_db_id)
        await services.playlists.remove_track(playlist_id, track_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(callback, "✖️ Removed from playlist.")
    text, keyboard = await render_playlist_page(services, user_db_id, playlist_id)
    await edit_screen(callback.message, text, keyboard)


# ----------------------------------------------------------------------
# Queueing whole playlists
# ----------------------------------------------------------------------
async def _queue_playlist(
    callback: CallbackQuery,
    services: "ServiceContainer",
    playlist_id: int,
    *,
    shuffle: bool,
) -> None:
    """Queue all playlist tracks (optionally shuffled) and show the queue."""
    owner = QueueOwner(kind="user", id=callback.from_user.id)
    chat_id = callback.message.chat.id if callback.message else owner.id
    try:
        added = await services.playlists.queue_playlist(
            owner, playlist_id, services.queue
        )
        if shuffle:
            await services.queue.shuffle(owner)
        session = await services.sessions.get(owner)
        if session.status in ("idle", "stopped"):
            await services.playback.next(
                owner, chat_id, callback.bot, manual=True, skip=False
            )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    logger.info(
        "bot.playlist_queued",
        extra=log_extra(playlist_id=playlist_id, tracks=added, shuffle=shuffle),
    )
    await safe_answer(callback, f"▶️ {added} tracks queued")

    from app.bot.handlers.playback import render_queue_view

    text, keyboard = await render_queue_view(services, owner)
    await edit_screen(callback.message, text, keyboard)


@router.callback_query(F.data.regexp(r"^pl:play:\d+$"))
async def on_playlist_play(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Queue a playlist in order and start playback when idle."""
    playlist_id = int(str(callback.data).rsplit(":", 1)[1])
    await _queue_playlist(callback, services, playlist_id, shuffle=False)


@router.callback_query(F.data.regexp(r"^pl:shuf:\d+$"))
async def on_playlist_shuffle(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Queue a playlist and shuffle it before playback starts."""
    playlist_id = int(str(callback.data).rsplit(":", 1)[1])
    await _queue_playlist(callback, services, playlist_id, shuffle=True)


@router.callback_query(F.data.regexp(r"^pl:export:\d+$"))
async def on_playlist_export(callback: CallbackQuery, services: ServiceContainer) -> None:
    """Send the playlist as a standalone, forwardable text message."""
    playlist_id = int(str(callback.data).rsplit(":", 1)[1])
    try:
        user_db_id = await _user_db_id(services, callback.from_user.id)
        text = await services.playlists.export_text(playlist_id, user_db_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    # A NEW message (not an edit): the export has no keyboard so the user
    # can forward it to any chat as-is.
    if callback.message is not None:
        await callback.message.answer(text)
    await safe_answer(callback, "📤 Exported — forward it anywhere!")


# ----------------------------------------------------------------------
# Import flow (paste/forward an export, get a playlist back)
# ----------------------------------------------------------------------
@router.callback_query(F.data == "pl:import")
async def on_playlist_import(callback: CallbackQuery, state: FSMContext) -> None:
    """Start the import flow: ask for the playlist text."""
    await state.set_state(PlaylistFSM.importing)
    text = (
        "📥 <b>IMPORT PLAYLIST</b>\n\n"
        "Send me a playlist export (forward it or paste the text) or any "
        "numbered list like:\n\n"
        "<code>1. Title — Artist\n2. Title — Artist</code>\n\n"
        "I'll search the catalog and build a new playlist from the matches."
    )
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[cancel_button()]])
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


@router.message(
    F.chat.type == "private", StateFilter(PlaylistFSM.importing), F.text
)
async def on_playlist_import_text(
    message: Message, services: ServiceContainer, state: FSMContext
) -> None:
    """Parse the sent text and build the playlist from its matches."""
    try:
        user_db_id = await _user_db_id(services, message.from_user.id)
        result = await services.playlists.import_text(
            user_db_id, message.text or "", services.music.search
        )
    except BotError as exc:
        # state is kept so the user can simply send another text
        await message.answer(exc.user_message, parse_mode="HTML")
        return
    await state.clear()
    logger.info(
        "bot.playlist_imported",
        extra=log_extra(
            playlist_id=result.playlist.id,
            matched=len(result.matched),
            unmatched=len(result.unmatched),
        ),
    )
    lines = [
        f"✅ Imported <b>{len(result.matched)}</b> track(s) into "
        f"<b>{escape(result.playlist.title)}</b>."
    ]
    if result.unmatched:
        lines.append("\n⚠️ <b>Not found:</b>")
        for line in result.unmatched[:5]:
            label = line.title + (f" — {line.artist}" if line.artist else "")
            lines.append(f"• {escape(label)}")
        if len(result.unmatched) > 5:
            lines.append(f"… and {len(result.unmatched) - 5} more")
    await message.answer("\n".join(lines), parse_mode="HTML")
    text, keyboard = await render_playlist_page(services, user_db_id, result.playlist.id)
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


# ----------------------------------------------------------------------
# Add-songs flow (search FSM with playlist_add mode)
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(r"^pl:add:\d+$"))
async def on_playlist_add_songs(
    callback: CallbackQuery, services: ServiceContainer, state: FSMContext
) -> None:
    """Ask for a song name; subsequent search taps add to this playlist."""
    playlist_id = int(str(callback.data).rsplit(":", 1)[1])
    try:
        user_db_id = await _user_db_id(services, callback.from_user.id)
        playlist = await services.playlists.get(playlist_id)
        _owned_playlist(playlist, user_db_id)
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await state.set_state(SearchFSM.query)
    await state.update_data(
        mode="playlist_add",
        playlist_id=playlist_id,
        search_ids=[],
        search_query="",
        search_page=0,
    )
    text = (
        f"➕ <b>ADD TO PLAYLIST</b>\n\n"
        f"Send me a song name to add to <b>{escape(playlist.title)}</b>.\n\n"
        "Tap a result to add it, then keep searching."
    )
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[cancel_button()]])
    await edit_screen(callback.message, text, keyboard)
    await safe_answer(callback)


# ----------------------------------------------------------------------
# pladd:<playlist_id>:<track_id> — from the track page ➕ Playlist flow
# ----------------------------------------------------------------------
@router.callback_query(F.data.regexp(r"^pladd:\d+:\d+$"))
async def on_pladd(
    callback: CallbackQuery, services: ServiceContainer
) -> None:
    """Add the track to the chosen playlist (ownership checked)."""
    _, raw_playlist, raw_track = str(callback.data).split(":")
    playlist_id, track_id = int(raw_playlist), int(raw_track)
    try:
        user_db_id = await _user_db_id(services, callback.from_user.id)
        playlist = await services.playlists.get(playlist_id)
        _owned_playlist(playlist, user_db_id)
        added = await services.playlists.add_track(
            playlist_id, track_id, added_by=callback.from_user.id
        )
    except BotError as exc:
        await safe_answer(callback, exc.user_message)
        return
    await safe_answer(
        callback,
        f"✅ Added to {playlist.title}" if added else "ℹ️ Already in this playlist.",
    )


# ----------------------------------------------------------------------
# Private command
# ----------------------------------------------------------------------
@router.message(Command("playlists"), F.chat.type == "private")
async def cmd_playlists(message: Message, services: ServiceContainer) -> None:
    """/playlists — the playlist list as a fresh message."""
    try:
        user_db_id = await _user_db_id(services, message.from_user.id)
    except BotError as exc:
        await message.answer(exc.user_message, parse_mode="HTML")
        return
    text, keyboard = await render_playlists_list(services, user_db_id)
    await message.answer(text, parse_mode="HTML", reply_markup=keyboard)


def register(parent: Router) -> None:
    """Attach this router to the parent bot router."""
    parent.include_router(router)

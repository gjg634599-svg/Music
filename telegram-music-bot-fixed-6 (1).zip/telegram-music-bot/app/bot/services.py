"""Service container passed to every Telegram handler via aiogram workflow data.

The Application wires every service here at startup and stores it on the
dispatcher (``dp["services"] = container``); aiogram then injects it into
handlers that declare a ``services: ServiceContainer`` parameter.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover - typing-only imports (avoid cycles)
    from aiogram import Bot

    from app.admin.service import AdminService
    from app.audio.processor import AudioProcessor
    from app.broadcast.service import BroadcastService
    from app.broadcast.worker import BroadcastWorker
    from app.cache.redis import CacheProtocol, LockManager, RateLimiter
    from app.config import Settings
    from app.database.engine import Database
    from app.database.repositories.analytics import AnalyticsRepository
    from app.groups.permissions import GroupPermissions
    from app.groups.service import GroupService
    from app.groups.settings import GroupSettingsService
    from app.music.service import MusicService
    from app.playback.autoplay import AutoplayService
    from app.playback.controller import PlaybackController
    from app.playback.events import EventBus
    from app.playback.queue import QueueManager
    from app.playback.session import SessionManager
    from app.recommendation.engine import RecommendationEngine
    from app.storage import StorageService
    from app.users.history import HistoryService
    from app.users.library import LibraryService
    from app.users.playlists import PlaylistService
    from app.users.service import UserService
    from app.users.stats import UserStatsService
    from app.voice.login import VoiceLoginService
    from app.voice.manager import VoiceManager
    from app.workers.manager import WorkerManager


@dataclass(slots=True)
class ServiceContainer:
    """Every service the bot layer may need, injected explicitly."""

    settings: "Settings"
    db: "Database"
    cache: "CacheProtocol"
    limiter: "RateLimiter"
    locks: "LockManager"
    storage: "StorageService"
    events: "EventBus"

    # Music platform
    music: "MusicService"
    audio: "AudioProcessor"

    # Users / library
    users: "UserService"
    library: "LibraryService"
    history: "HistoryService"
    playlists: "PlaylistService"
    stats: "UserStatsService"

    # Groups
    groups: "GroupService"
    group_settings: "GroupSettingsService"
    permissions: "GroupPermissions"

    # Playback
    queue: "QueueManager"
    sessions: "SessionManager"
    playback: "PlaybackController"
    autoplay: "AutoplayService"
    recommendations: "RecommendationEngine"

    # Voice engine
    voice: "VoiceManager"
    voice_login: "VoiceLoginService"

    # Admin / broadcast / workers
    admin: "AdminService"
    broadcast: "BroadcastService"
    broadcast_worker: "BroadcastWorker"
    analytics: "AnalyticsRepository"
    workers: "WorkerManager"

    # Telegram bot instance (set at startup)
    bot: "Bot | None" = None

    def bot_or_raise(self) -> "Bot":
        if self.bot is None:  # pragma: no cover - startup order guarantee
            raise RuntimeError("Bot instance is not wired into the service container")
        return self.bot

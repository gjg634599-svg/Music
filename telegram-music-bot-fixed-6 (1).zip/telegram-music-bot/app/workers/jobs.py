"""Job model and types for the background worker system."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from enum import Enum

from app.errors import ValidationError


class JobType(str, Enum):
    """Registered job type identifiers (stored as plain strings on jobs)."""

    AUDIO_PROCESS = "audio_process"
    METADATA = "metadata"
    SEND_AUDIO = "send_audio"
    CLEANUP = "cleanup"
    BROADCAST = "broadcast"
    HEALTH_CHECK = "health_check"


@dataclass(slots=True)
class Job:
    """A queued background job."""

    id: str
    type: str
    payload: dict
    attempts: int = 0

    def to_dict(self) -> dict:
        """Serialize for the Redis queue (JSON-safe)."""
        return {"id": self.id, "type": self.type, "payload": self.payload,
                "attempts": self.attempts}

    @classmethod
    def from_dict(cls, data: dict) -> Job:
        """Rebuild a job from its serialized form."""
        return cls(
            id=str(data.get("id") or uuid.uuid4().hex[:12]),
            type=str(data.get("type") or ""),
            payload=dict(data.get("payload") or {}),
            attempts=int(data.get("attempts") or 0),
        )


def make_job(job_type: str, payload: dict | None = None) -> Job:
    """Create a new job with a short unique id."""
    job_type = (job_type or "").strip()
    if not job_type:
        raise ValidationError("Job type is required")
    return Job(
        id=uuid.uuid4().hex[:12],
        type=job_type,
        payload=dict(payload or {}),
        attempts=0,
    )


__all__ = ["Job", "JobType", "make_job"]

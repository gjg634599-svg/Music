"""Background worker manager: async job queue with a worker pool.

Transport: a Redis list (``jobs:queue``, LPUSH producers / BRPOP consumers)
when a ``redis.asyncio`` client is injected at wiring time, otherwise an
in-process ``asyncio.Queue`` (demo / single-process mode). Failed jobs are
re-enqueued with exponential delay up to ``MAX_ATTEMPTS`` tries; exhausted
jobs are dropped to the dead-letter list (``jobs:dead`` on Redis, logged in
memory mode).
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

from app.cache.redis import CacheProtocol, LockManager
from app.logging import get_logger, log_extra
from app.workers.jobs import Job
from app.workers.tasks import TASKS

logger = get_logger(__name__)

#: Redis list keys.
QUEUE_KEY = "jobs:queue"
DEAD_LETTER_KEY = "jobs:dead"

#: How long a Redis consumer waits for a job before looping (seconds).
FETCH_TIMEOUT = 5.0

#: Total delivery attempts (first try + retries) before dead-lettering.
MAX_ATTEMPTS = 3


class WorkerManager:
    """Job queue + worker pool supervisor."""

    def __init__(
        self,
        cache: CacheProtocol | None = None,
        locks: LockManager | None = None,
        *,
        redis: Any = None,
    ) -> None:
        self._cache = cache
        self._locks = locks
        self._redis = redis
        self._queue: asyncio.Queue[Job] = asyncio.Queue()
        self._tasks: list[asyncio.Task[None]] = []
        self._retry_tasks: set[asyncio.Task[None]] = set()
        self._stopped = False
        self._draining = False
        self._handlers: dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------
    def register(self, job_type: str, handler: Any) -> None:
        """Register (or replace) a handler for a job type."""
        self._handlers[job_type] = handler

    @property
    def redis_mode(self) -> bool:
        """True when jobs are transported through Redis."""
        return self._redis is not None

    # ------------------------------------------------------------------
    # Producer side
    # ------------------------------------------------------------------
    async def enqueue(self, job: Job) -> None:
        """Push a job onto the queue."""
        if self._redis is not None:
            await self._redis.lpush(QUEUE_KEY, json.dumps(job.to_dict()))
        else:
            self._queue.put_nowait(job)
        logger.info(
            "workers.enqueued", extra=log_extra(job_id=job.id, job_type=job.type)
        )

    # ------------------------------------------------------------------
    # Consumer side
    # ------------------------------------------------------------------
    async def run(self, concurrency: int = 2) -> None:
        """Start the worker pool and block until :meth:`stop` is called.

        The pool size defaults to ``settings.broadcast.worker_concurrency``
        (wiring passes it in). Workers survive job crashes; ``run`` returns
        once every worker task has exited.
        """
        self._stopped = False
        self._draining = False
        self._tasks = [
            asyncio.create_task(self._worker_loop(index), name=f"worker-{index}")
            for index in range(max(1, concurrency))
        ]
        try:
            await asyncio.gather(*self._tasks)
        except asyncio.CancelledError:
            await self._cancel_workers()
            raise

    async def stop(self) -> None:
        """Graceful stop: flag, cancel blocked workers, drain leftovers."""
        self._stopped = True
        await self._cancel_workers()
        for task in self._retry_tasks:
            task.cancel()
        if self._retry_tasks:
            await asyncio.gather(*self._retry_tasks, return_exceptions=True)
            self._retry_tasks.clear()
        await self._drain()
        logger.info("workers.stopped", extra={"redis_mode": self.redis_mode})

    async def _cancel_workers(self) -> None:
        for task in self._tasks:
            if not task.done():
                task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks = []

    async def _drain(self) -> None:
        """Log jobs left in the in-memory queue (Redis jobs stay persisted)."""
        self._draining = True
        leftover: list[Job] = []
        while not self._queue.empty():
            try:
                leftover.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        for job in leftover:
            logger.warning(
                "workers.job_dropped",
                extra=log_extra(job_id=job.id, job_type=job.type,
                                reason="shutdown"),
            )

    async def _worker_loop(self, index: int) -> None:
        """One consumer: fetch → execute, forever until stopped."""
        logger.info("workers.started", extra=log_extra(worker=index,
                                                       redis_mode=self.redis_mode))
        while not self._stopped:
            try:
                job = await self._fetch()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 — queue errors are retried
                logger.error("workers.fetch_failed", extra={"error": str(exc)[:300]})
                await asyncio.sleep(1.0)
                continue
            if job is None:
                continue
            await self._execute(job)
        logger.info("workers.stopped_loop", extra=log_extra(worker=index))

    async def _fetch(self) -> Job | None:
        """Fetch one job (Redis BRPOP or in-memory queue), or None on timeout."""
        if self._redis is not None:
            result = await self._redis.blpop(QUEUE_KEY, timeout=int(FETCH_TIMEOUT))
            if result is None:
                return None
            raw = result[1] if isinstance(result, (list, tuple)) else result
            return Job.from_dict(json.loads(raw))
        try:
            return await asyncio.wait_for(self._queue.get(), timeout=FETCH_TIMEOUT)
        except (asyncio.TimeoutError, TimeoutError):
            return None

    async def _execute(self, job: Job) -> None:
        """Run a job through its handler with retry handling."""
        handler = self._handlers.get(job.type) or TASKS.get(job.type)
        if handler is None:
            logger.error(
                "workers.no_handler",
                extra=log_extra(job_id=job.id, job_type=job.type),
            )
            return
        try:
            await handler(job.payload)
            logger.info(
                "workers.job_done",
                extra=log_extra(job_id=job.id, job_type=job.type,
                                attempts=job.attempts + 1),
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 — handler errors are contained
            attempts = job.attempts + 1
            logger.warning(
                "workers.job_failed",
                extra=log_extra(
                    job_id=job.id,
                    job_type=job.type,
                    attempts=attempts,
                    error=str(exc)[:300],
                ),
            )
            if attempts < MAX_ATTEMPTS:
                retry = asyncio.create_task(self._requeue_later(job, attempts))
                self._retry_tasks.add(retry)
                retry.add_done_callback(self._retry_tasks.discard)
            else:
                await self._dead_letter(job, str(exc))

    async def _requeue_later(self, job: Job, attempts: int) -> None:
        """Re-enqueue a failed job after exponential delay (2^attempts s)."""
        job.attempts = attempts
        await asyncio.sleep(min(2 ** attempts, 60))
        if self._stopped:
            logger.warning(
                "workers.job_dropped",
                extra=log_extra(job_id=job.id, job_type=job.type,
                                reason="shutdown during retry"),
            )
            return
        await self.enqueue(job)

    async def _dead_letter(self, job: Job, error: str) -> None:
        """Record an exhausted job (Redis dead list / log only)."""
        logger.error(
            "workers.job_dead",
            extra=log_extra(job_id=job.id, job_type=job.type, error=error[:300]),
        )
        if self._redis is not None:
            try:
                await self._redis.lpush(
                    DEAD_LETTER_KEY,
                    json.dumps({**job.to_dict(), "error": error[:500]}),
                )
            except Exception as exc:  # noqa: BLE001 — logging-only path
                logger.error("workers.dead_letter_failed",
                             extra={"error": str(exc)[:200]})


__all__ = ["WorkerManager", "QUEUE_KEY", "DEAD_LETTER_KEY", "MAX_ATTEMPTS"]

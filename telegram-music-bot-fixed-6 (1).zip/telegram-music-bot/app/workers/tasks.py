"""Background task registry.

Handlers are registered by name at import time with
:func:`register_task` and receive the services container at runtime via
:func:`bind` — the module never imports bot handlers or services directly
(they may live in modules that are not importable yet in other roles).

Registered tasks:

* ``cleanup_tmp`` — storage tmp sweeper.
* ``cleanup_downloads`` — completed download-cache sweeper.
* ``health_check`` — voice account health probe (voice-enabled deployments).
* ``broadcast`` — drive one broadcast through the delivery worker.
* ``audio_process`` — heavy audio pipeline processing for a track.
* ``send_audio`` — personal-mode playback send for a queued track.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import Any

from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: job type → handler
TASKS: dict[str, Callable[[dict], Awaitable[None]]] = {}

#: services container injected at wiring time (ServiceContainer)
_container: Any = None


def register_task(name: str) -> Callable[[Callable[[dict], Awaitable[None]]],
                                         Callable[[dict], Awaitable[None]]]:
    """Decorator: add a coroutine handler to the task registry."""

    def decorator(fn: Callable[[dict], Awaitable[None]]) -> Callable[[dict], Awaitable[None]]:
        if name in TASKS:
            raise RuntimeError(f"Task {name!r} is already registered")
        TASKS[name] = fn
        return fn

    return decorator


def bind(container: Any) -> None:
    """Inject the services container (called once at application startup)."""
    global _container
    _container = container
    logger.info("workers.container_bound")


def services() -> Any:
    """Return the bound container (or None when not wired yet)."""
    return _container


# ----------------------------------------------------------------------
# Built-in tasks
# ----------------------------------------------------------------------
@register_task("cleanup_tmp")
async def cleanup_tmp(payload: dict) -> None:
    """Remove stale files from the storage tmp directory."""
    storage = getattr(_container, "storage", None)
    if storage is None:
        logger.warning("workers.task_skipped", extra=log_extra(task="cleanup_tmp",
                                                               reason="no storage"))
        return
    max_age = int(payload.get("max_age_seconds") or 3600)
    removed = await asyncio.to_thread(storage.cleanup_tmp, max_age_seconds=max_age)
    logger.info("workers.cleanup_tmp", extra=log_extra(removed=removed))


@register_task("cleanup_downloads")
async def cleanup_downloads(payload: dict) -> None:
    """Remove expired files from the COMPLETED download cache.

    Retention comes from ``settings.cache_retention.retention_hours`` (the
    payload may override it). Files backing active playback are collected
    from the playback controller (``protected_file_paths``) and never
    deleted, whatever their age. Permanent content (uploads, artwork,
    databases, sessions) lives outside ``storage/downloads`` and is
    structurally out of scope. Removal counts and bytes are logged.
    """
    container = _container
    storage = getattr(container, "storage", None)
    settings = getattr(container, "settings", None)
    playback = getattr(container, "playback", None)
    if storage is None:
        logger.warning(
            "workers.task_skipped",
            extra=log_extra(task="cleanup_downloads", reason="no storage"),
        )
        return
    retention_hours = int(payload.get("retention_hours") or 0)
    if not retention_hours and settings is not None:
        retention_hours = int(
            getattr(getattr(settings, "cache_retention", None), "retention_hours", 72)
        )
    if retention_hours <= 0:
        logger.info("workers.cleanup_downloads_disabled")
        return

    protect: set[str] = set()
    if playback is not None and hasattr(playback, "protected_file_paths"):
        try:
            protect = {str(item) for item in await playback.protected_file_paths()}
        except Exception as exc:  # noqa: BLE001 — protection is best effort
            logger.warning(
                "workers.cleanup_protect_failed", extra=log_extra(error=str(exc)[:160])
            )

    removed, removed_bytes = await asyncio.to_thread(
        storage.cleanup_downloads,
        retention_hours * 3600,
        protect=protect,
    )
    logger.info(
        "workers.cleanup_downloads",
        extra=log_extra(removed=removed, bytes=removed_bytes, protected=len(protect)),
    )


@register_task("health_check")
async def health_check(payload: dict) -> None:
    """Probe voice accounts (no-op when the voice engine is disabled)."""
    container = _container
    voice = getattr(container, "voice", None)
    if voice is None:
        logger.warning("workers.task_skipped", extra=log_extra(task="health_check",
                                                               reason="no voice manager"))
        return
    settings = getattr(container, "settings", None)
    enabled = True
    if settings is not None:
        enabled = bool(getattr(settings, "voice_enabled", True))
    if not enabled:
        logger.info("workers.health_check_skipped", extra={"reason": "voice disabled"})
        return
    checker = getattr(voice, "run_health_checks", None)
    if checker is None:
        # VoiceManager facade exposes a HealthMonitor with run_checks().
        checker = getattr(voice, "run_checks", None)
    if checker is None:
        logger.warning("workers.task_skipped", extra=log_extra(task="health_check",
                                                               reason="no checker"))
        return
    try:
        result = checker()
        if hasattr(result, "__await__"):
            await result
        logger.info("workers.health_check_done")
    except Exception as exc:  # noqa: BLE001 — health probes must not crash workers
        logger.error("workers.health_check_failed", extra={"error": str(exc)[:300]})


@register_task("broadcast")
async def broadcast(payload: dict) -> None:
    """Drive one broadcast campaign through the delivery worker."""
    broadcast_id = payload.get("broadcast_id")
    if broadcast_id is None:
        logger.error("workers.broadcast_missing_id")
        return
    service = getattr(_container, "broadcast", None)
    if service is None:
        logger.warning("workers.task_skipped", extra=log_extra(task="broadcast",
                                                               reason="no service"))
        return
    try:
        await service.run_now(int(broadcast_id))
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "workers.broadcast_failed",
            extra=log_extra(broadcast_id=broadcast_id, error=str(exc)[:300]),
        )


@register_task("audio_process")
async def audio_process(payload: dict) -> None:
    """Run the heavy audio pipeline for a track (download/probe/convert).

    Tolerant wiring: resolves the pipeline from whichever attribute the
    container exposes (``pipeline`` / ``audio_pipeline``) and falls back to
    the AudioProcessor. Other agents' modules may not exist yet at import
    time of this module, so all attribute access is guarded.
    """
    track_id = payload.get("track_id")
    if track_id is None:
        logger.error("workers.audio_process_missing_track")
        return
    container = _container
    pipeline = (
        getattr(container, "pipeline", None)
        or getattr(container, "audio_pipeline", None)
        or getattr(container, "audio", None)
    )
    if pipeline is None or not hasattr(pipeline, "process_track"):
        logger.warning("workers.task_skipped", extra=log_extra(task="audio_process",
                                                               reason="no pipeline"))
        return
    music = getattr(container, "music", None)
    track = None
    if music is not None and hasattr(music, "get_track"):
        try:
            track = await music.get_track(int(track_id))
        except Exception as exc:  # noqa: BLE001
            logger.error("workers.audio_process_track_lookup_failed",
                         extra={"error": str(exc)[:300]})
            return
    if track is None:
        logger.warning("workers.audio_process_track_not_found",
                       extra={"track_id": track_id})
        return
    try:
        result = pipeline.process_track(track)
        if hasattr(result, "__await__"):
            await result
        logger.info("workers.audio_processed", extra=log_extra(track_id=track_id))
    except Exception as exc:  # noqa: BLE001
        logger.error("workers.audio_process_failed",
                     extra=log_extra(track_id=track_id, error=str(exc)[:300]))


@register_task("send_audio")
async def send_audio(payload: dict) -> None:
    """Personal-mode playback send: fetch the track and start playback.

    Payload: ``{user_tg_id, track_id, chat_id}``.
    """
    user_tg_id = payload.get("user_tg_id")
    track_id = payload.get("track_id")
    chat_id = payload.get("chat_id")
    if user_tg_id is None or track_id is None or chat_id is None:
        logger.error("workers.send_audio_missing_payload")
        return
    container = _container
    music = getattr(container, "music", None)
    playback = getattr(container, "playback", None)
    if music is None or playback is None or not hasattr(playback, "play_now"):
        logger.warning("workers.task_skipped", extra=log_extra(task="send_audio",
                                                               reason="no playback"))
        return
    try:
        from app.playback.queue import QueueOwner

        track = await music.get_track(int(track_id))
        if track is None:
            logger.warning("workers.send_audio_track_not_found",
                           extra={"track_id": track_id})
            return
        bot = getattr(container, "bot", None)
        if bot is None:
            provider = getattr(container, "bot_provider", None)
            bot = provider() if callable(provider) else None
        if bot is None:
            logger.warning("workers.task_skipped",
                           extra=log_extra(task="send_audio", reason="no bot"))
            return
        owner = QueueOwner(kind="user", id=int(user_tg_id))
        await playback.play_now(
            owner, int(chat_id), bot, int(track_id), int(user_tg_id)
        )
        logger.info("workers.audio_sent",
                    extra=log_extra(track_id=track_id, chat_id=chat_id))
    except Exception as exc:  # noqa: BLE001
        logger.error("workers.send_audio_failed",
                     extra=log_extra(track_id=track_id, error=str(exc)[:300]))


__all__ = ["TASKS", "register_task", "bind", "services"]

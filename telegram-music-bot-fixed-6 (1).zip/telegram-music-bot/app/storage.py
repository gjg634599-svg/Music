"""Storage abstraction: local storage now, S3-compatible later."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import BinaryIO

from app.config import Settings
from app.errors import ValidationError
from app.logging import get_logger
from app.security.validation import sanitize_filename

logger = get_logger(__name__)


class StorageService:
    """File storage under the configured storage directory.

    All paths are sandboxed inside the storage root — path traversal is
    impossible because user-supplied names are sanitized.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    # -- low-level API ---------------------------------------------------
    def resolve(self, relative: str) -> Path:
        """Safely resolve a storage-relative path."""
        candidate = (self.root / relative).resolve()
        if not candidate.is_relative_to(self.root):
            raise ValidationError("Invalid storage path")
        return candidate

    def save(self, relative: str, source: Path | BinaryIO | bytes) -> Path:
        """Save a file (from path, file object or bytes) into storage."""
        target = self.resolve(relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(source, bytes):
            target.write_bytes(source)
        elif isinstance(source, Path):
            shutil.copyfile(source, target)
        else:
            with target.open("wb") as handle:
                shutil.copyfileobj(source, handle)
        logger.info("storage.saved", extra={"path": relative})
        return target

    def get(self, relative: str) -> Path | None:
        path = self.resolve(relative)
        return path if path.exists() else None

    def exists(self, relative: str) -> bool:
        try:
            return self.resolve(relative).exists()
        except ValidationError:
            return False

    def delete(self, relative: str) -> bool:
        path = self.resolve(relative)
        if path.exists():
            path.unlink()
            return True
        return False

    def size(self, relative: str) -> int:
        return self.resolve(relative).stat().st_size

    # -- domain helpers --------------------------------------------------
    def music_dir(self) -> Path:
        path = self.root / "music"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def tmp_dir(self) -> Path:
        path = self.root / "tmp"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def downloads_dir(self) -> Path:
        path = self.root / "downloads"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def artwork_dir(self) -> Path:
        path = self.root / "artwork"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def unique_name(self, original_name: str, *, prefix: str = "") -> str:
        """A sanitized, unique filename inside the tmp dir."""
        import time
        import uuid

        safe = sanitize_filename(original_name)
        stamp = f"{int(time.time() * 1000)}-{uuid.uuid4().hex[:8]}"
        return f"{prefix}{stamp}-{safe}"

    def cleanup_tmp(self, max_age_seconds: int = 3600) -> int:
        """Remove stale files from the tmp directory; return removed count."""
        import time

        removed = 0
        cutoff = time.time() - max_age_seconds
        for path in self.tmp_dir().iterdir():
            try:
                if path.is_file() and path.stat().st_mtime < cutoff:
                    path.unlink()
                    removed += 1
            except OSError:  # pragma: no cover - best effort
                continue
        if removed:
            logger.info("storage.tmp_cleaned", extra={"removed": removed})
        return removed

    def cleanup_downloads(
        self,
        max_age_seconds: int = 72 * 3600,
        *,
        protect: set[str] | set[Path] | None = None,
    ) -> tuple[int, int]:
        """Remove expired files from the COMPLETED download cache.

        Distinct from :meth:`cleanup_tmp` (in-flight partial downloads): this
        sweeps ``storage/downloads/**`` — fully downloaded provider files.

        Safety rules:

        * Only regular files inside the downloads directory are removed —
          symlinks are skipped entirely (never followed, never deleted), so
          a planted link can never make the sweeper delete data outside
          the cache.
          Subdirectories ARE recursed, but each candidate must resolve
          inside the downloads root.
        * ``protect`` (storage-relative or absolute paths, best-effort
          matched on both forms) marks files backing ACTIVE playback —
          they are never touched, whatever their age.
        * Permanent content is structurally out of scope: uploads live in
          ``storage/music``, artwork in ``storage/artwork``, databases and
          sessions elsewhere — this method never walks those trees.
        * Permission/OS errors are logged and skipped; the sweep continues.

        Returns ``(removed_count, removed_bytes)``.
        """
        import time

        protect_set = {
            str(Path(item)) if isinstance(item, Path) else str(item)
            for item in (protect or ())
        }
        downloads = self.downloads_dir()
        removed_count = 0
        removed_bytes = 0
        cutoff = time.time() - max(0, int(max_age_seconds))

        def _is_protected(candidate: Path) -> bool:
            rel = str(candidate.relative_to(self.root))
            return rel in protect_set or str(candidate) in protect_set

        def _sweep(directory: Path) -> None:
            nonlocal removed_count, removed_bytes
            try:
                entries = list(directory.iterdir())
            except OSError as exc:  # pragma: no cover - missing dir/permissions
                logger.warning(
                    "storage.downloads_sweep_failed",
                    extra={"dir": str(directory), "error": str(exc)[:120]},
                )
                return
            for entry in entries:
                try:
                    if entry.is_symlink():
                        continue  # never follow or delete symlinks
                    if entry.is_dir():
                        if entry.resolve().is_relative_to(downloads):
                            _sweep(entry)
                        continue
                    if not entry.is_file():
                        continue
                    if not entry.resolve().is_relative_to(downloads):
                        continue  # sandbox escape guard (should not happen)
                    stat = entry.stat()
                    if stat.st_mtime >= cutoff:
                        continue  # too recent — keep
                    if _is_protected(entry):
                        logger.debug(
                            "storage.downloads_protected", extra={"path": entry.name}
                        )
                        continue
                    entry.unlink()
                    removed_count += 1
                    removed_bytes += int(stat.st_size)
                except OSError as exc:  # noqa: BLE001 — one bad file ≠ dead sweep
                    logger.warning(
                        "storage.downloads_remove_failed",
                        extra={"path": entry.name, "error": str(exc)[:120]},
                    )
                    continue

        _sweep(downloads)
        if removed_count:
            logger.info(
                "storage.downloads_cleaned",
                extra={"removed": removed_count, "bytes": removed_bytes},
            )
        return removed_count, removed_bytes


def create_storage(settings: Settings) -> StorageService:
    return StorageService(settings.storage_dir)

"""Broadcast delivery worker.

Drives a broadcast campaign to completion: fetches pending targets in
batches, delivers each message through the rate limiter, retries flood and
transient errors, records permanent failures and publishes
``broadcast_update`` progress events. Pause and cancel are checked while
the loop is running (status is re-read from the database every
``STATUS_CHECK_EVERY`` targets).
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from aiogram.exceptions import TelegramBadRequest
from app.broadcast.composer import buttons_to_keyboard
from app.broadcast.rate_limit import FLOOD, RETRY, classify
from app.config import Settings
from app.database.models.broadcast import Broadcast, BroadcastTarget
from app.database.repositories.broadcast import BroadcastRepository
from app.errors import BroadcastError
from app.logging import get_logger, log_extra
from app.playback.events import EventBus

logger = get_logger(__name__)

#: Batch size for pending-target fetches.
TARGET_BATCH = 500

#: Re-read the campaign status from the DB every N targets (pause/cancel).
STATUS_CHECK_EVERY = 25

#: Publish a progress event every N processed targets.
PROGRESS_EVERY = 20

#: aiogram Bot method names per single-media content type.
_MEDIA_SENDERS: dict[str, str] = {
    "photo": "send_photo",
    "video": "send_video",
    "audio": "send_audio",
    "document": "send_document",
    "animation": "send_animation",
    "voice": "send_voice",
}


def _is_parse_error(exc: TelegramBadRequest) -> bool:
    """Detect Telegram's "can't parse entities" HTML/Markdown failures."""
    return "parse entities" in str(exc).lower()


class BroadcastWorker:
    """Long-running broadcast delivery engine (one bot, rate limited)."""

    def __init__(
        self,
        bot: Any,
        repo: BroadcastRepository,
        limiter: Any,
        settings: Settings,
        events: EventBus,
    ) -> None:
        self._bot = bot
        self._repo = repo
        self._limiter = limiter
        self._settings = settings
        self._events = events
        self._processing: set[int] = set()
        self._stopped = False
        self._stop_event = asyncio.Event()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def run_once(self, broadcast_id: int) -> bool:
        """Process one broadcast to completion (resume-aware).

        Returns False when the broadcast does not exist or is not in a
        runnable state; True when this call finished (or paused/cancelled)
        the campaign. Safe to call repeatedly — a broadcast currently being
        processed by this worker is skipped.
        """
        broadcast = await self._repo.get(broadcast_id)
        if broadcast is None or broadcast.status not in ("pending", "sending", "paused"):
            return False
        if broadcast_id in self._processing:
            return False

        self._processing.add(broadcast_id)
        try:
            return await self._run_campaign(broadcast_id)
        finally:
            self._processing.discard(broadcast_id)

    async def process_all(self) -> None:
        """Run one pass over every active or pending broadcast."""
        campaigns = await self._repo.active_or_pending()
        for broadcast in campaigns:
            if self._stopped:
                break
            if broadcast.id in self._processing:
                continue
            try:
                await self.run_once(broadcast.id)
            except Exception as exc:  # noqa: BLE001 — a broken campaign must not kill the loop
                logger.error(
                    "broadcast.worker_crashed",
                    extra=log_extra(
                        broadcast_id=broadcast.id, error=str(exc)[:300]
                    ),
                )
                await self._repo.set_status(
                    broadcast.id, "failed", error=str(exc)[:500], completed=True
                )
                await self._publish(broadcast.id)
            await asyncio.sleep(1)

    async def run_forever(self) -> None:
        """Supervisor loop: process pending campaigns every 5 seconds."""
        self._stopped = False
        self._stop_event.clear()
        while not self._stopped:
            try:
                await self.process_all()
            except Exception as exc:  # noqa: BLE001
                logger.error(
                    "broadcast.supervisor_error", extra={"error": str(exc)[:300]}
                )
            # Interruptible sleep: stop() wakes us immediately.
            try:
                await asyncio.wait_for(self._stop_event.wait(), timeout=5.0)
            except (asyncio.TimeoutError, TimeoutError):
                pass

    async def stop(self) -> None:
        """Request a graceful stop of the supervisor loop."""
        self._stopped = True
        self._stop_event.set()

    async def cancel(self, broadcast_id: int) -> None:
        """Mark a broadcast cancelled (worker loop notices and skips targets)."""
        await self._repo.set_status(broadcast_id, "cancelled")

    async def pause(self, broadcast_id: int) -> None:
        """Mark a broadcast paused (delivery stops, targets stay pending)."""
        await self._repo.set_status(broadcast_id, "paused")

    async def retry_failed(self, broadcast_id: int) -> int:
        """Requeue failed targets for another pass."""
        return await self._repo.retry_failed(broadcast_id)

    # ------------------------------------------------------------------
    # Delivery loop
    # ------------------------------------------------------------------
    async def _run_campaign(self, broadcast_id: int) -> bool:
        await self._repo.set_status(broadcast_id, "sending", started=True)
        await self._publish(broadcast_id)

        passes = 0
        while True:
            passes += 1
            while True:
                targets = await self._repo.pending_targets(
                    broadcast_id, limit=TARGET_BATCH
                )
                if not targets:
                    break
                processed = 0
                for target in targets:
                    if self._stopped:
                        return True
                    if processed and processed % STATUS_CHECK_EVERY == 0:
                        state = await self._repo.get(broadcast_id)
                        if state is None:
                            return True
                        if state.status == "cancelled":
                            await self._finish_cancelled(broadcast_id)
                            return True
                        if state.status == "paused":
                            logger.info(
                                "broadcast.paused",
                                extra=log_extra(
                                    broadcast_id=broadcast_id, processed=processed
                                ),
                            )
                            return True
                    await self._deliver_target(broadcast_id, target)
                    processed += 1
                    if processed % PROGRESS_EVERY == 0:
                        await self._publish(broadcast_id)

            # All batches drained — inspect the final state.
            fresh = await self._repo.get(broadcast_id)
            if fresh is None:
                return True
            if fresh.status == "cancelled":
                await self._finish_cancelled(broadcast_id)
                return True
            if fresh.status == "paused":
                return True

            stats = await self._repo.stats(broadcast_id)
            if stats.get("remaining") and passes < 10:
                # New targets appeared concurrently (retry_failed) — do one
                # more pass (bounded to guard against pathological loops).
                continue
            break

        await self._repo.set_status(broadcast_id, "completed", completed=True)
        await self._publish(broadcast_id)
        logger.info(
            "broadcast.completed",
            extra=log_extra(
                broadcast_id=broadcast_id,
                sent=stats.get("sent_count", 0),
                failed=stats.get("failed_count", 0),
            ),
        )
        return True

    async def _deliver_target(
        self, broadcast_id: int, target: BroadcastTarget
    ) -> bool:
        """Deliver to one target with retry handling. True when sent."""
        broadcast = await self._repo.get(broadcast_id)
        if broadcast is None:
            return False
        max_attempts = max(1, int(self._settings.broadcast.max_retries))
        attempt = 0
        while True:
            await self._limiter.wait()  # NEVER bypass the rate limiter
            started = time.monotonic()
            try:
                await self._deliver(broadcast, target)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 — classified below
                latency_ms = int((time.monotonic() - started) * 1000)
                kind, retry_after = classify(exc)
                error_text = f"{type(exc).__name__}: {exc}"[:500]
                logger.warning(
                    "broadcast.send_failed",
                    extra=log_extra(
                        broadcast_id=broadcast_id,
                        chat_id=target.chat_id,
                        kind=kind,
                        attempt=attempt + 1,
                        error=error_text[:200],
                    ),
                )
                if kind == FLOOD and retry_after:
                    # FloodWait: sleep what Telegram demands (+1 s), then
                    # retry the same target (attempt budget is consumed —
                    # a chat that floods forever must eventually fail).
                    await asyncio.sleep(retry_after + 1)
                    attempt += 1
                    if attempt >= max_attempts:
                        return await self._mark_failed(
                            broadcast_id, target, error_text, latency_ms
                        )
                    continue
                if kind == RETRY:
                    await self._limiter.backoff(attempt)
                    attempt += 1
                    if attempt >= max_attempts:
                        return await self._mark_failed(
                            broadcast_id, target, error_text, latency_ms
                        )
                    continue
                return await self._mark_failed(
                    broadcast_id, target, error_text, latency_ms
                )
            latency_ms = int((time.monotonic() - started) * 1000)
            await self._repo.mark_target(target.id, "sent")
            await self._repo.record_delivery(
                broadcast_id, target.chat_id, True, latency_ms=latency_ms
            )
            await self._repo.update_counters(broadcast_id, sent=1)
            return True

    async def _mark_failed(
        self,
        broadcast_id: int,
        target: BroadcastTarget,
        error: str,
        latency_ms: int,
    ) -> bool:
        """Record a permanent target failure."""
        await self._repo.mark_target(target.id, "failed", error=error)
        await self._repo.record_delivery(
            broadcast_id, target.chat_id, False, error=error, latency_ms=latency_ms
        )
        await self._repo.update_counters(broadcast_id, failed=1)
        return False

    async def _finish_cancelled(self, broadcast_id: int) -> None:
        """Skip remaining pending targets and close a cancelled campaign."""
        remaining = await self._repo.pending_targets(broadcast_id, limit=10_000)
        for target in remaining:
            await self._repo.mark_target(target.id, "skipped", error="cancelled")
        await self._repo.set_status(broadcast_id, "cancelled", completed=True)
        await self._publish(broadcast_id)
        logger.info("broadcast.cancelled", extra=log_extra(broadcast_id=broadcast_id))

    async def _publish(self, broadcast_id: int) -> None:
        """Emit a progress event for the admin panel."""
        try:
            await self._events.publish("broadcast_update", broadcast_id=broadcast_id)
        except Exception as exc:  # noqa: BLE001 — events must never break delivery
            logger.warning(
                "broadcast.publish_failed", extra={"error": str(exc)[:200]}
            )

    async def publish_update(self, broadcast_id: int) -> None:
        """Public progress-event hook (used by BroadcastService controls)."""
        await self._publish(broadcast_id)

    # ------------------------------------------------------------------
    # Send dispatch
    # ------------------------------------------------------------------
    async def _deliver(self, broadcast: Broadcast, target: BroadcastTarget) -> None:
        """Send the campaign content to one chat (no retry logic here)."""
        chat_id = target.chat_id
        content_type = broadcast.content_type
        keyboard = buttons_to_keyboard(broadcast.buttons)

        if content_type == "text":
            await self._send_text(chat_id, broadcast, keyboard)
        elif content_type in _MEDIA_SENDERS:
            await self._send_media(chat_id, broadcast, keyboard)
        elif content_type == "album":
            await self._send_album(chat_id, broadcast)
        elif content_type == "copy":
            await self._send_copy(chat_id, broadcast, keyboard)
        else:
            raise BroadcastError(f"Unsupported broadcast content type: {content_type!r}")

    async def _send_text(self, chat_id: int, b: Broadcast, keyboard: Any) -> None:
        """Send a text message; retry as plain text on HTML parse errors."""
        try:
            await self._bot.send_message(
                chat_id,
                b.text,
                reply_markup=keyboard,
                parse_mode=b.parse_mode if b.parse_mode else None,
            )
        except TelegramBadRequest as exc:
            if _is_parse_error(exc) and b.parse_mode:
                # Admin-typed raw HTML that Telegram refuses to parse —
                # deliver it as plain text instead of losing the recipient.
                await self._bot.send_message(
                    chat_id, b.text, reply_markup=keyboard, parse_mode=None
                )
            else:
                raise

    async def _send_media(self, chat_id: int, b: Broadcast, keyboard: Any) -> None:
        """Send a single media message by file_id with optional caption."""
        media = b.media or []
        if not media or not media[0].get("file_id"):
            raise BroadcastError("Broadcast has no media file_id")
        sender = getattr(self._bot, _MEDIA_SENDERS[b.content_type])
        file_id = media[0]["file_id"]
        caption = b.caption
        parse_mode = b.parse_mode if caption else None
        try:
            await sender(
                chat_id,
                file_id,
                caption=caption,
                parse_mode=parse_mode,
                reply_markup=keyboard,
            )
        except TelegramBadRequest as exc:
            if _is_parse_error(exc) and caption and b.parse_mode:
                await sender(
                    chat_id,
                    file_id,
                    caption=caption,
                    parse_mode=None,
                    reply_markup=keyboard,
                )
            else:
                raise

    async def _send_album(self, chat_id: int, b: Broadcast) -> None:
        """Send a media group.

        Telegram media groups cannot carry inline keyboards — buttons are
        intentionally skipped for album broadcasts (documented design
        decision; a follow-up text message would defeat the silent UX).
        """
        from aiogram.types import (
            InputMediaDocument,
            InputMediaPhoto,
            InputMediaVideo,
        )

        builders = {
            "photo": InputMediaPhoto,
            "video": InputMediaVideo,
            "document": InputMediaDocument,
        }
        group: list[Any] = []
        for index, item in enumerate(b.media or []):
            media_type = item.get("type")
            builder = builders.get(media_type or "")
            if builder is None or not item.get("file_id"):
                raise BroadcastError(f"Invalid album item: {item!r}")
            caption = b.caption if index == 0 else None
            group.append(
                builder(
                    media=item["file_id"],
                    caption=caption,
                    parse_mode=b.parse_mode if caption else None,
                )
            )
        if not group:
            raise BroadcastError("Broadcast album is empty")
        try:
            await self._bot.send_media_group(chat_id, media=group)
        except TelegramBadRequest as exc:
            if _is_parse_error(exc) and b.parse_mode:
                # Retry the whole group with plain captions.
                plain = [
                    type(item)(media=item.media, caption=item.caption, parse_mode=None)
                    for item in group
                ]
                await self._bot.send_media_group(chat_id, media=plain)
            else:
                raise

    async def _send_copy(self, chat_id: int, b: Broadcast, keyboard: Any) -> None:
        """Copy the source message(s) to a chat (keyboard on the last item)."""
        source = b.copy_source or {}
        from_chat = source.get("chat_id")
        message_ids = source.get("message_ids") or []
        if from_chat is None or not message_ids:
            raise BroadcastError("Broadcast copy source is incomplete")
        last_index = len(message_ids) - 1
        for index, message_id in enumerate(message_ids):
            await self._bot.copy_message(
                chat_id,
                from_chat,
                message_id,
                reply_markup=keyboard if index == last_index else None,
            )


__all__ = ["BroadcastWorker"]

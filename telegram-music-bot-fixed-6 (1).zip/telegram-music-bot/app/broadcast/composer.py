"""Broadcast draft composition from admin-provided Telegram messages.

Turns an admin's text message, media message, media group or "copy this
message" selection into a :class:`BroadcastDraft`, and validates inline URL
buttons (only ``https://`` and ``tg://`` schemes are allowed — dangerous
schemes such as ``javascript:`` or ``data:`` are rejected).
"""

from __future__ import annotations

from dataclasses import dataclass

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message
from app.errors import ValidationError
from app.utils.formatting import TELEGRAM_MESSAGE_LIMIT

#: Media content types a single message can carry.
SINGLE_MEDIA_TYPES: tuple[str, ...] = (
    "photo",
    "video",
    "audio",
    "document",
    "animation",
    "voice",
)

#: Media types allowed inside an album (Telegram media groups).
ALBUM_MEDIA_TYPES: frozenset[str] = frozenset({"photo", "video", "document"})

#: Button URL schemes considered safe (Telegram also accepts tg:// links).
ALLOWED_BUTTON_SCHEMES: frozenset[str] = frozenset({"https", "tg"})

MAX_BUTTONS = 8
MAX_BUTTON_LABEL = 64
MAX_BUTTON_URL = 512


@dataclass(slots=True)
class BroadcastDraft:
    """A prepared broadcast payload (not yet persisted)."""

    content_type: str  # text|photo|video|audio|document|animation|voice|album|copy
    text: str | None = None
    caption: str | None = None
    media: list[dict] | None = None  # [{type, file_id}]
    copy_source: dict | None = None  # {chat_id, message_ids: [...]}
    buttons: list[dict] | None = None  # [{label, url}]
    parse_mode: str = "HTML"


def from_text(text: str, buttons: list[dict] | None = None) -> BroadcastDraft:
    """Build a text broadcast draft."""
    text = (text or "").strip()
    if not text:
        raise ValidationError("Broadcast text is empty")
    if len(text) > TELEGRAM_MESSAGE_LIMIT:
        raise ValidationError(
            f"Broadcast text is too long ({len(text)} > {TELEGRAM_MESSAGE_LIMIT} characters)"
        )
    validate_buttons(buttons)
    return BroadcastDraft(content_type="text", text=text, buttons=buttons)


def from_media_message(message: Message) -> BroadcastDraft:
    """Build a draft from a single media message (file_id based).

    Detects photo / video / animation / voice / audio / document. A document
    with a ``video/mp4`` MIME type is treated as an animation (Telegram
    itself distinguishes animation messages, but some clients forward GIFs
    as plain documents).
    """
    if message is None:
        raise ValidationError("No message provided")

    content_type: str | None = None
    file_id: str | None = None

    # NOTE: animation messages also carry a `document` attribute, so the
    # animation check must come before the document check.
    if message.animation is not None:
        content_type, file_id = "animation", message.animation.file_id
    elif message.photo:
        content_type, file_id = "photo", message.photo[-1].file_id
    elif message.video is not None:
        content_type, file_id = "video", message.video.file_id
    elif message.voice is not None:
        content_type, file_id = "voice", message.voice.file_id
    elif message.audio is not None:
        content_type, file_id = "audio", message.audio.file_id
    elif message.document is not None:
        if (message.document.mime_type or "").lower() == "video/mp4":
            content_type, file_id = "animation", message.document.file_id
        else:
            content_type, file_id = "document", message.document.file_id

    if content_type is None or file_id is None:
        raise ValidationError(
            "Unsupported message type. Send text, photo, video, animation, "
            "audio, voice or a document."
        )

    return BroadcastDraft(
        content_type=content_type,
        caption=message.caption,
        media=[{"type": content_type, "file_id": file_id}],
    )


def from_copy_message(message: Message) -> BroadcastDraft:
    """Build a draft that replays an existing message via copy_message."""
    if message is None:
        raise ValidationError("No message provided")
    return BroadcastDraft(
        content_type="copy",
        copy_source={
            "chat_id": message.chat.id,
            "message_ids": [message.message_id],
        },
        caption=message.caption or message.text,
    )


def from_media_group(messages: list[Message]) -> BroadcastDraft:
    """Build an album draft from a media group (2–10 items)."""
    if not messages:
        raise ValidationError("Media group is empty")
    if len(messages) > 10:
        raise ValidationError("A media group cannot have more than 10 items")

    media: list[dict[str, str]] = []
    caption: str | None = None
    for message in messages:
        if message.photo:
            media.append({"type": "photo", "file_id": message.photo[-1].file_id})
        elif message.video is not None:
            media.append({"type": "video", "file_id": message.video.file_id})
        elif message.document is not None:
            media.append({"type": "document", "file_id": message.document.file_id})
        else:
            raise ValidationError(
                "Media groups may only contain photos, videos and documents"
            )
        if caption is None and message.caption:
            caption = message.caption

    return BroadcastDraft(content_type="album", caption=caption, media=media)


def validate_buttons(buttons: list[dict] | None) -> None:
    """Validate inline URL button definitions.

    Each button must be a dict with a ``label`` (1..64 chars) and a ``url``.
    Only ``https://`` and ``tg://`` URLs are accepted; every other scheme
    (javascript:, data:, http://, file:, ...) is rejected.
    """
    if not buttons:
        return
    if not isinstance(buttons, list):
        raise ValidationError("Buttons must be a list")
    if len(buttons) > MAX_BUTTONS:
        raise ValidationError(f"A broadcast can have at most {MAX_BUTTONS} buttons")

    for index, button in enumerate(buttons, start=1):
        if not isinstance(button, dict):
            raise ValidationError(f"Button {index} must be an object")
        label = button.get("label")
        if not isinstance(label, str) or not (1 <= len(label.strip()) <= MAX_BUTTON_LABEL):
            raise ValidationError(
                f"Button {index}: label must be 1–{MAX_BUTTON_LABEL} characters"
            )
        url = button.get("url")
        if not isinstance(url, str) or not url.strip():
            raise ValidationError(f"Button {index}: URL is required")
        url = url.strip()
        if len(url) > MAX_BUTTON_URL:
            raise ValidationError(f"Button {index}: URL is too long")
        scheme = url.split(":", 1)[0].lower() if ":" in url else ""
        if scheme not in ALLOWED_BUTTON_SCHEMES or not url[len(scheme) :].startswith("://"):
            raise ValidationError(
                f"Button {index}: only https:// and tg:// links are allowed"
            )


def buttons_to_keyboard(
    buttons: list[dict] | None,
) -> InlineKeyboardMarkup | None:
    """Render validated URL buttons as an inline keyboard (rows of 2).

    Returns None when there are no buttons.
    """
    if not buttons:
        return None
    validate_buttons(buttons)
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=button["label"].strip(), url=button["url"].strip())
                for button in buttons[i : i + 2]
            ]
            for i in range(0, len(buttons), 2)
        ]
    )
    return keyboard


__all__ = [
    "BroadcastDraft",
    "from_text",
    "from_media_message",
    "from_copy_message",
    "from_media_group",
    "validate_buttons",
    "buttons_to_keyboard",
    "SINGLE_MEDIA_TYPES",
    "ALBUM_MEDIA_TYPES",
    "ALLOWED_BUTTON_SCHEMES",
]

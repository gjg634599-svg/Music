"""Telegram-side rate limiting for the broadcast engine.

Telegram enforces a global limit of roughly 30 messages per second per bot;
we stay comfortably below it with a token-spacer limiter (default 25 msg/s
minus a 10% safety margin). Every broadcast send MUST go through
:meth:`TelegramRateLimiter.wait` — the worker never bypasses it.
"""

from __future__ import annotations

import asyncio
import random
import time

import aiohttp
from aiogram.exceptions import (
    TelegramAPIError,
    TelegramBadRequest,
    TelegramEntityTooLarge,
    TelegramForbiddenError,
    TelegramMigrateToChat,
    TelegramNetworkError,
    TelegramNotFound,
    TelegramRetryAfter,
    TelegramServerError,
    TelegramUnauthorizedError,
)
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Telegram's documented global limit (~30 msg/s) — hard ceiling.
TELEGRAM_GLOBAL_LIMIT = 30.0

#: Safety margin applied to the configured rate (0.9 → 10% headroom).
SAFETY_MARGIN = 0.9

#: Outcome categories produced by :func:`classify`.
FLOOD = "flood"
RETRY = "retry"
PERMANENT = "permanent"

#: Lower-cased BadRequest markers that mean "this chat will never accept
#: the message" → permanent failure (no point retrying).
_PERMANENT_MARKERS: tuple[str, ...] = (
    "chat not found",
    "chat_write_forbidden",
    "blocked",
    "kicked",
    "deactivated",
    "user_id_invalid",
    "not_found",
    "have no rights to send",
    "need administrator",
)


def classify(exc: BaseException) -> tuple[str, int | None]:
    """Classify a Telegram API error into a delivery strategy.

    Returns:

    * ``('flood', seconds)`` — FloodWait: sleep ``seconds`` and retry.
    * ``('retry', None)`` — transient (network/timeout/server): backoff, retry.
    * ``('permanent', None)`` — the chat will never accept the message
      (blocked bot, deactivated user, chat not found, ...): fail the target.
    """
    if isinstance(exc, TelegramRetryAfter):
        return FLOOD, max(1, int(exc.retry_after))
    if isinstance(
        exc,
        (
            TelegramForbiddenError,
            TelegramUnauthorizedError,
            TelegramNotFound,
            TelegramMigrateToChat,
            TelegramEntityTooLarge,
        ),
    ):
        # Forbidden: bot kicked/blocked; Unauthorized: bot logged out;
        # NotFound: chat gone; MigrateToChat: group migrated (old id dead);
        # EntityTooLarge: content too big — all unrecoverable for this chat.
        return PERMANENT, None
    if isinstance(exc, TelegramBadRequest):
        message = str(exc).lower()
        if any(marker in message for marker in _PERMANENT_MARKERS):
            return PERMANENT, None
        return RETRY, None
    if isinstance(exc, (TelegramNetworkError, TelegramServerError)):
        return RETRY, None
    if isinstance(exc, (asyncio.TimeoutError, aiohttp.ClientError, ConnectionError, OSError)):
        # Transport-level hiccups (including raw aiohttp/asyncio errors).
        return RETRY, None
    if isinstance(exc, TelegramAPIError):
        # Any other Telegram API error — treat as transient.
        return RETRY, None
    return RETRY, None


class TelegramRateLimiter:
    """Token-spacer limiter keeping broadcast sends under a safe rate.

    The limiter is intentionally single-task (one broadcast worker at a
    time); cross-process coordination is unnecessary because the broadcast
    worker is the only producer of mass sends.
    """

    def __init__(self, rate_per_second: float = 25.0) -> None:
        rate = min(float(rate_per_second), TELEGRAM_GLOBAL_LIMIT) * SAFETY_MARGIN
        self._rate = max(0.1, rate)
        self._interval = 1.0 / self._rate
        self._last_send = 0.0
        logger.debug(
            "broadcast.rate_limiter_ready",
            extra=log_extra(rate_per_second=self._rate),
        )

    @property
    def rate_per_second(self) -> float:
        """Effective (safety-margined) send rate."""
        return self._rate

    async def wait(self) -> None:
        """Block until the next send slot is available."""
        now = time.monotonic()
        elapsed = now - self._last_send
        if elapsed < self._interval:
            await asyncio.sleep(self._interval - elapsed)
        self._last_send = time.monotonic()

    async def backoff(self, attempt: int) -> None:
        """Exponential backoff with jitter (capped at 60 s)."""
        delay = min(2 ** max(0, int(attempt)), 60) * (0.5 + random.random())
        await asyncio.sleep(delay)

    def classify(self, exc: BaseException) -> tuple[str, int | None]:
        """Instance wrapper around :func:`classify` (see module docstring)."""
        return classify(exc)


__all__ = [
    "TelegramRateLimiter",
    "classify",
    "FLOOD",
    "RETRY",
    "PERMANENT",
    "TELEGRAM_GLOBAL_LIMIT",
]

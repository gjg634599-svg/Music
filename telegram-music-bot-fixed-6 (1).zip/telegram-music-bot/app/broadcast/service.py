"""Broadcast service — admin-facing façade over the broadcast engine.

Combines draft persistence (repository), audience selection (TargetSelector)
and the delivery worker behind a small API used by the admin panel:
create → preview → start / pause / cancel / retry → history / stats.
"""

from __future__ import annotations

from typing import Any

from app.broadcast.composer import (
    SINGLE_MEDIA_TYPES,
    BroadcastDraft,
    validate_buttons,
)
from app.broadcast.targets import TARGET_TYPES, TargetSelector
from app.database.models.broadcast import Broadcast
from app.database.repositories.broadcast import BroadcastRepository
from app.errors import BroadcastCancelledError, BroadcastError
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Statuses from which a campaign can be started / resumed.
STARTABLE_STATUSES: frozenset[str] = frozenset({"draft", "pending", "paused"})
#: Statuses that can be paused mid-flight.
PAUSABLE_STATUSES: frozenset[str] = frozenset({"pending", "sending"})
#: Statuses from which failed targets can be retried.
RETRYABLE_STATUSES: frozenset[str] = frozenset({"completed", "cancelled", "failed"})


class BroadcastService:
    """High-level broadcast operations (used by the admin panel)."""

    def __init__(
        self,
        repo: BroadcastRepository,
        targets: TargetSelector,
        worker: Any = None,
    ) -> None:
        """``worker`` is a :class:`~app.broadcast.worker.BroadcastWorker`
        instance, a zero-arg callable returning one, or None (worker
        process mode only — start() then just flips the status)."""
        self._repo = repo
        self._targets = targets
        self._worker = worker

    # ------------------------------------------------------------------
    # Draft lifecycle
    # ------------------------------------------------------------------
    async def create_draft(
        self,
        draft: BroadcastDraft,
        target_type: str,
        created_by: int,
        target_filter: dict | None = None,
    ) -> Broadcast:
        """Persist a draft and precompute its target list."""
        if not isinstance(draft, BroadcastDraft):
            raise BroadcastError("Invalid broadcast draft")
        if target_type not in TARGET_TYPES:
            raise BroadcastError(
                f"Unknown target type: {target_type}",
                user_message="❌ Unknown audience for this broadcast.",
            )
        self._validate_content(draft)
        validate_buttons(draft.buttons)

        audience = await self._targets.build(target_type, target_filter)
        if not audience:
            raise BroadcastError(
                "The selected audience is empty",
                user_message="😕 Nobody matches this audience — broadcast not created.",
            )

        broadcast = await self._repo.create(
            created_by=created_by,
            content_type=draft.content_type,
            target_type=target_type,
            text=draft.text,
            caption=draft.caption,
            media=draft.media,
            copy_source=draft.copy_source,
            buttons=draft.buttons,
            parse_mode=draft.parse_mode,
            target_filter=target_filter,
        )
        await self._repo.set_targets(broadcast.id, audience)
        broadcast.target_count = len(audience)
        logger.info(
            "broadcast.draft_created",
            extra=log_extra(
                broadcast_id=broadcast.id,
                target_type=target_type,
                targets=len(audience),
            ),
        )
        return broadcast

    @staticmethod
    def _validate_content(draft: BroadcastDraft) -> None:
        """Ensure the draft carries the payload its content type needs."""
        content_type = draft.content_type
        if content_type == "text":
            if not (draft.text or "").strip():
                raise BroadcastError("Text broadcast has no text")
        elif content_type in SINGLE_MEDIA_TYPES:
            if not draft.media or not draft.media[0].get("file_id"):
                raise BroadcastError("Media broadcast has no file_id")
        elif content_type == "album":
            if not draft.media:
                raise BroadcastError("Album broadcast has no media")
        elif content_type == "copy":
            source = draft.copy_source or {}
            if source.get("chat_id") is None or not source.get("message_ids"):
                raise BroadcastError("Copy broadcast has no source message")
        else:
            raise BroadcastError(f"Unsupported content type: {content_type!r}")

    async def preview(self, broadcast_id: int) -> dict[str, Any]:
        """Pre-send summary (recipient count, content type, buttons)."""
        broadcast = await self._repo.get(broadcast_id)
        if broadcast is None:
            raise BroadcastError("Broadcast not found")
        messages_per_recipient = 1
        if broadcast.content_type == "album":
            messages_per_recipient = max(1, len(broadcast.media or []))
        elif broadcast.content_type == "copy":
            messages_per_recipient = max(
                1, len((broadcast.copy_source or {}).get("message_ids") or [])
            )
        return {
            "broadcast_id": broadcast.id,
            "status": broadcast.status,
            "content_type": broadcast.content_type,
            "target_type": broadcast.target_type,
            "target_count": broadcast.target_count,
            "buttons": len(broadcast.buttons or []),
            "messages_per_recipient": messages_per_recipient,
            "estimated_messages": broadcast.target_count * messages_per_recipient,
            "text": broadcast.text,
            "caption": broadcast.caption,
        }

    # ------------------------------------------------------------------
    # Lifecycle controls
    # ------------------------------------------------------------------
    async def start(self, broadcast_id: int) -> None:
        """Mark a broadcast pending — the worker loop picks it up."""
        broadcast = await self._require(broadcast_id)
        if broadcast.status not in STARTABLE_STATUSES:
            raise BroadcastError(
                f"Cannot start a broadcast in status {broadcast.status!r}",
                user_message="ℹ️ This broadcast cannot be started.",
            )
        await self._repo.set_status(broadcast_id, "pending")
        await self._emit(broadcast_id)

    async def pause(self, broadcast_id: int) -> None:
        """Pause a running broadcast (targets stay pending; resumable)."""
        broadcast = await self._require(broadcast_id)
        if broadcast.status not in PAUSABLE_STATUSES:
            raise BroadcastError(
                f"Cannot pause a broadcast in status {broadcast.status!r}",
                user_message="ℹ️ This broadcast is not running.",
            )
        await self._repo.set_status(broadcast_id, "paused")
        await self._emit(broadcast_id)

    async def stop(self, broadcast_id: int) -> None:
        """Stop = cancel (remaining targets are skipped)."""
        await self.cancel(broadcast_id)

    async def cancel(self, broadcast_id: int) -> None:
        """Cancel a broadcast (worker marks remaining targets 'skipped')."""
        broadcast = await self._require(broadcast_id)
        if broadcast.status in ("completed", "cancelled"):
            raise BroadcastCancelledError("Broadcast already finished")
        await self._repo.set_status(broadcast_id, "cancelled")
        await self._emit(broadcast_id)

    async def retry_failed(self, broadcast_id: int) -> int:
        """Requeue failed targets for a fresh delivery pass."""
        broadcast = await self._require(broadcast_id)
        if broadcast.status not in RETRYABLE_STATUSES:
            raise BroadcastError(
                f"Cannot retry a broadcast in status {broadcast.status!r}",
                user_message="ℹ️ There is nothing to retry for this broadcast.",
            )
        requeued = await self._repo.retry_failed(broadcast_id)
        if requeued:
            await self._repo.set_status(broadcast_id, "pending")
            await self._emit(broadcast_id)
        return requeued

    # ------------------------------------------------------------------
    # Views
    # ------------------------------------------------------------------
    async def history(self, limit: int = 20) -> list[Broadcast]:
        """Recent broadcasts (newest first)."""
        return await self._repo.list_history(limit=limit)

    async def stats(self, broadcast_id: int) -> dict[str, Any]:
        """Progress snapshot of one broadcast."""
        return await self._repo.stats(broadcast_id)

    async def active(self) -> list[Broadcast]:
        """Broadcasts currently pending, sending or paused."""
        return await self._repo.list_active()

    async def count_by_status(self) -> dict[str, int]:
        """Aggregate campaign counts per status."""
        return await self._repo.count_by_status()

    # ------------------------------------------------------------------
    # Worker bridge
    # ------------------------------------------------------------------
    async def run_now(self, broadcast_id: int) -> bool:
        """Immediately drive one broadcast through the worker (job payload).

        Raises :class:`BroadcastError` when no worker is wired.
        """
        worker = self._resolve_worker()
        if worker is None:
            raise BroadcastError(
                "No broadcast worker is available in this process",
                user_message="ℹ️ Broadcasts are processed by the worker role.",
            )
        return await worker.run_once(broadcast_id)

    def _resolve_worker(self) -> Any | None:
        """Accept a worker instance or a zero-arg provider callable."""
        if self._worker is None:
            return None
        if callable(self._worker) and not hasattr(self._worker, "run_once"):
            return self._worker()
        return self._worker

    async def _require(self, broadcast_id: int) -> Broadcast:
        broadcast = await self._repo.get(broadcast_id)
        if broadcast is None:
            raise BroadcastError(
                "Broadcast not found", user_message="ℹ️ Broadcast not found."
            )
        return broadcast

    async def _emit(self, broadcast_id: int) -> None:
        """Best-effort progress event for the admin panel."""
        worker = self._resolve_worker()
        publisher = getattr(worker, "publish_update", None)
        if publisher is not None:
            try:
                await publisher(broadcast_id)
            except Exception:  # noqa: BLE001 — events are best-effort
                pass


__all__ = ["BroadcastService"]

"""Voice-account login wizard service (shared by bot UI and CLI).

Implements the secure, expiring, concurrency-safe login state machine used to
connect a Telegram **user** account (not the bot account) to the voice engine::

    IDLE → WAITING_FOR_PHONE → WAITING_FOR_CODE → [WAITING_FOR_2FA] →
    AUTHENTICATING → VERIFYING_SESSION → COMPLETED
                                    ↘ FAILED / CANCELLED / EXPIRED

Security properties (see the master prompt §4):

* The flow is bound to the initiating admin id; no other admin can continue,
  observe or take over somebody else's login.
* Phone numbers, login codes and 2FA passwords are kept in memory only for
  as long as the step needs them — they are never logged, never echoed back
  and never persisted in plaintext. Only a pre-masked phone hint is stored.
* Bot tokens are explicitly rejected as user-account credentials.
* The Telethon session string exists only inside the finalize step; it is
  encrypted with the configured Fernet key before persistence.
* Duplicate accounts (same Telegram id) are detected before insertion.
* Every client is disconnected in ``finally`` blocks; cancelled, failed and
  expired flows leave no half-open connections behind.

The same service instance is reused by the Telegram admin wizard
(:mod:`app.bot.handlers.admin.voice_login`) and by the CLI fallback
(:mod:`scripts.add_voice_account`) so both paths share authentication,
validation, encryption, persistence and cleanup behaviour.
"""

from __future__ import annotations

import asyncio
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

from app.errors import ValidationError, VoiceError, VoiceUnavailableError
from app.logging import get_logger, log_extra

if TYPE_CHECKING:  # pragma: no cover - typing only
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

    from app.config import Settings
    from app.security.encryption import SessionCipher

logger = get_logger(__name__)

#: Seconds a login flow may stay idle before it expires.
LOGIN_IDLE_TIMEOUT_SECONDS = 600

#: Hard timeout for a single MTProto network call.
_NETWORK_TIMEOUT_SECONDS = 30.0

#: Bot tokens never are phone numbers.
_BOT_TOKEN_RE = re.compile(r"^\d{6,10}:[A-Za-z0-9_-]{30,}$")

#: Acceptable international phone numbers: optional +, 7–15 digits.
_PHONE_RE = re.compile(r"^\+?\d{7,15}$")

#: Login codes Telegram sends (usually 5 digits; be tolerant).
_CODE_RE = re.compile(r"^\d{3,8}$")


class LoginState(str, Enum):
    """States of the voice-account login state machine."""

    IDLE = "idle"
    WAITING_FOR_PHONE = "waiting_for_phone"
    WAITING_FOR_CODE = "waiting_for_code"
    WAITING_FOR_2FA = "waiting_for_2fa"
    AUTHENTICATING = "authenticating"
    VERIFYING_SESSION = "verifying_session"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    EXPIRED = "expired"


@dataclass(slots=True)
class LoginResult:
    """Outcome of one wizard step, safe to show to the admin."""

    state: LoginState
    message: str
    ok: bool = True
    retry: bool = False
    account_id: int | None = None
    telegram_id: int | None = None
    username: str | None = None


@dataclass(slots=True)
class _LoginContext:
    """Per-admin in-memory login state (never persisted, never logged)."""

    admin_id: int
    state: LoginState = LoginState.WAITING_FOR_PHONE
    phone: str = ""
    label: str = ""
    max_sessions: int = 5
    priority: int = 0
    client: Any = None
    created_at: float = field(default_factory=lambda: asyncio.get_running_loop().time() if _loop_running() else 0.0)
    last_activity: float = field(default_factory=lambda: asyncio.get_running_loop().time() if _loop_running() else 0.0)

    def touch(self) -> None:
        self.last_activity = _now()

    def expired(self, ttl: float = LOGIN_IDLE_TIMEOUT_SECONDS) -> bool:
        return (_now() - self.last_activity) > ttl


def _loop_running() -> bool:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return False
    return True


def _now() -> float:
    try:
        return asyncio.get_running_loop().time()
    except RuntimeError:  # pragma: no cover - outside the event loop
        import time

        return time.monotonic()


def mask_phone(phone: str) -> str:
    """Mask a phone number for storage (e.g. '+989***89')."""
    phone = phone.strip()
    if len(phone) <= 5:
        return phone[:1] + "***"
    return f"{phone[:3]}***{phone[-2:]}"


def normalize_phone(raw: str) -> str:
    """Validate and normalize a phone number to international format.

    Raises:
        ValidationError: not a phone number, or a bot token was supplied.
    """
    cleaned = re.sub(r"[\s\-\(\)\.]", "", (raw or "").strip())
    if _BOT_TOKEN_RE.match(cleaned):
        raise ValidationError(
            "That looks like a bot token — voice accounts need a Telegram "
            "*user* account phone number, never a bot token."
        )
    if not _PHONE_RE.match(cleaned):
        raise ValidationError(
            "Please send the phone number in international format, e.g. +989123456789."
        )
    return cleaned if cleaned.startswith("+") else f"+{cleaned}"


def validate_code(raw: str) -> str:
    """Validate a Telegram login code (digits only)."""
    code = re.sub(r"\s", "", (raw or "").strip())
    if not _CODE_RE.match(code):
        raise ValidationError("The login code is the number Telegram sent you (digits only).")
    return code


class VoiceLoginService:
    """Expiring, concurrency-safe voice-account login wizard."""

    def __init__(
        self,
        settings: "Settings",
        session_factory: "async_sessionmaker[AsyncSession]",
        cipher: "SessionCipher | None" = None,
        *,
        client_factory: "Callable[..., Any] | None" = None,
        on_account_saved: "Callable[[], Awaitable[None]] | None" = None,
    ) -> None:
        self._settings = settings
        self._session_factory = session_factory
        self._cipher = cipher
        self._client_factory = client_factory
        self._on_account_saved = on_account_saved
        self._contexts: dict[int, _LoginContext] = {}
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------
    def active_state(self, admin_id: int) -> LoginState | None:
        """Current state for *admin_id* (None when no flow is active)."""
        context = self._contexts.get(int(admin_id))
        if context is None:
            return None
        if context.expired():
            return LoginState.EXPIRED
        return context.state

    def has_active_flow(self) -> bool:
        """True when at least one non-terminal flow is running."""
        return any(
            context.state
            in (LoginState.WAITING_FOR_PHONE, LoginState.WAITING_FOR_CODE,
                LoginState.WAITING_FOR_2FA, LoginState.AUTHENTICATING,
                LoginState.VERIFYING_SESSION)
            for context in self._contexts.values()
        )

    # ------------------------------------------------------------------
    # State machine steps
    # ------------------------------------------------------------------
    async def begin(
        self,
        admin_id: int,
        *,
        label: str = "",
        max_sessions: int = 5,
        priority: int = 0,
    ) -> LoginResult:
        """Start (or restart) the wizard for *admin_id*."""
        admin_id = int(admin_id)
        async with self._lock:
            await self._gc_locked()
            existing = self._contexts.pop(admin_id, None)
            if existing is not None:
                await self._dispose_client(existing)
            try:
                self._check_voice_config()
            except (VoiceUnavailableError, VoiceError) as exc:
                return LoginResult(LoginState.FAILED, str(exc), ok=False)
            context = _LoginContext(
                admin_id=admin_id,
                label=(label or "").strip()[:64],
                max_sessions=max(1, int(max_sessions or 5)),
                priority=int(priority or 0),
            )
            self._contexts[admin_id] = context
        logger.info("voice.login.begin", extra=log_extra(admin_id=admin_id))
        return LoginResult(
            state=LoginState.WAITING_FOR_PHONE,
            message="Login started. Send the account's phone number in international format.",
        )

    async def submit_phone(self, admin_id: int, raw_phone: str, *, label: str = "") -> LoginResult:
        """Validate the phone number and request a Telegram login code."""
        admin_id = int(admin_id)
        try:
            phone = normalize_phone(raw_phone)
        except ValidationError as exc:
            return LoginResult(LoginState.WAITING_FOR_PHONE, str(exc), ok=False, retry=True)

        async with self._lock:
            context = self._require_context(admin_id, LoginState.WAITING_FOR_PHONE)
            if context is None:
                return LoginResult(LoginState.EXPIRED, "The login session expired — start again.", ok=False)
            context.touch()
            context.phone = phone  # in-memory only; never logged
            if label:
                context.label = label.strip()[:64]

            try:
                client = await self._build_client()
            except (VoiceUnavailableError, VoiceError) as exc:
                context.state = LoginState.FAILED
                self._contexts.pop(admin_id, None)
                return LoginResult(LoginState.FAILED, str(exc), ok=False)
            try:
                async with asyncio.timeout(_NETWORK_TIMEOUT_SECONDS):
                    await client.connect()
                    await client.send_code_request(phone)
            except asyncio.TimeoutError:
                await self._disconnect_client(client)
                self._contexts.pop(admin_id, None)
                return LoginResult(
                    LoginState.FAILED,
                    "Telegram did not respond in time. Please try again in a minute.",
                    ok=False,
                )
            except Exception as exc:  # noqa: BLE001 — Telethon error surface
                await self._disconnect_client(client)
                self._contexts.pop(admin_id, None)
                message = self._friendly_error(exc)
                logger.warning(
                    "voice.login.phone_failed",
                    extra=log_extra(admin_id=admin_id, error=type(exc).__name__),
                )
                return LoginResult(LoginState.FAILED, message, ok=False)

            context.client = client
            context.state = LoginState.WAITING_FOR_CODE
            logger.info(
                "voice.login.code_requested",
                extra=log_extra(admin_id=admin_id, phone_masked=mask_phone(phone)),
            )
            return LoginResult(
                LoginState.WAITING_FOR_CODE,
                "Telegram sent a login code to the account. Send me the code here.",
            )

    async def submit_code(self, admin_id: int, raw_code: str) -> LoginResult:
        """Submit the Telegram login code (or surface the 2FA requirement)."""
        admin_id = int(admin_id)
        try:
            code = validate_code(raw_code)
        except ValidationError as exc:
            return LoginResult(LoginState.WAITING_FOR_CODE, str(exc), ok=False, retry=True)

        async with self._lock:
            context = self._require_context(admin_id, LoginState.WAITING_FOR_CODE)
            if context is None:
                return LoginResult(LoginState.EXPIRED, "The login session expired — start again.", ok=False)
            context.touch()
            client = context.client
            if client is None:  # defensive — should not happen
                self._contexts.pop(admin_id, None)
                return LoginResult(LoginState.FAILED, "Login session lost — start again.", ok=False)

            try:
                async with asyncio.timeout(_NETWORK_TIMEOUT_SECONDS):
                    await client.sign_in(phone=context.phone, code=code)
            except Exception as exc:  # noqa: BLE001 — Telethon error surface
                if type(exc).__name__ == "SessionPasswordNeededError":
                    context.state = LoginState.WAITING_FOR_2FA
                    return LoginResult(
                        LoginState.WAITING_FOR_2FA,
                        "This account has two-step verification enabled. "
                        "Send me the 2FA password.",
                    )
                retryable, message = self._code_error(exc)
                if retryable:
                    return LoginResult(LoginState.WAITING_FOR_CODE, message, ok=False, retry=True)
                await self._dispose_client(context)
                self._contexts.pop(admin_id, None)
                return LoginResult(LoginState.FAILED, message, ok=False)

            needs_password = await self._needs_password(client)
            if needs_password:
                context.state = LoginState.WAITING_FOR_2FA
                return LoginResult(
                    LoginState.WAITING_FOR_2FA,
                    "This account has two-step verification enabled. Send me the 2FA password.",
                )
            return await self._finalize_locked(context)

    async def submit_password(self, admin_id: int, password: str) -> LoginResult:
        """Submit the two-step-verification password."""
        admin_id = int(admin_id)
        password = (password or "").strip()
        if not password:
            return LoginResult(
                LoginState.WAITING_FOR_2FA, "The password cannot be empty.", ok=False, retry=True
            )

        async with self._lock:
            context = self._require_context(admin_id, LoginState.WAITING_FOR_2FA)
            if context is None:
                return LoginResult(LoginState.EXPIRED, "The login session expired — start again.", ok=False)
            context.touch()
            client = context.client
            if client is None:  # defensive
                self._contexts.pop(admin_id, None)
                return LoginResult(LoginState.FAILED, "Login session lost — start again.", ok=False)
            try:
                async with asyncio.timeout(_NETWORK_TIMEOUT_SECONDS):
                    await client.sign_in(password=password)
            except Exception as exc:  # noqa: BLE001 — Telethon error surface
                retryable, message = self._password_error(exc)
                if retryable:
                    return LoginResult(LoginState.WAITING_FOR_2FA, message, ok=False, retry=True)
                await self._dispose_client(context)
                self._contexts.pop(admin_id, None)
                return LoginResult(LoginState.FAILED, message, ok=False)
            return await self._finalize_locked(context)

    async def resend_code(self, admin_id: int) -> LoginResult:
        """Request a fresh login code for the stored phone number."""
        admin_id = int(admin_id)
        async with self._lock:
            context = self._require_context(admin_id, LoginState.WAITING_FOR_CODE)
            if context is None:
                return LoginResult(LoginState.EXPIRED, "The login session expired — start again.", ok=False)
            context.touch()
            try:
                async with asyncio.timeout(_NETWORK_TIMEOUT_SECONDS):
                    await context.client.send_code_request(context.phone)
            except Exception as exc:  # noqa: BLE001
                message = self._friendly_error(exc)
                return LoginResult(LoginState.WAITING_FOR_CODE, message, ok=False, retry=True)
            return LoginResult(
                LoginState.WAITING_FOR_CODE,
                "A new login code was sent. Send me the code here.",
            )

    async def cancel(self, admin_id: int) -> LoginResult:
        """Cancel the flow and disconnect any live client."""
        admin_id = int(admin_id)
        async with self._lock:
            context = self._contexts.pop(admin_id, None)
            if context is None:
                return LoginResult(LoginState.IDLE, "No active login session.")
            await self._dispose_client(context)
            logger.info("voice.login.cancelled", extra=log_extra(admin_id=admin_id))
            return LoginResult(LoginState.CANCELLED, "Login cancelled. No account was added.")

    async def gc(self) -> list[int]:
        """Expire abandoned flows; returns the expired admin ids."""
        async with self._lock:
            return await self._gc_locked()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _gc_locked(self) -> list[int]:
        expired: list[int] = []
        for admin_id, context in list(self._contexts.items()):
            if context.expired() and context.state not in (
                LoginState.COMPLETED, LoginState.FAILED,
                LoginState.CANCELLED, LoginState.EXPIRED,
            ):
                await self._dispose_client(context)
                del self._contexts[admin_id]
                expired.append(admin_id)
                logger.info("voice.login.expired", extra=log_extra(admin_id=admin_id))
        return expired

    def _require_context(self, admin_id: int, expected: LoginState) -> "_LoginContext | None":
        """Return the live context in *expected* state (None when unusable)."""
        context = self._contexts.get(int(admin_id))
        if context is None or context.expired():
            return None
        if context.state is not expected:
            return None
        return context

    def _check_voice_config(self) -> None:
        if not self._settings.voice_enabled:
            raise VoiceError(
                "The voice engine is not configured.\n\n"
                "Set TELEGRAM_API_ID, TELEGRAM_API_HASH and "
                "VOICE_SESSION_ENCRYPTION_KEY on the server first."
            )
        if self._cipher is None:
            raise VoiceError("No session encryption key configured (VOICE_SESSION_ENCRYPTION_KEY).")

    async def _build_client(self) -> Any:
        """Create a fresh Telethon client with an empty StringSession."""
        try:
            from telethon import TelegramClient
            from telethon.sessions import StringSession
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise VoiceUnavailableError(
                "Voice engine dependencies are not installed on the server."
            ) from exc
        if self._client_factory is not None:
            return self._client_factory(StringSession, self._settings)
        return TelegramClient(
            StringSession(),
            self._settings.telegram_api_id,
            self._settings.telegram_api_hash,
        )

    @staticmethod
    def _export_session(client: Any) -> str:
        """Export the client's session as a string (never logged)."""
        from telethon.sessions import StringSession

        return StringSession.save(client.session)

    async def _needs_password(self, client: Any) -> bool:
        """Detect the two-step-verification requirement post sign-in."""
        try:
            async with asyncio.timeout(_NETWORK_TIMEOUT_SECONDS):
                return not bool(await client.is_user_authorized())
        except Exception:  # noqa: BLE001 — treat check failure as retryable
            return False

    async def _finalize_locked(self, context: _LoginContext) -> LoginResult:
        """Verify identity, detect duplicates, encrypt and persist."""
        context.state = LoginState.VERIFYING_SESSION
        admin_id = context.admin_id
        client = context.client
        try:
            async with asyncio.timeout(_NETWORK_TIMEOUT_SECONDS):
                me = await client.get_me()
            telegram_id = getattr(me, "id", None)
            username = getattr(me, "username", None)
            if telegram_id is None:
                raise VoiceError("Telegram did not return the account identity.")

            from app.database.repositories.voice import VoiceRepository

            repo = VoiceRepository(self._session_factory)
            duplicate = await repo.get_by_telegram_id(int(telegram_id))
            if duplicate is not None:
                logger.info(
                    "voice.login.duplicate",
                    extra=log_extra(admin_id=admin_id, account_id=duplicate.id),
                )
                return LoginResult(
                    LoginState.FAILED,
                    f"This Telegram account is already connected as "
                    f"“{duplicate.label}” (#{duplicate.id}).",
                    ok=False,
                )

            # The plaintext session string exists only inside this block.
            session_string = self._export_session(client)
            encrypted = self._cipher.encrypt(session_string)
            del session_string

            label = context.label or await self._auto_label(repo)
            account = await repo.create(
                label,
                encrypted,
                telegram_id=int(telegram_id),
                username=username,
                phone_hint=mask_phone(context.phone),
                max_sessions=context.max_sessions,
                priority=context.priority,
            )
        except (VoiceUnavailableError, VoiceError) as exc:
            await self._dispose_client(context)
            self._contexts.pop(admin_id, None)
            return LoginResult(LoginState.FAILED, str(exc), ok=False)
        except Exception as exc:  # noqa: BLE001 — Telethon / DB error surface
            await self._dispose_client(context)
            self._contexts.pop(admin_id, None)
            logger.warning(
                "voice.login.finalize_failed",
                extra=log_extra(admin_id=admin_id, error=type(exc).__name__),
            )
            return LoginResult(
                LoginState.FAILED,
                f"Could not save the account ({type(exc).__name__}). "
                "Nothing was stored — you can try again.",
                ok=False,
            )
        finally:
            # The temporary client is always disconnected, success or not.
            await self._dispose_client(context)
            self._contexts.pop(admin_id, None)

        context.state = LoginState.COMPLETED
        logger.info(
            "voice.login.completed",
            extra=log_extra(admin_id=admin_id, account_id=account.id),
        )
        hook = self._on_account_saved
        if hook is not None:
            try:
                await hook()
            except Exception as exc:  # noqa: BLE001 — reload is best-effort
                logger.warning(
                    "voice.login.reload_failed",
                    extra=log_extra(account_id=account.id, error=str(exc)[:160]),
                )
        return LoginResult(
            LoginState.COMPLETED,
            "Voice account connected.",
            account_id=account.id,
            telegram_id=int(telegram_id),
            username=username,
        )

    async def _auto_label(self, repo: Any) -> str:
        """Non-colliding default label: “Account N”."""
        try:
            accounts = await repo.list_accounts(include_disabled=True)
        except Exception:  # noqa: BLE001 — cosmetic only
            accounts = []
        return f"Account {len(accounts) + 1}"

    async def _dispose_client(self, context: _LoginContext) -> None:
        """Disconnect the context's client, swallowing every error."""
        client, context.client = context.client, None
        await self._disconnect_client(client)

    @staticmethod
    async def _disconnect_client(client: Any) -> None:
        """Disconnect a client object (best-effort, never raises)."""
        if client is None:
            return
        try:
            if client.is_connected():
                await client.disconnect()
        except Exception:  # noqa: BLE001 — cleanup must never raise
            pass

    # ------------------------------------------------------------------
    # Telethon error mapping (admin-friendly, no secrets)
    # ------------------------------------------------------------------
    @staticmethod
    def _friendly_error(exc: Exception) -> str:
        name = type(exc).__name__
        seconds = getattr(exc, "seconds", None)
        if seconds is not None and "Flood" in name:
            return f"Telegram is rate-limiting logins — please retry in {seconds} seconds."
        mapping = {
            "PhoneNumberInvalidError": "That phone number is not valid. Check the international format.",
            "PhoneNumberBannedError": "That phone number is banned on Telegram and cannot be used.",
            "PhoneNumberUnoccupiedError": "No Telegram account exists for that phone number.",
            "ApiIdInvalidError": "The server's TELEGRAM_API_ID/API_HASH pair is invalid.",
        }
        if name in mapping:
            return mapping[name]
        return f"Telegram rejected the request ({name}). Please try again."

    @classmethod
    def _code_error(cls, exc: Exception) -> tuple[bool, str]:
        """Map sign-in-with-code errors → (retryable, message)."""
        name = type(exc).__name__
        if name in {
            "PhoneCodeInvalidError",
            "PhoneCodeEmptyError",
            "PhoneCodeExpiredError",
        }:
            hint = {
                "PhoneCodeExpiredError": "The code has expired — request a new one.",
            }.get(name, "That code is not valid. Check Telegram and resend the code.")
            return True, hint
        seconds = getattr(exc, "seconds", None)
        if seconds is not None and "Flood" in name:
            return False, f"Telegram is rate-limiting logins — retry in {seconds} seconds."
        return False, cls._friendly_error(exc)

    @classmethod
    def _password_error(cls, exc: Exception) -> tuple[bool, str]:
        """Map sign-in-with-password errors → (retryable, message)."""
        name = type(exc).__name__
        if name == "PasswordHashInvalidError":
            return True, "That password is not correct. Try again (or cancel)."
        seconds = getattr(exc, "seconds", None)
        if seconds is not None and "Flood" in name:
            return False, f"Too many attempts — retry in {seconds} seconds."
        return False, cls._friendly_error(exc)


__all__ = [
    "LOGIN_IDLE_TIMEOUT_SECONDS",
    "LoginResult",
    "LoginState",
    "VoiceLoginService",
    "mask_phone",
    "normalize_phone",
    "validate_code",
]

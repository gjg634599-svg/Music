"""A connected Telegram user account used for voice-chat playback.

One :class:`VoiceAccountClient` wraps one Telethon client (from an encrypted
session string) plus its :class:`~app.voice.transport.NativeTransport`. The
decrypted session string exists only inside :meth:`VoiceAccountClient.connect`
— it is never logged, never placed in exceptions and never exposed through
public APIs or ``repr``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from app.config import Settings
from app.errors import VoiceError, VoiceUnavailableError
from app.logging import get_logger, log_extra
from app.voice.transport import NativeTransport

if TYPE_CHECKING:
    from app.database.models.voice import VoiceAccount
    from app.security.encryption import SessionCipher

logger = get_logger(__name__)


class VoiceAccountClient:
    """Runtime wrapper around one voice account row."""

    def __init__(
        self,
        model: VoiceAccount,
        settings: Settings,
        cipher: SessionCipher | None,
    ) -> None:
        self._model = model
        self._settings = settings
        self._cipher = cipher
        self._client: Any = None
        self._transport: NativeTransport | None = None
        self._telegram_id: int | None = None
        self._username: str | None = None
        self._active_sessions = 0

    # ------------------------------------------------------------------
    # Identity & state
    # ------------------------------------------------------------------
    @property
    def model(self) -> VoiceAccount:
        """The underlying ORM row (never exposes the session secret via us)."""
        return self._model

    @property
    def label(self) -> str:
        """Human-readable account label."""
        return self._model.label

    @property
    def telegram_id(self) -> int | None:
        """Telegram user id (cached from ``get_me`` at connect time)."""
        return self._telegram_id if self._telegram_id is not None else self._model.telegram_id

    @property
    def username(self) -> str | None:
        """Telegram username (cached from ``get_me`` at connect time)."""
        return self._username if self._username is not None else self._model.username

    @property
    def is_connected(self) -> bool:
        """True while the MTProto client is connected."""
        return self._client is not None and bool(self._client.is_connected())

    @property
    def transport(self) -> NativeTransport | None:
        """The group-call transport (``None`` until connected)."""
        return self._transport

    @property
    def raw_client(self) -> Any:
        """The underlying Telethon client (``None`` while disconnected).

        Exposed for the voice layer's own MTProto operations (group
        membership checks / invite imports in
        :mod:`app.voice.group_access`) — never for logging or serialization;
        the session secret stays encapsulated inside the client.
        """
        return self._client

    @property
    def active_sessions(self) -> int:
        """Number of live group leases served by this account (in-memory)."""
        return self._active_sessions

    @active_sessions.setter
    def active_sessions(self, value: int) -> None:
        self._active_sessions = max(0, int(value))

    @property
    def max_sessions(self) -> int:
        """Maximum concurrent group sessions allowed for this account."""
        return int(self._model.max_sessions or 0)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def connect(self) -> None:
        """Decrypt the stored session, connect MTProto and start the transport.

        Raises:
            VoiceUnavailableError: telethon / py-tgcalls not installed.
            VoiceError: missing cipher or credentials, failed decryption,
                connection failure or the session is no longer authorized
                (``auth_required``).
        """
        try:
            from telethon import TelegramClient
            from telethon.sessions import StringSession
        except ImportError as exc:
            raise VoiceUnavailableError(
                "Voice engine dependencies are not installed on the server"
            ) from exc

        if self._cipher is None:
            raise VoiceError("No session encryption key configured")
        if self._settings.telegram_api_id is None or not self._settings.telegram_api_hash:
            raise VoiceError("Voice engine is not configured (missing API credentials)")

        try:
            # The plaintext session string never leaves this scope and is
            # never logged or embedded into exceptions.
            session_string = self._cipher.decrypt(self._model.session_encrypted)
        except Exception as exc:  # noqa: BLE001 — ConfigError from SessionCipher
            logger.warning(
                "voice.account.decrypt_failed",
                extra=log_extra(account_id=self._model.id),
            )
            raise VoiceError("Session decryption failed — encryption key changed?") from exc

        client = TelegramClient(
            StringSession(session_string),
            self._settings.telegram_api_id,
            self._settings.telegram_api_hash,
        )
        try:
            await client.connect()
        except Exception as exc:  # noqa: BLE001 — network / protocol errors
            await _quiet_disconnect(client)
            logger.warning(
                "voice.account.connect_failed",
                extra=log_extra(account_id=self._model.id, error=str(exc)[:200]),
            )
            raise VoiceError(f"MTProto connection failed: {str(exc)[:160]}") from exc

        try:
            authorized = await client.is_user_authorized()
        except Exception as exc:  # noqa: BLE001
            await _quiet_disconnect(client)
            raise VoiceError(f"Authorization check failed: {str(exc)[:160]}") from exc
        if not authorized:
            await _quiet_disconnect(client)
            raise VoiceError("auth_required")

        transport = NativeTransport(client)
        try:
            await transport.ensure_started()
        except VoiceError:
            # Without group-call support the account cannot serve playback.
            await _quiet_disconnect(client)
            raise

        self._client = client
        self._transport = transport
        await self._cache_identity()
        logger.info(
            "voice.account.connected",
            extra=log_extra(
                account_id=self._model.id,
                label=self._model.label,
                telegram_id=self._telegram_id,
            ),
        )

    async def _cache_identity(self) -> None:
        """Best-effort ``get_me`` to cache telegram_id / username."""
        try:
            me = await self._client.get_me()
        except Exception as exc:  # noqa: BLE001 — identity is non-critical
            logger.warning(
                "voice.account.identity_failed",
                extra=log_extra(account_id=self._model.id, error=str(exc)[:160]),
            )
            return
        if me is None:
            return
        self._telegram_id = getattr(me, "id", None)
        self._username = getattr(me, "username", None)
        # Keep the detached ORM row fresh for admin-facing summaries.
        self._model.telegram_id = self._telegram_id
        self._model.username = self._username

    async def disconnect(self) -> None:
        """Best-effort disconnect (never raises)."""
        client, self._client = self._client, None
        self._transport = None
        if client is None:
            return
        try:
            if client.is_connected():
                await client.disconnect()
            logger.info(
                "voice.account.disconnected",
                extra=log_extra(account_id=self._model.id),
            )
        except Exception as exc:  # noqa: BLE001 — shutdown must not raise
            logger.warning(
                "voice.account.disconnect_failed",
                extra=log_extra(account_id=self._model.id, error=str(exc)[:160]),
            )

    def __repr__(self) -> str:  # pragma: no cover — debug helper
        return f"<VoiceAccountClient #{self._model.id} {self._model.label}>"


async def _quiet_disconnect(client: Any) -> None:
    """Disconnect a Telethon client, swallowing every error."""
    try:
        if client.is_connected():
            await client.disconnect()
    except Exception:  # noqa: BLE001 — best effort during error paths
        pass


__all__ = ["VoiceAccountClient"]

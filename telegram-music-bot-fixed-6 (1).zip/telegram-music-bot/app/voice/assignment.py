"""Account→group assignment strategy (load balancing).

The strategy is deterministic: among connected accounts with free capacity,
pick the one with the fewest active sessions; ties are broken by descending
priority, then ascending account id.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.voice.account import VoiceAccountClient


class AssignmentStrategy:
    """Least-loaded-first account selection."""

    def select(self, accounts: list[VoiceAccountClient]) -> VoiceAccountClient | None:
        """Pick the best available account, or ``None`` when none qualify."""
        eligible = [account for account in accounts if self._eligible(account)]
        if not eligible:
            return None
        eligible.sort(
            key=lambda account: (
                account.active_sessions,
                -int(account.model.priority or 0),
                int(account.model.id),
            )
        )
        return eligible[0]

    @staticmethod
    def _eligible(account: VoiceAccountClient) -> bool:
        """Connected and below its concurrent-session cap."""
        try:
            return bool(account.is_connected) and account.active_sessions < account.max_sessions
        except Exception:  # noqa: BLE001 — a broken account is simply skipped
            return False


__all__ = ["AssignmentStrategy"]

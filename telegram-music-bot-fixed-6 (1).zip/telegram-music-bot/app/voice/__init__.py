"""Voice engine: accounts, sessions, health, assignment, failover.

Public surface (see CONTRACTS.md section 4):

* :class:`VoiceManager` — the facade used by playback + admin.
* :class:`VoiceAccountClient` — one connected userbot account.
* :class:`VoiceSessionRuntime` — one group's live lease.
* :class:`HealthMonitor`, :class:`AssignmentStrategy`,
  :class:`FailoverController` — engine components (also injectable directly).
* :class:`NativeTransport` / :data:`PYTGCALLS_AVAILABLE` — group-call
  transport (py-tgcalls is optional; imports are guarded).
"""

from __future__ import annotations

from app.voice.account import VoiceAccountClient
from app.voice.assignment import AssignmentStrategy
from app.voice.failover import FailoverController
from app.voice.health import HealthMonitor
from app.voice.manager import (
    VoiceAccountSummary,
    VoiceEngineStatus,
    VoiceManager,
)
from app.voice.session import VoiceSessionRuntime
from app.voice.transport import (
    PYTGCALLS_AVAILABLE,
    NativeTransport,
    VoiceTransport,
)

__all__ = [
    "PYTGCALLS_AVAILABLE",
    "AssignmentStrategy",
    "FailoverController",
    "HealthMonitor",
    "NativeTransport",
    "VoiceAccountClient",
    "VoiceAccountSummary",
    "VoiceEngineStatus",
    "VoiceManager",
    "VoiceSessionRuntime",
    "VoiceTransport",
]

"""Failover controller — recover a group's voice session after a failure.

``handle_failure`` is idempotent per group (a short-lived distributed lock
prevents concurrent failovers), marks the failed session/account in the
database and publishes ``voice_failure:<group_id>``. The
:class:`~app.voice.manager.VoiceManager` subscribes to that event and
re-assigns the group through :meth:`FailoverController.reassign` (the manager
is reached via a late-binding callable to avoid a circular dependency).
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from app.logging import get_logger, log_extra

if TYPE_CHECKING:
    from app.cache.redis import LockManager
    from app.database.repositories.voice import VoiceRepository
    from app.playback.events import EventBus

logger = get_logger(__name__)

#: Lifetime of the per-group failover lock (idempotency window).
_FAILOVER_LOCK_TTL = 30


class FailoverController:
    """Coordinates session failure marking and account reassignment."""

    def __init__(
        self,
        get_manager: Callable[[], Any],
        repo: VoiceRepository,
        locks: LockManager,
        events: EventBus,
    ) -> None:
        self._get_manager = get_manager
        self._repo = repo
        self._locks = locks
        self._events = events

    async def handle_failure(self, group_tg_id: int, error: str | None = None) -> None:
        """Mark the group's live session as failed and notify listeners.

        Safe to call repeatedly / concurrently — a lock makes the critical
        section single-flight per group.
        """
        group_tg_id = int(group_tg_id)
        lock = await self._locks.try_acquire(f"failover:{group_tg_id}", ttl=_FAILOVER_LOCK_TTL)
        if lock is None:
            logger.info(
                "voice.failover.skipped_locked",
                extra=log_extra(group_id=group_tg_id),
            )
            return
        try:
            try:
                session = await self._repo.get_active_by_group(group_tg_id)
            except Exception as exc:  # noqa: BLE001 — DB outage must not crash callers
                logger.error(
                    "voice.failover.session_lookup_failed",
                    extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
                )
                session = None
            if session is not None:
                try:
                    await self._repo.update_session(session.id, status="failed")
                except Exception as exc:  # noqa: BLE001
                    logger.warning(
                        "voice.failover.mark_failed_error",
                        extra=log_extra(session_id=session.id, error=str(exc)[:160]),
                    )
                if session.account_id is not None:
                    try:
                        await self._repo.set_status(
                            session.account_id,
                            "degraded",
                            error=error[:200] if error else None,
                        )
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "voice.failover.degrade_failed",
                            extra=log_extra(account_id=session.account_id, error=str(exc)[:160]),
                        )
            await self._events.publish(
                f"voice_failure:{group_tg_id}", group_id=group_tg_id, error=error
            )
            logger.warning(
                "voice.failover.handled",
                extra=log_extra(
                    group_id=group_tg_id,
                    session_id=session.id if session else None,
                    error=(error or "")[:160],
                ),
            )
        finally:
            await lock.release()

    async def reassign(self, group_tg_id: int) -> bool:
        """Release the group's lease and acquire a fresh one.

        Returns True when a new session was established. Used by the manager's
        ``voice_failure`` subscription and available for programmatic failover
        (e.g. admin reconnect flows).
        """
        group_tg_id = int(group_tg_id)
        manager = self._get_manager() if self._get_manager is not None else None
        if manager is None:
            logger.warning("voice.failover.no_manager", extra=log_extra(group_id=group_tg_id))
            return False
        try:
            await manager.release(group_tg_id)
        except Exception as exc:  # noqa: BLE001 — release is best-effort
            logger.warning(
                "voice.failover.release_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
            )
        runtime = None
        try:
            runtime = await manager.acquire(group_tg_id)
        except Exception as exc:  # noqa: BLE001 — never raise into event handlers
            logger.error(
                "voice.failover.reacquire_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
            )
        if runtime is None:
            logger.warning(
                "voice.failover.no_account_available",
                extra=log_extra(group_id=group_tg_id),
            )
            return False
        await self._events.publish("voice:reassigned", group_id=group_tg_id)
        logger.info(
            "voice.failover.reassigned",
            extra=log_extra(group_id=group_tg_id, session_id=runtime.session_id),
        )
        return True


__all__ = ["FailoverController"]

"""Private-group membership verification and automatic invite-link joining.

Separates the two distinct Telegram operations this workflow touches:

* **Joining a group** (becoming a chat member) — done here, via membership
  checks and ``ImportChatInviteRequest`` when authorized;
* **Joining a group voice chat** (connecting to an active call) — done by
  the transport (py-tgcalls) *after* group access is confirmed.

Automatic joining flow (mirrors established Telegram music bots such as
ShizuMusic's assistant pattern, adapted to this codebase):

1. Resolve the target group id (aiogram-style → Telethon-style peer id).
2. Check whether the voice (user) account is already a member — if so,
   continue without generating any invitation.
3. When not a member and ``voice.auto_join_enabled`` is off, fail with an
   actionable message (the account must be added manually).
4. Otherwise ask the *bot* account to create a dedicated invite link
   for the group (``create_chat_invite_link`` — requires bot admin rights
   with the "invite users via link" permission; never touches the group's
   primary link, unlike ``export_chat_invite_link`` which may rotate it).
   The link is cached for reuse so we never spam link creations.
5. Import the invite hash through the MTProto user account with
   ``ImportChatInviteRequest`` — the supported Telethon API for joining
   private groups via link.
6. Classify every failure mode (already participant, expired/invalid link,
   banned, join-request approval, flood waits, revoked admin rights) into
   user-safe, actionable messages.
7. Verify membership after joining; only then does playback proceed to the
   voice-chat connection step.

Privacy guarantees:

* links are obtained exclusively for groups where an authorized playback
  command occurred (the manager calls this service only from its playback
  path — never for unrelated groups);
* a failed join puts the group on a cooldown so we never retry endlessly
  or hammer Telegram with invite imports;
* invite links and hashes are never logged (only host/length metadata).
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

from app.config import Settings
from app.logging import get_logger, log_extra

logger = get_logger(__name__)

#: Provider returns the group's invite link (or ``None`` when unavailable).
InviteLinkProvider = Callable[[int], Awaitable[str | None]]


@dataclass(slots=True)
class GroupAccessOutcome:
    """Result of one membership/ join attempt (never raises by itself)."""

    ok: bool
    joined: bool
    status: str
    detail: str = ""
    user_message: str | None = None
    retry_after_seconds: int | None = None


@dataclass(slots=True)
class GroupLinkResolution:
    """Result of resolving a user-submitted group link to a target group.

    ``ok`` carries the overall verdict; ``status`` is a machine code
    (``ok`` on success, a :data:`STATUS_MESSAGES` key otherwise);
    ``group_tg_id`` / ``title`` / ``chat_type`` describe the resolved
    group (Bot API-style id, ready for queues and voice sessions);
    ``joined`` is True when the voice account actually joined during
    resolution. Never raised — every failure is a typed result.
    """

    ok: bool
    status: str
    group_tg_id: int | None = None
    title: str | None = None
    chat_type: str | None = None
    joined: bool = False
    user_message: str | None = None
    retry_after_seconds: int | None = None


#: Machine status → user-facing message (None on success statuses).
STATUS_MESSAGES: dict[str, str] = {
    "auto_join_disabled": (
        "🎙️ The voice account is not a member of this group yet. "
        "Add it manually or enable automatic joining "
        "(VOICE_AUTO_JOIN_ENABLED) and try again."
    ),
    "invite_unavailable": (
        "🎙️ I couldn't get an invitation link for this group. Make sure the "
        "bot is a group admin with the “Invite users via link” permission, "
        "then try again."
    ),
    "invite_link_invalid": (
        "🎙️ The group invitation link is invalid or revoked. Ask an admin to "
        "generate a new link (or add the voice account manually) and retry."
    ),
    "invite_link_expired": (
        "🎙️ The group invitation link has expired. Ask an admin to create a "
        "new link (or add the voice account manually) and retry."
    ),
    "account_banned": (
        "🎙️ The voice account cannot join this group (banned or restricted). "
        "Ask a group admin to remove the restriction first."
    ),
    "group_private": (
        "🎙️ This group is private and the voice account has no access to it. "
        "Invite it manually, then retry playback."
    ),
    "approval_pending": (
        "🎙️ A join request was sent — a group admin must approve it before "
        "playback can start. Try again once it's approved."
    ),
    "membership_unverified": (
        "🎙️ Couldn't verify the voice account's membership after joining. "
        "Add it to the group manually and retry."
    ),
    "flood_limited": (
        "⏳ Telegram is limiting join requests. Please retry in a moment."
    ),
    "cooldown": (
        "🎙️ Joining this group failed recently. Please wait a few minutes "
        "before trying again (or add the voice account manually)."
    ),
    # DM link-resolution statuses (appended for the DM→group workflow).
    "invalid_link": (
        "⚠️ That doesn't look like a Telegram group link.\n\n"
        "Send one of:\n"
        "• a public group link — https://t.me/yourgroup\n"
        "• a group username — @yourgroup\n"
        "• a private invite link — https://t.me/+AbCdEf…"
    ),
    "call_link": (
        "📞 That's a <b>Telegram call link</b> (t.me/call/…) — it starts a "
        "phone/video call, it doesn't identify a group.\n\n"
        "Send a group destination instead:\n"
        "• a public group link — https://t.me/yourgroup\n"
        "• a group username — @yourgroup\n"
        "• a private invite link — https://t.me/+AbCdEf…"
    ),
    "not_group": (
        "⚠️ That link points to a channel or a private chat, not a group. "
        "Only group (voice-chat capable) links are supported."
    ),
    "not_found": (
        "🔎 Couldn't resolve that link — check it and send it again."
    ),
    "user_not_member": (
        "🚫 You are not a member of that group, so you can't start playback "
        "there. Join the group first, then try again."
    ),
    "membership_unknown": (
        "🤔 Couldn't verify your membership in that group. Try again in a "
        "moment, or ask the group to add the bot directly."
    ),
    "voice_chat_missing": (
        "🎙️ There is no active voice chat in that group yet. A group "
        "admin needs to start one (Group Menu → Voice Chat) — then press "
        "Retry."
    ),
}

_SUCCESS = "ok"

#: Failure statuses that mean the *invite link itself* is dead — the cached
#: link must be dropped so the next attempt exports a fresh one.
_LINK_UNUSABLE_STATUSES = frozenset(
    {"invite_link_invalid", "invite_link_expired", "account_banned"}
)


def _now() -> float:
    """Monotonic clock (patchable in tests)."""
    return time.monotonic()


def to_telethon_entity_id(group_tg_id: int) -> int:
    """Convert an aiogram-style chat id to a Telethon entity id.

    * ``-100XXXXXXXXXX`` (supergroup / channel) → kept as the marked id
      Telethon's ``get_entity`` accepts directly;
    * ``-XXXXXXX`` (basic group) → the plain positive chat id Telethon uses;
    * anything else (public channel id, positive) → unchanged.
    """
    value = int(group_tg_id)
    if value <= -1000000000000:  # -100 + >=10 digits ⇒ marked channel id
        return value
    if value < 0:  # basic group (aiogram negates basic chat ids)
        return -value
    return value


def from_telethon_chat(entity: Any) -> int | None:
    """Convert a Telethon chat entity to a Bot API-style chat id.

    * :class:`telethon.tl.types.Channel` (supergroup) → the marked id
      ``-(10^12 + channel_id)`` — the same arithmetic form Telethon's
      ``utils.get_peer_id`` and the Bot API use for modern (≥10-digit)
      channel ids, matching :func:`to_telethon_entity_id`'s inverse;
    * :class:`telethon.tl.types.Chat` (basic group) → ``-<id>``;
    * anything else (users, broadcasts used elsewhere) → ``None``.
    """
    try:
        from telethon import types
    except ImportError:  # pragma: no cover — telethon is a hard voice dep
        return None
    if isinstance(entity, types.Channel):
        return int(-1000000000000 - int(entity.id))
    if isinstance(entity, types.Chat):
        return -int(entity.id)
    return None


def extract_invite_hash(link: str) -> str | None:
    """Extract the invite hash from a ``t.me`` join link, else ``None``.

    Accepted shapes::

        https://t.me/+AbCdEf123
        https://t.me/joinchat/AbCdEf123
        tg://join?invite=AbCdEf123
        https://telegram.me/joinchat/AbCdEf123
    """
    text = (link or "").strip()
    if not text:
        return None
    try:
        parsed = urlparse(text)
    except ValueError:
        return None
    scheme = (parsed.scheme or "").lower()
    host = (parsed.hostname or "").lower()

    if scheme == "tg":
        # tg://join?invite=HASH ("join" parses as the netloc)
        if (parsed.netloc or "").lower() == "join" or "join" in (parsed.path or "").lower():
            for key, value in _parse_qsl(parsed.query):
                if key == "invite" and value:
                    return value
        return None

    if host not in ("t.me", "telegram.me", "www.t.me", "telegram.dog"):
        return None
    path = (parsed.path or "").strip("/")
    if path.startswith("+"):
        hash_ = path[1:]
        return hash_ or None
    if path.startswith("joinchat/"):
        hash_ = path.split("/", 1)[1]
        return hash_ or None
    return None


def extract_public_username(link: str) -> str | None:
    """Public ``t.me/<username>`` link → username (``None`` otherwise).

    Special ``t.me`` link kinds that are NOT public usernames (``c/``,
    ``joinchat/``, ``+``, ``addstickers/``, ...) return ``None`` — see
    :func:`classify_tme_link` for the full classification.
    """
    text = (link or "").strip()
    if not text:
        return None
    try:
        parsed = urlparse(text)
    except ValueError:
        return None
    host = (parsed.hostname or "").lower()
    if host not in ("t.me", "telegram.me", "www.t.me", "telegram.dog"):
        return None
    path = (parsed.path or "").strip("/")
    if not path or path.startswith(("+", "joinchat/", "c/", "addstickers/")):
        return None
    username = path.split("/", 1)[0]
    return username or None


#: ``t.me`` path prefixes that identify a NON-group link kind.  Anything in
#: this table is rejected up-front with a specific, honest message instead
#: of being treated as a (bogus) public username and failing as "not found".
_TME_SPECIAL_KINDS: dict[str, str] = {
    "call": "call_link",  # t.me/call/<id> — Telegram call link
    "addstickers": "invalid_link",  # sticker pack
    "addtheme": "invalid_link",  # theme
    "addemoji": "invalid_link",  # emoji pack
    "proxy": "invalid_link",  # MTProto proxy
    "socks": "invalid_link",  # SOCKS proxy
    "bg": "invalid_link",  # wallpaper
    "boost": "invalid_link",  # channel boost
    "giftcode": "invalid_link",  # gift code
    "share": "invalid_link",  # share url
    "contact": "invalid_link",  # contact card
    "confirm": "invalid_link",  # login confirmation
    "login": "invalid_link",  # login code
    "setlanguage": "invalid_link",  # custom language pack
}


def classify_tme_link(link: str) -> str | None:
    """Classify special ``t.me`` link kinds that are NOT group links.

    Returns a :data:`STATUS_MESSAGES` status key (``"call_link"`` for
    Telegram call links, ``"invalid_link"`` for other special kinds) or
    ``None`` when the link looks like a regular ``t.me/<username>`` path,
    an invite link (``+``/``joinchat``) or is not a ``t.me`` link at all.
    """
    text = (link or "").strip()
    if not text:
        return None
    try:
        parsed = urlparse(text)
    except ValueError:
        return None
    host = (parsed.hostname or "").lower()
    if host not in ("t.me", "telegram.me", "www.t.me", "telegram.dog"):
        return None
    path = (parsed.path or "").strip("/")
    if not path:
        return None
    head = path.split("/", 1)[0].lower()
    if head in _TME_SPECIAL_KINDS:
        return _TME_SPECIAL_KINDS[head]
    # ``t.me/c/<internal-id>`` links point at private channel content —
    # not a group username and not joinable; report as unresolvable.
    if path.startswith("c/"):
        return "not_found"
    return None


def _parse_qsl(query: str) -> list[tuple[str, str]]:
    """Minimal &-split query parser (avoids importing parse_qsl quirks)."""
    pairs: list[tuple[str, str]] = []
    for chunk in (query or "").split("&"):
        if not chunk:
            continue
        key, _, value = chunk.partition("=")
        pairs.append((key, value))
    return pairs


def _log_safe_link(link: str) -> str:
    """Link metadata safe for logs (host + length — never the hash)."""
    try:
        host = urlparse(link).hostname or ""
    except ValueError:
        host = ""
    return f"{host}({len(link)})"


class GroupAccessService:
    """Membership verification + authorized invite-link joining."""

    def __init__(
        self,
        settings: Settings,
        invite_provider: InviteLinkProvider | None = None,
        *,
        clock: Callable[[], float] = _now,
    ) -> None:
        self._settings = settings
        self._invite_provider = invite_provider
        self._clock = clock
        # (account_id, group_id) → membership-known-until timestamp.
        self._membership_cache: dict[tuple[int, int], float] = {}
        # group_id → (invite link, valid-until).
        self._link_cache: dict[int, tuple[str, float]] = {}
        # group_id → (status, blocked-until) — failed-join cooldowns.
        self._blocked: dict[int, tuple[str, float]] = {}
        # group_id → single-flight join mutex.
        self._locks: dict[int, asyncio.Lock] = {}

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------
    def set_invite_provider(self, provider: InviteLinkProvider | None) -> None:
        """Attach (or replace) the bot-backed invite link provider."""
        self._invite_provider = provider

    @property
    def auto_join_enabled(self) -> bool:
        """Whether automatic joining is enabled at all."""
        return bool(self._settings.voice.auto_join_enabled)

    # ------------------------------------------------------------------
    # Membership
    # ------------------------------------------------------------------
    async def check_membership(
        self, client: Any, group_tg_id: int, *, account_id: int | None = None
    ) -> bool | None:
        """True/False when membership is known, ``None`` when undeterminable.

        ``None`` typically means the account never interacted with the group
        (Telethon cannot resolve the entity) — the caller should treat it as
        "probably not a member" and, when allowed, attempt the invite join.
        """
        group_tg_id = int(group_tg_id)
        if account_id is not None and self._cached_member(account_id, group_tg_id):
            return True
        try:
            from telethon import functions, types
            from telethon.errors import UserNotParticipantError
        except ImportError:  # pragma: no cover — telethon is a hard dep of voice
            logger.warning("voice.group_access.telethon_missing")
            return None

        entity_id = to_telethon_entity_id(group_tg_id)
        try:
            entity = await client.get_entity(entity_id)
        except ValueError:
            # Not in the session — the account never saw this group.
            return None
        except Exception as exc:  # noqa: BLE001 — network/protocol errors
            logger.debug(
                "voice.group_access.entity_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
            )
            return None

        if isinstance(entity, types.Channel):
            try:
                await client(
                    functions.channels.GetParticipantRequest(
                        entity, types.InputPeerSelf()
                    )
                )
                self._remember_member(account_id, group_tg_id)
                return True
            except UserNotParticipantError:
                return False
            except Exception as exc:  # noqa: BLE001 — admin-only/participant errs
                logger.debug(
                    "voice.group_access.participant_check_failed",
                    extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
                )
                return None

        if isinstance(entity, types.Chat):
            # Basic groups: messages.getFullChat works only for members.
            try:
                full = await client(
                    functions.messages.GetFullChatRequest(entity.id)
                )
            except Exception as exc:  # noqa: BLE001 — kicked/no access
                logger.debug(
                    "voice.group_access.full_chat_failed",
                    extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
                )
                return None
            participants = getattr(getattr(full, "full_chat", None), "participants", None)
            if participants is None:
                # ChatParticipantsForbidden — but reaching full info at all
                # implies membership.
                self._remember_member(account_id, group_tg_id)
                return True
            me = await _get_own_id(client)
            if me is not None:
                for participant in getattr(participants, "participants", []) or []:
                    if getattr(participant, "user_id", None) == me:
                        self._remember_member(account_id, group_tg_id)
                        return True
                return False
            return None

        logger.warning(
            "voice.group_access.unexpected_entity_type",
            extra=log_extra(group_id=group_tg_id, type=type(entity).__name__),
        )
        return None

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------
    async def ensure_access(
        self, client: Any, group_tg_id: int, *, account_id: int | None = None
    ) -> GroupAccessOutcome:
        """Guarantee the account can access *group*; join via invite if allowed.

        Never raises — every failure is a typed :class:`GroupAccessOutcome`
        with a user-safe message. Called only from authorized playback flows
        (the music command originated inside this very group).
        """
        group_tg_id = int(group_tg_id)

        member = await self.check_membership(
            client, group_tg_id, account_id=account_id
        )
        if member:
            self._blocked.pop(group_tg_id, None)
            return GroupAccessOutcome(
                ok=True, joined=False, status="member"
            )

        if not self.auto_join_enabled:
            return self._fail(group_tg_id, "auto_join_disabled")

        blocked = self._blocked.get(group_tg_id)
        if blocked is not None and blocked[1] > self._clock():
            return self._fail(group_tg_id, "cooldown")

        async with self._locks.setdefault(group_tg_id, asyncio.Lock()):
            # Single-flight: a concurrent caller may have just joined.
            member = await self.check_membership(
                client, group_tg_id, account_id=account_id
            )
            if member:
                self._blocked.pop(group_tg_id, None)
                return GroupAccessOutcome(
                    ok=True, joined=False, status="member"
                )

            link = await self._invite_link(group_tg_id)
            if link is None:
                return self._fail(group_tg_id, "invite_unavailable")

            outcome = await self._join_with_link(client, group_tg_id, link)
            if not outcome.ok:
                self._block(group_tg_id, outcome.status)
                return outcome

            # Import accepted — verify actual membership (join-request
            # groups approve members only after an admin accepts).
            member = await self.check_membership(
                client, group_tg_id, account_id=account_id
            )
            if member:
                actually_joined = outcome.status == "ok"
                logger.info(
                    "voice.group_access.joined",
                    extra=log_extra(group_id=group_tg_id, via=outcome.status),
                )
                return GroupAccessOutcome(
                    ok=True, joined=actually_joined, status="joined"
                )
            # Joined on Telegram's side but not a participant → pending.
            return self._fail(group_tg_id, "approval_pending")

    # ------------------------------------------------------------------
    # Introspection (admin)
    # ------------------------------------------------------------------
    def cooldown_remaining(self, group_tg_id: int) -> float:
        """Seconds left on the group's failed-join cooldown (0 = none)."""
        blocked = self._blocked.get(int(group_tg_id))
        if blocked is None:
            return 0.0
        return max(0.0, blocked[1] - self._clock())

    def forget_group(self, group_tg_id: int) -> None:
        """Drop all cached state for a group (admin reset action)."""
        group_tg_id = int(group_tg_id)
        self._blocked.pop(group_tg_id, None)
        self._link_cache.pop(group_tg_id, None)
        self._locks.pop(group_tg_id, None)
        self._membership_cache = {
            key: until
            for key, until in self._membership_cache.items()
            if key[1] != group_tg_id
        }

    # ------------------------------------------------------------------
    # DM link resolution (search-in-DM → play-in-group workflow)
    # ------------------------------------------------------------------
    async def resolve_target(
        self,
        client: Any,
        link: str,
        *,
        account_id: int | None = None,
        allow_join: bool = True,
    ) -> GroupLinkResolution:
        """Resolve a user-submitted group link to a playable target group.

        Accepted inputs: public group links (``https://t.me/<username>``),
        bare usernames (``@<username>``) and private invite links
        (``https://t.me/+hash``, ``/joinchat/<hash>``, ``tg://join``).
        Telegram CALL links (``https://t.me/call/...``) are recognized and
        rejected with a dedicated explanation (they are not a group
        destination); other special ``t.me`` kinds (sticker packs, proxies,
        …) are rejected as invalid group links.  Channels and users are
        rejected; the voice account may join private groups through the
        invite when *allow_join* is set (the user explicitly asked to play
        there — that is the documented consent for this flow).

        Never raises; every failure is a typed :class:`GroupLinkResolution`
        with a user-safe message. The link itself is never logged.
        """
        link = (link or "").strip()
        if not link:
            return self._link_resolution(False, "invalid_link")

        # Special t.me link kinds (call links, sticker packs, proxies ...)
        # are rejected up-front with specific, honest messages — a Telegram
        # call link is NOT a group destination and must never be treated as
        # a (bogus) username or as authorization to join anything.
        special = classify_tme_link(link)
        if special is not None:
            return self._link_resolution(False, special)

        invite_hash = extract_invite_hash(link)
        username = None if invite_hash else extract_public_username(link)
        if username is None and not invite_hash:
            raw = link.lstrip("@")
            if raw != link and raw and " " not in raw and "/" not in raw:
                username = raw  # bare "@username" form
            elif link.startswith(("t.me/", "telegram.me/")):
                username = link.split("/", 1)[1].strip() or None
        if invite_hash is None and username is None:
            return self._link_resolution(False, "invalid_link")

        if invite_hash is not None:
            return await self._resolve_invite(
                client, invite_hash, account_id=account_id, allow_join=allow_join
            )
        return await self._resolve_username(client, username or "")

    async def _resolve_invite(
        self,
        client: Any,
        invite_hash: str,
        *,
        account_id: int | None,
        allow_join: bool,
    ) -> GroupLinkResolution:
        """Private invite link → preview (CheckChatInvite) → join if allowed."""
        try:
            from telethon import functions, types
            from telethon.errors import (
                ChannelPrivateError,
                FloodWaitError,
                InviteHashExpiredError,
                InviteHashInvalidError,
                InviteRequestSentError,
                RPCError,
                UserAlreadyParticipantError,
                UserBannedInChannelError,
            )
        except ImportError:  # pragma: no cover — telethon is a hard voice dep
            return self._link_resolution(False, "auto_join_disabled")

        try:
            preview = await client(
                functions.messages.CheckChatInviteRequest(invite_hash)
            )
        except InviteHashExpiredError:
            return self._link_resolution(False, "invite_link_expired")
        except InviteHashInvalidError:
            return self._link_resolution(False, "invite_link_invalid")
        except (ChannelPrivateError, UserBannedInChannelError):
            return self._link_resolution(False, "account_banned")
        except FloodWaitError as exc:
            return self._link_resolution(
                False,
                "flood_limited",
                retry_after_seconds=int(getattr(exc, "seconds", 0) or 0) or None,
            )
        except (RPCError, ValueError) as exc:
            logger.debug(
                "voice.link.check_invite_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
            return self._link_resolution(False, "not_found")

        # Already a member → the response carries the chat itself.
        if isinstance(preview, types.ChatInviteAlready):
            return self._resolution_from_entity(preview.chat, joined=False)

        if not isinstance(preview, types.ChatInvite):
            logger.warning(
                "voice.link.unexpected_preview",
                extra=log_extra(preview=type(preview).__name__),
            )
            return self._link_resolution(False, "not_found")

        # Preview metadata: reject broadcast channels — only groups have
        # group calls. Telethon's ChatInvite carries ``broadcast`` and
        # ``megagroup`` booleans (a basic-group invite has both False).
        if getattr(preview, "broadcast", False):
            return self._link_resolution(False, "not_group")

        if not allow_join:
            return self._link_resolution(False, "auto_join_disabled")

        try:
            await client(functions.messages.ImportChatInviteRequest(invite_hash))
        except UserAlreadyParticipantError:
            # Joined between the check and the import — re-check to learn
            # the actual chat.
            try:
                again = await client(
                    functions.messages.CheckChatInviteRequest(invite_hash)
                )
            except Exception:  # noqa: BLE001
                again = None
            if isinstance(again, types.ChatInviteAlready):
                return self._resolution_from_entity(again.chat, joined=False)
            return self._link_resolution(False, "membership_unverified")
        except InviteRequestSentError:
            return self._link_resolution(False, "approval_pending")
        except InviteHashExpiredError:
            return self._link_resolution(False, "invite_link_expired")
        except InviteHashInvalidError:
            return self._link_resolution(False, "invite_link_invalid")
        except (ChannelPrivateError, UserBannedInChannelError):
            return self._link_resolution(False, "account_banned")
        except FloodWaitError as exc:
            return self._link_resolution(
                False,
                "flood_limited",
                retry_after_seconds=int(getattr(exc, "seconds", 0) or 0) or None,
            )
        except RPCError as exc:
            logger.debug(
                "voice.link.import_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
            return self._link_resolution(False, "group_private")

        # Import accepted — re-check to learn the chat (and whether the
        # join still needs admin approval).
        try:
            final = await client(
                functions.messages.CheckChatInviteRequest(invite_hash)
            )
        except Exception as exc:  # noqa: BLE001 — membership unverified
            logger.debug(
                "voice.link.recheck_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
            return self._link_resolution(False, "membership_unverified")
        if isinstance(final, types.ChatInviteAlready):
            return self._resolution_from_entity(final.chat, joined=True)
        return self._link_resolution(False, "approval_pending")

    async def _resolve_username(
        self, client: Any, username: str
    ) -> GroupLinkResolution:
        """Public group link / username → entity (must be a real group)."""
        username = (username or "").strip().lstrip("@")
        if not username:
            return self._link_resolution(False, "invalid_link")
        try:
            from telethon import types
        except ImportError:  # pragma: no cover
            return self._link_resolution(False, "auto_join_disabled")
        try:
            entity = await client.get_entity(username)
        except ValueError:
            return self._link_resolution(False, "not_found")
        except Exception as exc:  # noqa: BLE001 — network/protocol errors
            logger.debug(
                "voice.link.entity_failed",
                extra=log_extra(error=str(exc)[:160]),
            )
            return self._link_resolution(False, "not_found")

        if isinstance(entity, types.Channel) and not entity.megagroup:
            return self._link_resolution(False, "not_group")  # broadcast channel
        if isinstance(entity, (types.Channel, types.Chat)):
            return self._resolution_from_entity(entity, joined=False)
        return self._link_resolution(False, "not_group")  # user / other

    def _resolution_from_entity(
        self, entity: Any, *, joined: bool
    ) -> GroupLinkResolution:
        """Build a success resolution from a Telethon chat entity."""
        chat_id = from_telethon_chat(entity)
        if chat_id is None:
            return self._link_resolution(False, "not_group")
        try:
            from telethon import types
        except ImportError:  # pragma: no cover
            return self._link_resolution(False, "auto_join_disabled")
        chat_type = "supergroup" if isinstance(entity, types.Channel) else "group"
        if joined and chat_id is not None:
            self._blocked.pop(int(chat_id), None)
        logger.info(
            "voice.link.resolved",
            extra=log_extra(
                group_id=chat_id,
                chat_type=chat_type,
                joined=joined,
                title_len=len(getattr(entity, "title", "") or ""),
            ),
        )
        return GroupLinkResolution(
            ok=True,
            status=_SUCCESS,
            group_tg_id=chat_id,
            title=(getattr(entity, "title", "") or None),
            chat_type=chat_type,
            joined=joined,
        )

    def _link_resolution(
        self,
        ok: bool,
        status: str,
        *,
        retry_after_seconds: int | None = None,
    ) -> GroupLinkResolution:
        """Build a typed failure resolution with the standard message."""
        if ok:
            return GroupLinkResolution(ok=True, status=_SUCCESS)
        logger.info("voice.link.denied", extra=log_extra(status=status))
        return GroupLinkResolution(
            ok=False,
            status=status,
            user_message=STATUS_MESSAGES.get(status),
            retry_after_seconds=retry_after_seconds,
        )

    # ------------------------------------------------------------------
    # Voice-chat and user-membership checks (DM workflow prerequisites)
    # ------------------------------------------------------------------
    async def check_voice_chat(self, client: Any, group_tg_id: int) -> bool | None:
        """Whether the group has an ACTIVE voice chat right now.

        ``True``/``False`` when determinable, ``None`` when the full-info
        lookup failed (treated by callers as "cannot verify — let the
        transport surface its own error"). Requires the account to see
        the group (entity resolvable).
        """
        group_tg_id = int(group_tg_id)
        try:
            from telethon import functions, types
        except ImportError:  # pragma: no cover
            return None
        entity_id = to_telethon_entity_id(group_tg_id)
        try:
            entity = await client.get_entity(entity_id)
        except Exception as exc:  # noqa: BLE001 — unknown entity etc.
            logger.debug(
                "voice.group_access.vc_entity_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
            )
            return None
        try:
            if isinstance(entity, types.Channel):
                full = await client(
                    functions.channels.GetFullChannelRequest(entity)
                )
            elif isinstance(entity, types.Chat):
                full = await client(
                    functions.messages.GetFullChatRequest(entity.id)
                )
            else:
                return None
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "voice.group_access.vc_full_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
            )
            return None
        group_call = getattr(getattr(full, "full_chat", None), "groupcall", None)
        return group_call is not None

    async def check_user_membership(
        self, client: Any, group_tg_id: int, user_tg_id: int
    ) -> tuple[bool, bool] | None:
        """Whether *user_tg_id* is a member of the group (and an admin).

        Returns ``(is_member, is_admin)``; ``None`` when it could not be
        determined (callers should fail closed with a retry hint).
        ``group_tg_id`` is a Bot API-style chat id.
        """
        group_tg_id = int(group_tg_id)
        user_tg_id = int(user_tg_id)
        try:
            from telethon import functions, types
            from telethon.errors import UserNotParticipantError
        except ImportError:  # pragma: no cover
            return None
        entity_id = to_telethon_entity_id(group_tg_id)
        try:
            entity = await client.get_entity(entity_id)
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "voice.group_access.user_entity_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
            )
            return None

        if isinstance(entity, types.Channel):
            try:
                result = await client(
                    functions.channels.GetParticipantRequest(entity, user_tg_id)
                )
            except UserNotParticipantError:
                return (False, False)
            except Exception as exc:  # noqa: BLE001 — admin-only groups etc.
                logger.debug(
                    "voice.group_access.user_participant_failed",
                    extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
                )
                return None
            participant = getattr(result, "participant", None)
            is_admin = isinstance(
                participant, (types.ChannelParticipantAdmin, types.ChannelParticipantCreator)
            )
            return (True, is_admin)

        if isinstance(entity, types.Chat):
            try:
                full = await client(
                    functions.messages.GetFullChatRequest(entity.id)
                )
            except Exception as exc:  # noqa: BLE001
                logger.debug(
                    "voice.group_access.user_full_failed",
                    extra=log_extra(group_id=group_tg_id, error=str(exc)[:160]),
                )
                return None
            participants = getattr(getattr(full, "full_chat", None), "participants", None)
            if participants is None:
                return None  # cannot enumerate — fail closed
            for participant in getattr(participants, "participants", []) or []:
                if getattr(participant, "user_id", None) == user_tg_id:
                    is_admin = isinstance(
                        participant,
                        (types.ChatParticipantAdmin, types.ChatParticipantCreator),
                    )
                    return (True, is_admin)
            return (False, False)

        return None

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _invite_link(self, group_tg_id: int) -> str | None:
        """Cached invite link from the bot provider (``None`` = unavailable)."""
        now = self._clock()
        cached = self._link_cache.get(group_tg_id)
        if cached is not None and cached[1] > now:
            return cached[0]
        if self._invite_provider is None:
            return None
        try:
            link = await self._invite_provider(group_tg_id)
        except Exception as exc:  # noqa: BLE001 — provider must not raise
            logger.warning(
                "voice.group_access.invite_export_failed",
                extra=log_extra(group_id=group_tg_id, error=str(exc)[:200]),
            )
            return None
        link = (link or "").strip() or None
        if link is None:
            logger.info(
                "voice.group_access.invite_unavailable",
                extra=log_extra(group_id=group_tg_id),
            )
            return None
        ttl = max(30, int(self._settings.voice.invite_link_cache_seconds))
        self._link_cache[group_tg_id] = (link, now + ttl)
        logger.info(
            "voice.group_access.invite_exported",
            extra=log_extra(group_id=group_tg_id, link=_log_safe_link(link)),
        )
        return link

    async def _join_with_link(
        self, client: Any, group_tg_id: int, link: str
    ) -> GroupAccessOutcome:
        """Attempt joining through *link* (import hash / public username)."""
        try:
            from telethon import functions
            from telethon.errors import (
                ChannelPrivateError,
                ChatWriteForbiddenError,
                FloodWaitError,
                InviteHashExpiredError,
                InviteHashInvalidError,
                InviteRequestSentError,
                RPCError,
                UserAlreadyParticipantError,
                UserBannedInChannelError,
            )
        except ImportError:  # pragma: no cover
            return self._outcome(False, "auto_join_disabled", "telethon missing")

        invite_hash = extract_invite_hash(link)
        if invite_hash is None:
            username = extract_public_username(link)
            if username is not None:
                return await self._join_public(client, group_tg_id, username)
            return self._outcome(
                False, "invite_link_invalid", f"unrecognized link shape: {_log_safe_link(link)}"
            )

        try:
            await client(functions.messages.ImportChatInviteRequest(invite_hash))
            return self._outcome(True, _SUCCESS, "invite imported")
        except UserAlreadyParticipantError:
            return self._outcome(True, "already_participant")
        except InviteHashExpiredError:
            # The cached link may be stale — drop it and retry ONCE with a
            # freshly exported link (never loops; at most one re-export).
            self._link_cache.pop(int(group_tg_id), None)
            fresh = await self._invite_link(group_tg_id)
            if fresh and fresh != link:
                try:
                    await client(
                        functions.messages.ImportChatInviteRequest(
                            extract_invite_hash(fresh) or ""
                        )
                    )
                    return self._outcome(True, _SUCCESS, "fresh invite imported")
                except UserAlreadyParticipantError:
                    return self._outcome(True, "already_participant")
                except InviteHashExpiredError:
                    return self._outcome(False, "invite_link_expired", "fresh link expired")
                except FloodWaitError as exc:
                    return self._flood(exc)
                except InviteRequestSentError:
                    return self._outcome(
                        False, "approval_pending", "join request sent (fresh link)"
                    )
                except (ChannelPrivateError, UserBannedInChannelError):
                    return self._outcome(False, "account_banned", "banned/private (fresh)")
                except ChatWriteForbiddenError:
                    return self._outcome(False, "account_banned", "write forbidden (fresh)")
                except RPCError as exc:
                    return self._outcome(False, "group_private", f"rpc {type(exc).__name__}")
            return self._outcome(False, "invite_link_expired", "no fresh link available")
        except InviteHashInvalidError:
            return self._outcome(False, "invite_link_invalid", "hash rejected")
        except InviteRequestSentError:
            return self._outcome(False, "approval_pending", "join request sent")
        except FloodWaitError as exc:
            return self._flood(exc)
        except (ChannelPrivateError, UserBannedInChannelError):
            return self._outcome(False, "account_banned", "banned/private")
        except ChatWriteForbiddenError:
            return self._outcome(False, "account_banned", "write forbidden")
        except RPCError as exc:
            return self._outcome(False, "group_private", f"rpc {type(exc).__name__}")
        except Exception as exc:  # noqa: BLE001 — unexpected library errors
            return self._outcome(False, "group_private", str(exc)[:200])

    async def _join_public(
        self, client: Any, group_tg_id: int, username: str
    ) -> GroupAccessOutcome:
        """Join a public group by username (no invite hash needed)."""
        try:
            from telethon import functions
            from telethon.errors import (
                ChannelPrivateError,
                FloodWaitError,
                InviteRequestSentError,
                RPCError,
                UserAlreadyParticipantError,
                UserBannedInChannelError,
            )
        except ImportError:  # pragma: no cover
            return self._outcome(False, "auto_join_disabled", "telethon missing")
        try:
            entity = await client.get_entity(username)
            await client(functions.channels.JoinChannelRequest(entity))
            return self._outcome(True, _SUCCESS, f"joined public @{username}")
        except UserAlreadyParticipantError:
            return self._outcome(True, "already_participant")
        except InviteRequestSentError:
            return self._outcome(False, "approval_pending", "join request sent")
        except FloodWaitError as exc:
            return self._flood(exc)
        except (ChannelPrivateError, UserBannedInChannelError):
            return self._outcome(False, "account_banned", "banned/private")
        except (ValueError, RPCError) as exc:
            return self._outcome(False, "invite_link_invalid", str(exc)[:160])
        except Exception as exc:  # noqa: BLE001
            return self._outcome(False, "group_private", str(exc)[:200])

    def _flood(self, exc: Any) -> GroupAccessOutcome:
        """FloodWait mapping with the server-provided wait time."""
        seconds = int(getattr(exc, "seconds", 0) or 0)
        logger.warning(
            "voice.group_access.flood_wait",
            extra=log_extra(seconds=seconds),
        )
        return GroupAccessOutcome(
            ok=False,
            joined=False,
            status="flood_limited",
            detail=f"flood wait {seconds}s",
            user_message=STATUS_MESSAGES["flood_limited"],
            retry_after_seconds=seconds or None,
        )

    def _outcome(self, ok: bool, status: str, detail: str = "") -> GroupAccessOutcome:
        """Build an outcome with the standard user message for *status*."""
        return GroupAccessOutcome(
            ok=ok,
            joined=False,
            status=status,
            detail=detail,
            user_message=None if ok else STATUS_MESSAGES.get(status),
        )

    def _fail(self, group_tg_id: int, status: str) -> GroupAccessOutcome:
        """Outcome for a terminal failure (logged with group context)."""
        logger.info(
            "voice.group_access.denied",
            extra=log_extra(group_id=group_tg_id, status=status),
        )
        return self._outcome(False, status)

    def _block(self, group_tg_id: int, status: str) -> None:
        """Put the group on the failed-join cooldown."""
        cooldown = max(0, int(self._settings.voice.join_cooldown_seconds))
        self._blocked[int(group_tg_id)] = (status, self._clock() + cooldown)
        if status in _LINK_UNUSABLE_STATUSES:
            # The link itself is dead (invalid/expired/banned) — drop it so
            # the next attempt (after the cooldown) exports a fresh one.
            self._link_cache.pop(int(group_tg_id), None)
        logger.info(
            "voice.group_access.cooldown",
            extra=log_extra(group_id=int(group_tg_id), status=status, seconds=cooldown),
        )

    def _cached_member(self, account_id: int, group_tg_id: int) -> bool:
        """True while a recent positive membership result is still valid."""
        until = self._membership_cache.get((int(account_id), int(group_tg_id)))
        return until is not None and until > self._clock()

    def _remember_member(self, account_id: int | None, group_tg_id: int) -> None:
        """Cache a positive membership result (per account, TTL-bounded)."""
        if account_id is None:
            return
        ttl = max(0, int(self._settings.voice.membership_cache_seconds))
        if ttl == 0:
            return
        self._membership_cache[(int(account_id), int(group_tg_id))] = (
            self._clock() + ttl
        )


async def _get_own_id(client: Any) -> int | None:
    """Best-effort own user id via ``get_me`` (``None`` on failure)."""
    try:
        me = await client.get_me()
    except Exception:  # noqa: BLE001 — identity is non-critical here
        return None
    return getattr(me, "id", None) if me is not None else None


__all__ = [
    "STATUS_MESSAGES",
    "GroupAccessOutcome",
    "GroupLinkResolution",
    "GroupAccessService",
    "classify_tme_link",
    "extract_invite_hash",
    "extract_public_username",
    "from_telethon_chat",
    "to_telethon_entity_id",
]

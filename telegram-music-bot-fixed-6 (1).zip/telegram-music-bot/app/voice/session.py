"""A live lease: one account's presence in one group voice chat.

:class:`VoiceSessionRuntime` owns playback state for a single group session:
it drives the transport, writes the audit trail through
:class:`~app.database.repositories.voice.VoiceRepository`, runs the
``last_heartbeat`` keep-alive and — critically — runs the track duration
timer that publishes ``track_end:group:<id>`` so the playback controller can
advance the queue.

Error policy: transport failures propagate as :class:`app.errors.VoiceError`
subclasses; repository failures are *logged and swallowed* — bookkeeping must
never interrupt live playback.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from pathlib import Path
from time import monotonic
from typing import TYPE_CHECKING

from app.errors import VoiceError
from app.logging import get_logger, log_extra

if TYPE_CHECKING:
    from app.database.models.voice import VoiceSession
    from app.database.repositories.voice import VoiceRepository
    from app.playback.events import EventBus
    from app.voice.account import VoiceAccountClient
    from app.voice.transport import VoiceTransport

#: Probe callable: path -> duration in seconds (0 = unknown).
DurationProbe = Callable[[Path], Awaitable[int]]

logger = get_logger(__name__)


class VoiceSessionRuntime:
    """Runtime state machine for one group's voice session."""

    def __init__(
        self,
        repo: VoiceRepository,
        model: VoiceSession,
        account: VoiceAccountClient,
        events: EventBus,
        *,
        duration_probe: DurationProbe | None = None,
        heartbeat_interval: float | None = None,
    ) -> None:
        self._repo = repo
        self._model = model
        self._account = account
        self._events = events
        self._duration_probe = duration_probe
        self._heartbeat_interval = heartbeat_interval

        self._timer: asyncio.Task[None] | None = None
        self._heartbeat: asyncio.Task[None] | None = None
        self._track_duration = 0.0
        self._elapsed = 0.0
        self._play_started_at: float | None = None
        # Idle tracking: timestamp of the last playback/user interaction.
        # The voice manager releases leases idle for longer than the
        # configured timeout (see ``VoiceManager.release_idle_sessions``).
        self._last_activity: float = monotonic()

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------
    @property
    def group_id(self) -> int:
        """Telegram id of the group owning this session."""
        return int(self._model.group_id)

    @property
    def session_id(self) -> int:
        """Database id of the VoiceSession row."""
        return int(self._model.id)

    @property
    def account(self) -> VoiceAccountClient:
        """The account serving this session."""
        return self._account

    @property
    def status(self) -> str:
        """Current session status (in-memory mirror of the DB row)."""
        return str(self._model.status or "joining")

    @property
    def last_activity(self) -> float:
        """Monotonic timestamp of the last playback/user interaction."""
        return self._last_activity

    @property
    def idle_seconds(self) -> float:
        """Seconds since the last interaction (0 while playing)."""
        if self.status == "playing":
            return 0.0
        return max(0.0, monotonic() - self._last_activity)

    def _touch_activity(self) -> None:
        """Mark the session as active (called on every interaction)."""
        self._last_activity = monotonic()

    # ------------------------------------------------------------------
    # Playback control
    # ------------------------------------------------------------------
    async def start_playback(self, path: Path, *, duration: int | None = None) -> None:
        """Start streaming ``path`` into the group voice chat.

        Args:
            path: Local audio file (opus voice profile recommended).
            duration: Track duration in seconds; when omitted, the injected
                duration probe (ffprobe) is consulted. A duration of 0 or an
                unknown duration disables the auto-advance timer.
        """
        transport = self._require_transport()
        await transport.play(self.group_id, path)

        if duration is None:
            duration = await self._probe_duration(path)
        await self._record_event("play", {"path": Path(path).name})
        await self._update(status="playing")
        self._touch_activity()
        self._start_timer(float(duration or 0))
        self._start_heartbeat()
        logger.info(
            "voice.session.playing",
            extra=log_extra(
                session_id=self.session_id,
                group_id=self.group_id,
                path=Path(path).name,
                duration=int(duration or 0),
            ),
        )

    async def pause(self) -> None:
        """Pause the stream (timer freezes at the current position)."""
        transport = self._require_transport()
        await transport.pause(self.group_id)
        self._freeze_timer()
        await self._record_event("pause")
        await self._update(status="paused")
        self._touch_activity()  # a user interaction — restart the idle window
        logger.info(
            "voice.session.paused",
            extra=log_extra(session_id=self.session_id, group_id=self.group_id),
        )

    async def resume(self) -> None:
        """Resume the paused stream (timer continues with remaining time)."""
        transport = self._require_transport()
        await transport.resume(self.group_id)
        await self._update(status="playing")
        self._touch_activity()
        self._resume_timer()
        logger.info(
            "voice.session.resumed",
            extra=log_extra(session_id=self.session_id, group_id=self.group_id),
        )

    async def stop_playback(self) -> None:
        """Stop the audio without leaving the chat.

        pytgcalls cannot halt a stream without leaving the call, so the stream
        is paused instead — the account stays in the voice chat.
        """
        transport = self._require_transport()
        await transport.pause(self.group_id)
        self._freeze_timer()
        await self._record_event("stop")
        await self._update(status="paused")
        self._touch_activity()  # a user interaction — restart the idle window
        logger.info(
            "voice.session.stopped",
            extra=log_extra(session_id=self.session_id, group_id=self.group_id),
        )

    async def leave(self) -> None:
        """Leave the voice chat and close the session lease."""
        self._cancel_timer()
        self._cancel_heartbeat()
        transport = self._account.transport
        if transport is not None:
            await transport.leave(self.group_id)
        await self._record_event("leave")
        try:
            await self._repo.end_session(self.session_id, status="ended")
        except Exception as exc:  # noqa: BLE001 — bookkeeping never blocks leave
            logger.warning(
                "voice.session.end_failed",
                extra=log_extra(session_id=self.session_id, error=str(exc)[:160]),
            )
        else:
            self._model.status = "ended"
        logger.info(
            "voice.session_left",
            extra=log_extra(session_id=self.session_id, group_id=self.group_id),
        )

    async def touch(self) -> None:
        """Stamp ``last_heartbeat`` (never raises)."""
        try:
            await self._repo.touch_heartbeat(self.session_id)
        except Exception as exc:  # noqa: BLE001 — heartbeat must not crash playback
            logger.warning(
                "voice.session.touch_failed",
                extra=log_extra(session_id=self.session_id, error=str(exc)[:160]),
            )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    def _require_transport(self) -> VoiceTransport:
        """Return the account transport or raise a typed error."""
        transport = self._account.transport
        if transport is None:
            raise VoiceError("Voice account has no active transport")
        return transport

    async def _probe_duration(self, path: Path) -> int:
        """Best-effort duration lookup via the injected probe."""
        if self._duration_probe is None:
            return 0
        try:
            return int(await self._duration_probe(path) or 0)
        except Exception as exc:  # noqa: BLE001 — timer-less playback is degraded, not broken
            logger.warning(
                "voice.session.duration_probe_failed",
                extra=log_extra(session_id=self.session_id, error=str(exc)[:160]),
            )
            return 0

    async def _record_event(self, event: str, details: dict | None = None) -> None:
        """Append an audit event; failures are logged, never raised."""
        try:
            await self._repo.add_event(self.session_id, event, details)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "voice.session.event_failed",
                extra=log_extra(session_id=self.session_id, event=event, error=str(exc)[:160]),
            )

    async def _update(self, **fields: object) -> None:
        """Persist whitelisted session fields; failures are logged only."""
        try:
            await self._repo.update_session(self.session_id, **fields)  # type: ignore[arg-type]
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "voice.session.update_failed",
                extra=log_extra(session_id=self.session_id, error=str(exc)[:160]),
            )
        else:
            for key, value in fields.items():
                setattr(self._model, key, value)

    # -- duration timer ---------------------------------------------------
    def _start_timer(self, duration_seconds: float) -> None:
        """Arm the track-end timer for a freshly started track."""
        self._cancel_timer()
        self._track_duration = max(0.0, duration_seconds)
        self._elapsed = 0.0
        if self._track_duration <= 0:
            return
        self._play_started_at = monotonic()
        self._timer = asyncio.create_task(self._fire_track_end(self._track_duration))

    def _freeze_timer(self) -> None:
        """Stop counting playback time (pause/stop)."""
        if self._play_started_at is not None:
            self._elapsed += monotonic() - self._play_started_at
            self._play_started_at = None
        self._cancel_timer()

    def _resume_timer(self) -> None:
        """Continue the timer with the remaining play time."""
        if self._track_duration <= 0 or self._play_started_at is not None:
            return
        remaining = max(1.0, self._track_duration - self._elapsed)
        self._play_started_at = monotonic()
        self._timer = asyncio.create_task(self._fire_track_end(remaining))

    def _cancel_timer(self) -> None:
        if self._timer is not None and not self._timer.done():
            self._timer.cancel()
        self._timer = None

    async def _fire_track_end(self, delay: float) -> None:
        """Sleep out the track, then publish the queue-advance event."""
        try:
            await asyncio.sleep(delay)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 — sleep does not raise otherwise
            return
        logger.info(
            "voice.session.track_end",
            extra=log_extra(session_id=self.session_id, group_id=self.group_id),
        )
        try:
            await self._events.publish(f"track_end:group:{self.group_id}")
        except Exception as exc:  # noqa: BLE001 — never crash the timer task
            logger.error(
                "voice.session.track_end_publish_failed",
                extra=log_extra(session_id=self.session_id, error=str(exc)[:160]),
            )

    # -- heartbeat ---------------------------------------------------------
    def _start_heartbeat(self) -> None:
        """Start the periodic ``last_heartbeat`` writer (once per runtime)."""
        if self._heartbeat is not None or not self._heartbeat_interval:
            return
        self._heartbeat = asyncio.create_task(self._heartbeat_loop())

    def _cancel_heartbeat(self) -> None:
        if self._heartbeat is not None and not self._heartbeat.done():
            self._heartbeat.cancel()
        self._heartbeat = None

    async def _heartbeat_loop(self) -> None:
        """Touch the session row at a fixed cadence until cancelled."""
        assert self._heartbeat_interval is not None
        try:
            while True:
                await asyncio.sleep(self._heartbeat_interval)
                await self.touch()
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 — heartbeat must never crash playback
            logger.warning(
                "voice.session.heartbeat_loop_failed",
                extra=log_extra(session_id=self.session_id, error=str(exc)[:160]),
            )


__all__ = ["VoiceSessionRuntime"]

"""Voice account health monitoring.

Each check probes connectivity, measures latency, decides a status
(``healthy`` / ``degraded`` / ``offline`` / ``disabled``), persists a
:class:`~app.database.models.voice.VoiceAccountHealth` row and transitions the
account status. Persistence failures are logged, never raised — monitoring
must not take the engine down.
"""

from __future__ import annotations

from time import monotonic
from typing import TYPE_CHECKING

from app.config import Settings
from app.logging import get_logger, log_extra

if TYPE_CHECKING:
    from app.database.repositories.voice import VoiceRepository
    from app.voice.account import VoiceAccountClient

logger = get_logger(__name__)

#: Connected but slower than this (ms) → 'degraded'.
_DEGRADED_LATENCY_MS = 2000


class HealthMonitor:
    """Periodic health prober for the voice account pool."""

    def __init__(self, settings: Settings, repo: VoiceRepository) -> None:
        self._settings = settings
        self._repo = repo

    async def check_account(self, account: VoiceAccountClient) -> str:
        """Check one account and persist the result; returns the status str."""
        account_id = int(account.model.id)
        if not self._settings.voice_enabled:
            status, latency_ms = "disabled", None
        else:
            try:
                started = monotonic()
                connected = bool(account.is_connected)
                latency_ms = int((monotonic() - started) * 1000)
                if connected and latency_ms < _DEGRADED_LATENCY_MS:
                    status = "healthy"
                elif connected:
                    status = "degraded"
                else:
                    status = "offline"
            except Exception as exc:  # noqa: BLE001 — a broken probe is 'offline'
                status, latency_ms = "offline", None
                logger.warning(
                    "voice.health.probe_failed",
                    extra=log_extra(account_id=account_id, error=str(exc)[:160]),
                )

        try:
            await self._repo.record_health(account_id, status, latency_ms, error=None)
            await self._repo.set_status(account_id, status)
        except Exception as exc:  # noqa: BLE001 — persistence must not break checks
            logger.warning(
                "voice.health.persist_failed",
                extra=log_extra(account_id=account_id, error=str(exc)[:160]),
            )
        logger.info(
            "voice.health.checked",
            extra=log_extra(account_id=account_id, status=status, latency_ms=latency_ms),
        )
        return status

    async def run_checks(self, accounts: list[VoiceAccountClient]) -> dict[int, str]:
        """Check every account; returns ``{account_id: status}``."""
        results: dict[int, str] = {}
        for account in accounts:
            results[int(account.model.id)] = await self.check_account(account)
        return results


__all__ = ["HealthMonitor"]

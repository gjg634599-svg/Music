# CONTRACTS.md — Module Interfaces (binding for all contributors)

This document is the **single source of truth** for module paths, class names and
public method signatures. Every module MUST match these signatures exactly.
Foundation files (config, logging, errors, utils, security, cache, storage,
events, database models/engine/defaults) already exist and must not be edited
except where explicitly listed.

## 0. Global conventions

- Python 3.12+, `from __future__ import annotations` at top of every module.
- Every module starts with a docstring. Type hints everywhere. Google-style.
- Async everywhere; NO blocking calls (use `asyncio.create_subprocess_exec`
  for ffmpeg, `aiohttp` for HTTP).
- Logging: `from app.logging import get_logger, log_extra` →
  `logger.info("module.event", extra=log_extra(key=value))`.
- Errors: raise subclasses of `app.errors` (read that file). Never show
  stack traces to users. `BotError.user_message` is the user text.
- DB access ONLY via repositories (`app/database/repositories/*.py`).
  Repos take an `async_sessionmaker[AsyncSession]` in `__init__` and open a
  session per method via `async with self.sessions() as s:` (commit inside).
  Pattern for a repo session helper:
  ```python
  from collections.abc import AsyncIterator
  from contextlib import asynccontextmanager
  from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

  class BaseRepository:
      def __init__(self, sessions: async_sessionmaker[AsyncSession]) -> None:
          self.sessions = sessions

      @asynccontextmanager
      async def _session(self) -> AsyncIterator[AsyncSession]:
          async with self.sessions() as s:
              try:
                  yield s
                  await s.commit()
              except Exception:
                  await s.rollback()
                  raise
  ```
  (Put `BaseRepository` in `app/database/repositories/base.py`.)
- Services are plain classes receiving dependencies via `__init__` (DI).
- ORM models: import from `app.database.models` (all 33 tables exist:
  User, UserPreferences, LikedTrack, ListeningHistory, SearchHistory,
  Artist, Album, Genre, Track, TrackSource, Playlist, PlaylistTrack,
  QueueItem, PlaybackSession, Group, GroupMember, GroupSettings,
  Admin, AdminAuditLog, BotSetting, BotMessage, BotAsset, BotButton,
  Broadcast, BroadcastTarget, BroadcastDelivery,
  VoiceAccount, VoiceAccountHealth, VoiceSession, VoiceSessionEvent,
  VoiceAccountAssignment, AnalyticsEvent, RecommendationEvent).
- Helpers you can import: `app.utils` (see `app/utils/__init__.py`),
  `app.storage.StorageService`, `app.cache.redis` (CacheProtocol, RateLimiter,
  LockManager), `app.playback.events.EventBus`,
  `app.security.validation` (validate_url, validate_callback_data,
  validate_audio_upload, sanitize_filename, is_direct_audio_url),
  `app.security.encryption` (SessionCipher), `app.config.Settings`,
  `app.database.defaults` (DEFAULT_MESSAGES/SETTINGS/BUTTONS).
- Telegram bot layer uses **aiogram 3.x**: `Router`, `F` filters,
  `Command` from `aiogram.filters`, `FSMContext` from `aiogram.fsm.context`.
- Never hardcode secrets/tokens. Never log session strings.

## 1. Dataclasses (app/music/models.py — Task 2-a)

```python
@dataclass(slots=True)
class TrackResult:
    title: str
    artist: str | None
    album: str | None
    duration_seconds: int
    source: str          # 'local' | 'jamendo' | 'audius' | 'upload' | 'url'
    source_id: str
    stream_url: str | None = None
    artwork_url: str | None = None
    genre: str | None = None
    language: str | None = None
    mood: str | None = None
    tempo: int | None = None
    popularity: int = 0
    isrc: str | None = None
    extra: dict = field(default_factory=dict)

@dataclass(slots=True)
class StreamInfo:
    url_or_path: str     # http(s) URL or local path
    is_local: bool
    expires_at: float | None = None

@dataclass(slots=True)
class AudioMetadata:
    title: str | None = None
    artist: str | None = None
    album: str | None = None
    duration_seconds: int = 0
    genre: str | None = None
    language: str | None = None
    tempo: int | None = None
```

## 2. Music platform (Task 2-a)

`app/music/sources/base.py`:
```python
class MusicSource(ABC):
    name: str
    def __init__(self, settings: Settings, http: aiohttp.ClientSession) -> None: ...
    def is_configured(self) -> bool: ...
    @abstractmethod async def search(self, query: str, limit: int = 10) -> list[TrackResult]: ...
    @abstractmethod async def get_track(self, source_id: str) -> TrackResult | None: ...
    async def resolve_url(self, url: str) -> TrackResult | None:  # default: None
    async def get_stream(self, source_id: str) -> StreamInfo | None: ...
```
`app/music/sources/__init__.py`: `def build_sources(settings, http) -> list[MusicSource]`
(implements LocalSource, JamendoSource (api.jamendo.com v3.0, param client_id,
graceful when unconfigured), AudiusSource (audius.co API discovery + /v1/tracks/search + /v1/tracks/{id}/stream)).

`app/music/normalizer.py`:
`normalize_text(s: str) -> str`, `normalized_key(title, artist) -> str`,
`clean_title(title) -> str`.

`app/music/search.py` — `class SearchAggregator` (multi-source fan-out, dedupe by
normalized key, cache via CacheProtocol with ttl 300):
`async def search(self, query: str, limit: int = 10) -> list[TrackResult]`.

`app/music/metadata.py` — `class MetadataService`: wraps audio probing
(accepts an injected `probe` callable for testability):
`async def extract(self, file_path: str | Path) -> AudioMetadata`.

`app/music/resolver.py` — `class TrackResolver` (deps: TrackRepository,
ArtistRepository, AlbumRepository, GenreRepository):
`async def resolve(self, result: TrackResult) -> Track` — upserts artist/album/genres/track,
dedupes by (source, source_id).

`app/music/service.py` — `class MusicService` (facade; deps: sources list,
SearchAggregator, TrackResolver, TrackRepository, MetadataService, StorageService,
CacheProtocol, EventBus, AnalyticsRepository):
```python
async def search(self, query: str, limit: int = 10) -> list[Track]        # search + resolve to DB
async def get_track(self, track_id: int) -> Track | None
async def resolve_url(self, url: str) -> Track                             # raises UnsupportedUrlError
async def register_upload(self, tg_user_id: int, file_path: str, file_name: str, meta: AudioMetadata) -> Track
async def get_playable_path(self, track: Track) -> Path                    # local path (download if needed) — raises DownloadError
async def ensure_audio_file_id(self, track: Track, bot) -> str | None      # cache tg file_id
async def find_similar(self, track: Track, limit: int = 20) -> list[Track] # same artist/genre candidates
```

`app/database/repositories/music.py`: `class TrackRepository`, `class
ArtistRepository`, `class AlbumRepository`, `class GenreRepository` (each extends
BaseRepository; provide get_by_id, upsert_from_result-style helpers,
search_catalog(query, limit) with LIKE on title/artist name, random(limit),
increment_play_count(track_id), update methods for file_path/audio_file_id).

## 3. Playback + recommendation (Task 2-b)

`app/playback/queue.py`:
```python
@dataclass(frozen=True, slots=True)
class QueueOwner:
    kind: str   # 'user' | 'group'
    id: int     # telegram id
    def topic(self) -> str: ...  # f"{self.kind}:{self.id}"

class QueueManager:  # deps: QueueRepository, TrackRepository, EventBus
    async def add(self, owner: QueueOwner, track_id: int, added_by: int | None = None, *, front: bool = False) -> int
    async def get_queue(self, owner: QueueOwner) -> list[QueueItem]
    async def pop_next(self, owner: QueueOwner) -> QueueItem | None
    async def peek_next(self, owner: QueueOwner) -> QueueItem | None
    async def clear(self, owner: QueueOwner) -> int
    async def shuffle(self, owner: QueueOwner) -> int      # returns new size
    async def remove(self, owner: QueueOwner, item_id: int) -> bool
    async def size(self, owner: QueueOwner) -> int
```

`app/playback/controller.py` — `class PlaybackController` (deps: QueueManager,
AutoplayService, MusicService, VoiceManager (protocol), SessionManager,
EventBus, AnalyticsRepository, HistoryService (protocol), SettingsService
(protocol), Bot provider injected per-call):
```python
async def play_now(self, owner: QueueOwner, chat_id: int, bot, track_id: int, user_tg_id: int, *, edit_message=None) -> None
async def next(self, owner: QueueOwner, chat_id: int, bot, *, manual: bool = True, skip: bool = False) -> None
async def pause(self, owner: QueueOwner, bot) -> None
async def resume(self, owner: QueueOwner, chat_id: int, bot) -> None
async def stop(self, owner: QueueOwner, bot) -> None
async def enqueue(self, owner: QueueOwner, chat_id: int, bot, track_id: int, user_tg_id: int, *, edit_message=None) -> int  # returns queue size; starts playback if idle (edit_message → Now Playing control)
```
Personal mode: sends the audio file + edits/sends a Now Playing control
message, runs a duration timer that publishes `track_end`. Group mode: plays
through VoiceManager.play(); relies on its track_end events. When
`edit_message` is supplied (a transient group status message such as
"⬇️ Loading track…"), it is edited into the Now Playing control — or into
the failure text via the error path — so one message carries the whole
request.

`app/playback/session.py` — `class SessionManager` (runtime session state,
persisted via PlaybackSessionRepository; timers per owner):
```python
async def get(self, owner: QueueOwner) -> PlaybackSession   # get_or_create
async def set_now_playing(self, owner, track_id, queue_item_id, message_id, chat_id) -> None
async def update_status(self, owner, status, position_seconds=None) -> None
async def set_repeat(self, owner, mode) / set_shuffle / set_autoplay
async def start_timer(self, owner, duration: int) / cancel_timer(self, owner)
async def message_payload(self, owner) -> dict  # {track, position, status,...}
```

`app/playback/autoplay.py` — `class AutoplayService` (deps:
RecommendationEngine, QueueManager, AnalyticsRepository):
`async def refill(self, owner: QueueOwner, seed_track_id: int | None, count: int = 1) -> int`
(uses engine; logs RecommendationEvent; publishes `autoplay_selected` analytics).

`app/recommendation/scoring.py`:
```python
@dataclass(slots=True)
class RecommendationWeights:
    track_similarity: float = 1.0
    artist_similarity: float = 1.5
    genre_similarity: float = 1.2
    user_preference: float = 2.0
    popularity: float = 0.6
    playlist_context: float = 0.8
    recently_played_penalty: float = 2.5
    skipped_track_penalty: float = 1.8
    same_track_penalty: float = 6.0
    @classmethod def from_dict(cls, data: dict) -> RecommendationWeights

@dataclass(slots=True)
class ScoredTrack: track_id: int; score: float; reason: str

def score_candidates(candidates: list[CandidateTrack], profile: TasteProfile,
                     weights: RecommendationWeights, *, seed: CandidateTrack | None,
                     playlist_context_ids: set[int]) -> list[ScoredTrack]
```
(`CandidateTrack` dataclass in same module: track_id, artist_id, genre_ids,
language, tempo, popularity, normalized_title, artist_normalized.)

`app/recommendation/profile.py` — `class TasteProfile` (dataclass:
liked_track_ids, liked_artist_ids, liked_genre_ids, recent_track_ids,
recent_artist_ids, skipped_track_ids, play_counts, artist_weights) +
`class ProfileBuilder` (deps: ListeningHistoryRepository, LikedTrackRepository):
`async def build_user(self, user_tg_id: int) -> TasteProfile`,
`async def build_group(self, group_tg_id: int) -> TasteProfile` (aggregates
members' history).

`app/recommendation/similarity.py`: `genre_overlap(a: set[int], b: set[int]) -> float`,
`tempo_closeness(a: int | None, b: int | None) -> float`,
`title_token_overlap(a: str, b: str) -> float`.

`app/recommendation/engine.py` — `class RecommendationEngine` (deps:
TrackRepository, ProfileBuilder, SettingsRepository (weights from
bot_setting 'recommendation_weights'), CacheProtocol):
```python
async def recommend_for_user(self, user_tg_id: int, seed_track_id: int | None, limit: int = 1, exclude: set[int] | None = None) -> list[ScoredTrack]
async def recommend_for_group(self, group_tg_id: int, seed_track_id: int | None, limit: int = 1, exclude: set[int] | None = None) -> list[ScoredTrack]
```

`app/database/repositories/playback.py`: `class QueueRepository` (add with
next position, list queued order by position, mark_played, clear, shuffle
randomize positions, remove, size, get_current_item),
`class PlaybackSessionRepository` (get_or_create(owner_kind, owner_id),
update fields, all sessions).

## 4. Voice engine + audio (Task 2-c)

`app/audio/ffmpeg.py` — `class FFmpegToolkit(settings)`: 
`async def probe(self, path) -> dict` (ffprobe -print_format json),
`async def extract_metadata(self, path) -> AudioMetadata`,
`async def to_voice_format(self, src: Path, dst: Path) -> Path` (opus 48k stereo),
`async def to_thumbnail(self, src: Path, dst: Path) -> Path | None`,
`async def synth_demo_track(self, dst: Path, *, freq: int, duration: int, tempo: int) -> Path`
(ffmpeg lavfi sine + tremolo), `async def synth_artwork(self, dst: Path, *, color: str) -> Path`
(lavfi gradients/color). All via `asyncio.create_subprocess_exec`; raise
`app.errors.PlaybackError` on failure.

`app/audio/processor.py` — `class AudioProcessor(settings, ffmpeg: FFmpegToolkit,
storage: StorageService, cache: CacheProtocol)`:
`async def prepare_for_voice(self, track) -> Path` (cached opus conversion),
`async def prepare_for_send(self, track) -> Path` (ensures local playable file),
`async def probe_metadata(self, path) -> AudioMetadata`.

`app/audio/pipeline.py` — `class AudioPipeline` orchestrating download→probe→
convert with cache + events (used by workers for heavy jobs):
`async def process_track(self, track) -> Path` (voice-ready path),
`async def process_upload(self, src_path: Path) -> tuple[Path, AudioMetadata]`.

`app/voice/transport.py`:
```python
class VoiceTransport(Protocol):
    async def join(self, group_tg_id: int) -> None
    async def play(self, group_tg_id: int, path: Path, *args, **kwargs) -> None
    async def pause(self, group_tg_id: int) -> None
    async def resume(self, group_tg_id: int) -> None
    async def set_volume(self, group_tg_id: int, volume: int) -> None
    async def leave(self, group_tg_id: int) -> None
    async def is_connected(self, group_tg_id: int) -> bool
```
`class NativeTransport` — real implementation with GUARDED imports
(`try: from pytgcalls import PyTgCalls ... except ImportError: available=False`);
`__init__(self, client)`. Every method wrapped, raising `VoiceError` with
clear messages (incl. "voice chat not found"). No-op for unavailable.

`app/voice/account.py` — `class VoiceAccountClient` (one userbot account):
`__init__(self, model: VoiceAccount, settings, cipher)`,
`async def connect(self) -> None` (Telethon StringSession, guarded import),
`async def disconnect(self) -> None`, `properties: telegram_id, is_connected`,
`transport() -> NativeTransport | None`, `active_sessions: int` (int field),
`max_sessions`.

`app/voice/session.py` — `class VoiceSessionRuntime` (a live lease:
account + group): heartbeat task writing VoiceSession.last_heartbeat,
`async def start_playback(self, path: Path)`, `pause/resume/stop`, events
written via VoiceRepository.

`app/voice/health.py` — `class HealthMonitor(voice_repo, interval)`:
`async def check_account(self, account: VoiceAccountClient) -> str` (status str
healthy/degraded/offline/auth_required, persists VoiceAccountHealth rows),
`async def run_checks(self, accounts: list[VoiceAccountClient]) -> dict[int, str]`.

`app/voice/assignment.py` — `class AssignmentStrategy`:
`select(self, accounts: list[VoiceAccountClient]) -> VoiceAccountClient | None`
(healthy first, least active sessions, respects max_sessions/priority).

`app/voice/failover.py` — `class FailoverController` (deps: VoiceManager (via
late binding), VoiceRepository, EventBus):
`async def handle_failure(self, group_tg_id: int) -> None` — uses LockManager
idempotency, marks account degraded, publishes `voice_failure:<group_id>`.

`app/voice/manager.py` — `class VoiceManager` (the facade; deps: VoiceRepository,
settings, cipher, cache/LockManager, EventBus, HealthMonitor):
```python
async def start(self) -> None            # load + connect accounts (skip when voice disabled)
async def shutdown(self) -> None
async def acquire(self, group_tg_id: int) -> VoiceSessionRuntime | None  # None ⇒ VoiceAccountOfflineError later
async def release(self, group_tg_id: int) -> None
async def play(self, group_tg_id: int, path: Path) -> None     # joins if needed
async def pause(self, group_tg_id: int) / resume / stop / set_volume
async def status(self) -> VoiceEngineStatus    # dataclass: accounts summary, active sessions
async def list_active_sessions(self) -> list[VoiceSession]
async def is_voice_enabled(self) -> bool
```
On playback end, runtime publishes `track_end:group:<id>` via a duration timer.

`app/database/repositories/voice.py`: `class VoiceRepository` (accounts CRUD,
health records, sessions get/create/update, events, assignments, active counts).

`scripts/add_voice_account.py` — CLI: `python scripts/add_voice_account.py --label "Account 1" --phone +98...`
Interactive Telethon login on the SERVER (never via bot chat), encrypts session
with Fernet (env key), upserts VoiceAccount row. Uses argparse; connects to DB
via app.database.engine; documents usage in --help.

## 5. Broadcast + workers (Task 2-d)

`app/broadcast/composer.py`:
```python
@dataclass(slots=True)
class BroadcastDraft:
    content_type: str                  # text|photo|video|audio|document|animation|voice|album|copy
    text: str | None = None
    caption: str | None = None
    media: list[dict] | None = None    # [{type, file_id}]
    copy_source: dict | None = None    # {chat_id, message_ids:[...]}
    buttons: list[dict] | None = None  # [{label, url}]
    parse_mode: str = "HTML"

def from_text(text: str, buttons: list[dict] | None = None) -> BroadcastDraft
def from_media_message(message) -> BroadcastDraft          # aiogram Message → draft (file_id based)
def from_copy_message(message) -> BroadcastDraft
def from_media_group(messages: list) -> BroadcastDraft
def validate_buttons(buttons: list[dict] | None) -> None   # raises ValidationError (bad URL schemes)
```

`app/broadcast/targets.py` — `class TargetSelector(UserRepository,
GroupRepository)`:
`async def build(self, target_type: str, filter_data: dict | None) -> list[tuple[str, int]]`
(chat_type, chat_id) pairs; supports:
all_users, active_users, inactive_users, users_by_language, users_with_groups,
specific_users, all_groups, active_groups, specific_groups.
(Active = seen within 30 days, `User.last_seen_at`.)

`app/broadcast/rate_limit.py` — `class TelegramRateLimiter`:
`async def wait(self) -> None` (token bucket ≤ rate_per_second, default 25),
`async def backoff(self, attempt: int) -> None` (exponential, cap 60s),
`def classify(exc) -> tuple[str, int | None]` — ('flood', seconds) /
('retry', None) / ('permanent', None).

`app/broadcast/worker.py` — `class BroadcastWorker(bot, BroadcastRepository,
TargetSelector-less (targets prebuilt), limiter, settings, EventBus)`:
```python
async def run_once(self, broadcast_id: int) -> bool   # process a broadcast to completion; resume-aware
async def process_all(self) -> None                   # loop: pending/paused→resume broadcasts
async def cancel(self, broadcast_id: int) -> None
async def pause(self, broadcast_id: int) -> None
async def retry_failed(self, broadcast_id: int) -> None
```
Delivery per target: text → send_message; photo/video/audio/document/animation/
voice → send_* with file_id + caption; album → send_media_group; copy →
bot.copy_message(chat_id, src_chat, src_msg, reply_markup=kb). InlineKeyboard
from buttons (url type only + optional callback 'dismiss'). Retries on
flood/retry (≤ max_retries); permanent failures recorded. Updates Broadcast
counters + BroadcastTarget/BroadcastDelivery rows + `broadcast_update` events.

`app/broadcast/service.py` — `class BroadcastService(BroadcastRepository,
TargetSelector, worker provider)`: create_draft/preview/start/pause/stop/
retry_failed/history(limit)/stats()/active().

`app/database/repositories/broadcast.py`: `class BroadcastRepository` (create
with targets, get, list_history, counters update, target rows update,
delivery insert, active/pending lists, pause/stop status transitions, retry
failed reset).

`app/workers/jobs.py`: `@dataclass Job: id: str; type: str; payload: dict;
attempts: int = 0`. `JobType` enum: AUDIO_PROCESS, METADATA, SEND_AUDIO,
CLEANUP, BROADCAST, HEALTH_CHECK.

`app/workers/tasks.py` — registry `TASKS: dict[str, Callable[[dict], Awaitable[None]]]`
wired at runtime via `register_task(name)` decorator + `def bind(services) -> None`
(no imports of handlers; services container passed in).

`app/workers/manager.py` — `class WorkerManager(cache, LockManager)`:
async job queue on Redis list `jobs:queue` with in-memory `asyncio.Queue`
fallback; `async def enqueue(self, job: Job) -> None`,
`async def run(self, concurrency: int = 2) -> None` (worker pool loop),
`async def stop(self) -> None` (graceful drain),
`def register(self, job_type: str, handler) -> None`.

## 6. Users + groups (Task 2-e)

`app/users/service.py` — `class UserService(UserRepository, GroupMemberRepository)`:
`async def get_or_create(self, message_from) -> User` (updates username/
last_seen, ensures preferences row), `async def get(self, tg_id) -> User | None`,
`async def account_summary(self, tg_id) -> dict` (plays, likes, playlists,
groups count), `async def my_groups(self, tg_id) -> list[dict]` (groups with
bot status), `async def set_blocked(self, tg_id, blocked: bool)`.

`app/users/library.py` — `class LibraryService(LikedTrackRepository,
TrackRepository)`: `async def toggle_like(self, user_db_id, track_id) -> bool`
(True=liked), `async def is_liked(self, user_db_id, track_id) -> bool`,
`async def liked_tracks(self, user_db_id, limit=50) -> list[Track]`,
`async def recent_tracks(self, user_db_id, limit=10) -> list[Track]`.

`app/users/history.py` — `class HistoryService(ListeningHistoryRepository,
UserRepository)`: `async def record(self, user_tg_id, track_id, *, context,
group_id=None, completed=False, skipped=False, duration_played=0)`,
`async def history(self, user_db_id, limit=20) -> list[ListeningHistory]`,
`async def search_history(self, user_db_id, limit=10)`,
`async def record_search(self, user_tg_id, query, results_count)` (also writes SearchHistory).

`app/users/playlists.py` — `class PlaylistService(PlaylistRepository)`:
create/list/get/rename/delete, add_track (dedupe), remove_track, tracks(playlist_id),
`async def my_playlists(self, user_db_id) -> list[Playlist]`,
`async def queue_playlist(self, owner: QueueOwner, playlist_id, queue: QueueManager) -> int`.

`app/groups/service.py` — `class GroupService(GroupRepository)`:
`async def get_or_create(self, chat) -> Group` (+ default settings),
`async def sync_member(self, group_db_id, user_db_id, tg_user_id, *, is_admin=False, is_dj=False)`,
`async def status_summary(self, group_tg_id) -> dict` (bot active, vc active,
current track, queue size, autoplay — via repo joins).

`app/groups/settings.py` — `class GroupSettingsService(GroupSettingsRepository)`:
`async def get(self, group_tg_id) -> GroupSettings`,
`async def update(self, group_tg_id, **fields) -> GroupSettings` (whitelist:
permission_mode, silent_mode, mention_mode, autoplay_enabled, queue_limit,
idle_timeout_minutes, volume).

`app/groups/permissions.py` — `class GroupPermissions(GroupSettingsRepository,
GroupMemberRepository)`:
```python
async def can(self, group_tg_id: int, user_tg_id: int, action: str,
              *, is_chat_admin: bool = False) -> bool
```
Actions: play, skip, pause, resume, stop, queue, settings, dj_manage.
Modes: everyone ⇒ all can; admins ⇒ only chat admins; dj ⇒ admins + is_dj.
`async def set_dj(self, group_tg_id, user_tg_id, value: bool)`,
`async def list_members(self, group_tg_id) -> list[GroupMember]`.

`app/groups/silent_mode.py`:
```python
def should_process_group_message(message) -> bool
```
Pure logic: True only when message has a BOT_COMMAND entity (any) — used by
middleware; also `def is_callback(callback) -> bool` trivial helper. NO I/O.

`app/database/repositories/users.py`: `UserRepository` (get_or_create by
telegram_id incl. preferences; update_username/last_seen; counts: total/active/
blocked; by_language; with_groups; specific ids; set_blocked),
`UserPreferenceRepository`, `SearchHistoryRepository`.
`app/database/repositories/library.py`: `LikedTrackRepository` (toggle, is_liked,
list), `ListeningHistoryRepository` (record, list, recent track ids w/ counts,
skipped track ids, group aggregation).
`app/database/repositories/playlists.py`: `PlaylistRepository` (CRUD, tracks,
add/remove, reorder, count).
`app/database/repositories/groups.py`: `GroupRepository`, `GroupMemberRepository`,
`GroupSettingsRepository`.
`app/database/repositories/analytics.py`: `class AnalyticsRepository`:
`async def track(self, event_type, user_id=None, group_id=None, track_id=None, payload=None)`,
`async def counts_by_type(self, hours=24) -> dict`,
`async def top_tracks(self, limit=10, days=30) -> list`,
`async def daily_plays(self, days=14) -> dict`.

## 7. Admin services (Task 2-f)

`app/admin/permissions.py`:
```python
class Role(str, Enum): SUPER_ADMIN="super_admin"; ADMIN="admin"; MODERATOR="moderator"
PERMISSIONS: dict[Role, set[str]]  # e.g. admin: {users, groups, broadcast, appearance, buttons, voice, settings, stats}, moderator: {users, groups, stats}, super_admin: all + roles
class PermissionService(AdminRepository, admin_ids: tuple[int, ...]):
    async def role_of(self, tg_id) -> Role | None
    async def has(self, tg_id, permission: str) -> bool
    async def is_admin(self, tg_id) -> bool
    async def add_admin(self, tg_id, role: Role, added_by) / remove_admin
    async def list_admins(self) -> list[Admin]
```

`app/admin/appearance.py` — `class AppearanceService(BotMessageRepository,
BotAssetRepository)`:
`async def message(self, key, **placeholders) -> str`,
`async def set_message(self, key, text, updated_by)`,
`async def reset_message(self, key)`,
`async def set_logo(self, file_id, file_unique_id, updated_by)`,
`async def logo(self) -> BotAsset | None`, `async def remove_logo()`,
`async def preview_start(self) -> tuple[str, list[BotButton]]`.

`app/admin/buttons.py` — `class ButtonService(BotButtonRepository)`:
`async def list_buttons(self, enabled_only=False) -> list[BotButton]`,
`async def create(self, label, action, button_type, url=None, position=None) -> BotButton`,
`async def update(self, button_id, **fields)`,
`async def delete(self, button_id)`, `async def move(self, button_id, direction: int)`,
`async def toggle(self, button_id, enabled: bool)`,
`async def render_keyboard(self) -> InlineKeyboardMarkup` (rows of 2; add_group
type → url button https://t.me/<bot_username>?startgroup=true — username
injected at render time via `bot_username` param),
`async def ensure_defaults(self) -> None` (seed DEFAULT_BUTTONS once).

`app/admin/settings.py` — `class SettingsService(BotSettingsRepository)`:
`async def get(self, key, default=None)`, `async def set(self, key, value, updated_by)`,
`async def recommendation_weights() -> RecommendationWeights`,
`async def autoplay_enabled() -> bool`, `async def maintenance() -> dict`,
`async def set_maintenance(self, enabled, groups_continue, updated_by)`,
`async def feature_flags() -> dict`, `async def ensure_defaults()`.

`app/admin/statistics.py` — `class StatisticsService(UserRepository,
GroupRepository, TrackRepository, AnalyticsRepository, BroadcastRepository,
VoiceRepository, cache)`:
`async def overview(self) -> dict` (users total/new 7d, groups, tracks, plays
24h, likes, autoplay selections), `async def system_health(db, cache,
workers_ok: bool, voice_status) -> dict`.

`app/admin/audit.py` — `class AuditService(AdminAuditLogRepository)`:
`async def log(self, admin_tg_id, action, target_type=None, target_id=None,
details=None, result="ok")`, `async def recent(self, limit=20)`.

`app/admin/service.py` — `class AdminService` facade aggregating the above
(PermissionService, AppearanceService, ButtonService, SettingsService,
StatisticsService, AuditService) + expose them as attributes.

`app/database/repositories/settings.py`: `BotSettingsRepository` (get/set/
ensure_defaults from DEFAULT_SETTINGS), `BotMessageRepository` (get/set/reset/
ensure_defaults from DEFAULT_MESSAGES), `BotAssetRepository` (latest(kind),
save, delete), `BotButtonRepository` (list ordered, create/update/delete/
move/toggle, ensure_defaults).
`app/database/repositories/admin.py`: `AdminRepository`, `AdminAuditLogRepository`.

## 8. Bot layer (Tasks 3-a/3-b/3-c)

Everything imports services from a single container:
`app/bot/services.py`:
```python
@dataclass
class ServiceContainer:
    settings: Settings
    cache: CacheProtocol
    limiter: RateLimiter
    locks: LockManager
    storage: StorageService
    events: EventBus
    db: Database
    users: UserService
    library: LibraryService
    history: HistoryService
    playlists: PlaylistService
    groups: GroupService
    group_settings: GroupSettingsService
    permissions: GroupPermissions
    music: MusicService
    audio: AudioProcessor
    queue: QueueManager
    sessions: SessionManager
    autoplay: AutoplayService
    recommendations: RecommendationEngine
    playback: PlaybackController
    voice: VoiceManager
    broadcast: BroadcastService
    admin: AdminService
    analytics: AnalyticsRepository
    workers: WorkerManager
```
Handlers signature: `async def handler(message: Message, services: ServiceContainer) -> None`
(aiogram injects `services` because dispatcher["services"] = container).

**Callback data registry (≤64 bytes)** — use exactly these:
```
nav:cancel  nav:home
dash:<action>            # search|library|playlists|history|settings|account|help|commands|group
sch:pg:<page>            # search results pagination
trk:<track_id>           # track page
trk:play:<id>  trk:dl:<id>  trk:like:<id>  trk:pl:<id>  trk:share:<id>  trk:back:<page>
pl:<id>  pl:new  pl:play:<id>  pl:shuf:<id>  pl:add:<id>  pl:ren:<id>  pl:del:<id>  pl:trk:<playlist_id>:<track_id>  pl:page:<id>:<page>
lib:liked  lib:liked:<page>  lib:recent  lib:home  lib:new  lib:new:<page>
q:home  q:clear  q:shuf  q:skip  q:rm:<item_id>  q:page:<page>
np:pause  np:resume  np:next  np:prev  np:shuf  np:rep  np:like  np:queue  np:close
set:autoplay  set:shuffle  set:repeat  set:lang
grp:home  grp:queue  grp:np  grp:settings  grp:set:<key>:<value>  grp:pmode:<mode>  grp:dj:<user_id>
grp:new  grp:new:<page>  grp:newq:<track_id>   # group /new browse + one-tap queue
grp:pause  grp:resume  grp:skip  grp:stop      # group transport (permission "play"/"stop")
grp:shuf  grp:rep  grp:vol:dn|up  grp:auto     # stateful toggles (play-permission; labels show state)
dm:grp:<track_id>:<gid>  dm:link:<track_id>  dm:back:<track_id>  dm:cancel  dm:close
dmc:<gid>:<action>   # DM controls for a group session (pause|resume|next|stop|queue|close)
acct:home  acct:groups  acct:group:<group_id>
adm:home  adm:me  adm:users  adm:users:<page>  adm:user:<tg_id>  adm:groups  adm:groups:<page>  adm:group:<id>
adm:app  adm:app:logo  adm:app:logo:del  adm:app:msg:<key>  adm:app:msg:<key>:edit  adm:app:msg:<key>:reset
adm:btn  adm:btn:add  adm:btn:new:<type>  adm:btn:<id>:edit  adm:btn:<id>:del  adm:btn:<id>:up  adm:btn:<id>:down  adm:btn:<id>:toggle
adm:bc  adm:bc:new  adm:bc:type:<type>  adm:bc:target:<target>  adm:bc:btn  adm:bc:send  adm:bc:hist  adm:bc:hist:<page>  adm:bc:<id>:pause  adm:bc:<id>:stop  adm:bc:<id>:retry  adm:bc:<id>:refresh  adm:bc:cancel
adm:vc  adm:vc:acc  adm:vc:acc:<id>  adm:vc:acc:<id>:toggle  adm:vc:acc:<id>:reconnect  adm:vc:acc:<id>:del  adm:vc:acc:<id>:del:yes  adm:vc:ses  adm:vc:ses:<id>:skip  adm:vc:ses:<id>:pause  adm:vc:ses:<id>:stop  adm:vc:ses:<id>:reassign  adm:vc:add
adm:stats  adm:sys  adm:set  adm:set:<key>:<value>
grp add (private): add:group
```
**FSM states (aiogram)**: `SearchFSM:query`, `PlaylistFSM:title|rename`,
`AdminFSM:edit_message|logo|btn_label|btn_url|bc_text|bc_caption|bc_btn_label|bc_btn_url|specific_ids`.
FSM storage configured in application (NOT in handlers).

**Handlers must**:
- Keep messages short (UX principle); always HTML-escape user content.
- Use `safe_edit`/`edit_or_send` from `app.utils.telegram` to EDIT existing
  messages for navigation instead of sending new ones.
- Answer callbacks with `safe_answer`.
- In groups: respond concisely, edit the existing Now Playing message where
  possible (one message per group, stored in PlaybackSession.now_playing_message_id).

**Silent group mode (binding)**: `app/bot/middleware/group_silent.py` —
outer middleware on message: if chat is group/supergroup and message has no
BOT_COMMAND entity → drop. Service messages (new_chat_members etc.) also
dropped (they never have commands). Callback queries always pass. Bot must
NEVER send unsolicited group messages: no welcome on join (handler for
`my_chat_member`/`new_chat_members` must exist only to update DB silently).

**AIOPROMPT commands registration** (in `app/bot/commands.py`, Task 3-a):
`def build_command_scopes() -> list[tuple[BotCommandScopeDefault|..., list[BotCommand]]]`
private: start, search, playlists, liked, history, settings, commands, group, help, admin(admins only handled separately)
group: play, search, queue, nowplaying, skip, pause, resume, stop, shuffle, repeat, volume, settings, help.

`app/bot/middleware/` modules: `GroupSilentMiddleware`, `RateLimitMiddleware`
(uses services.limiter; limits from settings.rate_limits; keys `search:`,
`heavy:`, `cmd:`; raises → answers with RateLimitedError.user_message),
`LoggingMiddleware` (update latency, errors), `AuthMiddleware` (callback-level
admin guard for `adm:` prefix + maintenance check + blocked users).

Each handler module exposes `router = Router(name="<module>")` and a
`def register(parent: Router) -> None: parent.include_router(router)` pattern.

## 9. What each Task owns (do NOT create/edit files outside your list)

- **2-a music**: app/music/**, app/database/repositories/music.py
- **2-b playback+reco**: app/playback/{queue,session,controller,autoplay}.py
  (events.py already exists — do not edit), app/recommendation/**,
  app/database/repositories/playback.py, app/database/repositories/base.py
- **2-c voice+audio**: app/audio/**, app/voice/**, app/database/repositories/voice.py,
  scripts/add_voice_account.py
- **2-d broadcast+workers**: app/broadcast/**, app/workers/**,
  app/database/repositories/broadcast.py
- **2-e users+groups**: app/users/**, app/groups/**, app/database/repositories/{users,library,playlists,groups,analytics}.py
- **2-f admin**: app/admin/**, app/database/repositories/{settings,admin}.py
- **3-a bot personal**: app/bot/handlers/{start,help,commands,search,playback,library,playlists,account,uploads,links}.py,
  app/bot/callbacks/{track,queue,library,navigation}.py,
  app/bot/keyboards/{start,track,queue,library,common}.py,
  app/bot/middleware/{group_silent,rate_limit,logging}.py, app/bot/commands.py
- **3-b bot group**: app/bot/handlers/groups.py, app/bot/callbacks/group.py,
  app/bot/keyboards/group.py, app/bot/middleware/auth.py
- **3-c bot admin**: app/bot/handlers/admin/**, app/bot/callbacks/admin.py,
  app/bot/keyboards/admin.py
- **4-a tests+migrations**: migrations/**, tests/**, scripts/seed_catalog.py, pytest.ini
- **4-b docker+docs**: Dockerfile, docker-compose.yml, README.md, .dockerignore, scripts/dev_setup.sh

**Cross-references are resolved via imports; if you must call something not in
this contract, define a local `typing.Protocol` instead of importing it.**

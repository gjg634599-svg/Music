# Telegram Compatibility Audit — telegram-music-bot

Feature-by-feature audit of every command, button, callback, handler,
worker and integration in the project, including dependency and Telegram
API compatibility. Companion to the repair round that produced
`telegram-music-bot-fixed.zip`.

---

## 1. Audit date

2025-10-10 — first repair round (logging, login wizard, search UX,
dependency pins); **2025-10-11 — second repair round** (critical
"Couldn't download this track" root-cause fix: Audius stream resolution +
absolute-path contract; private-group automatic invite-link joining;
admin Group-Access screen); **2025-10-11 — third repair round** (the
confirmed `source='local'` provider-identity corruption: LocalSource
catalog rows now keep their original provider + provider-specific id, the
resolver upserts onto the real row instead of creating dead duplicates,
playback resolves remote streams through the owning provider adapter, and
legacy duplicate rows self-heal; the full DM→group playback workflow with
MTProto link resolution, prerequisite verification and honest
confirmation; group-control-keyboard and trk:-routing wrong-target button
fixes). Baseline archive `telegram-music-bot.zip` was re-audited
end-to-end each round, not just the modified code.

## 2. Python version tested

- **3.12.15** (automated suite — all 770 tests).
- The code itself targets Python 3.12+ and avoids version-fragile stdlib
  internals; the logging fix specifically removed the reference to the
  nonexistent `logging.Mapping` alias, which was the root cause of the
  production `TypeError` spam seen on Python 3.14 deployments.
- **Python 3.14 was not available in the audit environment** — 3.14 runtime
  verification is NOT TESTED.

## 3. Exact dependency versions tested

| Package | Installed / tested | Requirement |
| --- | --- | --- |
| aiogram | 3.31.0 | `>=3.13,<4` |
| Telethon | 1.45.0 | `>=1.36` |
| py-tgcalls | 2.2.11 | `>=2.2,<3` **(changed — see §14)** |
| ntgcalls (backend) | 2.2.5 | via py-tgcalls (`>=2.1,<3`) |
| SQLAlchemy | 2.1.4 | `>=2.0.35` |
| asyncpg | 0.29.0* | `>=0.29` |
| aiosqlite | 0.21.0* | `>=0.20` |
| alembic | 1.20.0 | `>=1.13` |
| redis-py | 8.1.0 | `>=5.0` |
| cryptography | 50.0.2 | `>=42` |
| aiohttp | 3.14.4 | `>=3.9` |
| pytest / pytest-asyncio | 9.1.1 / 1.4.0 | test-only |

\* asyncpg was installed but PostgreSQL itself was not available in the
audit sandbox — the PostgreSQL path was NOT TESTED (SQLite path fully
tested; engine code is shared).

## 4. Official Telegram API documentation references

- Bot API reference used for this audit: <https://core.telegram.org/bots/api>
  (sendMessage / editMessageText / answerCallbackQuery / sendAudio /
  setMyCommands / getMe semantics; 64-byte callback-data limit;
  50 MB bot upload cap; message-length limit 4096).
- Update model, command entities and privacy mode:
  <https://core.telegram.org/bots/features> (bot commands, mentions,
  group privacy).
- Bot login flow and token format: <https://core.telegram.org/bots#botfather>.
- MTProto user-account authorization (login code, two-step verification,
  FloodWait): Telethon documentation
  <https://docs.telethon.dev/en/stable/basic/signing-in.html> and
  <https://docs.telethon.dev/en/stable/concepts/errors.html>.
- my.telegram.org API ID/hash: <https://core.telegram.org/api/obtaining_api_id>.

## 5. Library documentation / source references

- aiogram 3.x docs: <https://docs.aiogram.dev/en/latest/> — middlewares,
  routers, FSM, `Bot.me()` cached alias, `TelegramRetryAfter`, `Command`
  filter mention validation (verified against the installed 3.31.0 source).
- py-tgcalls: <https://pytgcalls.github.io/> — the 2.x API
  (`start`, `play`, `pause`, `resume`, `leave_call`, `change_volume_call`)
  verified against the installed 2.2.11 source (`tests/test_dependency_audit.py`
  asserts the method surface at test time).
- Telethon `TelegramClient.sign_in` / `send_code_request` /
  `SessionPasswordNeededError` / `StringSession` verified against 1.45.0.
- SQLAlchemy 2.x async ORM: <https://docs.sqlalchemy.org/en/20/asyncio.html>.

## 6. Full feature inventory (from source)

| Area | Features found in source |
| --- | --- |
| Personal | /start dashboard (configurable logo/text/buttons), /search, free-text search, URL links, audio uploads, track pages (like/download/share/play), liked library, playlists (create/add/remove/export/import), listening history, search history, /new releases, /mystats, /settings, /group invite, /help, /commands |
| Playback | personal audio send, group queue (add/remove/reorder/paginate), pause/resume/skip/stop/shuffle/repeat/volume, Now Playing, autoplay recommendations, queue persistence, playback sessions |
| Groups | registration on join (silent), group settings, permissions (everyone/admins/DJ), /play /search /new /queue /nowplaying /skip /pause /resume /stop /shuffle /repeat /volume /settings /help, group-isolated queues, strict silence middleware |
| Voice engine | account pool, encrypted sessions, assignment (least-loaded), health checks, failover, idle release, admin wizard + CLI login, session/assignment audit trail |
| Admin | /admin panel, roles (super_admin/admin/moderator), appearance editor (logo/text/buttons), user & group management, voice management, health, statistics, maintenance mode, audit log, broadcast composer (text/media/copy, targets, preview, pause/resume/cancel) |
| Infra | workers (job queue via Redis w/ memory fallback), broadcast worker with rate limiter, health HTTP endpoint, cleanup loop, graceful shutdown, structured logging with redaction |

## 7. Feature-by-feature status

Status labels: **PASS** (verified by automated tests + static trace of the
full interaction path), **BLOCKED** (cannot be verified without external
credentials/infrastructure), **NOT TESTED** (not exercised this round).

### Personal music experience

| Feature | Static | Unit | Integration | Telegram sim. | Live | Status |
| --- | --- | --- | --- | --- | --- | --- |
| /start dashboard + configurable UI | ✔ | ✔ | ✔ (defaults seeded) | ✔ (FakeMessage handlers) | — | **PASS** |
| Search by title/artist (animated) | ✔ | ✔ (24 tests) | ✔ | ✔ | — | **PASS** (mocked providers) |
| Search via URL | ✔ | ✔ (SSRF + redirect suite) | ✔ | ✔ | — | **PASS** |
| Track details / like / download / share | ✔ | ✔ | ✔ | ✔ | — | **PASS** |
| Playlists CRUD + export/import | ✔ | ✔ | ✔ | ✔ | — | **PASS** |
| Library / history / stats | ✔ | ✔ | ✔ | ✔ | — | **PASS** |
| Search animation in **live Telegram** | ✔ | ✔ | ✔ | — | — | **NOT TESTED** (needs live bot) |

### Music sources

| Feature | Status |
| --- | --- |
| Local catalog search | **PASS** |
| Jamendo search | **PASS** (mocked HTTP; live API NOT TESTED — needs JAMENDO_CLIENT_ID) |
| Audius search | **PASS** (mocked HTTP; live API NOT TESTED — network blocked in sandbox) |
| Provider timeouts / partial results / error isolation | **PASS** |
| Track dedupe by (source, source_id) | **PASS** |
| **Audius stream resolution connected to playback** (production "Couldn't download this track" root cause #1) | **PASS** — `get_stream()` now consulted by `MusicService.get_playable_path` (45-download-test suite, incl. full chain search→resolve→download with the real `AudiusSource` class against scripted HTTP); live Audius API NOT TESTED (sandbox network blocked) |
| **Absolute playable path contract** (root cause #2: relative `file_path` was returned) | **PASS** — returns absolute `Path`; regression-tested incl. CWD independence |
| Expired stream URL re-resolution (one retry) | **PASS** (mocked HTTP) |
| Downloaded content validation (audio header sniff, empty/garbage rejection) | **PASS** (17 header-matrix cases + pipeline tests) |
| Concurrent download safety (per-track lock, unique temp + atomic rename) | **PASS** (5-way concurrency test) |
| Temp-file cleanup after failure | **PASS** |

### Playback & voice engine

| Feature | Status |
| --- | --- |
| Queue operations (unit/integration) | **PASS** |
| Autoplay & recommendation engine | **PASS** |
| Voice account login wizard (mocked MTProto) | **PASS** (30 tests) |
| Voice login wizard **live** (real code via Telegram) | **BLOCKED** — requires TELEGRAM_API_ID/HASH, a real user account, and Telegram network access; the service was verified with a duck-typed Telethon client only |
| Voice session join/stream/pause/resume/leave **live** | **BLOCKED** — requires a live group voice chat; transport API surface verified against installed py-tgcalls 2.2.11 (**PASS** static+unit), actual audio streaming NOT TESTED |
| Health checks / failover / idle release (unit) | **PASS** |
| **Private-group membership verification** (supergroup `getParticipant`, basic-chat `getFullChat`, unresolvable-entity fallback) | **PASS** (mocked MTProto; live NOT TESTED) |
| **Automatic invite-link joining** (bot `createChatInviteLink` → Telethon `ImportChatInviteRequest`) | **PASS** (49-test suite with a duck-typed Telethon client covering member fast-path, successful join, already-participant, invalid/expired link + one re-creation, banned, approval-pending, flood wait, cooldowns, link caching, single-flight); round-5 provider regression locks (create-not-export + AST sweep); **live joining NOT TESTED** — requires a real private group, bot admin rights and a real voice account |
| Manager wiring: play() enforces access before streaming, typed `VoiceGroupAccessError` | **PASS** (mocked) |
| Admin “Group Access” check screen | **PASS** (handler smoke tests; live NOT TESTED) |

### Groups

| Feature | Status |
| --- | --- |
| Strict silence (text/media/links/mentions/replies) | **PASS** (middleware-path tests) |
| Commands for other bots dropped | **PASS** |
| Supported group commands reach handlers | **PASS** (router filter tests) |
| Group playback **live** | **BLOCKED** (voice-chat credentials) |

### Admin

| Feature | Status |
| --- | --- |
| Role-based permissions & guards | **PASS** |
| Appearance / buttons / settings editors | **PASS** |
| Voice account management incl. login wizard UI | **PASS** (mocked) |
| Statistics / audit log | **PASS** |
| Broadcast composition & delivery (mocked) | **PASS** |
| Broadcast **live** delivery | **BLOCKED** (needs live bot) |

### Round 3 — source identity, DM→group playback, callback routing

| Feature | Status |
| --- | --- |
| Catalog rows keep original provider identity (`LocalSource._to_result`) | **PASS** — 18-test regression suite incl. the exact production `hindi` chain |
| Resolver upserts onto the real `(source, source_id)` row (no dead `local` duplicates) | **PASS** |
| Remote stream resolution routed by provider, provider-specific id (never the DB PK) | **PASS** — full search→resolver→`get_playable_path` chain |
| Legacy duplicate rows self-heal on playback (both rows get the resolved URL / file path) | **PASS** |
| Local-stream re-check in `get_playable_path` (previously raised after a successful local heal) | **PASS** |
| `new_releases` hides legacy dead duplicates | **PASS** |
| DM destination chooser (known groups + link + personal fallback) | **PASS** (mocked) |
| DM link resolution: public username / t.me link / @name / private invite (`+hash`, `joinchat`, `tg://join`) | **PASS** (mocked MTProto — 52-test suite) |
| Invite preview via `CheckChatInviteRequest`, join via `ImportChatInviteRequest`, re-check after import | **PASS** (mocked; live NOT TESTED) |
| Channel / user links rejected (`not_group`) | **PASS** |
| Expired / invalid / revoked invite → actionable message | **PASS** (mocked errors) |
| Join-request approval groups → `approval_pending` message | **PASS** (mocked) |
| Active-voice-chat prerequisite check (`GetFullChannel`/`GetFullChat` `groupcall`) | **PASS** (mocked; live NOT TESTED) |
| Requesting-user membership + admin detection via MTProto | **PASS** (mocked) |
| Group permission model enforced for DM-initiated playback and `dmc:` controls | **PASS** |
| Playback routed to the target group's queue/session (never the DM chat id) | **PASS** |
| Busy group → honest "Added to the queue, position #N" | **PASS** |
| Playback failure never reported as success | **PASS** |
| Pending-operation TTL (10 min) with recovery screen | **PASS** |
| Duplicate submission / double-click suppression (per-user execution lock) | **PASS** |
| Back / Cancel / X distinct semantics (cancel clears only `dmop_*`, search state preserved) | **PASS** |
| DM group controls `dmc:` (pause/skip/stop/queue) permission-checked per press | **PASS** |
| Group Now-Playing control message uses `grp:` callbacks (was `np:` — wrong-target buttons) | **PASS** — regression-locked |
| Private-scope `trk:` handlers chat-filtered (group presses no longer swallowed by the personal router) | **PASS** — dispatcher-level verification |
| Dashboard Now Playing / Queue entries (`dash:np`, `dash:queue` handlers + default buttons) | **PASS** (fresh installs; existing installs keep admin-configured buttons) |

### Infrastructure

| Feature | Status |
| --- | --- |
| Worker lifecycle / job retries (memory queue) | **PASS** |
| Redis-mode queue | **NOT TESTED** (no Redis in sandbox; fallback mode tested) |
| PostgreSQL path | **NOT TESTED** (no PostgreSQL in sandbox; SQLite tested) |
| Health endpoint (incl. voice readiness states) | **PASS** |
| Graceful shutdown (unit-level) | **PASS** |
| Logging pipeline (production bug) | **PASS** — root cause fixed, 32 regression tests |
| Alembic migrations | **PASS** (0001 + new 0002 run on disposable SQLite; PostgreSQL NOT TESTED) |

## 8. Unit and integration test results

- Command: `.venv/bin/python -m pytest` → **770 passed, 0 failed, 0 skipped**
  (in the audit environment; optional-dependency tests skip cleanly on
  machines without py-tgcalls/telethon).
- New suites added across the three rounds: `test_logging.py` (32),
  `test_voice_login.py` (30), `test_search_progress.py` (24),
  redirect-safety cases in `test_music_urls.py` (10), command-targeting
  cases in `test_silent_mode.py` (13), `test_dependency_audit.py` (5),
  `test_music_download.py` (45 — download-pipeline root-cause regression
  suite incl. real-AudiusSource full-chain test),
  `test_voice_group_access.py` (49 — membership / invite-join matrix +
  manager integration + admin handler smoke tests), voice auto-join config
  cases in `test_config.py` (3), **`test_source_identity.py` (18 — the
  confirmed `source='local'` corruption chain: catalog identity, resolver
  dedupe, provider-routed stream resolution, legacy self-healing,
  local-stream re-check, new_releases filtering)** and
  **`test_dm_group_play.py` (52 — DM→group workflow: link resolution
  matrix, prerequisite checks, honest outcomes, Back/Cancel/X, expiry,
  duplicate suppression, `dmc:` controls, group-keyboard routing)**.
- Full-application bootstrap integration check (SQLite, fake token, all
  services + container + router) executed successfully.

## 9. Live Telegram test results

**Not performed.** The audit sandbox has no outbound access to Telegram
servers, no bot token, no API ID/hash and no voice account. Everything
verifiable without those was verified (see §7); the remaining live checks
are precisely enumerated there and must be run against a staging bot before
production sign-off:

1. polling start/stop logs are clean (no `--- Logging error ---`);
2. animated search against the real Audius/Jamendo/local sources;
3. admin login wizard end-to-end (code + 2FA) on a disposable account;
4. group voice-chat streaming with the wizard-connected account;
5. broadcast delivery and FloodWait behaviour;
6. **private-group auto-join end-to-end**: bot with *Invite users via link*
   admin permission in a private group, voice account not a member →
   `/play` → verify the account joined and playback started (link export,
   `ImportChatInviteRequest`, post-join membership verification — all
   verified individually with mocked MTProto, but never against real
   Telegram);
7. **Audius live playback**: search → select → play with a real Audius
   discovery provider (the stream endpoint URL shape and the download/
   validation pipeline are unit-verified; the live API was unreachable
   from the sandbox);
8. **DM→group workflow live**: send a real group link in a DM → verify
   `CheckChatInviteRequest`/`ImportChatInviteRequest`/`GetFullChannel`
   behaviour, the voice-chat existence check, user-membership detection
   and the actual group playback start (all individually verified with
   mocked MTProto — never against real Telegram);
9. **provider identity live regression**: search a term that matches a
   previously cached Audius row in the production catalog and confirm the
   resulting track keeps `source='audius'` and plays (the exact `hindi`
   reproduction from the production log is covered by the automated
   `test_source_identity.py` suite against the real resolver/aggregator
   classes — the live check confirms production data heals the same way).

## 10. Unsupported capabilities & required permissions

- **Bot API vs MTProto**: sending audio to private chats, all admin UI,
  broadcasts and callbacks are pure Bot API. Joining and streaming into
  group voice chats requires a **user account via MTProto** (Telethon +
  py-tgcalls) — bots cannot join voice chats.
- **Group admin permissions**: the voice account must be a member of the
  group (with permission to join voice chats). Group `/play` requires the
  bot to see the command — with privacy mode ON (default), the bot only
  receives commands addressed to it or via its command menu, which matches
  the strict-silence design.
- **Automatic invite-link joining** additionally requires the **bot** to
  be a group admin with the *Invite users via link* permission (Bot API
  `createChatInviteLink` — a dedicated link; the group's primary link is
  never exported or rotated). Without it the bot reports the actionable
  error
  and the voice account must be invited manually. Groups with join
  requests enabled cannot be joined automatically — the request must be
  approved by an admin first (surfaced as "approval pending").
- **Bot uploads** are capped at 50 MB by Telegram (`MAX_AUDIO_SIZE_MB=45`
  enforced below the limit).
- **Message edits** are rate-limited by Telegram — the search animation
  uses a ~3 s interval, skips no-op edits and backs off on
  `TelegramRetryAfter`.
- **Callback data** ≤ 64 bytes — all project callbacks follow the
  `ns:action[:id]` pattern and are validated by
  `app.security.validation.validate_callback_data`.
- **Voice playback readiness** is explicitly not implied by login success
  (the wizard and health endpoint distinguish `healthy` account vs actual
  streaming; only a live `/play` verifies audio).
- **No DRM circumvention**: Spotify/YouTube/SoundCloud/Deezer/Apple Music
  links are politely rejected (`UnauthorizedSourceError`).

## 11. Known limitations

1. Live Telegram / MTProto / PostgreSQL / Redis paths unverified (see §9);
   in particular **live private-group auto-join and live Audius playback
   were NOT tested against real Telegram** — both are unit-verified with
   mocked MTProto/HTTP and documented here per the no-unsupported-claims
   policy.
2. `set_volume` depends on an optional py-tgcalls API; it degrades to a
   debug log when unavailable (by design).
3. The `MemoryCache`/in-memory job queue is single-process only —
   multi-instance deployments must configure Redis.
4. `build_router()` assembles one dispatcher per process (aiogram routers
   are single-parent); the duplicate guard now resets per build so repeated
   calls fail loudly instead of silently returning an empty router.
5. Python 3.14 not available in the audit environment (the stdlib logging
   usage is now 3.12–3.14-safe by construction — no private aliases).
6. Audio content validation uses magic-byte header sniffing (no ffprobe
   round-trip per download): exotic but playable containers that match no
   known signature would be rejected as invalid audio — the covered set
   (MP3 tagged/raw, AAC, Ogg, FLAC, WAV, M4A/MP4, WMA, MIDI, APE) spans
   everything the configured providers serve.
7. Auto-join operates per playback request: membership positives are cached
   (`VOICE_MEMBERSHIP_CACHE_SECONDS`), but a revocation is only noticed
   after that TTL or at the next failed playback.

## 12. Environment requirements

- Python 3.12+ (3.13/3.14 expected compatible; 3.14 NOT TESTED)
- FFmpeg + ffprobe on PATH (or `FFMPEG_PATH`/`FFPROBE_PATH`)
- PostgreSQL (asyncpg) for production; SQLite (aiosqlite) for demo/tests
- Redis optional (falls back to in-memory for single process)
- `BOT_TOKEN` required; `TELEGRAM_API_ID`/`TELEGRAM_API_HASH` +
  `VOICE_SESSION_ENCRYPTION_KEY` required for the voice engine

## 13. Migration notes

- **New migration `0002_voice_telegram_id_unique`** — creates a unique
  index on `voice_accounts.telegram_id` after clearing pre-existing
  duplicates (newest row keeps the id; older duplicates are preserved with
  `telegram_id = NULL`). Non-destructive; upgrade with
  `alembic upgrade head`. SQLite demo deployments using `create_all` get
  the same constraint from the model.
- No other schema changes. Existing data, settings, messages and buttons
  are untouched. New default message key `search_slow` is seeded
  idempotently on first startup.
- Callback formats are unchanged (`adm:vc:add` now opens the wizard instead
  of CLI instructions — same callback data, new behaviour;
  `adm:vc:acc:<id>:access` is a new callback for the Group-Access screen).
- **No schema changes in the second repair round** — the download-pipeline
  fix and the auto-join workflow reuse existing columns
  (`tracks.stream_url`, `tracks.file_path`) and new env-only settings;
  `alembic upgrade head` remains the only required step (migration 0002
  from the first round).

## 14. Security findings (both repair rounds)

1. **Logging mutation bug (fixed round 1, high impact)** —
   `SecretRedactingFilter` rendered `record.msg` and then dereferenced the
   nonexistent `logging.Mapping`, swallowing the `AttributeError` and
   leaving records half-rendered → the production
   `TypeError: not all arguments converted` / `--- Logging error ---` spam
   on every aiogram/Telethon parameterized log. The filter no longer
   mutates positional records at all; mapping-args are redacted with keys
   preserved; the formatter renders defensively and preserves tracebacks.
2. **Redirect SSRF bypass (fixed round 1, high severity)** — direct-audio downloads
   followed redirects automatically (`allow_redirects=True`), allowing a
   public redirector to bounce requests into private networks despite the
   initial SSRF validation. Redirects are now resolved manually with a
   fresh `validate_url` on **every** hop (`follow_redirects_safely`);
   JSON provider APIs no longer follow redirects.
3. **Dependency incompatibility (fixed round 1, functional)** — the old
   `py-tgcalls>=1.1,<2` pin resolved to py-tgcalls 1.2.9, whose API
   (`join_group_call`/`pause_stream`/...) never matched the transport layer
   (`play`/`pause`/`resume`/`leave_call`) **and** whose unbounded
   `ntgcalls` requirement silently breaks against ntgcalls 3.x — the voice
   engine would degrade to "unavailable" with only a guarded-import
   fallback. Now pinned to the matching `py-tgcalls>=2.2,<3` line with a
   runtime API-surface regression test.
4. **Command targeting (fixed round 1, hardening)** — group commands qualified for
   other bots (`/play@OtherBot`) passed the silence gate; they are now
   dropped using aiogram's cached `bot.me()` username.
5. **Duplicate voice accounts (fixed round 1, data integrity)** —
   `get_by_telegram_id` + service-level duplicate detection + unique index
   (migration 0002).
6. **Relative-path playback bug (fixed round 2, critical)** —
   `get_playable_path` returned the storage-relative `file_path` string
   after downloading, so the voice layer received a path that only resolved
   if the process CWD happened to be the project root. It now returns the
   validated absolute `Path`.
7. **Unvalidated download content (fixed round 2, hardening)** — HTTP-200
   HTML error bodies and empty payloads could reach Telegram upload /
   py-tgcalls and surface as confusing library errors. Downloads are now
   magic-byte-validated before the atomic rename; failures never replace a
   previously good cached file and never leave `.part` files behind.
8. **Invite-link hygiene (round 2, by construction)** — invite links and
   hashes are never logged (only host + length), links are only requested
   for groups where an authorized playback command occurred, failed joins
   cool down instead of retrying, and at most one link re-export happens
   per playback request.

## 15. Remaining blockers

- Live verification matrix of §9 (staging bot + disposable user account +
  reachable PostgreSQL/Redis) — the only path to marking the live rows in
  §7 as PASS.
- Python 3.14 environment for a final smoke run.
- A real group voice chat for audio-streaming verification.

---

# Round 4 audit — transport API compatibility, HTML safety, UX benchmark

*Audit date: round 4 (post-UX-overhaul). Environment: Python 3.12.15,
aiogram 3.31.0, Telethon 1.45.0, **py-tgcalls 2.3.3** (installed line moved
from 2.2.11 within the `>=2.2,<3` pin — transport re-verified against it),
SQLAlchemy 2.1.4, pytest 9.1.1.*

## 16. Round-4 root causes (from the live production log)

1. **Playback died at the final transport step** —
   `voice.transport.play_failed error="got an unexpected keyword argument
   'loop'"`: `NativeTransport.play()` constructed
   `MediaStream(str(path), loop=False)` but **py-tgcalls 2.3.3's
   `MediaStream.__init__` has no `loop` parameter** (verified via
   `inspect.signature`). Search → resolve → download all succeeded first,
   then the `TypeError` killed every playback attempt. Reproduced
   in-venv char-for-char; fixed (`MediaStream(str(path))` + explicit
   `GroupCallConfig(auto_start=False)`); regression-locked against the
   real installed class (`test_production_regressions.py`).
2. **Group replies rejected by Telegram** —
   `groups.reply_failed error="can't parse entities: Unsupported start tag
   \"song\" at byte offset 18"`: `USAGE_PLAY` carried a raw `<song name>`
   placeholder while every group reply uses `parse_mode="HTML"`
   (byte offset 18 = "💡 Usage: /play " exactly). Same latent defect in
   `USAGE_SEARCH` / `USAGE_VOLUME`. All fixed to `&lt;…&gt;`; an AST scan
   of every string literal in `app/` now runs in the test suite so no
   raw placeholder tag can ship again.
3. **Duplicate `/new` handler registration** (dead router weight) —
   removed; a duplicate-registration guard test now walks the real
   aiogram router filters.

`GroupCallConfig(auto_start=False)` rationale: with the library default
(`auto_start=True`) a missing voice chat makes the *userbot* attempt to
create one (requires manage-call admin rights → obscure RPC errors).
With it off, py-tgcalls raises the clean `NoActiveGroupCall` — now
classified as `VoiceChatMissingError` ("start a voice chat first"),
matching the honest-error design used across the bot.

## 17. UX benchmark — references actually inspected

The round-4 UX overhaul was pattern-matched against publicly accessible
references, fetched and read during development:

| Reference | What was taken from it |
| --- | --- |
| **AsmSafone/MusicPlayer** README (github.com/AsmSafone/MusicPlayer — raw fetch) | persistent "cool controls anytime" panel (loop/mode/pause/resume), chat-hygiene rules, per-chat queue isolation, admin-restricted control commands |
| **Jockie Music command reference** (jockiemusic.com/commands — page fetch) | command categories (playback / track-state / queue-state), stateful `autoplay toggle` semantics, `clean` chat-hygiene command, rich command **aliases**, per-command help |
| **iturrit.com — "The Best Telegram Bots for Music Lovers 2025"** (page fetch) | @SpotyBot / @YTAudioBot / @DeezerMusicBot flows: search-or-paste-link, direct delivery, quick-start onboarding steps |
| **Pancake commands reference** (pancake.gg/commands + search snippets) | repeat-mode cycling UI, one-tap skip vs vote-skip, instant admin skip |
| **pytgcalls / vcplayer GitHub topic listings** | per-chat queue as the standard isolation model for py-tgcalls bots |
| **Telegram inline-keyboard pagination & layout references** (grammy keyboard plugin docs, thedevs.org pagination article — via search) | ≤100 buttons/message, 2-per-row layouts, numbered-page navigation |

Implemented improvements mapped to those patterns:

* **One shared Now Playing renderer** (`app.utils.now_playing_text`):
  header / title / artist / playhead progress bar
  (`▬▬▬▬▬●─────────` + clamped `1:23 / 3:53`) / state badges /
  requester attribution / queue count — the personal player, the group
  control message, the dashboard screen and the DM control screen
  previously kept four drifting copies.
* **Stateful control buttons**: `🔀 Shuffle: On` / `🔁 Repeat: All`
  labels on every player and queue keyboard (personal `np:`, personal
  queue `q:`, group `grp:`), so users see the mode a press will change.
* **Group control panel extended**: shuffle + repeat toggles and
  `🔉 Vol − / 🔊 Vol +` step buttons (±25, clamped 0–200, labels show the
  target value) joined Pause/Skip/Queue/Stop — all `grp:`-namespaced and
  permission-checked per press (`grp:rep`, `grp:vol:dn|up` handlers).
* **Queue views enriched**: per-entry durations, requester mentions
  (`tg://user?id=…` deep links with best-known names) and the
  `📋 N in queue · ≈ 18 min` footer (personal, group and DM queue views).
* **Search results are never a dead end**: a `🔄 New Search | 🏠 Home`
  row on personal results (previously only pagination — escape required
  `/start`), and a `🎧 Now Playing | 📋 Queue` follow-up row on group
  results.
* **Command aliases**: `/p /q /np /next` for play/queue/nowplaying/skip
  (Jockie-style), documented in the seeded `/commands` and group help.
* **Onboarding & recovery texts**: 3-step quick start on `/start`,
  example hint on the search prompt, actionable no-results guidance,
  autoplay invitation on empty queues — all admin-customizable and
  Telegram-HTML-safe by test.
* **DM→group flow polish**: queued outcome shows `Position #N of M`;
  the DM status screen reuses the shared renderer (custom
  "NOW PLAYING IN THE GROUP" header); DM queue view shows durations +
  total time.

## 18. Round-4 test results

- `.venv/bin/python -m compileall -q app tests` → clean.
- `.venv/bin/python -m pytest` → **842 passed, 0 failed** (770 → 842).
- New suites: `test_production_regressions.py` (13 — the `loop` kwarg
  regression against the REAL installed MediaStream class,
  `GroupCallConfig(auto_start=False)` lock, `NoActiveGroupCall`
  classification, Telegram-tag parser reproduction of the
  `<song>` rejection, module-constant HTML audit, duplicate-command
  guard) and `test_ux_overhaul.py` (59 — shared renderer, playhead bar,
  queue totals, user links, stateful keyboards, controller panel
  namespace discipline, dead-end-free search results, aliases, new
  group callbacks wiring, queue-view enrichment, defaults HTML safety,
  track-page meta line).
- Live Telegram behaviour of the new buttons/aliases: **NOT TESTED**
  (same sandbox constraints as §9; the callback contracts and
  permission gates are unit-verified).
- py-tgcalls moved 2.2.11 → 2.3.3 inside the pinned `>=2.2,<3` range:
  every transport call re-verified against the installed signatures
  (`play`, `pause`, `resume`, `leave_call`, `change_volume_call`;
  `set_volume` correctly absent → fallback path).

## 19. Round-4 continuation — third production bug + group status UX

The follow-up production run (2026-10-11, timestamps
07:52–07:58) confirmed the two round-4 fixes were not yet deployed (both
symptoms still present on the old build) **and** exposed a third defect
round 4 had missed:

1. **`bot.link_resolve_failed error="name 'UnsupportedUrlError' is not
   defined'"`** — `app/music/sources/url_resolver.py` line "raise
   UnsupportedUrlError(...)" used the symbol without importing it (the
   import list carried only `DownloadError`, `FileTooLargeError`,
   `UnauthorizedSourceError`). Every DM link that fell through to the
   direct-audio fallback raised `NameError` instead of the intended
   user-facing `BotError`, so the member saw the generic
   "something went wrong" text and the log lost the real reason. Fixed
   by importing `UnsupportedUrlError` from `app.errors`; verified at
   runtime (`resolve_direct_audio('https://audius.co/track/…')` now
   raises `UnsupportedUrlError: Not a direct audio URL: …`).
   Regression-locked three ways in `test_music_urls.py` (page URL,
   extension-less stream URL, and an AST guard that every documented
   error symbol used in the module is imported). A full-repo **pyflakes
   audit** then confirmed this was the *only* latent undefined-name bug
   in `app/` + `scripts/` + `run.py` (remaining findings: benign unused
   imports only).
2. **Group request dead air (UX gap from the same log)** — a group
   `/play` spanned **35.9 s** (7 s Audius search + 23 s download) and a
   group `/search` ~8 s with **zero feedback**, because the round-4
   animated progress reporter is deliberately private-chat-only (group
   design rule: no animation, low noise). Fixed with a *single static
   status message per request*: posted before any provider call
   (`🔎 Searching… / Query: …`), edited to `⬇️ Loading track…` once a
   match is found, then edited into its final state — the Now Playing
   control (new `edit_message` passthrough: `PlaybackController.enqueue
   → play_now → _start_group → _upsert_control`), the queue
   confirmation (`➕ Added to queue: … — #N in queue`), the results
   screen (`/search`), or the failure text (`_notify_error` now edits
   the transient message instead of posting a duplicate error). Every
   edit is fail-safe (`_edit_or_say`: uneditable/missing status → fresh
   reply), so no path can end without an answer. Exactly ONE group
   message per request — no animation, honoring the §17 group-hygiene
   patterns (AsmSafone chat-hygiene rules, Pancake/Jockie instant
   acknowledgement style).

Verification for this continuation round:

- `python -m compileall -q app tests` → clean.
- `python -m pytest` → **865 passed, 0 failed** (842 → 865: +3 URL
  error-class regressions, +17 group status-flow tests in
  `test_group_status_flow.py`, +3 controller `edit_message` tests in
  `test_playback_controller.py`).
- `pyflakes app/ scripts/ run.py` → no undefined names anywhere.
- Live Telegram behaviour of the status-message lifecycle: **NOT
  TESTED** (same sandbox constraints as §9); the message flow
  (ack → edit → outcome), the controller passthrough and all fallbacks
  are unit-verified with duck-typed Telegram messages.

---

# Round 5 audit — final repairs, autoplay, invite-link safety, download cap

Production evidence: the 2026-10-11 08:24–08:37 run (deployed build
includes the round-4 transport/HTML/import fixes — group playback now
**starts successfully** in two groups) plus the supplied screenshots.
This round fixes the defects that run exposed and completes the
autoplay/UX work.

## 20. Round-5 root causes (from the live production log)

1. **`playback.group_play_failed error="Download exceeded cap of
   47185920 bytes"` (twice, both groups)** — the voice-chat streaming
   path downloaded through `_download_to_cache`, which capped at
   `max_audio_size_mb` (45 MiB). That cap exists for Bot API
   **uploads** (Telegram's 50 MB bot limit) — but voice playback never
   re-uploads: the file is piped locally through ffmpeg/PyTgCalls, so
   the honest bound is disk usage. Long DJ mixes commonly exceed
   45 MiB, aborting group playback mid-flow (one `/play` ran 96 s
   before failing). **Root-cause fix:** a dedicated
   `VOICE_MAX_AUDIO_SIZE_MB` setting (default 200, bounds 1–2000,
   validated at startup) governs the voice streaming path; the upload
   cap keeps guarding personal/direct-URL delivery. `FileTooLargeError`
   now reports the ACTUAL limit ("…over 200 MB… raise
   VOICE_MAX_AUDIO_SIZE_MB") instead of a hardcoded, wrong "45 MB".
   Direct remote streaming into PyTgCalls was evaluated and **not**
   chosen: provider URLs expire/redirect and reliability cannot be
   verified in this sandbox — the documented, bounded local cache keeps
   the existing retry/validation pipeline intact (an honest engineering
   trade-off, recorded here per §10 policy).
2. **Skip racing a pending natural advance → the same track played
   twice** (08:32:09 and 08:32:16, both `track-12.mp3`) — a skip
   pressed while a natural track-end advance was mid-download (70 s)
   waited on the per-owner lock, then advanced AGAIN from the OLD
   session state: a second, cached recommendation (seed 11) was
   enqueued and the just-started track restarted. **Root-cause fix:**
   `PlaybackController.next()` captures the session's current track
   BEFORE acquiring the lock; after acquiring it, a changed track
   proves another advance already delivered a new track — the stale
   call returns without advancing (logged as
   `playback.stale_advance_dropped`). Verified by a gated-gateway test
   reproducing the exact production interleaving.
3. **Recommendation served mid-shutdown** (08:37:46, between
   `shutdown_begin` and `session_left`) — in-flight advances kept
   running during shutdown. **Root-cause fix:** `cleanup()` sets a
   closing flag first; `_on_track_end` ignores events and `_advance`
   skips refills once closing; failure notifications are suppressed
   during shutdown.
4. **DM→group destination hijack (screenshot)** — while the FSM waited
   for a GROUP link, the `links` router (registered before `dm_play`)
   matched `https://t.me/call/…` as a music URL and answered "only
   links from authorized music sources are supported" — wrong for that
   step of the conversation. **Root-cause fix (two parts):**
   (a) `on_link_message` now excludes `DmPlayFSM.waiting_link`, so the
   DM-play router receives the message; (b) `t.me/call/…` is
   classified explicitly (`classify_tme_link`) and answered with a
   dedicated message: "That's a Telegram **call link** — it doesn't
   identify a group", plus the supported destination formats. Other
   special `t.me` kinds (sticker packs, proxies, wallpapers, boosts,
   private-channel `c/` links) are likewise rejected up-front with
   honest reasons instead of a bogus "not found" username lookup.
5. **Invite-link provider could rotate the group's PRIMARY link** —
   the composition root used `bot.export_chat_invite_link(chat_id)`,
   which returns (and may replace) the group's primary link. **Root
   -cause fix:** the provider now calls
   `bot.create_chat_invite_link(chat_id, name="Music bot voice
   account")` — a DEDICATED link that never touches the primary one.
   Permission/API failures degrade to `None` → the existing
   `invite_unavailable` actionable message; the returned object is
   validated (`invite_link` non-empty); the link value is never logged.
   All call sites audited (AST sweep: no `export_chat_invite_link`
   attribute access remains anywhere in `app/`).
6. **Auto-advance failures stalled silently** — when an automatic
   advance failed (e.g. the download cap), the session kept a stale
   Now Playing message and the timer was already cancelled: music
   stopped with no explanation. **Fix:** non-manual advance failures
   now surface the categorized error on the control message and park
   the session idle; manual paths keep raising to their handlers.
7. **Autoplay unreachable from the player** — the group settings
   screen toggled `Group.autoplay_enabled`, but the controller gates on
   `PlaybackSession.autoplay`: the two surfaces disagreed (an admin
   could turn autoplay "off" in settings while it kept playing).
   **Fix:** a dedicated 🤖 Autoplay ON/OFF button on the group player
   panel (`grp:auto`) toggles the REAL per-group setting the controller
   reads AND syncs the group-settings row; the settings-screen toggle
   (`grp:set:auto:`) now syncs the session the same way. The toggle
   always reads the ACTUAL session state, so stale keyboards can never
   desynchronize it.

**Investigated and deliberately NOT "fixed":** the 11↔12 recommendation
ping-pong in the log is legitimate behavior with a two-track group
history (the engine alternates its only two candidates — repeat
rotation, not duplicate enqueueing); repeat/shuffle semantics are
preserved unchanged.

## 21. Group player UX (screenshot-driven)

- **Clipped labels fixed** ("Shuffle: Of…", "Repeat: Of…"): the three
  stateful toggles (🔀 Shuffle, 🔁 Repeat, 🤖 Autoplay) now take
  FULL-WIDTH rows — they can never truncate on narrow screens; the
  transport pairs (Pause|Skip, Vol−|Vol+, Queue|Stop) stay two-wide.
  The same layout rule is applied to the personal `np:` panel.
- **Autoplay button placement:** last row of the group player panel,
  directly after Queue/Stop ("near queue information"), and also on
  the group queue view's keyboard.
- Buttons remain stateful (label = current state), `grp:`-namespaced,
  permission-checked per press (`play` action for autoplay, matching
  Shuffle/Repeat), promptly answered, and the player message is
  re-rendered immediately after a toggle.
- Callback registry in `CONTRACTS.md` §8 updated to include every
  `grp:` transport/toggle callback and the `dm:`/`dmc:` namespaces
  (they were missing from the contract table since round 3/4).

## 22. Round-5 test results

- `python -m compileall -q app tests` → clean (exit 0).
- `python -m pytest -q` → **920 passed, 0 failed** (865 → 920:
  +55 regression locks in `tests/test_round5_fixes.py`), covering:
  invite-provider call semantics + AST no-export sweep + full-call-site
  audit; call-link classification and the DM-flow re-prompt with the
  selected track preserved; the links-router state exclusion (real
  aiogram filter-walk); the voice/upload cap split (defaults, env
  parsing, bounds validation, Content-Length precheck, streamed-byte
  enforcement, partial-file cleanup, just-below/just-above caps, the
  two distinct user messages); autoplay semantics (ON+queue,
  ON+empty→refill once, OFF+empty→no request, OFF+queue, repeat-one and repeat-all (existing semantics preserved),
  group isolation, persistence, shutdown guards, recommendation
  failure → exactly one attempt, auto-advance failure surfacing,
  manual-raise preserved); the skip-race/duplicate-track-end stale
  guards (gated-gateway reproduction of the production interleaving);
  the 🤖 button labels/layout/callback wiring/handler registration;
  permission denial; stale-keyboard safety; and a static audit that
  every group-player button maps to a registered handler.
- Live Telegram behaviour: **NOT TESTED** in this sandbox (unchanged
  §9 constraints). All fixes are unit-verified; the transport call
  itself was already proven live in the supplied production log
  (playback starts, `voice.session.playing`, two groups streaming).

## 23. Deployment notes for this round

- New optional env var `VOICE_MAX_AUDIO_SIZE_MB` (default 200) — see
  `.env.example`. No migration required (autoplay already persisted on
  playback sessions; the group-settings sync is runtime-only).
- Deploy WITHOUT touching the existing database: the schema is
  unchanged; SQLite/PostgreSQL rows keep working.
- The invite provider change requires no new permissions beyond the
  ones the old export call needed ("invite users via link" admin
  right) — but it no longer risks rotating a group's primary link.

## 24. Round 6 — 2026-10-11 audit of `telegram-music-bot-fixed (5).zip`

### 24.1 New production-log evidence analyzed

The supplied `Log (1).txt` (2026-10-11, two runs) shows, verbatim:

* Run 1: `/play "hindi remix"` → `queue.added … track_id=23 position=2 size=2`
  → `queue.popped track_id=25` → 69 s download attempt → DNS outage
  (`Cannot connect to host api.audius.co:443 … name resolution`,
  `api.telegram.org … Network is unreachable`) →
  `playback.group_play_failed` ×2 → **both popped tracks silently lost**,
  session left claiming "playing".
* Run 2 (fresh start, same DB): `/play hindi` →
  `queue.added … track_id=11 position=1 size=1` → **nothing else — ever**.
  No `queue.popped`, no `voice.acquired`, no `playback.started`: the
  userbot never even attempted to join the voice chat. The DM flow the
  run before logged `voice.link.resolved … joined=false` and reported
  "no active voice chat" for a group whose call state it could not see
  as a non-member.

### 24.2 Root causes found (and fixed)

| # | Defect | Root cause | Fix |
| --- | --- | --- | --- |
| A1 | Queued group track never plays after a restart | Persisted `PlaybackSession.status` survives restarts as `playing`/`paused`; `enqueue()` only starts playback when status ∈ {idle, stopped} — a stale "playing" row makes every later `/play` silently queue forever. No startup reconciliation existed. | `SessionManager.reset_active_sessions()` + `PlaybackController.recover_stale_sessions()` called from `Application._bootstrap()`; every stale session is parked `stopped` (queues preserved). |
| A2 | Failed playback start leaves the group marked "playing" and loses the track | `_start_group`'s failure path only edited an error message: the session status was never reset and the popped queue item was never recovered. | New `_fail_group_start()`: parks the session **idle**, requeues the failed track at the queue FRONT once (bounded: a second consecutive failure drops it with a truthful message and purges queued copies), and surfaces the reason + recovery outcome. A successful start resets the failure counter. |
| A3 | Mid-run stale status after voice lease loss | Released/failed voice sessions leave the playback session "playing" while no lease exists. | `VoiceManager.is_active()` + controller/handler `was_active` cross-checks (duck-typed; older fakes keep legacy behavior) — `enqueue()` and the group/DM flows now correct the lie and actually start playback (and no longer double-render "Added to queue" over the fresh Now Playing message). |
| B1 | DM→group playback fails "No active voice chat" although a chat exists | `_execute_play` checked `check_voice_chat` BEFORE `ensure_access` — a non-member account cannot reliably see `full_chat.groupcall`, so a live-but-invisible call was reported missing and the account never joined. | Steps reordered: ensure group access/auto-join FIRST, then the voice-chat verdict (now reliable). Locked by ordering tests (runtime + source-order). |
| V1 | Volume label/behavior mismatch | Keyboard/labels used 0-200 while the session clamped to 0-100 and the transport passed raw values. | One consistent human percent 0-100 everywhere (command, buttons, session) with the transport mapping percent→engine scale (×2, NTgCalls 0-200). |
| C1 | Completed download cache never cleaned | Only `tmp/` was swept (`cleanup_tmp`); `storage/downloads/**` grew unbounded. | `StorageService.cleanup_downloads()` (symlink-safe, sandboxed, protected-path aware) + `cleanup_downloads` worker task + periodic loop integration + `DOWNLOAD_CACHE_RETENTION_HOURS` / `DOWNLOAD_CACHE_CLEANUP_INTERVAL_MINUTES` config. |
| D1 | Group command clutter | No auto-delete of handled commands. | `CommandAutoDeleteMiddleware` (inner, finally-block): deletes recognized, addressed commands in groups only; best-effort; `GROUP_COMMAND_AUTO_DELETE=false` disables; DMs and plain messages are never touched. |

### 24.3 Verification matrix (round 6)

| Requirement area | Status | Evidence |
| --- | --- | --- |
| A: queue → join → stream path | **Verified (mocked integration)** | `tests/test_round6_fixes.py` — recovery, requeue policy, cross-check, auto-advance failure; transport join itself already live-proven in earlier rounds' logs |
| B: DM→group ordering | **Verified** | runtime ordering test + source-order lock |
| Invite-link creation | Verified (round 5, unchanged) | `create_chat_invite_link` provider; no export rotation |
| Provider/DB track identity | Verified (round 4, unchanged) | Audius source_id preserved through resolver |
| Player clipped labels | **Fixed + locked** | compact ≤16-char labels, 2-button rows; layout tests |
| All player buttons work | Verified | callbacks pre-registered (round 5 audit); volume clamp fixed |
| Autoplay/repeat/shuffle/skip | Verified (round 5) + failure-path tests added | see 24.4 |
| Download caps/partial cleanup | Verified (round 5, unchanged) | 45 MiB upload / 200 MiB voice caps |
| Completed-cache cleanup | **Implemented + locked** | age/protection/symlink/scope/missing-dir/worker tests |
| Group command auto-delete | **Implemented + locked** | enabled/disabled/DM/other-bot/qualified/error/failure tests |
| Network outage recovery | **Policy implemented** | requeue-once + idle reset + bounded retries (existing) |
| Graceful shutdown | Verified + progress-task cancellation added | `cleanup()` cancels tickers; smoke-verified |
| `/start` + home redesign | Polished + locked | voice-chat requirement text; repeated-`/start` housekeeping test |
| DM search/results | Verified (rounds 3-5, unchanged) | stable identity, expiry, isolation |
| Pending-flow isolation | Verified (round 5, unchanged) | per-user FSM + TTL |
| TOP Music Bot identity | **Not verifiable — documented ambiguity** | see §24.5 |
| Reference sources inspected | **Verified** | §24.5 list |
| Live Telegram playback | **NOT TESTED** | no credentials/group VC in sandbox |

### 24.4 Test results (round 6)

- `python -m compileall -q app tests` → exit 0.
- `python -m pytest -q` → **970 passed, 0 failed** (920 → 970: +50 in
  `tests/test_round6_fixes.py`), covering: startup recovery (playing,
  paused, idle-untouched, controller reporting, post-recovery playback
  actually starting); failure policy (idle reset, front requeue, drop
  on second consecutive failure, counter reset after success,
  auto-advance failure, enqueue failure); stale-status cross-check
  (dead lease → start, live lease → queue behind, no-is_active legacy);
  DM ordering (runtime + source); volume mapping + clamps; download-cache
  cleanup (old/recent/protected/symlink/scope/missing/worker/disabled);
  command auto-delete (8 scenarios); progress ticker (edits, stop-cancel,
  cleanup-cancel); Up next rendering + escaping + group message;
  protected paths; config defaults/env/validation; `is_active`;
  repeated-`/start` housekeeping; malformed deep links; stale-verdict
  double-render guard.
- Application-bootstrap smoke (not part of the suite): full
  `Application._bootstrap()` + `shutdown()` with the new wiring → OK.

### 24.5 Reference research — "TOP Music Bot" investigation

**Identity: AMBIGUOUS — not conclusively identified.** Live checks show
`@TopMusicBot` (display name "Music") and `@top_music_bot` (display name
"Top music") are two separate, live, closed-source bots;
`@TopMusicRobot` does not exist; GitHub has no "TopMusic" Telegram repo;
web search returns only Discord/Highrise bots. No Telegram client was
available to interact with either bot, so their runtime UI was **not
observed** (never guessed). Recommended: ask for the exact `@username`
or a screenshot.

**References actually inspected (source files read, this session):**

| Bot | Repo | License | Key files read |
| --- | --- | --- | --- |
| Yukki Music | TeamYukki/YukkiMusicBot | MIT | strings/langs/en.yml, utils/inline/{start,play,queue,help}.py, plugins/bot/start.py, core/call.py |
| AnonXMusic | AnonymousX1025/AnonXMusic | MIT | anony/helpers/_inline.py, plugins/start.py, locales/en.json |
| VCPlayBot | Shiv-x/VCPlayBot | GPL-3.0 | modules/inline.py, callback.py, play.py |
| VCsMusicBot | lushaimusic/VCsMusicBot | AGPL-3.0 | modules/private.py, msg.py, play.py |
| MusicPlayer (Safone) | AsmSafone/MusicPlayer | AGPL-3.0 | lang/en.json, core/stream.py |
| RadioPlayerV3 | AsmSafone/RadioPlayerV3 | AGPL-3.0 | plugins/bot/{private,inline}.py |
| MusicPlayer (subinps) | subinps/MusicPlayer | MIT | plugins/{commands,player}.py |
| callsmusic (orig + fork) | rojserbest, callsmusic | mixed | helpers/reply_markup.py, handlers/* |
| Telegram_VC_Bot | TheHamkerCat | MIT | main.py (no inline keyboards — precursor) |
| TGVCBot | ArnabXD/TGVCBot | Apache-2.0 | src/handlers/*.ts, middlewares |
| py-tgcalls examples | pytgcalls/pytgcalls | LGPL | example/simple_calls, change_volume_call observed |
| flora-music-bot | gabrielmaialva33 | GPL-3.0 | internal/core/buttons.go, locales/en.yml, modules/start.go |

**Adopted ideas (pattern-level only; no branding, strings or code from
GPL/AGPL repos):** compact glyph-pair transport rows; stateful
toggle labels; queue-confirmation copy ("Queued at position #N");
close/back conventions; the explicit "no active voice chat → start one"
error copy family; progress display; volume as a differentiator (modern
py-tgcalls supports it — most incumbents don't offer buttons). Full
comparison matrix and per-bot observations live in the research notes
that fed this section.

### 24.6 Deployment notes (round 6)

- New optional env vars (all defaulted, none required):
  `GROUP_COMMAND_AUTO_DELETE` (true), `PROGRESS_EDIT_INTERVAL` (15),
  `DOWNLOAD_CACHE_RETENTION_HOURS` (72), `DOWNLOAD_CACHE_CLEANUP_INTERVAL_MINUTES`
  (60). Volume is now 0-100 everywhere (`/volume` usage text updated).
- No schema changes, no destructive migrations, no dependency changes —
  deploy over the existing database; the startup recovery step parks
  stale sessions as `stopped` on first boot after upgrade.
- Upgrading heals the exact production symptom automatically: after
  restart, the first `/play` in an affected group starts playback again.

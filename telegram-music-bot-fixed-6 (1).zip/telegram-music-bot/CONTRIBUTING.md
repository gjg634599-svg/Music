# Contributing

Thanks for considering a contribution! This bot is a production-oriented
template — the bar is: **typed, tested, documented, silent in groups.**
This document explains the layout, the rules and the workflow.

> Reading order for newcomers: [README](README.md) → [CONTRACTS](CONTRACTS.md)
> (module interfaces) → this file → [SECURITY.md](SECURITY.md) when touching
> anything security-adjacent.

---

## 1. Development setup

```bash
git clone <your-fork> && cd telegram-music-bot
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
# minimal demo configuration (SQLite + in-memory cache fallbacks):
#   BOT_TOKEN=123456789:AAA...   (any syntactically valid token for local runs)

python scripts/seed_catalog.py     # optional: 10 synth demo tracks
python3 -m pytest                  # full suite — must be green
python run.py                      # demo mode boot
```

Requirements: Python 3.12+, FFmpeg binary on PATH (`ffmpeg -version`),
optionally PostgreSQL 16 / Redis 7 for production-parity development.

## 2. Project map

```
run.py                 entry point (--role bot|worker|all)
app/
  application.py       composition root — ALL wiring happens here
  config.py            pydantic-settings, typed env contract
  bot/                 aiogram layer: handlers, keyboards, middleware, callbacks
  music/               sources (local/jamendo/audius), search, resolver, metadata
  playback/            queue, sessions, controller, autoplay, event bus
  recommendation/      engine, weighted scoring, taste profiles, similarity
  voice/               account pool, transport, assignment, failover, health, idle
  broadcast/           composer, targets, rate limiter, delivery worker
  admin/               permissions, appearance, buttons, settings, stats, audit
  groups/              group service, settings, permissions, silent gate
  users/               user, library, history, playlist, stats services
  audio/               FFmpeg toolkit, processor, pipeline
  database/            models (35 tables), repositories, defaults, engine
  cache/               Redis client + in-memory fallbacks
  security/            validation (SSRF/URL/callbacks), encryption, secrets
  workers/             job manager, task registry
migrations/            Alembic (async env) — 0001_initial is metadata-driven
tests/                 pytest suite (asyncio_mode=auto, SQLite in-memory)
scripts/               seed_catalog, add_voice_account, dev_setup
```

Dependency direction (enforced by convention, verified in review):
`bot → services → repositories → models`. Handlers must not import
repositories directly; services must not import aiogram.

## 3. Hard rules

1. **Silent group mode is sacred.** Any new group-facing handler only fires
   for updates that pass `GroupSilentMiddleware` (explicit command entity or
   inline callback). If you add a message path that can post into a group
   unprompted, it will be rejected. Extend `tests/test_silent_mode.py` when
   in doubt.
2. **No secrets in code, logs or error messages.** Use `mask_secret` /
   `mask_phone` from `app/security/secrets.py`; the logging filter covers
   field *names*, not free-form strings you concatenate yourself.
3. **Authorized sources only.** Never add code that bypasses DRM or scrapes
   services that forbid it. A new source = subclass of
   `app/music/sources/base.py` (`search/get_track/get_metadata/get_playable_source`)
   + tests with faked HTTP.
4. **Everything async, everything typed.** Python 3.12 syntax, `from
   __future__ import annotations` where needed, no `Any` unless justified in
   a comment.
5. **Repositories own SQL.** Services call repositories; no raw SQL/ORM
   queries in handlers or services.
6. **Config comes from `app/config.py`.** No `os.environ` reads scattered
   around; add a typed field with a default and document it in
   `.env.example` + README `## Configuration`.
7. **Fail closed.** Permission/guard code must deny when a dependency is
   missing (see `AdminGuardMiddleware` for the pattern).

## 4. Adding a feature — checklist

Example: adding a `/weather` command.

- [ ] Handler in `app/bot/handlers/…`, registered in `app/bot/router.py`.
- [ ] Keyboard builders stay in `app/bot/keyboards/`, callback prefixes
      registered in the validation registry (`app/security/validation.py`).
- [ ] Any new table: model in `app/database/models/`, repository in
      `app/database/repositories/`, wiring in `app/application.py`, **and**
      an Alembic revision (`alembic revision --autogenerate -m "…"`, then
      review the generated file — autogenerate misses constraint renames).
- [ ] New settings: default in `app/database/defaults.py`, admin-panel
      exposure if operators need it.
- [ ] BotFather command menu text updated in `app/bot/commands.py`.
- [ ] Tests: service-level (fake repositories) + handler smoke test +
      silent-mode matrix if the command works in groups.
- [ ] Docs: README feature bullet + command table row.
- [ ] Full suite green: `python3 -m pytest` (target: 100% of prior tests
      still passing plus yours).

## 5. Testing discipline

- The suite runs **without network, Telegram, PostgreSQL or Redis** — keep it
  that way. Fake HTTP via `unittest.mock`/monkeypatch; SQLite in-memory via
  the `conftest.py` fixtures; `fakeredis` only if a Redis-specific behavior
  is under test.
- One test file per subsystem mirror (`test_<module>.py`), function-scoped
  DB fixtures, no cross-test state.
- Voice-engine tests use fake transports — never real MTProto sessions.
- If your change touches `app/application.py` or DI wiring, run a boot
  smoke: `python -c "import asyncio, os; os.environ.setdefault('BOT_TOKEN','123456789:'+'A'*33); from app.application import Application; asyncio.run(Application.create())"`
  and confirm graceful shutdown.

## 6. Code style

- Format: black-compatible defaults (88 cols), `ruff` rules welcome.
- Docstrings: one-line summary + params/returns for public service methods;
  module docstring for every new file.
- Logging: structured `logger.info("module.event", extra={…})` style with
  constant event names — never f-strings in the event field.
- Error handling: raise the typed errors from `app/errors.py`; handlers map
  them to user-facing messages in one place.

## 7. Pull requests

1. Fork → branch (`feat/…`, `fix/…`, `docs/…`).
2. Commit message: imperative subject + body explaining *why*.
3. PR description: what changed, why, test evidence
   (`python3 -m pytest` output tail), screenshots for any Telegram-UI
   change.
4. A maintainer will review against the checklist above. Security-relevant
   changes additionally get a `SECURITY.md` impact read.

## 8. Releasing / packaging

The distributable ZIP is rooted at `telegram-music-bot/` and must contain:
application, migrations, tests, scripts, Dockerfile, docker-compose.yml,
`.env.example`, README, CONTRACTS, SECURITY, CONTRIBUTING — and **no**
`.env`, `*.session`, `*.db`, caches or secrets. After any Python change,
re-run the full test suite before repackaging.

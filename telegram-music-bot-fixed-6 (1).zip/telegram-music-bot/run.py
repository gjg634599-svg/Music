"""Telegram Music Bot — application entry point.

Loads configuration, logging, database, services, workers, voice engine
and the Telegram bot, then runs the application until shutdown.

Usage:
    python run.py                # run everything (bot + workers)
    python run.py --role worker  # run background workers only
    python run.py --role bot     # run bot process only
"""

from __future__ import annotations

import argparse
import asyncio
import sys

from app.application import Application, ApplicationError
from app.config import Role, load_settings


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Telegram Music Bot — a Telegram-native music platform.",
    )
    parser.add_argument(
        "--role",
        choices=[role.value for role in Role],
        default=Role.ALL.value,
        help="Process role: 'bot' runs the Telegram bot, 'worker' runs "
        "background workers, 'all' (default) runs both in one process.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        application = Application.create(role=Role(args.role))
    except ApplicationError as exc:
        print(f"Failed to start application: {exc}", file=sys.stderr)
        return 1

    try:
        asyncio.run(application.run())
    except KeyboardInterrupt:  # pragma: no cover - manual stop
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

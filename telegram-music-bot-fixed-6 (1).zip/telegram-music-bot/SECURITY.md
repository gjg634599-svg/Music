# Security Policy

This document describes the security model of the Telegram Music Bot: what
the code protects against, where the boundaries are, how to deploy it safely,
and how to report a vulnerability.

It complements the [README](README.md) (`## Security` section gives the
one-paragraph overview). Everything below refers to real mechanisms in
`app/security/`, `app/bot/middleware/`, `app/logging.py` and friends — not
aspirations.

---

## 1. Threat model

| # | Threat | Mitigation | Where |
|---|--------|-----------|-------|
| 1 | Attacker sends the bot a link pointing at internal infrastructure (SSRF) | Scheme allowlist (http/https only), hostname resolution checked against private/loopback/link-local ranges *after* DNS, private IP literals rejected, URL length cap, download size cap | `app/security/validation.py::validate_url` |
| 2 | Malicious upload (fake audio, oversized file, hostile filename) | MIME + extension allowlists, size cap, `ffprobe` must recognize the file, filename sanitization, storage sandboxed under `STORAGE_DIR` with traversal checks | `app/security/validation.py`, `app/storage.py`, `app/audio/` |
| 3 | Crafted callback data (flood / injection / probing) | Strict regex grammar (`^[a-z0-9_]+(?::…){0,4}$`), 64-byte cap, unknown prefixes rejected, admin routes additionally gated by role middleware | `app/security/validation.py::validate_callback_data`, `app/bot/middleware/auth.py` |
| 4 | Secrets leaking into logs | Structured logging filter masks fields named `token`, `session`, `password`, `secret`, `api_hash`, `api_key`, `auth_key`, `encryption_key`, `login_code`, …; token/session-shaped *values* are also pattern-masked | `app/logging.py`, `app/security/secrets.py` |
| 5 | Voice-account session theft from the database | Session strings Fernet-encrypted at rest (`VOICE_SESSION_ENCRYPTION_KEY`), decrypted only in memory, never rendered in admin UI or logs, phone numbers masked | `app/security/encryption.py` |
| 6 | Abuse / resource exhaustion of the bot | Fixed-window per-user and per-group rate limits (search, heavy ops, commands), per-account voice session caps, broadcast token-spacer under Telegram's global 30 msg/s | `app/bot/middleware/rate_limit.py`, `app/voice/assignment.py`, `app/broadcast/rate_limit.py` |
| 7 | Unauthorized group actions | Configurable permission model per action (everyone / admins / DJs), admin role hierarchy (super admin / admin / moderator), admin-panel callback guard | `app/groups/permissions.py`, `app/admin/permissions.py` |
| 8 | Malicious broadcast buttons | URL buttons restricted to `https://` and `tg://`; `javascript:`, `data:` and other schemes rejected at compose time | `app/broadcast/composer.py`, `app/security/validation.py` |
| 9 | Privilege escalation via admin panel | Every admin callback passes `AdminGuardMiddleware` (fails closed when the services container is missing); every mutating admin action writes an audit entry (actor, action, target, result) | `app/bot/middleware/auth.py`, `app/admin/audit.py` |
| 10 | Bot spamming groups (reputation/ToS risk) | Silent-group middleware drops every non-command group update before any handler; one editable Now Playing message per group | `app/bot/middleware/group_silent.py`, `app/groups/silent_mode.py` |

## 2. Secrets handling

- **Source of truth is the environment.** `app/config.py` reads `.env`
  (via pydantic-settings); nothing sensitive is hardcoded anywhere in the
  repository or the Docker image.
- **`.env` never ships.** `.gitignore` and `.dockerignore` both exclude it;
  the repository only contains `.env.example` with placeholder values.
- **The packaged ZIP contains no secrets.** The packaging script scans for
  token-shaped strings and refuses to include `.env`, `*.session`, or
  database files. Test fixtures use obviously dummy values
  (`123456789:AAAA…`).
- **Rotation.** Rotate `BOT_TOKEN` by editing `.env` and restarting — no
  database migration involved. Rotating `VOICE_SESSION_ENCRYPTION_KEY`
  requires re-adding voice accounts (existing ciphertext becomes
  undecryptable by design).

### Secret inventory

| Variable | Purpose | Rotation cost |
|----------|---------|---------------|
| `BOT_TOKEN` | Bot API identity | restart only |
| `TELEGRAM_API_ID` / `API_HASH` | MTProto app credentials (voice accounts) | re-login voice accounts |
| `VOICE_SESSION_ENCRYPTION_KEY` | Fernet key for session strings at rest | re-add all voice accounts |
| `DATABASE_URL` | PostgreSQL DSN (may embed password) | restart only |
| `REDIS_URL` | Redis DSN (may embed password) | restart only |
| `JAMENDO_CLIENT_ID` | Music source API key | restart only |

## 3. Deployment checklist

Before exposing the bot to real users:

- [ ] `BOT_TOKEN` set from @BotFather; bot username recorded.
- [ ] `ADMIN_IDS` contains **your** Telegram user id (numeric).
- [ ] `DATABASE_URL` points at PostgreSQL over the private network — not a
      publicly exposed port; credentials not in the URL when scraped logs
      are enabled.
- [ ] `VOICE_SESSION_ENCRYPTION_KEY` generated fresh
      (`python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`),
      never shared between environments.
- [ ] Redis requires a password when reachable from other hosts.
- [ ] `STORAGE_DIR` is on a volume with a size limit; the broadcast and
      download directories cannot grow unbounded (cleanup jobs run on
      schedule — verify `workers` role is running).
- [ ] Docker images built from the included `Dockerfile` (non-root user,
      pinned base); no host network mode needed.
- [ ] The `GET /health` endpoint (`HEALTH_PORT`) is reachable only from
      your monitoring/ingress, not the public internet.
- [ ] Admin panel tested with a **non-admin** account: every `adm:` button
      must show the denial alert (fails closed).

## 4. What is intentionally *not* protected against

- **DRM circumvention — not supported, by design.** The bot only plays
  sources you are authorized to use: your local catalog, Creative-Commons
  Jamendo, public-API Audius, and direct links you control. There is no
  code path that rips protected streams; feature requests in that direction
  are out of scope.
- **A compromised host.** If an attacker can read the process memory or the
  `.env` file, the Fernet key and tokens are theirs. Standard host hardening
  applies.
- **Malicious PostgreSQL/Redis instances.** The app trusts its own
  infrastructure services.
- **Telegram-side account bans.** Voice accounts are real user accounts and
  must follow Telegram ToS; the multi-account pool is for *capacity*, not
  for evading enforcement. Keep session counts within sane limits
  (default cap 5 per account).

## 5. Reporting a vulnerability

Please report privately to the repository maintainer (see the contact in
`README.md`). Include:

1. Affected component and file (if known).
2. Steps to reproduce, ideally as a failing test.
3. Impact assessment and any mitigations you suggest.

Do **not** open a public issue with exploitable details. Reports about the
music sources' own APIs should go to those providers directly.

## 6. Verification

The security-critical behaviors are covered by automated tests so they
cannot silently regress:

- `tests/test_music_urls.py` — SSRF matrix (private ranges, loopback,
  link-local, DNS rebinding style resolution checks, scheme allowlist,
  callback grammar).
- `tests/test_storage.py` — path traversal matrix.
- `tests/test_silent_mode.py` — full silent-group gate matrix.
- `tests/test_permissions.py` — group permission model.
- `tests/test_handlers_smoke.py` — admin guard fails closed.
- `tests/test_config.py` — configuration validation (no token, bad values).

Run them all: `python3 -m pytest` (no network required).

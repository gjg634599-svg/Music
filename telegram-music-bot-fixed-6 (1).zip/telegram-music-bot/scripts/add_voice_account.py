#!/usr/bin/env python3
"""Add a voice account to the Telegram Music Bot (server-side CLI).

Performs an interactive Telethon login with the given phone number using the
SAME :class:`~app.voice.login.VoiceLoginService` the Telegram admin wizard
uses (Admin Panel → Voice Engine → Add Account), so both paths share
validation, encryption, duplicate detection, persistence and cleanup
behaviour. The exported session is encrypted with the configured Fernet key
and stored as a ``voice_accounts`` row.

Usage:
    python scripts/add_voice_account.py --label "Account 1" --phone +989123456789
    python scripts/add_voice_account.py --label "Backup" --phone +98... \
        --max-sessions 3 --priority 10

Requirements (server .env):
    TELEGRAM_API_ID, TELEGRAM_API_HASH  — my.telegram.org credentials
    VOICE_SESSION_ENCRYPTION_KEY        — Fernet key
        (generate: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")

The session string is transmitted nowhere except into the encrypted database
column — it is never printed, never logged.

Exit codes:
    0  success
    2  bot/voice configuration incomplete
    3  telethon not installed
    4  login or database failure
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

# Allow running from any working directory (repo root = parent of scripts/).
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import ConfigError, load_settings  # noqa: E402
from app.logging import get_logger, setup_logging  # noqa: E402
from app.voice.login import (  # noqa: E402
    LoginState,
    VoiceLoginService,
    mask_phone,
    normalize_phone,
)

logger = get_logger(__name__)

EXIT_OK = 0
EXIT_CONFIG = 2
EXIT_NO_TELETHON = 3
EXIT_LOGIN_FAILED = 4


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="add_voice_account.py",
        description=(
            "Add a Telegram user account to the bot's voice engine.\n\n"
            "Runs an interactive login (code from the Telegram app, plus the "
            "2FA password when enabled) through the same login service as "
            "the Telegram admin wizard, encrypts the session with the "
            "VOICE_SESSION_ENCRYPTION_KEY Fernet key and saves it to the "
            "database.\n\n"
            "Prefer the in-chat wizard (Admin Panel → Voice Engine → Add "
            "Account); this CLI is the server-side fallback."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  python scripts/add_voice_account.py --label 'Account 1' --phone +989123456789\n"
            "  python scripts/add_voice_account.py --label 'Backup' --phone +15551234567 "
            "--max-sessions 3 --priority 10\n"
        ),
    )
    parser.add_argument(
        "--label", default="", help="Display label for the account (default: auto 'Account N')"
    )
    parser.add_argument(
        "--phone", required=True, help="Phone number in international format (e.g. +989123456789)"
    )
    parser.add_argument(
        "--max-sessions",
        type=int,
        default=5,
        help="Maximum concurrent group voice sessions for this account (default: 5)",
    )
    parser.add_argument(
        "--priority",
        type=int,
        default=0,
        help="Assignment priority (higher = preferred, default: 0)",
    )
    return parser


async def run_login(args: argparse.Namespace, settings) -> int:
    """Interactive login → encrypted account row (shared wizard service)."""
    try:
        from telethon import TelegramClient  # noqa: F401
    except ImportError:
        print(
            "❌ telethon is not installed. Install voice dependencies first:\n"
            "   pip install telethon cryptg py-tgcalls",
            file=sys.stderr,
        )
        return EXIT_NO_TELETHON

    if settings.telegram_api_id is None or not settings.telegram_api_hash:
        print("❌ TELEGRAM_API_ID / TELEGRAM_API_HASH are not configured.", file=sys.stderr)
        return EXIT_CONFIG

    from app.database.engine import Database
    from app.security.encryption import get_cipher

    cipher = get_cipher(settings.voice.encryption_key)
    if cipher is None:
        print(
            "❌ VOICE_SESSION_ENCRYPTION_KEY is not configured.",
            file=sys.stderr,
        )
        return EXIT_CONFIG

    try:
        phone = normalize_phone(args.phone)
    except Exception as exc:  # noqa: BLE001 — CLI boundary
        print(f"❌ Invalid phone number: {exc}", file=sys.stderr)
        return EXIT_LOGIN_FAILED

    db = Database(settings.database_url)
    try:
        # Demo/SQLite deployments may not have run migrations yet; create_all
        # is check-first and a no-op on already-migrated databases.
        await db.create_all()
        service = VoiceLoginService(settings, db.sessionmaker(), cipher)

        # Drive the same state machine the Telegram wizard drives.
        admin_key = 0  # CLI pseudo-admin (no Telegram admin involved).
        began = await service.begin(
            admin_key,
            label=args.label,
            max_sessions=args.max_sessions,
            priority=args.priority,
        )
        if not began.ok:
            print(f"❌ {began.message}", file=sys.stderr)
            return EXIT_CONFIG

        print(f"📞 Sending login code to {mask_phone(phone)} ...")
        phone_result = await service.submit_phone(admin_key, phone, label=args.label)
        if not phone_result.ok:
            print(f"❌ {phone_result.message}", file=sys.stderr)
            return EXIT_LOGIN_FAILED

        code = input("Login code: ").strip()
        result = await service.submit_code(admin_key, code)
        while result.state is LoginState.WAITING_FOR_2FA:
            from getpass import getpass

            password = getpass("2FA password: ")
            result = await service.submit_password(admin_key, password)

        if result.state is not LoginState.COMPLETED:
            print(f"❌ {result.message}", file=sys.stderr)
            return EXIT_LOGIN_FAILED

        logger.info(
            "cli.voice_account_added",
            extra={"account_id": result.account_id},
        )
        print(
            f"✅ Voice account #{result.account_id} added "
            f"(Telegram ID {result.telegram_id}, "
            f"@{result.username or '—'}). "
            "The bot reloaded its account pool automatically."
        )
        return EXIT_OK
    except Exception as exc:  # noqa: BLE001 — CLI boundary
        print(f"❌ Login failed: {str(exc)[:200]}", file=sys.stderr)
        return EXIT_LOGIN_FAILED
    finally:
        try:
            await service.cancel(0)  # ensure any half-open client is closed
        except Exception:  # noqa: BLE001
            pass
        try:
            await db.dispose()
        except Exception:  # noqa: BLE001
            pass


async def async_main(args: argparse.Namespace) -> int:
    """Load settings, validate voice configuration, run the login flow."""
    try:
        settings = load_settings()
    except ConfigError as exc:
        print(f"❌ Configuration error: {exc}", file=sys.stderr)
        return EXIT_CONFIG

    if not settings.voice_enabled:
        print(
            "❌ The voice engine is not configured.\n\n"
            "Set these in your environment or .env:\n"
            "  TELEGRAM_API_ID / TELEGRAM_API_HASH — from https://my.telegram.org\n"
            "  VOICE_SESSION_ENCRYPTION_KEY — Fernet key, generate with:\n"
            '    python -c "from cryptography.fernet import Fernet; '
            'print(Fernet.generate_key().decode())"\n',
            file=sys.stderr,
        )
        return EXIT_CONFIG

    return await run_login(args, settings)


def main() -> int:
    """CLI entry point."""
    setup_logging()
    args = build_parser().parse_args()
    return asyncio.run(async_main(args))


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Seed the catalog with synthesized demo tracks (server-side CLI).

Generates ten short demo tracks with ffmpeg (sine + tremolo — varied
frequency/tempo/duration), one artwork PNG per track, and registers three
artists, one compilation album ("Demo Sessions"), three genres and the ten
tracks in the database. The bot then works out of the box: search finds the
demo catalog, playback streams the local files, recommendations have varied
popularity/tempo/genre data to chew on.

Usage:
    python scripts/seed_catalog.py                       # settings DATABASE_URL
    python scripts/seed_catalog.py --db "sqlite+aiosqlite:///./storage/musicbot.db"
    python scripts/seed_catalog.py --force               # re-create demo content

Idempotency: tracks are keyed by ``source='local', source_id='demo-<slug>'``;
an already-seeded track is skipped (its audio file is re-synthesized only
when missing from disk). ``--force`` deletes all demo tracks (rows + files)
first, then regenerates everything.

Files land in the configured storage directory (default ``storage/``):
``music/demo-<slug>.mp3`` and ``artwork/demo-<slug>.png``.

Exit codes:
    0  success (created, skipped or nothing to do)
    2  configuration / environment error
    3  ffmpeg synthesis failure
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from dataclasses import dataclass
from pathlib import Path

# Allow running from any working directory (repo root = parent of scripts/).
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import delete, func, select  # noqa: E402

from app.audio.ffmpeg import FFmpegToolkit  # noqa: E402
from app.config import ConfigError, Settings, load_settings  # noqa: E402
from app.database.engine import Database  # noqa: E402
from app.database.models import Artist, Track  # noqa: E402
from app.database.repositories.music import (  # noqa: E402
    AlbumRepository,
    ArtistRepository,
    GenreRepository,
    TrackRepository,
)
from app.logging import get_logger  # noqa: E402
from app.music.normalizer import normalize_text  # noqa: E402

logger = get_logger(__name__)

EXIT_OK = 0
EXIT_CONFIG = 2
EXIT_SYNTH_FAILED = 3

DEMO_SOURCE = "local"
DEMO_SOURCE_PREFIX = "demo-"
ALBUM_TITLE = "Demo Sessions"


@dataclass(frozen=True, slots=True)
class DemoTrack:
    """Specification of one synthesized demo track."""

    title: str
    artist: str
    genre: str
    freq: int  # Hz, 220..880
    tempo: int  # BPM, 90..140
    duration: int  # seconds, 20..40
    popularity: int
    color: str  # artwork base color (ffmpeg hex)

    @property
    def slug(self) -> str:
        return normalize_text(self.title).replace(" ", "-") or "track"

    @property
    def source_id(self) -> str:
        return f"{DEMO_SOURCE_PREFIX}{self.slug}"

    @property
    def audio_name(self) -> str:
        return f"{DEMO_SOURCE_PREFIX}{self.slug}.mp3"

    @property
    def artwork_name(self) -> str:
        return f"{DEMO_SOURCE_PREFIX}{self.slug}.png"


#: The ten mandated demo tracks (artists: Skyline Circuit 4, Neon Bureau 3,
#: Velocity Club 3; genres: synthwave / electronic / ambient).
TRACKS: tuple[DemoTrack, ...] = (
    DemoTrack("Neon Dawn", "Skyline Circuit", "synthwave", 220, 96, 22, 88, "0x1DB954"),
    DemoTrack("Midnight Drive", "Skyline Circuit", "synthwave", 294, 104, 26, 74, "0x0FA3B1"),
    DemoTrack("Sunset Boulevard", "Skyline Circuit", "electronic", 349, 112, 30, 62, "0xF2A104"),
    DemoTrack("Electric Skyline", "Skyline Circuit", "synthwave", 440, 120, 34, 90, "0x8E44AD"),
    DemoTrack("Velvet Echo", "Neon Bureau", "ambient", 523, 90, 24, 55, "0x5C6BC0"),
    DemoTrack("Crystal Rain", "Neon Bureau", "ambient", 587, 92, 28, 48, "0x26A69A"),
    DemoTrack("Urban Pulse", "Neon Bureau", "electronic", 659, 136, 32, 70, "0xEF6C00"),
    DemoTrack("Aurora Waves", "Velocity Club", "ambient", 698, 94, 20, 66, "0x7E57C2"),
    DemoTrack("Synth Horizon", "Velocity Club", "synthwave", 784, 118, 36, 82, "0xD81B60"),
    DemoTrack("Chrome Dreams", "Velocity Club", "electronic", 880, 140, 40, 58, "0x455A64"),
)


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="seed_catalog.py",
        description=(
            "Seed the database with a synthesized demo catalog "
            "(10 tracks / 3 artists / 1 album / 3 genres + artwork).\n\n"
            "Audio is generated locally with ffmpeg — no network access needed."
        ),
    )
    parser.add_argument(
        "--db",
        dest="database_url",
        default=None,
        help="Database URL override (default: DATABASE_URL from settings, "
        "e.g. sqlite+aiosqlite:///./storage/musicbot.db).",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Delete existing demo tracks (rows and files) before re-seeding.",
    )
    return parser


def _load_settings_for_seed() -> Settings:
    """Load app settings, tolerating an unconfigured bot environment.

    Seeding only needs the ffmpeg paths and the storage directory; a missing
    BOT_TOKEN (or a foreign DATABASE_URL in the shell) must not block a
    database bootstrap, so ConfigError falls back to pure defaults.
    """
    try:
        return load_settings()
    except ConfigError as exc:
        print(f"[seed] note: using default settings for bootstrap ({exc})")
        return Settings()


async def _delete_demo_tracks(sessions, music_dir: Path, artwork_dir: Path) -> int:
    """Remove every demo track row and its files.

    TrackRepository has no bulk delete (by design), and this is a maintenance
    CLI, so the delete runs on a raw session — documented exception to the
    repositories-only rule that binds the app runtime.
    """
    async with sessions() as session:
        result = await session.execute(
            delete(Track).where(
                Track.source == DEMO_SOURCE,
                Track.source_id.like(f"{DEMO_SOURCE_PREFIX}%"),
            )
        )
        await session.commit()
        removed = int(result.rowcount or 0)
    for directory in (music_dir, artwork_dir):
        if not directory.is_dir():
            continue
        for path in directory.glob(f"{DEMO_SOURCE_PREFIX}*"):
            try:
                path.unlink()
            except OSError:  # pragma: no cover - best effort
                logger.warning("seed.unlink_failed", extra={"path": str(path)})
    if removed:
        print(f"[seed] --force: removed {removed} existing demo track(s)")
    return removed


async def _counts(sessions) -> tuple[int, int]:
    """(demo tracks in DB, distinct artists among them)."""
    async with sessions() as session:
        track_count = int(
            await session.scalar(
                select(func.count(Track.id)).where(
                    Track.source == DEMO_SOURCE,
                    Track.source_id.like(f"{DEMO_SOURCE_PREFIX}%"),
                )
            )
            or 0
        )
        artist_count = int(
            await session.scalar(
                select(func.count(func.distinct(Track.artist_id))).where(
                    Track.source == DEMO_SOURCE,
                    Track.source_id.like(f"{DEMO_SOURCE_PREFIX}%"),
                )
            )
            or 0
        )
    return track_count, artist_count


def _existing_audio_path(storage_root: Path, file_path: str | None) -> Path | None:
    if not file_path:
        return None
    candidate = storage_root / file_path
    return candidate if candidate.is_file() else None


async def seed(database_url: str, settings: Settings, *, force: bool) -> int:
    """Run the seeding; returns the process exit code."""
    ffmpeg = FFmpegToolkit(settings)

    storage_root = Path(settings.storage_dir)
    music_dir = storage_root / "music"
    artwork_dir = storage_root / "artwork"
    music_dir.mkdir(parents=True, exist_ok=True)
    artwork_dir.mkdir(parents=True, exist_ok=True)

    database = Database(database_url)
    if database_url.startswith("sqlite"):
        # SQLite (demo) deployments create the schema here; PostgreSQL uses
        # `alembic upgrade head` and must already be migrated.
        await database.create_all()
    sessions = database.sessionmaker()

    tracks_repo = TrackRepository(sessions)
    artists_repo = ArtistRepository(sessions)
    albums_repo = AlbumRepository(sessions)
    genres_repo = GenreRepository(sessions)

    if force:
        await _delete_demo_tracks(sessions, music_dir, artwork_dir)

    artist_ids: dict[str, Artist] = {}
    created = skipped = artworks = 0
    album_id: int | None = None

    for spec in TRACKS:
        # -- catalog parents (idempotent upserts) --------------------------
        if spec.artist not in artist_ids:
            artist_ids[spec.artist] = await artists_repo.get_or_create(spec.artist)
        artist = artist_ids[spec.artist]
        genre = await genres_repo.get_or_create(spec.genre)
        await genres_repo.associate_artist(artist.id, [genre.id])

        existing = await tracks_repo.get_by_source(DEMO_SOURCE, spec.source_id)
        if existing is not None:
            # Idempotent re-run: keep the row, but repair a missing audio file.
            audio = _existing_audio_path(storage_root, existing.file_path)
            if audio is None:
                audio = await ffmpeg.synth_demo_track(
                    music_dir / spec.audio_name,
                    freq=spec.freq,
                    duration=spec.duration,
                    tempo=spec.tempo,
                )
                await tracks_repo.update(
                    existing.id,
                    file_path=audio.relative_to(storage_root).as_posix(),
                )
                print(f"[seed] repaired missing audio for {spec.title!r}")
            skipped += 1
            continue

        # -- audio + artwork ------------------------------------------------
        audio_path = await ffmpeg.synth_demo_track(
            music_dir / spec.audio_name,
            freq=spec.freq,
            duration=spec.duration,
            tempo=spec.tempo,
        )
        artwork_path = await ffmpeg.synth_artwork(
            artwork_dir / spec.artwork_name, color=spec.color
        )
        artworks += 1

        # One shared compilation album; artwork filled in on first creation.
        if album_id is None:
            album = await albums_repo.get_or_create(
                ALBUM_TITLE,
                artwork_url=artwork_path.relative_to(storage_root).as_posix(),
            )
            album_id = int(album.id)

        track = await tracks_repo.create(
            title=spec.title,
            artist_id=artist.id,
            album_id=album_id,
            duration_seconds=spec.duration,
            tempo=spec.tempo,
            popularity=spec.popularity,
            source=DEMO_SOURCE,
            source_id=spec.source_id,
            file_path=audio_path.relative_to(storage_root).as_posix(),
            artwork_url=artwork_path.relative_to(storage_root).as_posix(),
            is_playable=True,
        )
        await genres_repo.associate_track(track.id, [genre.id])
        created += 1
        print(
            f"[seed] + {spec.title} — {spec.artist} ({spec.genre}, "
            f"{spec.duration}s, {spec.tempo} BPM, {spec.freq} Hz)"
        )

    # -- summary ------------------------------------------------------------
    total_tracks, total_artists = await _counts(sessions)
    audio_files = sorted(music_dir.glob(f"{DEMO_SOURCE_PREFIX}*.mp3")) + sorted(
        music_dir.glob(f"{DEMO_SOURCE_PREFIX}*.m4a")
    )
    artwork_files = sorted(artwork_dir.glob(f"{DEMO_SOURCE_PREFIX}*.png"))
    await database.dispose()

    print()
    print("=" * 62)
    print("Demo catalog seeded")
    print("=" * 62)
    print(f"  created      : {created} track(s)")
    print(f"  skipped      : {skipped} track(s) (already present)")
    print(f"  db totals    : {total_tracks} demo tracks / {total_artists} artists")
    print(f"  album        : {ALBUM_TITLE!r}")
    print(f"  genres       : synthwave, electronic, ambient")
    print(f"  audio files  : {len(audio_files)} in {music_dir}/")
    print(f"  artwork      : {len(artwork_files)} PNG in {artwork_dir}/")
    print(f"  database     : {database_url}")
    print("=" * 62)

    if created + skipped == 0:
        print("[seed] nothing to do")
    return EXIT_OK


def main(argv: list[str] | None = None) -> int:
    """CLI entry point."""
    args = build_parser().parse_args(argv)
    settings = _load_settings_for_seed()
    database_url = args.database_url or settings.database_url
    if not database_url.startswith(("postgresql+asyncpg://", "sqlite+aiosqlite://")):
        print(
            "[seed] DATABASE_URL must be postgresql+asyncpg:// or "
            f"sqlite+aiosqlite:// (got {database_url!r})",
            file=sys.stderr,
        )
        return EXIT_CONFIG
    try:
        return asyncio.run(seed(database_url, settings, force=args.force))
    except ConfigError as exc:
        print(f"[seed] configuration error: {exc}", file=sys.stderr)
        return EXIT_CONFIG
    except Exception as exc:  # noqa: BLE001 — CLI boundary
        print(f"[seed] failed: {exc}", file=sys.stderr)
        logger.error("seed.failed", extra={"error": str(exc)[:300]})
        return EXIT_SYNTH_FAILED


if __name__ == "__main__":
    raise SystemExit(main())

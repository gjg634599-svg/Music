#!/usr/bin/env bash
# ============================================================
# Telegram Music Bot — local development setup
#
# What it does:
#   1. Verifies Python 3.12+ is available
#   2. Creates a virtualenv (.venv) if missing
#   3. Installs requirements.txt into it
#   4. Copies .env.example -> .env if missing
#   5. Generates VOICE_SESSION_ENCRYPTION_KEY into .env if empty
#
# Run it with:
#   bash scripts/dev_setup.sh        (or: chmod +x scripts/dev_setup.sh
#                                     once, then ./scripts/dev_setup.sh)
# ============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${REPO_ROOT}"

# ------------------------------------------------------------
# 1. Find a Python >= 3.12
# ------------------------------------------------------------
find_python() {
    local candidate
    for candidate in python3.13 python3.12 python3; do
        if command -v "${candidate}" >/dev/null 2>&1; then
            if "${candidate}" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)'; then
                printf '%s\n' "${candidate}"
                return 0
            fi
        fi
    done
    return 1
}

if ! PYTHON_BIN="$(find_python)"; then
    echo "ERROR: Python 3.12+ is required (found: $(python3 --version 2>&1 || echo 'none'))." >&2
    echo "Install Python 3.12+ from https://www.python.org/downloads/ and re-run." >&2
    exit 1
fi
echo "OK  using $("${PYTHON_BIN}" --version) ($("${PYTHON_BIN}" -c 'import sys; print(sys.executable)'))"

# ------------------------------------------------------------
# 2. Create the virtualenv if missing
# ------------------------------------------------------------
if [ ! -d .venv ]; then
    echo "==> Creating virtualenv .venv ..."
    "${PYTHON_BIN}" -m venv .venv
fi

# Works on POSIX and Git-Bash/WSL Windows venv layouts alike.
if [ -x .venv/bin/python ]; then
    VENV_PY=".venv/bin/python"
elif [ -x .venv/Scripts/python.exe ]; then
    VENV_PY=".venv/Scripts/python.exe"
elif [ -x .venv/Scripts/python ]; then
    VENV_PY=".venv/Scripts/python"
else
    echo "ERROR: .venv exists but no python interpreter was found inside it." >&2
    echo "       Remove the .venv directory and re-run this script." >&2
    exit 1
fi
echo "OK  virtualenv ready (${VENV_PY})"

# ------------------------------------------------------------
# 3. Install dependencies
# ------------------------------------------------------------
echo "==> Upgrading pip ..."
"${VENV_PY}" -m pip install --quiet --upgrade pip

echo "==> Installing requirements.txt ..."
"${VENV_PY}" -m pip install --quiet -r requirements.txt
echo "OK  dependencies installed"

# ------------------------------------------------------------
# 4. Create .env from the example if missing
# ------------------------------------------------------------
if [ ! -f .env ]; then
    echo "==> Creating .env from .env.example ..."
    cp .env.example .env
    echo "OK  .env created (edit it and set BOT_TOKEN!)"
fi

# ------------------------------------------------------------
# 5. Generate VOICE_SESSION_ENCRYPTION_KEY if empty
#    (only needed for the voice engine; harmless otherwise)
# ------------------------------------------------------------
if grep -q '^VOICE_SESSION_ENCRYPTION_KEY=..*' .env; then
    echo "OK  VOICE_SESSION_ENCRYPTION_KEY already set"
else
    echo "==> Generating VOICE_SESSION_ENCRYPTION_KEY (Fernet) ..."
    FERNET_KEY="$("${VENV_PY}" -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')"
    sed -i.bak "s|^VOICE_SESSION_ENCRYPTION_KEY=.*|VOICE_SESSION_ENCRYPTION_KEY=${FERNET_KEY}|" .env
    rm -f .env.bak
    echo "OK  VOICE_SESSION_ENCRYPTION_KEY written to .env"
fi

# ------------------------------------------------------------
# 6. Next steps
# ------------------------------------------------------------
cat <<'EOF'

Setup complete. Next steps:

  1. Activate the virtualenv:
       source .venv/bin/activate          # POSIX (Linux/macOS/WSL)
       .venv\Scripts\activate             # Windows (cmd/PowerShell)

  2. Edit .env and set at least:
       BOT_TOKEN=...        from @BotFather
       ADMIN_IDS=...        your Telegram user id(s), comma-separated

  3. Create the database schema:
       alembic upgrade head
     (No DATABASE_URL in .env? A local SQLite demo database is used.)

  4. Optional — seed a demo catalog so search has content:
       python scripts/seed_catalog.py

  5. Run the bot:
       python run.py                      # bot + workers in one process
       python run.py --role bot           # bot only
       python run.py --role worker        # background workers only

  6. Optional — voice chats (group playback): set TELEGRAM_API_ID /
     TELEGRAM_API_HASH in .env, then add a voice account ON THE SERVER:
       python scripts/add_voice_account.py --label "Account 1" --phone +15551234567

  Tests:  pytest
  Docker: cp .env.example .env && docker compose up -d --build
EOF

echo
echo "Done."

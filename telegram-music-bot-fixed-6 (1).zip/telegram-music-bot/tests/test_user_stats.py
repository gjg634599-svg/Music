"""Personal listening statistics (/mystats) — service + render tests.

Covers :class:`app.users.stats.UserStatsService` end to end on the seeded
in-memory catalog: aggregation correctness (totals, unique tracks, top
tracks, top artists, listening time), per-user scoping, the empty state,
graceful degradation when an aggregation fails, and the rendered HTML.
"""

from __future__ import annotations

import pytest

from app.errors import ValidationError
from app.users.stats import (
    TOP_ARTISTS_LIMIT,
    TOP_TRACKS_LIMIT,
    UserStats,
    UserStatsService,
)

from .conftest import build_services


def _fmt_duration(seconds: int) -> str:
    return UserStats(tg_user_id=1, listening_seconds=seconds).listening_time_label


class TestUserStatsService:
    async def test_unknown_user_rejected(self, services, db_setup) -> None:
        with pytest.raises(ValidationError):
            await services.stats.build(555)

    async def test_empty_user_renders_friendly_state(
        self, services, db_setup
    ) -> None:
        text = await services.stats.render(db_setup.tg_101)

        assert "MY LISTENING STATS" in text
        assert "Nothing here yet" in text
        assert "Top tracks" not in text

    async def test_totals_and_top_tracks(self, services, db_setup) -> None:
        a = db_setup.track_ids_by_title["Neon Sunrise"]
        b = db_setup.track_ids_by_title["Popular Anthem"]
        c = db_setup.track_ids_by_title["Velvet Night"]

        # Neon Sunrise ×3, Popular Anthem ×2, Velvet Night ×1
        for track_id, times, seconds in ((a, 3, 30), (b, 2, 128), (c, 1, 90)):
            for _ in range(times):
                await services.history_service.record(
                    db_setup.tg_101, track_id, duration_played=seconds
                )

        stats = await services.stats.build(db_setup.tg_101)

        assert stats.total_plays == 6
        assert stats.unique_tracks == 3
        assert stats.listening_seconds == 3 * 30 + 2 * 128 + 90
        assert [track.title for track, _ in stats.top_tracks] == [
            "Neon Sunrise",
            "Popular Anthem",
            "Velvet Night",
        ]
        assert stats.top_tracks[0][1] == 3
        assert len(stats.top_artists) == 1  # all seeded tracks share one artist
        assert stats.top_artists[0][1] == 6

    async def test_render_contains_headers_and_escapes(
        self, services, db_setup
    ) -> None:
        a = db_setup.track_ids_by_title["Static Bloom"]
        await services.history_service.record(
            db_setup.tg_101, a, completed=True, duration_played=132
        )

        text = await services.stats.render(db_setup.tg_101)

        assert "📊 <b>MY LISTENING STATS</b>" in text
        assert "1</b> plays" in text
        assert "Static Bloom" in text
        assert "Top artists" in text
        assert "2m 12s" in text  # 132 s label
        assert _fmt_duration(132) == "2m 12s"

    async def test_stats_are_per_user(self, services, db_setup) -> None:
        a = db_setup.track_ids_by_title["Rainy Digits"]
        await services.history_service.record(db_setup.tg_101, a, duration_played=85)

        mine = await services.stats.build(db_setup.tg_101)
        theirs = await services.stats.build(db_setup.tg_102)

        assert mine.total_plays == 1
        assert theirs.total_plays == 0
        assert theirs.is_empty is True

    async def test_liked_count_feeds_empty_state(self, services, db_setup) -> None:
        """A user with only likes (no plays) is NOT the empty state."""
        a = db_setup.track_ids_by_title["Crystal Meadow"]
        await services.library.toggle_like(db_setup.tg_101, a)

        stats = await services.stats.build(db_setup.tg_101)

        assert stats.is_empty is False
        assert stats.liked_count == 1
        assert stats.total_plays == 0

        text = await services.stats.render(db_setup.tg_101)
        assert "1</b> liked" in text

    async def test_top_tracks_limit_is_five(self, services, db_setup) -> None:
        for track_id in db_setup.track_ids:  # 8 distinct tracks
            await services.history_service.record(
                db_setup.tg_101, track_id, duration_played=10
            )

        stats = await services.stats.build(db_setup.tg_101)

        assert stats.unique_tracks == 8
        assert len(stats.top_tracks) == TOP_TRACKS_LIMIT
        # Ties are broken deterministically by ascending track id.
        ids = [track.id for track, _ in stats.top_tracks]
        assert ids == sorted(ids)

    async def test_top_artists_limit_and_ordering(
        self, services, db_setup, mk_sessions
    ) -> None:
        """Second artist is created on the fly; ordering must follow plays."""
        from app.database.models.music import Track
        from app.database.repositories.music import ArtistRepository
        from app.music.normalizer import normalize_text

        artist_repo = ArtistRepository(mk_sessions)
        second = await artist_repo.get_or_create("Second Artist")

        async with mk_sessions() as session:
            session.add(
                Track(
                    title="Second Artist Hit",
                    normalized_title=normalize_text("Second Artist Hit"),
                    artist_id=int(second.id),
                    duration_seconds=200,
                    popularity=50,
                    source="local",
                    source_id="stats-second-1",
                    is_playable=True,
                )
            )
            await session.commit()

        hit = await services.tracks_repo.get_by_source("local", "stats-second-1")
        assert hit is not None

        seeded = db_setup.track_ids_by_title["Neon Sunrise"]
        # Second artist's track played 2×, seeded artist's 1×.
        await services.history_service.record(db_setup.tg_101, int(hit.id))
        await services.history_service.record(db_setup.tg_101, int(hit.id))
        await services.history_service.record(db_setup.tg_101, seeded)

        stats = await services.stats.build(db_setup.tg_101)
        names = await services.stats._artist_names(  # noqa: SLF001 - test hook
            [artist_id for artist_id, _ in stats.top_artists]
        )

        assert len(stats.top_artists) == 2
        assert stats.top_artists[0][0] == int(second.id)
        assert names[stats.top_artists[0][0]] == "Second Artist"

    async def test_aggregation_failure_degrades_gracefully(
        self, services, db_setup
    ) -> None:
        """A broken repo method must not take the whole screen down."""
        a = db_setup.track_ids_by_title["Neon Sunrise"]
        await services.history_service.record(db_setup.tg_101, a, duration_played=30)

        class BrokenHistory:
            """Every method raises — only used for this test."""

            async def count_for_user(self, user_db_id: int) -> int:
                raise RuntimeError("boom-count")

            async def play_counts(self, user_db_id: int, limit: int = 200):
                raise RuntimeError("boom-plays")

            async def artist_play_counts(self, user_db_id: int):
                raise RuntimeError("boom-artists")

            async def listening_seconds(self, user_db_id: int) -> int:
                raise RuntimeError("boom-seconds")

            async def recent(self, user_db_id: int, limit: int = 20):
                raise RuntimeError("boom-recent")

        broken = UserStatsService(
            BrokenHistory(),
            services.liked_repo,
            services.tracks_repo,
            services.artists_repo,
            services.users_repo,
        )

        stats = await broken.build(db_setup.tg_101)

        assert stats.total_plays == 0
        assert stats.listening_seconds == 0
        assert stats.top_tracks == []
        assert stats.top_artists == []

        text = broken.format(stats, {})
        assert "MY LISTENING STATS" in text  # still renders

    async def test_missing_track_hydration_skipped(self, services, db_setup) -> None:
        """Deleted tracks vanish from play_counts → hydration skips them."""
        a = db_setup.track_ids_by_title["Circuit Breaker"]
        await services.history_service.record(db_setup.tg_101, a)

        stats = await services.stats.build(db_setup.tg_101)
        assert len(stats.top_tracks) == 1

        class _VanishingTracks:
            async def get_by_id(self, track_id: int):
                return None

        service = UserStatsService(
            services.history_repo,
            services.liked_repo,
            _VanishingTracks(),
            services.artists_repo,
            services.users_repo,
        )
        rebuilt = await service.build(db_setup.tg_101)
        assert rebuilt.top_tracks == []
        assert rebuilt.total_plays == 1  # totals unaffected

    async def test_listening_time_labels(self) -> None:
        assert _fmt_duration(0) == "0s"
        assert _fmt_duration(59) == "59s"
        assert _fmt_duration(60) == "1m 00s"
        assert _fmt_duration(125) == "2m 05s"
        assert _fmt_duration(3725) == "1h 02m"

    async def test_top_artists_limit_constant(self) -> None:
        assert TOP_ARTISTS_LIMIT == 3
        assert TOP_TRACKS_LIMIT == 5


class TestStatsServiceWiring:
    async def test_build_services_exposes_stats(
        self, db_setup, mk_sessions
    ) -> None:
        bundle = build_services(mk_sessions)
        assert isinstance(bundle.stats, UserStatsService)

        text = await bundle.stats.render(db_setup.tg_101)
        assert "MY LISTENING STATS" in text


__all__ = ["TestStatsServiceWiring", "TestUserStatsService"]

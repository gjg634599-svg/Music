"""FFmpegToolkit tests against the REAL ffmpeg binary (skipped when absent).

Covers synthetic demo-track generation, probing and voice-format conversion —
the exact operations ``scripts/seed_catalog.py`` relies on.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from app.audio.ffmpeg import FFmpegToolkit
from app.config import Settings
from app.errors import PlaybackError

FFMPEG_BIN = shutil.which("ffmpeg")
FFPROBE_BIN = shutil.which("ffprobe")

pytestmark = pytest.mark.skipif(
    FFMPEG_BIN is None or FFPROBE_BIN is None,
    reason="ffmpeg/ffprobe binaries not installed",
)


@pytest.fixture
def toolkit() -> FFmpegToolkit:
    return FFmpegToolkit(Settings(bot_token="123456789:" + "A" * 33))


@pytest.fixture
async def demo_track(toolkit: FFmpegToolkit, tmp_path: Path) -> Path:
    """A synthesized 3-second demo track (sine + tremolo)."""
    dst = tmp_path / "demo.mp3"
    path = await toolkit.synth_demo_track(dst, freq=440, duration=3, tempo=120)
    assert path.exists()
    return path


class TestSynthDemoTrack:
    async def test_file_created_and_non_trivial(
        self, toolkit: FFmpegToolkit, tmp_path: Path
    ) -> None:
        dst = tmp_path / "track.mp3"
        path = await toolkit.synth_demo_track(dst, freq=330, duration=2, tempo=100)
        assert path.exists()
        assert path.stat().st_size > 1000  # not a stub file
        # Either the requested mp3 or the AAC fallback container.
        assert path.suffix in {".mp3", ".m4a"}

    async def test_longer_track_is_bigger(
        self, toolkit: FFmpegToolkit, tmp_path: Path
    ) -> None:
        short = await toolkit.synth_demo_track(
            tmp_path / "short.mp3", freq=440, duration=2, tempo=120
        )
        long = await toolkit.synth_demo_track(
            tmp_path / "long.mp3", freq=440, duration=10, tempo=120
        )
        assert long.stat().st_size > short.stat().st_size


class TestProbe:
    async def test_probe_reports_format_and_streams(
        self, toolkit: FFmpegToolkit, demo_track: Path
    ) -> None:
        data = await toolkit.probe(demo_track)
        assert "format" in data and "streams" in data
        assert any(stream.get("codec_type") == "audio" for stream in data["streams"])

    async def test_duration_at_least_two_seconds(
        self, toolkit: FFmpegToolkit, demo_track: Path
    ) -> None:
        meta = await toolkit.probe_metadata(demo_track)
        assert int(meta["duration"]) >= 2

    async def test_extract_metadata_maps_to_dataclass(
        self, toolkit: FFmpegToolkit, demo_track: Path
    ) -> None:
        metadata = await toolkit.extract_metadata(demo_track)
        assert metadata.duration_seconds >= 2

    async def test_probe_missing_file_raises(
        self, toolkit: FFmpegToolkit, tmp_path: Path
    ) -> None:
        with pytest.raises(PlaybackError):
            await toolkit.probe(tmp_path / "missing.mp3")


class TestVoiceFormat:
    async def test_converts_to_opus_48k(
        self, toolkit: FFmpegToolkit, demo_track: Path, tmp_path: Path
    ) -> None:
        dst = tmp_path / "voice.opus"
        path = await toolkit.to_voice_format(demo_track, dst)
        assert path.exists() and path.stat().st_size > 1000

        data = await toolkit.probe(path)
        audio = next(s for s in data["streams"] if s.get("codec_type") == "audio")
        assert audio["codec_name"] == "opus"
        assert int(audio["sample_rate"]) == 48000
        assert int(audio["channels"]) == 2


class TestArtwork:
    async def test_synth_artwork_creates_image(
        self, toolkit: FFmpegToolkit, tmp_path: Path
    ) -> None:
        dst = tmp_path / "cover.png"
        path = await toolkit.synth_artwork(dst, color="0x1DB954")
        assert path.exists() and path.stat().st_size > 100

    async def test_thumbnail_absent_without_embedded_art(
        self, toolkit: FFmpegToolkit, demo_track: Path, tmp_path: Path
    ) -> None:
        """A bare synthesized track has no embedded artwork — must be None."""
        result = await toolkit.to_thumbnail(demo_track, tmp_path / "thumb.jpg")
        assert result is None

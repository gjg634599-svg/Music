"""Track-title normalization tests (app.music.normalizer)."""

from __future__ import annotations

from app.music.normalizer import clean_title, normalized_key, normalize_text


class TestNormalizeText:
    def test_lowercase_and_strip_punctuation(self) -> None:
        assert normalize_text("  Héllo   WORLD! ") == "hello world"

    def test_punctuation_becomes_spaces(self) -> None:
        assert normalize_text("Rock'n'Roll - Remastered") == "rock n roll remastered"

    def test_underscores_are_punctuation(self) -> None:
        assert normalize_text("track_name") == "track name"

    def test_empty_and_none_safe(self) -> None:
        assert normalize_text("") == ""

    def test_diacritics_removed(self) -> None:
        assert normalize_text("Béyoncé — Halo") == "beyonce halo"


class TestCleanTitle:
    def test_removes_official_video_suffix(self) -> None:
        assert clean_title("Believer (Official Video)") == "Believer"

    def test_removes_repeated_noise_suffixes(self) -> None:
        assert clean_title("Song (Official Video) [HD]") == "Song"

    def test_removes_dash_suffix(self) -> None:
        assert clean_title("Song - Official Audio") == "Song"

    def test_keeps_meaningful_segments(self) -> None:
        assert clean_title("Song (Live at Wembley)") == "Song (Live at Wembley)"

    def test_keeps_original_when_all_noise(self) -> None:
        assert clean_title("(Official Video)") == "(Official Video)"

    def test_empty(self) -> None:
        assert clean_title("") == ""
        assert clean_title(None) == ""


class TestNormalizedKey:
    def test_dedupe_across_noise_titles(self) -> None:
        a = normalized_key("Believer (Official Video)", "Imagine Dragons")
        b = normalized_key("believer", "imagine dragons")
        assert a == b

    def test_different_artists_differ(self) -> None:
        assert normalized_key("Halo", "A") != normalized_key("Halo", "B")

    def test_punctuation_and_case_insensitive(self) -> None:
        assert normalized_key("Héllo, World!", "Ärtist") == normalized_key(
            "hello world", "artist"
        )

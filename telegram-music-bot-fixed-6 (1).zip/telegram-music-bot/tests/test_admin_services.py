"""Admin services tests: permissions, appearance, buttons, settings, audit."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from app.admin.appearance import AppearanceService
from app.admin.audit import AuditService
from app.admin.buttons import ButtonService
from app.admin.permissions import PermissionService, Role
from app.admin.service import AdminService
from app.admin.settings import SettingsService
from app.database.repositories.admin import AdminRepository, AdminAuditLogRepository
from app.database.defaults import DEFAULT_BUTTONS
from app.database.repositories.settings import (
    BotAssetRepository,
    BotButtonRepository,
    BotMessageRepository,
    BotSettingsRepository,
)

from .conftest import build_services

ENV_ADMIN = 1  # super admin via env
DB_ADMIN = 2
DB_MODERATOR = 3
PLAIN_USER = 999


@pytest.fixture
async def admin_services(db_setup, mk_sessions):
    """The admin service facade on the seeded database."""
    admins_repo = AdminRepository(mk_sessions)
    audit_repo = AdminAuditLogRepository(mk_sessions)
    messages_repo = BotMessageRepository(mk_sessions)
    assets_repo = BotAssetRepository(mk_sessions)
    buttons_repo = BotButtonRepository(mk_sessions)
    settings_repo = BotSettingsRepository(mk_sessions)

    permissions = PermissionService(admins_repo, env_admin_ids=(ENV_ADMIN,))
    appearance = AppearanceService(messages_repo, assets_repo, buttons_repo)
    buttons = ButtonService(buttons_repo)
    settings = SettingsService(settings_repo)
    audit = AuditService(audit_repo)
    admin = AdminService(
        permission=permissions,
        appearance=appearance,
        buttons=buttons,
        settings=settings,
        statistics=SimpleNamespace(),  # not under test here
        audit=audit,
    )

    await admin.permissions.add_admin(DB_ADMIN, Role.ADMIN, added_by=ENV_ADMIN)
    await admin.permissions.add_admin(DB_MODERATOR, Role.MODERATOR, added_by=ENV_ADMIN)

    return SimpleNamespace(
        admin=admin,
        permissions=permissions,
        appearance=appearance,
        buttons=buttons,
        settings_service=settings,
        audit=audit,
        settings_repo=settings_repo,
        buttons_repo=buttons_repo,
    )


class TestPermissionService:
    async def test_env_super_admin_has_all(self, admin_services) -> None:
        assert await admin_services.permissions.role_of(ENV_ADMIN) is Role.SUPER_ADMIN
        for permission in ("users", "groups", "broadcast", "appearance", "buttons",
                           "voice", "settings", "stats", "roles", "maintenance"):
            assert await admin_services.permissions.has(ENV_ADMIN, permission) is True

    async def test_db_admin_limited(self, admin_services) -> None:
        assert await admin_services.permissions.role_of(DB_ADMIN) is Role.ADMIN
        assert await admin_services.permissions.has(DB_ADMIN, "broadcast") is True
        assert await admin_services.permissions.has(DB_ADMIN, "users") is True
        assert await admin_services.permissions.has(DB_ADMIN, "roles") is False
        assert await admin_services.permissions.has(DB_ADMIN, "maintenance") is False

    async def test_moderator_subset(self, admin_services) -> None:
        assert await admin_services.permissions.role_of(DB_MODERATOR) is Role.MODERATOR
        assert await admin_services.permissions.has(DB_MODERATOR, "users") is True
        assert await admin_services.permissions.has(DB_MODERATOR, "groups") is True
        assert await admin_services.permissions.has(DB_MODERATOR, "stats") is True
        assert await admin_services.permissions.has(DB_MODERATOR, "broadcast") is False
        assert await admin_services.permissions.has(DB_MODERATOR, "settings") is False

    async def test_non_admin_is_none(self, admin_services) -> None:
        assert await admin_services.permissions.role_of(PLAIN_USER) is None
        assert await admin_services.permissions.is_admin(PLAIN_USER) is False
        assert await admin_services.permissions.has(PLAIN_USER, "users") is False

    async def test_env_admin_cannot_be_demoted(self, admin_services) -> None:
        result = await admin_services.permissions.add_admin(
            ENV_ADMIN, Role.MODERATOR, added_by=ENV_ADMIN
        )
        assert result is None  # logged no-op
        assert await admin_services.permissions.role_of(ENV_ADMIN) is Role.SUPER_ADMIN

    async def test_env_admin_cannot_be_removed(self, admin_services) -> None:
        assert await admin_services.permissions.remove_admin(ENV_ADMIN) is False
        assert await admin_services.permissions.role_of(ENV_ADMIN) is Role.SUPER_ADMIN

    async def test_db_admin_can_be_removed(self, admin_services) -> None:
        assert await admin_services.permissions.remove_admin(DB_ADMIN) is True
        assert await admin_services.permissions.role_of(DB_ADMIN) is None

    async def test_list_admins(self, admin_services) -> None:
        admins = await admin_services.permissions.list_admins()
        assert {row.telegram_id for row in admins} == {DB_ADMIN, DB_MODERATOR}

    async def test_facade_require(self, admin_services) -> None:
        from app.errors import AdminAccessDeniedError

        await admin_services.admin.require(ENV_ADMIN, "roles")  # ok
        with pytest.raises(AdminAccessDeniedError):
            await admin_services.admin.require(DB_MODERATOR, "broadcast")


class TestAppearanceService:
    async def test_message_default_fallback(self, admin_services) -> None:
        text = await admin_services.appearance.message("start", name="Alice")
        assert "Alice" in text

    async def test_message_set_and_reset(self, admin_services) -> None:
        await admin_services.appearance.set_message(
            "start", "Hey {name}, welcome back!", updated_by=ENV_ADMIN
        )
        assert (
            await admin_services.appearance.message("start", name="Bob")
            == "Hey Bob, welcome back!"
        )

        assert await admin_services.appearance.reset_message("start") is True
        default = await admin_services.appearance.message("start", name="Bob")
        assert "Bob" in default and "welcome back" not in default

    async def test_logo_latest_wins(self, admin_services) -> None:
        await admin_services.appearance.set_logo("file-id-1", created_by=ENV_ADMIN)
        await admin_services.appearance.set_logo("file-id-2", created_by=ENV_ADMIN)

        logo = await admin_services.appearance.logo()
        assert logo is not None and logo.file_id == "file-id-2"

        assert await admin_services.appearance.remove_logo() >= 1
        assert await admin_services.appearance.logo() is None

    async def test_preview_start(self, admin_services) -> None:
        await admin_services.buttons.ensure_defaults()
        text, buttons = await admin_services.appearance.preview_start(name="Alice")
        assert "Alice" in text
        assert buttons  # enabled default buttons


class TestButtonService:
    async def test_ensure_defaults_idempotent(self, admin_services) -> None:
        # db_setup already seeded the 10 DEFAULT_BUTTONS exactly once …
        assert await admin_services.buttons.count() == len(DEFAULT_BUTTONS)
        # … so re-running ensure_defaults must be a no-op.
        assert await admin_services.buttons.ensure_defaults() == 0
        assert await admin_services.buttons.count() == len(DEFAULT_BUTTONS)

    async def test_render_keyboard_rows_of_two(self, admin_services) -> None:
        await admin_services.buttons.ensure_defaults()
        keyboard = await admin_services.buttons.render_keyboard(bot_username="mybot")

        rows = keyboard.inline_keyboard
        assert all(len(row) <= 2 for row in rows)
        assert sum(len(row) for row in rows) == len(DEFAULT_BUTTONS)
        assert len(rows) == -(-len(DEFAULT_BUTTONS) // 2)  # rows of two

    async def test_render_keyboard_add_group_deeplink(self, admin_services) -> None:
        await admin_services.buttons.ensure_defaults()
        keyboard = await admin_services.buttons.render_keyboard(bot_username="mybot")

        add_group_buttons = [
            button
            for row in keyboard.inline_keyboard
            for button in row
            if button.url and "startgroup" in button.url
        ]
        assert len(add_group_buttons) == 1
        assert add_group_buttons[0].url == "https://t.me/mybot?startgroup=true"

    async def test_create_toggle_move_delete(self, admin_services) -> None:
        await admin_services.buttons.ensure_defaults()  # 10 buttons at 10..90
        button = await admin_services.buttons.create(
            label="Extra", action="dash:help", button_type="callback"
        )
        assert button.position is not None

        moved = await admin_services.buttons.move(button.id, direction=-1)
        assert moved is not None and moved.position < button.position

        assert await admin_services.buttons.toggle(button.id, False) is True
        enabled = [
            b for b in await admin_services.buttons.list_buttons(enabled_only=True)
            if b.id == button.id
        ]
        assert enabled == []

        assert await admin_services.buttons.delete(button.id) is True


class TestSettingsService:
    async def test_autoplay_roundtrip(self, admin_services) -> None:
        assert await admin_services.settings_service.autoplay_enabled() is True
        await admin_services.settings_service.set_autoplay(False, updated_by=ENV_ADMIN)
        assert await admin_services.settings_service.autoplay_enabled() is False
        await admin_services.settings_service.set_autoplay(True, updated_by=ENV_ADMIN)
        assert await admin_services.settings_service.autoplay_enabled() is True

    async def test_maintenance_roundtrip(self, admin_services) -> None:
        await admin_services.settings_service.set_maintenance(
            enabled=True, groups_continue=True, updated_by=ENV_ADMIN
        )
        state = await admin_services.settings_service.maintenance()
        assert state["enabled"] is True
        assert state["groups_continue"] is True

        await admin_services.settings_service.set_maintenance(
            enabled=False, groups_continue=False, updated_by=ENV_ADMIN
        )
        state = await admin_services.settings_service.maintenance()
        assert state["enabled"] is False

    async def test_recommendation_weights_shape(self, admin_services) -> None:
        weights = await admin_services.settings_service.recommendation_weights()
        assert isinstance(weights, dict)
        assert weights["artist_similarity"] == 1.5

    async def test_get_set_generic(self, admin_services) -> None:
        await admin_services.settings_service.set("features", {"url_processing": False},
                                                  updated_by=ENV_ADMIN)
        assert await admin_services.settings_service.get("features") == {
            "url_processing": False
        }
        assert await admin_services.settings_service.get("missing_key", "dflt") == "dflt"


class TestAuditService:
    async def test_recent_newest_first(self, admin_services) -> None:
        await admin_services.audit.log(ENV_ADMIN, "settings.autoplay", result="ok")
        await admin_services.audit.log(ENV_ADMIN, "broadcast.start", details={"id": 5})

        rows = await admin_services.audit.recent(limit=10)
        assert len(rows) == 2
        assert rows[0].action == "broadcast.start"
        assert rows[1].action == "settings.autoplay"
        assert await admin_services.audit.count() == 2
        by_action = await admin_services.audit.by_action("broadcast.start")
        assert len(by_action) == 1

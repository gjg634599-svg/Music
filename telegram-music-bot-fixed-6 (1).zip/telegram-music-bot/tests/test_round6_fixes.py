"""Round 6 regression tests — the 2026-10 audit fixes.

Covers, with real components and fakes following the suite's conventions:

* **Critical bug A** — a queued group track must actually start playback:
  startup recovery of stale playing/paused sessions, the failure-path
  reset + bounded requeue policy, and the live-voice cross-check that
  corrects a stale persisted status at enqueue time.
* **Critical bug B** — DM→group flow ordering: group access (auto-join) is
  verified BEFORE the active-voice-chat check.
* Volume scale consistency (human percent 0-100 → engine 0-200).
* Completed download-cache cleanup (age, protection, symlinks, scope).
* Group command auto-delete middleware (recognized commands only).
* The live progress ticker (edits, cancellation, disabled state).
* ``Up next`` rendering on the group Now Playing message.
* New configuration parsing and validation.
"""

from __future__ import annotations

import asyncio
import os
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from app.errors import DownloadError, VoiceChatMissingError
from app.playback.controller import PlaybackController
from app.playback.events import EventBus
from app.playback.queue import QueueOwner, QueueManager
from app.playback.session import SessionManager
from app.recommendation.engine import RecommendationEngine
from app.playback.autoplay import AutoplayService

from .conftest import build_services

from .test_playback_controller import (
    FakeAnalyticsRecorder,
    FakeBot,
    FakeHistoryGateway,
    FakeMusicGateway,
    FakeVoiceGateway,
)


# ---------------------------------------------------------------------------
# Shared bundle (mirrors test_playback_controller's, with extra knobs)
# ---------------------------------------------------------------------------
class ScriptedVoiceGateway(FakeVoiceGateway):
    """VoiceGateway fake whose ``play`` follows a scripted result list.

    ``play_results`` entries: ``None`` (success), an ``Exception`` instance
    (raised), or ``"stale"`` (succeeds but reports no live lease via
    ``is_active`` — used to simulate a released session).
    """

    def __init__(self, *, enabled: bool = True, active_groups: set[int] | None = None):
        super().__init__(enabled=enabled)
        self.play_results: list[Any] = []
        #: Groups reported as having a live voice lease by ``is_active``.
        self.active_groups: set[int] = set(
            active_groups if active_groups is not None else {-100999}
        )
        self.is_active_calls: list[int] = []

    async def play(self, group_tg_id: int, path: Path) -> None:
        result = self.play_results.pop(0) if self.play_results else None
        if isinstance(result, Exception):
            raise result
        await super().play(group_tg_id, path)
        self.active_groups.add(group_tg_id)

    async def release(self, group_tg_id: int) -> None:
        await super().release(group_tg_id)
        self.active_groups.discard(group_tg_id)

    async def is_active(self, group_tg_id: int) -> bool:
        self.is_active_calls.append(group_tg_id)
        return group_tg_id in self.active_groups


async def _make_bundle(
    db_setup, mk_sessions, tmp_path, *, progress_interval: float = 0, **voice_kwargs
):
    services = build_services(mk_sessions)
    events = EventBus()
    queue = QueueManager(services.queue_repo, services.tracks_repo, events)
    sessions = SessionManager(services.sessions_repo, services.tracks_repo, events)
    engine = RecommendationEngine(
        services.tracks_repo, services.profiles, services.settings_repo, services.cache
    )
    autoplay = AutoplayService(engine, queue, services.analytics_repo)
    music = FakeMusicGateway(services.tracks_repo, tmp_path)
    voice = ScriptedVoiceGateway(**voice_kwargs)
    bot = FakeBot()
    controller = PlaybackController(
        queue=queue,
        autoplay=autoplay,
        music=music,
        voice=voice,
        sessions=sessions,
        events=events,
        analytics=FakeAnalyticsRecorder(),
        history=FakeHistoryGateway(),
        autoplay_enabled=None,
        default_autoplay=False,
        progress_edit_interval=progress_interval,
    )
    bundle = SimpleNamespace(
        services=services,
        events=events,
        queue=queue,
        sessions=sessions,
        controller=controller,
        music=music,
        voice=voice,
        bot=bot,
    )
    try:
        yield bundle
    finally:
        await controller.cleanup()


@pytest.fixture
async def bundle(db_setup, mk_sessions, tmp_path):
    async for value in _make_bundle(db_setup, mk_sessions, tmp_path):
        yield value


@pytest.fixture
def group_owner() -> QueueOwner:
    return QueueOwner(kind="group", id=-100999)


# ---------------------------------------------------------------------------
# Critical bug A — startup recovery of stale sessions
# ---------------------------------------------------------------------------
class TestStartupRecovery:
    async def test_playing_sessions_reset_to_stopped(
        self, db_setup, mk_sessions, tmp_path
    ) -> None:
        services = build_services(mk_sessions)
        sessions = SessionManager(services.sessions_repo, services.tracks_repo)
        owner = QueueOwner(kind="group", id=-100777)
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]

        # Simulate a crashed run: status "playing" persisted in the DB.
        await sessions.set_now_playing(owner, track_id, None, 42, -100777)
        stale = await sessions.get(owner)
        assert stale.status == "playing"

        recovered = await sessions.reset_active_sessions()
        assert recovered == [("group", -100777, "playing")]

        fresh = await sessions.get(owner)
        assert fresh.status == "stopped"

    async def test_paused_sessions_recovered_too(
        self, db_setup, mk_sessions, tmp_path
    ) -> None:
        services = build_services(mk_sessions)
        sessions = SessionManager(services.sessions_repo, services.tracks_repo)
        owner = QueueOwner(kind="user", id=55)
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]
        await sessions.set_now_playing(owner, track_id, None, 1, 55)
        await sessions.update_status(owner, "paused")

        recovered = await sessions.reset_active_sessions()
        assert ("user", 55, "paused") in recovered

        fresh = await sessions.get(owner)
        assert fresh.status == "stopped"

    async def test_idle_sessions_untouched(self, db_setup, mk_sessions) -> None:
        services = build_services(mk_sessions)
        sessions = SessionManager(services.sessions_repo, services.tracks_repo)
        owner = QueueOwner(kind="group", id=-100888)
        await sessions.get(owner)  # creates an idle row

        recovered = await sessions.reset_active_sessions()
        assert recovered == []

    async def test_controller_recover_stale_sessions_reports(
        self, db_setup, mk_sessions, tmp_path, group_owner
    ) -> None:
        async for b in _make_bundle(db_setup, mk_sessions, tmp_path):
            track_id = db_setup.track_ids_by_title["Neon Sunrise"]
            await b.sessions.set_now_playing(
                group_owner, track_id, None, 1, -100999
            )
            recovered = await b.controller.recover_stale_sessions()
            assert recovered == [("group", -100999, "playing")]
            session = await b.sessions.get(group_owner)
            assert session.status == "stopped"

    async def test_recovered_group_accepts_new_play(
        self, db_setup, mk_sessions, tmp_path, group_owner
    ) -> None:
        """The regression lock for the production bug: after recovery a
        fresh enqueue must START playback (pop + voice play), not just
        queue silently."""
        async for b in _make_bundle(db_setup, mk_sessions, tmp_path):
            track_id = db_setup.track_ids_by_title["Neon Sunrise"]
            await b.sessions.set_now_playing(
                group_owner, track_id, None, 1, -100999
            )
            await b.controller.recover_stale_sessions()

            other = db_setup.track_ids_by_title["Velvet Night"]
            await b.controller.enqueue(
                group_owner, -100999, b.bot, other, 101
            )
            assert b.voice.played, "playback never started after recovery"
            session = await b.sessions.get(group_owner)
            assert session.status == "playing"
            assert session.current_track_id == other


# ---------------------------------------------------------------------------
# Critical bug A — failure-path reset + bounded requeue
# ---------------------------------------------------------------------------
class TestGroupStartFailurePolicy:
    async def test_failed_start_parks_idle_and_requeues_front(
        self, bundle, db_setup, group_owner
    ) -> None:
        b = bundle
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]
        b.voice.play_results = [VoiceChatMissingError("Voice chat is not available")]

        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)

        # Session must NOT claim to be playing.
        session = await b.sessions.get(group_owner)
        assert session.status == "idle"
        # The failed track was requeued at the front exactly once.
        items = await b.queue.get_queue(group_owner)
        assert len(items) == 1 and items[0].track_id == track_id
        # The user saw the truthful reason plus the recovery note.
        assert b.bot.messages_sent, "no error surfaced"
        error_text = b.bot.messages_sent[-1][1]
        assert "voice chat" in error_text.lower()
        assert "front of the queue" in error_text

    async def test_second_consecutive_failure_drops_not_loops(
        self, bundle, db_setup, group_owner
    ) -> None:
        b = bundle
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]
        b.voice.play_results = [
            DownloadError("Download failed for api.audius.co"),
            DownloadError("Download failed for api.audius.co"),
        ]
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
        # First failure requeued; simulate the retry by popping it again.
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)

        items = await b.queue.get_queue(group_owner)
        assert items == [], "second failure must drop the track (no loop)"
        session = await b.sessions.get(group_owner)
        assert session.status == "idle"
        error_text = b.bot.messages_sent[-1][1]
        assert "keeps failing" in error_text

    async def test_successful_start_resets_failure_counter(
        self, bundle, db_setup, group_owner
    ) -> None:
        b = bundle
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]
        # One failure, then a success, then one failure — the second
        # failure must still requeue (the success reset the counter).
        b.voice.play_results = [DownloadError("temporary network error")]
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
        assert (await b.queue.get_queue(group_owner))

        # Clear the queue and succeed.
        await b.queue.clear(group_owner)
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
        session = await b.sessions.get(group_owner)
        assert session.status == "playing"

        b.voice.play_results = [DownloadError("another transient error")]
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
        assert (await b.queue.get_queue(group_owner)), (
            "fresh failure after a success should requeue again"
        )

    async def test_auto_advance_failure_requeues(
        self, bundle, db_setup, group_owner
    ) -> None:
        b = bundle
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(group_owner, -100999, b.bot, first, 101)
        await b.queue.add(group_owner, second, added_by=101)
        # The next start fails (expired URL).
        b.voice.play_results = [DownloadError("Stream URL rejected")]

        await b.controller.next(
            group_owner, -100999, b.bot, manual=False, skip=False
        )

        session = await b.sessions.get(group_owner)
        assert session.status == "idle"
        items = await b.queue.get_queue(group_owner)
        assert len(items) == 1 and items[0].track_id == second

    async def test_enqueue_failure_parks_idle_and_requeues(
        self, bundle, db_setup, group_owner
    ) -> None:
        """enqueue() start path (idle session) with a failing voice join."""
        b = bundle
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]
        b.voice.play_results = [VoiceChatMissingError("no active group call")]

        await b.controller.enqueue(group_owner, -100999, b.bot, track_id, 101)

        session = await b.sessions.get(group_owner)
        assert session.status == "idle"
        items = await b.queue.get_queue(group_owner)
        assert len(items) == 1 and items[0].track_id == track_id


# ---------------------------------------------------------------------------
# Critical bug A — stale persisted status vs live voice lease
# ---------------------------------------------------------------------------
class TestEnqueueStaleStatusCrossCheck:
    async def test_stale_playing_status_with_no_voice_lease_starts(
        self, bundle, db_setup, group_owner
    ) -> None:
        """A group marked playing whose voice lease is gone must start the
        new track instead of silently queueing it forever (the exact
        production symptom from the 2026-10-11 log)."""
        b = bundle
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]

        # A previous track played, then the lease was released (failover /
        # idle release) — the persisted status is still "playing".
        await b.controller.play_now(group_owner, -100999, b.bot, first, 101)
        await b.voice.release(-100999)
        session = await b.sessions.get(group_owner)
        assert session.status == "playing"  # the stale lie

        await b.controller.enqueue(group_owner, -100999, b.bot, second, 101)

        assert b.voice.is_active_calls, "controller never checked the lease"
        # The new track actually started.
        assert b.voice.played and b.voice.played[-1][0] == -100999
        session = await b.sessions.get(group_owner)
        assert session.status == "playing"
        assert session.current_track_id == second

    async def test_live_playing_session_queues_behind(
        self, bundle, db_setup, group_owner
    ) -> None:
        b = bundle
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(group_owner, -100999, b.bot, first, 101)

        await b.controller.enqueue(group_owner, -100999, b.bot, second, 101)

        # Live lease exists — the new track queues behind, no new start.
        assert len(b.voice.played) == 1
        items = await b.queue.get_queue(group_owner)
        assert len(items) == 1 and items[0].track_id == second

    async def test_gateway_without_is_active_keeps_legacy_behavior(
        self, db_setup, mk_sessions, tmp_path, group_owner
    ) -> None:
        """Older fakes without ``is_active`` trust the persisted status."""
        services = build_services(mk_sessions)
        events = EventBus()
        queue = QueueManager(services.queue_repo, services.tracks_repo, events)
        sessions = SessionManager(services.sessions_repo, services.tracks_repo, events)
        engine = RecommendationEngine(
            services.tracks_repo, services.profiles, services.settings_repo, services.cache
        )
        autoplay = AutoplayService(engine, queue, services.analytics_repo)
        music = FakeMusicGateway(services.tracks_repo, tmp_path)
        voice = FakeVoiceGateway()  # no is_active attribute
        controller = PlaybackController(
            queue=queue, autoplay=autoplay, music=music, voice=voice,
            sessions=sessions, events=events,
            analytics=FakeAnalyticsRecorder(), history=FakeHistoryGateway(),
            default_autoplay=False, progress_edit_interval=0,
        )
        try:
            first = db_setup.track_ids_by_title["Neon Sunrise"]
            second = db_setup.track_ids_by_title["Velvet Night"]
            await controller.play_now(group_owner, -100999, FakeBot(), first, 101)
            await controller.enqueue(group_owner, -100999, FakeBot(), second, 101)
            assert len(voice.played) == 1  # queued, not restarted
        finally:
            await controller.cleanup()


# ---------------------------------------------------------------------------
# Critical bug B — DM flow ordering
# ---------------------------------------------------------------------------
class TestDmFlowOrdering:
    async def test_ensure_access_runs_before_voice_chat_check(self) -> None:
        """Regression lock: group access (auto-join) must be verified
        BEFORE the active-voice-chat verdict, so a live-but-invisible
        voice chat is no longer reported as missing."""
        from app.bot.handlers import dm_play as dm

        calls: list[str] = []

        class _Access:
            async def ensure_access(self, client, group_tg_id, *, account_id=None):
                calls.append("ensure_access")
                return SimpleNamespace(ok=True, joined=True, status="joined")

            async def check_voice_chat(self, client, group_tg_id):
                calls.append("check_voice_chat")
                return True

            async def check_user_membership(self, client, group_tg_id, user_tg_id):
                return (True, False)

        class _Playback:
            async def now_playing(self, owner):
                return {"status": "idle"}

            async def play_now(self, owner, chat_id, bot, track_id, user_id):
                calls.append("play_now")

        class _Message:
            async def edit_text(self, text, **kwargs):
                calls.append("edit")

        message = _Message()
        services = SimpleNamespace(
            music=SimpleNamespace(
                get_track=async_return(
                    SimpleNamespace(
                        id=7, title="T", artist=None, duration_seconds=60,
                        source="audius", source_id="x",
                    )
                )
            ),
            voice=SimpleNamespace(
                has_accounts=lambda: True,
                pick_client=lambda: (
                    SimpleNamespace(model=SimpleNamespace(id=1)), object()
                ),
                group_access=_Access(),
            ),
            permissions=SimpleNamespace(can=async_return(True)),
            groups=SimpleNamespace(
                register_group=async_return(
                    SimpleNamespace(id=1, title="G")
                ),
                sync_member=async_return(None),
            ),
            users=SimpleNamespace(get_or_create=async_return(SimpleNamespace(id=3))),
            playback=_Playback(),
            queue=SimpleNamespace(get_queue=async_return([])),
        )
        state = SimpleNamespace(
            get_data=async_return({}),
            update_data=async_return(None),
            set_data=async_return(None),
            get_state=async_return(None),
            set_state=async_return(None),
            clear=async_return(None),
        )
        bot = SimpleNamespace(
            get_chat=async_return(True),
            send_message=async_return(None),
        )
        await dm._execute_play(
            message,
            services,
            state,
            track_id=7,
            group_tg_id=-100123,
            group_title="G",
            requester=SimpleNamespace(id=42),
            bot=bot,
            chat_id=42,
        )
        assert calls.index("ensure_access") < calls.index("check_voice_chat")
        assert "play_now" in calls

    async def test_missing_voice_chat_reported_after_join(
        self, monkeypatch
    ) -> None:
        """When access is fine but the voice chat genuinely does not exist,
        the user sees the actionable 'start a voice chat' message — and the
        source-order lock: ensure_access precedes check_voice_chat."""
        import inspect

        from app.bot.handlers import dm_play as dm

        source = inspect.getsource(dm._execute_play)
        assert "ensure_access" in source
        assert "check_voice_chat" in source
        # The ensure_access call must precede the check_voice_chat call in
        # the source order too (belt-and-braces static lock).
        assert source.index("ensure_access") < source.index("check_voice_chat")


def _import_dm_execute() -> Any:
    from app.bot.handlers import dm_play as dm

    return dm._execute_play


def async_return(value: Any):
    async def _inner(*args: Any, **kwargs: Any) -> Any:
        return value

    return _inner


# ---------------------------------------------------------------------------
# Volume scale consistency
# ---------------------------------------------------------------------------
class TestVolumeScale:
    async def test_transport_maps_percent_to_engine_scale(self) -> None:
        from app.voice.transport import NativeTransport

        calls: list[tuple[int, int]] = []

        class _Calls:
            async def change_volume_call(self, group_id: int, volume: int) -> None:
                calls.append((group_id, volume))

        transport = NativeTransport(object())
        transport._calls = _Calls()
        transport._started = True
        await transport.set_volume(-100999, 100)
        await transport.set_volume(-100999, 50)
        await transport.set_volume(-100999, 250)  # clamped to 100 → 200
        assert calls == [(-100999, 200), (-100999, 100), (-100999, 200)]

    async def test_session_volume_clamped_0_100(
        self, db_setup, mk_sessions
    ) -> None:
        services = build_services(mk_sessions)
        sessions = SessionManager(services.sessions_repo, services.tracks_repo)
        owner = QueueOwner(kind="group", id=-100999)
        assert await sessions.set_volume(owner, 150) == 100
        assert await sessions.set_volume(owner, -5) == 0


# ---------------------------------------------------------------------------
# Completed download-cache cleanup
# ---------------------------------------------------------------------------
class TestDownloadCacheCleanup:
    def _storage(self, tmp_path: Path):
        from app.storage import StorageService

        return StorageService(tmp_path / "storage")

    def test_old_removed_recent_kept(self, tmp_path: Path) -> None:
        storage = self._storage(tmp_path)
        old = storage.downloads_dir() / "old.mp3"
        old.write_bytes(b"x" * 10)
        recent = storage.downloads_dir() / "recent.mp3"
        recent.write_bytes(b"y" * 10)
        age = 3600
        past = time.time() - (age + 600)
        os.utime(old, (past, past))

        removed, removed_bytes = storage.cleanup_downloads(max_age_seconds=age)
        assert removed == 1 and removed_bytes == 10
        assert not old.exists()
        assert recent.exists()

    def test_protected_files_survive(self, tmp_path: Path) -> None:
        storage = self._storage(tmp_path)
        protected = storage.downloads_dir() / "live.mp3"
        protected.write_bytes(b"z" * 32)
        past = time.time() - 999_999
        os.utime(protected, (past, past))

        removed, _ = storage.cleanup_downloads(
            max_age_seconds=60, protect={str(protected)}
        )
        assert removed == 0
        assert protected.exists()

    def test_symlinks_skipped_never_followed(self, tmp_path: Path) -> None:
        storage = self._storage(tmp_path)
        target = tmp_path / "secret.txt"
        target.write_text("do not delete")
        link = storage.downloads_dir() / "planted.mp3"
        link.symlink_to(target)
        past = time.time() - 999_999
        os.utime(link, (past, past), follow_symlinks=False)

        removed, _ = storage.cleanup_downloads(max_age_seconds=60)
        assert removed == 0
        assert target.exists()
        assert link.exists()  # symlinks are never deleted either

    def test_permanent_trees_out_of_scope(self, tmp_path: Path) -> None:
        storage = self._storage(tmp_path)
        upload = storage.music_dir() / "upload.mp3"
        upload.write_bytes(b"u" * 10)
        art = storage.artwork_dir() / "cover.jpg"
        art.write_bytes(b"a" * 10)
        past = time.time() - 999_999
        os.utime(upload, (past, past))
        os.utime(art, (past, past))

        removed, _ = storage.cleanup_downloads(max_age_seconds=60)
        assert removed == 0
        assert upload.exists() and art.exists()

    def test_subdirectories_recursed(self, tmp_path: Path) -> None:
        storage = self._storage(tmp_path)
        nested = storage.downloads_dir() / "url-abc"
        nested.mkdir()
        stale = nested / "file.mp3"
        stale.write_bytes(b"n" * 7)
        past = time.time() - 999_999
        os.utime(stale, (past, past))

        removed, removed_bytes = storage.cleanup_downloads(max_age_seconds=60)
        assert removed == 1 and removed_bytes == 7
        assert not stale.exists()

    def test_missing_directory_is_noop(self, tmp_path: Path) -> None:
        from app.storage import StorageService

        storage = StorageService(tmp_path / "fresh")
        # The downloads dir does not exist yet (created lazily) — the sweep
        # must tolerate that and remove nothing.
        removed, _ = storage.cleanup_downloads(max_age_seconds=60)
        assert removed == 0

    async def test_worker_task_collects_protection(self, tmp_path) -> None:
        from app.workers import tasks as worker_tasks

        captured: dict[str, Any] = {}

        class _Storage:
            def cleanup_downloads(self, max_age, *, protect=None):
                captured["max_age"] = max_age
                captured["protect"] = protect
                return (1, 100)

        class _Playback:
            async def protected_file_paths(self):
                return {"downloads/a.mp3"}

        class _Settings:
            cache_retention = SimpleNamespace(retention_hours=5)

        previous = worker_tasks._container
        try:
            worker_tasks.bind(
                SimpleNamespace(
                    storage=_Storage(), settings=_Settings(), playback=_Playback()
                )
            )
            await worker_tasks.cleanup_downloads({})
        finally:
            worker_tasks.bind(previous)
        assert captured["max_age"] == 5 * 3600
        assert captured["protect"] == {"downloads/a.mp3"}

    async def test_worker_task_disabled_at_zero_retention(self) -> None:
        from app.workers import tasks as worker_tasks

        swept = {"called": False}

        class _Storage:
            def cleanup_downloads(self, *a, **k):
                swept["called"] = True
                return (0, 0)

        class _Settings:
            cache_retention = SimpleNamespace(retention_hours=0)

        previous = worker_tasks._container
        try:
            worker_tasks.bind(
                SimpleNamespace(storage=_Storage(), settings=_Settings(), playback=None)
            )
            await worker_tasks.cleanup_downloads({})
        finally:
            worker_tasks.bind(previous)
        assert swept["called"] is False


# ---------------------------------------------------------------------------
# Group command auto-delete middleware
# ---------------------------------------------------------------------------
class TestCommandAutoDeleteMiddleware:
    def _middleware(self, enabled: bool = True):
        from app.bot.middleware.command_cleanup import CommandAutoDeleteMiddleware

        return CommandAutoDeleteMiddleware(), SimpleNamespace(
            settings=SimpleNamespace(group_command_auto_delete=enabled)
        )

    def _message(self, chat_type: str, text: str, commands: list[str]):
        from aiogram.types import (
            BotCommand as _Unused,  # noqa: F401 — prove aiogram types load
        )

        # Lightweight duck-typed message (entities computed from commands).
        entities = []
        offset = 0
        for command in commands:
            entity = SimpleNamespace(type="bot_command", offset=0, length=len(command))
            entities.append(entity)
            offset += len(command)
        deleted: list[bool] = []

        async def _delete() -> None:
            deleted.append(True)

        async def _handler(event, data):
            return "handled"

        message = SimpleNamespace(
            chat=SimpleNamespace(id=-100999, type=chat_type),
            text=text,
            entities=entities,
            message_id=77,
            delete=_delete,
            bot=None,
        )
        return message, _handler, deleted

    def _data(self, services, username="MyBot"):
        me = SimpleNamespace(username=username)

        class _Bot:
            async def me(self):
                return me

        return {"services": services, "bot": _Bot()}

    async def test_group_command_deleted_after_handling(self) -> None:
        middleware, services = self._middleware()
        message, handler, deleted = self._message(
            "supergroup", "/play hello", ["/play"]
        )
        result = await middleware(handler, message, self._data(services))
        assert result == "handled"
        assert deleted == [True]

    async def test_private_message_never_deleted(self) -> None:
        middleware, services = self._middleware()
        message, handler, deleted = self._message("private", "/start", ["/start"])
        await middleware(handler, message, self._data(services))
        assert deleted == []

    async def test_disabled_config_never_deletes(self) -> None:
        middleware, services = self._middleware(enabled=False)
        message, handler, deleted = self._message(
            "group", "/skip", ["/skip"]
        )
        await middleware(handler, message, self._data(services))
        assert deleted == []

    async def test_other_bots_command_not_deleted(self) -> None:
        middleware, services = self._middleware()
        message, handler, deleted = self._message(
            "group", "/play@OtherBot song", ["/play@OtherBot"]
        )
        await middleware(handler, message, self._data(services))
        assert deleted == []

    async def test_qualified_own_command_deleted(self) -> None:
        middleware, services = self._middleware()
        message, handler, deleted = self._message(
            "group", "/play@MyBot song", ["/play@MyBot"]
        )
        await middleware(handler, message, self._data(services))
        assert deleted == [True]

    async def test_plain_message_not_deleted(self) -> None:
        middleware, services = self._middleware()
        message, handler, deleted = self._message("group", "just chatting", [])
        await middleware(handler, message, self._data(services))
        assert deleted == []

    async def test_handler_exception_still_deletes_and_propagates(self) -> None:
        middleware, services = self._middleware()
        message, _, deleted = self._message("group", "/boom", ["/boom"])

        async def _handler(event, data):
            raise RuntimeError("boom")

        with pytest.raises(RuntimeError):
            await middleware(_handler, message, self._data(services))
        assert deleted == [True]

    async def test_deletion_failure_swallowed(self) -> None:
        middleware, services = self._middleware()
        message, handler, _ = self._message("group", "/play x", ["/play"])

        async def _broken_delete() -> None:
            raise RuntimeError("message to delete not found")

        message.delete = _broken_delete
        result = await middleware(handler, message, self._data(services))
        assert result == "handled"


# ---------------------------------------------------------------------------
# Live progress ticker
# ---------------------------------------------------------------------------
class TestProgressTicker:
    async def test_ticker_edits_progress_periodically(
        self, db_setup, mk_sessions, tmp_path, group_owner
    ) -> None:
        async for b in _make_bundle(
            db_setup, mk_sessions, tmp_path, progress_interval=0.05
        ):
            track_id = db_setup.track_ids_by_title["Neon Sunrise"]
            await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
            edits_before = len(b.bot.edits)
            await asyncio.sleep(0.35)  # several ticker intervals (≥5s floor mocked off)
            assert len(b.bot.edits) > edits_before, "ticker never edited"
            # The ticker text carries the progress bar + queue count.
            latest = b.bot.edits[-1][2]
            assert "in queue" in latest

    async def test_ticker_cancelled_on_stop(
        self, db_setup, mk_sessions, tmp_path, group_owner
    ) -> None:
        async for b in _make_bundle(
            db_setup, mk_sessions, tmp_path, progress_interval=0.05
        ):
            track_id = db_setup.track_ids_by_title["Neon Sunrise"]
            await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)
            await b.controller.stop(group_owner, b.bot)
            edits_before = len(b.bot.edits)
            await asyncio.sleep(0.25)
            assert len(b.bot.edits) == edits_before, "ticker ran after stop"

    async def test_ticker_cancelled_on_cleanup(
        self, db_setup, mk_sessions, tmp_path, group_owner
    ) -> None:
        from app.playback.controller import PlaybackController
        from .test_playback_controller import (
            FakeAnalyticsRecorder,
            FakeHistoryGateway,
        )

        services = build_services(mk_sessions)
        events = EventBus()
        queue = QueueManager(services.queue_repo, services.tracks_repo, events)
        sessions = SessionManager(services.sessions_repo, services.tracks_repo, events)
        engine = RecommendationEngine(
            services.tracks_repo,
            services.profiles,
            services.settings_repo,
            services.cache,
        )
        autoplay = AutoplayService(engine, queue, services.analytics_repo)
        controller = PlaybackController(
            queue=queue,
            autoplay=autoplay,
            music=FakeMusicGateway(services.tracks_repo, tmp_path),
            voice=ScriptedVoiceGateway(),
            sessions=sessions,
            events=events,
            analytics=FakeAnalyticsRecorder(),
            history=FakeHistoryGateway(),
            default_autoplay=False,
            progress_edit_interval=0.01,
        )
        bot = FakeBot()
        try:
            track_id = db_setup.track_ids_by_title["Neon Sunrise"]
            owner = QueueOwner(kind="group", id=-100999)
            await controller.play_now(owner, -100999, bot, track_id, 101)
            assert controller._progress_tasks
            await controller.cleanup()
            await asyncio.sleep(0.05)
            assert not controller._progress_tasks
        finally:
            await controller.cleanup()


# ---------------------------------------------------------------------------
# Up-next rendering + protected paths
# ---------------------------------------------------------------------------
class TestUpNextAndProtectedPaths:
    def test_up_next_line_rendered(self) -> None:
        from app.utils import now_playing_text

        track = SimpleNamespace(
            title="Song A", artist=None, duration_seconds=120
        )
        text = now_playing_text(track, up_next="Song B", queue_size=1)
        assert "⏭ Up next: Song B" in text
        assert "1 in queue" in text

    def test_up_next_omitted_without_queue(self) -> None:
        from app.utils import now_playing_text

        track = SimpleNamespace(title="Song A", artist=None, duration_seconds=120)
        text = now_playing_text(track, queue_size=0)
        assert "Up next" not in text

    def test_up_next_html_escaped(self) -> None:
        from app.utils import now_playing_text

        track = SimpleNamespace(title="A", artist=None, duration_seconds=10)
        text = now_playing_text(track, up_next="<b>weird & name</b>", queue_size=1)
        assert "&lt;b&gt;weird &amp; name&lt;/b&gt;" in text

    async def test_group_now_playing_includes_up_next(
        self, db_setup, mk_sessions, tmp_path, group_owner
    ) -> None:
        async for b in _make_bundle(db_setup, mk_sessions, tmp_path):
            second = db_setup.track_ids_by_title["Velvet Night"]
            third = db_setup.track_ids_by_title["Static Bloom"]
            # Seed the queue first, then enqueue: the pop starts "second"
            # while "third" waits behind — the Now Playing message must
            # carry the Up next line.
            await b.queue.add(group_owner, second, added_by=101)
            await b.controller.enqueue(group_owner, -100999, b.bot, third, 101)
            assert b.bot.messages_sent, "no Now Playing message was sent"
            text = b.bot.messages_sent[0][1]
            assert "Up next:" in text
            assert "Static Bloom" in text

    async def test_protected_file_paths_from_active_sessions(
        self, db_setup, mk_sessions, tmp_path, group_owner
    ) -> None:
        class _PathMusic(FakeMusicGateway):
            async def file_path_of(self, track_id: int) -> str | None:
                return f"downloads/track-{track_id}.mp3"

        services = build_services(mk_sessions)
        events = EventBus()
        queue = QueueManager(services.queue_repo, services.tracks_repo, events)
        sessions = SessionManager(services.sessions_repo, services.tracks_repo, events)
        engine = RecommendationEngine(
            services.tracks_repo,
            services.profiles,
            services.settings_repo,
            services.cache,
        )
        autoplay = AutoplayService(engine, queue, services.analytics_repo)
        music = _PathMusic(services.tracks_repo, tmp_path)
        controller = PlaybackController(
            queue=queue,
            autoplay=autoplay,
            music=music,
            voice=ScriptedVoiceGateway(),
            sessions=sessions,
            events=events,
            analytics=FakeAnalyticsRecorder(),
            history=FakeHistoryGateway(),
            default_autoplay=False,
            progress_edit_interval=0,
        )
        try:
            track_id = db_setup.track_ids_by_title["Neon Sunrise"]
            await controller.play_now(group_owner, -100999, FakeBot(), track_id, 101)
            protected = await controller.protected_file_paths()
            assert f"downloads/track-{track_id}.mp3" in protected
        finally:
            await controller.cleanup()


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
class TestNewConfiguration:
    def test_defaults(self) -> None:
        from app.config import Settings

        settings = Settings(bot_token="123456789:" + "A" * 33)
        assert settings.cache_retention.retention_hours == 72
        assert settings.cache_retention.cleanup_interval_minutes == 60
        assert settings.group_command_auto_delete is True
        assert settings.progress_edit_interval == 15

    def test_env_parsing(self, monkeypatch) -> None:
        from app.config import load_settings

        monkeypatch.setenv("BOT_TOKEN", "123456789:" + "A" * 33)
        monkeypatch.setenv("DOWNLOAD_CACHE_RETENTION_HOURS", "24")
        monkeypatch.setenv("DOWNLOAD_CACHE_CLEANUP_INTERVAL_MINUTES", "30")
        monkeypatch.setenv("GROUP_COMMAND_AUTO_DELETE", "false")
        monkeypatch.setenv("PROGRESS_EDIT_INTERVAL", "0")
        settings = load_settings(env_file=None)
        assert settings.cache_retention.retention_hours == 24
        assert settings.cache_retention.cleanup_interval_minutes == 30
        assert settings.group_command_auto_delete is False
        assert settings.progress_edit_interval == 0

    def test_negative_rejected(self, monkeypatch) -> None:
        from app.config import ConfigError, load_settings

        monkeypatch.setenv("BOT_TOKEN", "123456789:" + "A" * 33)
        monkeypatch.setenv("DOWNLOAD_CACHE_RETENTION_HOURS", "-1")
        with pytest.raises(ConfigError):
            load_settings(env_file=None)


# ---------------------------------------------------------------------------
# VoiceManager.is_active
# ---------------------------------------------------------------------------
class TestVoiceManagerIsActive:
    async def test_is_active_tracks_leases(self) -> None:
        from app.voice.manager import VoiceManager
        from app.voice.session import VoiceSessionRuntime

        manager = VoiceManager.__new__(VoiceManager)
        manager._sessions = {}
        assert await manager.is_active(-100999) is False

        runtime = SimpleNamespace()
        manager._sessions[-100999] = runtime
        assert await manager.is_active(-100999) is True


# ---------------------------------------------------------------------------
# Repeated /start housekeeping (DM UX)
# ---------------------------------------------------------------------------
class TestStartDashboardHousekeeping:
    async def test_repeated_start_deletes_previous_dashboard(self) -> None:
        from app.bot.handlers import start as start_module

        deleted: list[tuple[int, int]] = []
        sent_ids = iter(range(500, 510))

        class _Bot:
            async def me(self):
                return SimpleNamespace(username="MyBot")

            async def delete_message(self, chat_id, message_id):
                deleted.append((chat_id, message_id))

        class _Message:
            def __init__(self) -> None:
                self.bot = _Bot()
                self.chat = SimpleNamespace(id=42, type="private")
                self.from_user = SimpleNamespace(id=42, first_name="U")

            async def answer(self, text, **kwargs):
                return SimpleNamespace(message_id=next(sent_ids))

        class _State:
            def __init__(self) -> None:
                self.data: dict[str, Any] = {}

            async def get_data(self):
                return dict(self.data)

            async def update_data(self, **kwargs):
                self.data.update(kwargs)

            async def set_data(self, data):
                self.data = dict(data)

            async def get_state(self):
                return None

            async def set_state(self, value):
                pass

            async def clear(self):
                self.data = {}

        services = SimpleNamespace(
            admin=SimpleNamespace(
                appearance=SimpleNamespace(
                    message=async_return("hi {name}"), logo=async_return(None),
                ),
                buttons=SimpleNamespace(
                    render_keyboard=async_return(
                        SimpleNamespace(inline_keyboard=[])
                    ),
                ),
            ),
        )

        state = _State()
        first = _Message()
        sent1 = await start_module.send_dashboard(first, services, state)
        assert sent1 is not None
        first_id = sent1.message_id

        # A repeated /start: cmd_start deletes the old dashboard BEFORE the
        # FSM clear wipes its id, then the new one is sent.
        second = _Message()
        await start_module._delete_previous_dashboard(second, state)
        await state.clear()
        await start_module.send_dashboard(second, services, state)
        assert deleted == [(42, first_id)]

    async def test_deep_link_payload_malformed_falls_through(self) -> None:
        """Unknown/malformed /start payloads must never crash the handler."""
        from app.bot.handlers.start import TRACK_PAYLOAD_PREFIX

        payload = "track_notanumber"
        assert payload.startswith(TRACK_PAYLOAD_PREFIX)
        try:
            int(payload[len(TRACK_PAYLOAD_PREFIX):])
            raise AssertionError("expected ValueError")
        except ValueError:
            pass  # the handler catches exactly this and falls through


# ---------------------------------------------------------------------------
# Group _enqueue stale-status verdict (double-render guard)
# ---------------------------------------------------------------------------
class TestEnqueueStaleVerdictInHandlers:
    async def test_stale_status_with_dead_lease_reports_not_active(self) -> None:
        from app.bot.handlers.groups import _enqueue

        class _Playback:
            async def now_playing(self, owner):
                return {"status": "playing"}  # the stale persisted lie

            async def enqueue(self, *args, **kwargs):
                return 1

        class _Voice:
            async def is_active(self, group_tg_id):
                return False  # no live lease
        services = SimpleNamespace(playback=_Playback(), voice=_Voice())
        size, was_active = await _enqueue(services, -100999, None, 5, 101)
        assert (size, was_active) == (1, False)

    async def test_live_lease_reports_active(self) -> None:
        from app.bot.handlers.groups import _enqueue

        class _Playback:
            async def now_playing(self, owner):
                return {"status": "playing"}

            async def enqueue(self, *args, **kwargs):
                return 2

        class _Voice:
            async def is_active(self, group_tg_id):
                return True

        services = SimpleNamespace(playback=_Playback(), voice=_Voice())
        size, was_active = await _enqueue(services, -100999, None, 5, 101)
        assert (size, was_active) == (2, True)

    async def test_gateway_without_is_active_keeps_persisted_verdict(self) -> None:
        from app.bot.handlers.groups import _enqueue

        class _Playback:
            async def now_playing(self, owner):
                return {"status": "paused"}

            async def enqueue(self, *args, **kwargs):
                return 3

        services = SimpleNamespace(playback=_Playback(), voice=SimpleNamespace())
        size, was_active = await _enqueue(services, -100999, None, 5, 101)
        assert (size, was_active) == (3, True)

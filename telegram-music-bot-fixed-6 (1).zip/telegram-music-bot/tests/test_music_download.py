"""Regression tests for the fixed download/playback pipeline.

Covers the two root causes of the production "Unable to download track"
failure and the hardening added around them:

1. **Stream resolution was never connected** — Audius search results carry
   ``stream_url=None`` by design (the URL only exists behind the source's
   ``get_stream()``), but nothing in the pipeline ever called it. Playback
   of any Audius track raised ``DownloadError("has neither file nor stream
   URL")`` → the user-facing "❌ Couldn't download this track".
2. **Relative path returned** — after a successful download the service
   returned ``updated.file_path`` (a storage-RELATIVE string like
   ``downloads/track-42.mp3``), so the voice layer was handed a path that
   only resolves when the process CWD happens to be the project root.

Plus: expired-URL re-resolution, content validation, concurrency safety,
temp-file cleanup and cache behaviour.

All Telegram/HTTP interactions run against in-memory fakes — no network.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from app.cache.redis import MemoryCache
from app.config import Settings
from app.database.base import Base
from app.database.repositories.music import TrackRepository
from app.errors import (
    DownloadError,
    InvalidAudioError,
    MusicSourceError,
)
from app.music.models import StreamInfo
from app.music.service import (
    MusicService,
    _recognized_audio_header,
    _validate_audio_file,
)
from app.playback.events import EventBus
from app.storage import StorageService

# ---------------------------------------------------------------------------
# Fakes
# ---------------------------------------------------------------------------
_MP3_BODY = b"ID3\x04\x00\x00\x00\x00\x00\x00" + b"\x01\x02\x03" * 64  # ~200 bytes


class _FakeContent:
    """Duck-typed ``aiohttp`` content stream."""

    def __init__(self, body: bytes) -> None:
        self._body = body

    async def iter_chunked(self, chunk_size: int):
        for i in range(0, len(self._body), chunk_size):
            yield self._body[i : i + chunk_size]


class _FakeResponse:
    """Duck-typed ``aiohttp`` response (context manager)."""

    def __init__(self, status: int = 200, body: bytes = b"", headers: dict | None = None) -> None:
        self.status = status
        self.headers = headers or {}
        self._body = body

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc_info):
        return False

    async def text(self) -> str:
        return self._body.decode("utf-8", "replace")

    @property
    def content(self) -> _FakeContent:
        return _FakeContent(self._body)


class _FakeHttpSession:
    """``aiohttp.ClientSession`` duck-type with scripted GET responses.

    Every ``http.get`` pops the next scripted response; an unexpected extra
    request fails the test loudly.
    """

    def __init__(self, responses: list[_FakeResponse]) -> None:
        self._responses = list(responses)
        self.requested_urls: list[str] = []

    def get(self, url: str, **kwargs):
        assert kwargs.get("allow_redirects") is False, (
            "downloads must follow redirects manually (SSRF re-validation)"
        )
        self.requested_urls.append(url)
        if not self._responses:
            raise AssertionError(f"unexpected extra request: {url}")
        return self._responses.pop(0)

    @property
    def request_count(self) -> int:
        return len(self.requested_urls)


class _FakeSource:
    """Minimal MusicSource duck-type exercising the stream pipeline."""

    name = "audius"

    def __init__(
        self,
        *,
        stream_urls: list[str | None] | None = None,
        configured: bool = True,
        error: Exception | None = None,
        settings: Settings | None = None,
    ) -> None:
        self.settings = settings
        self.http = None
        self._configured = configured
        self._error = error
        # FIFO of stream URLs returned by successive get_stream() calls.
        self._stream_urls = list(stream_urls or [])
        self.get_stream_calls = 0

    def is_configured(self) -> bool:
        return self._configured

    async def get_stream(self, source_id: str) -> StreamInfo | None:
        self.get_stream_calls += 1
        if self._error is not None:
            raise self._error
        if not self._stream_urls:
            return None
        url = self._stream_urls.pop(0)
        if url is None:
            return None
        return StreamInfo(url_or_path=url, is_local=False)


class _FakeAggregator:  # only referenced by search(); unused in most tests
    pass


class _PassThroughAggregator:
    """Single-source aggregator stand-in used by full-chain tests."""

    def __init__(self, source) -> None:
        self._source = source

    async def search(self, query: str, limit: int = 10, on_progress=None):
        return await self._source.search(query, limit=limit)


class _FakeResolver:
    pass


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture()
def settings(tmp_path: Path) -> Settings:
    return Settings(
        bot_token="123456789:" + "A" * 33,
        storage_dir=tmp_path / "storage",
        max_audio_size_mb=45,
        http_timeout=5,
    )


@pytest.fixture()
async def db(tmp_path: Path):
    """In-memory DB with all tables created; yields a session factory."""
    from sqlalchemy.ext.asyncio import (
        AsyncSession,
        async_sessionmaker,
        create_async_engine,
    )
    from sqlalchemy.pool import StaticPool

    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    await engine.dispose()


@pytest.fixture()
async def tracks(db) -> TrackRepository:
    return TrackRepository(db)


@pytest.fixture(autouse=True)
def _no_dns(monkeypatch: pytest.MonkeyPatch) -> None:
    """Skip SSRF DNS resolution — tests use fake hosts."""
    monkeypatch.setattr("app.music.service.validate_url", lambda url: url)
    monkeypatch.setattr(
        "app.music.sources.url_resolver.validate_url", lambda url: url
    )


def _make_service(
    settings: Settings,
    tracks: TrackRepository,
    http: _FakeHttpSession,
    source: _FakeSource | None = None,
) -> MusicService:
    source = source or _FakeSource(settings=settings)
    return MusicService(
        sources=[source],
        aggregator=_FakeAggregator(),  # type: ignore[arg-type]
        resolver=_FakeResolver(),  # type: ignore[arg-type]
        tracks=tracks,
        metadata=None,  # type: ignore[arg-type]
        storage=StorageService(settings.storage_dir),
        cache=MemoryCache(),
        events=EventBus(),
        settings=settings,
        http=http,  # type: ignore[arg-type]
    )


async def _make_track(tracks: TrackRepository, **overrides) -> object:
    fields = dict(
        title="Test Track",
        source="audius",
        source_id="abc123",
        stream_url=None,
        is_playable=True,
    )
    fields.update(overrides)
    return await tracks.create(**fields)


def _audio_responses(urls: list[str], body: bytes = _MP3_BODY) -> list[_FakeResponse]:
    """One redirect-check response + one download response per URL."""
    responses: list[_FakeResponse] = []
    for _ in urls:
        responses.append(_FakeResponse(status=200))  # redirect probe (no Location)
        responses.append(_FakeResponse(status=200, body=body))
    return responses


# ---------------------------------------------------------------------------
# Root cause 1 — stream resolution connected to playback
# ---------------------------------------------------------------------------
class TestAudiusStreamResolution:
    async def test_audius_track_without_url_downloads_via_get_stream(
        self, settings, tracks
    ) -> None:
        """THE production bug: Audius tracks (stream_url=None) must play."""
        track = await _make_track(tracks, stream_url=None, file_path=None)
        # Audius stream endpoint 302-redirects to the media CDN — every hop
        # is re-validated (SSRF) before the download GET is issued:
        # probe(audius)→302, probe(cdn)→200, download(cdn)→200+body.
        http = _FakeHttpSession(
            [
                _FakeResponse(
                    status=302,
                    headers={"Location": "https://cdn.example.com/s1.mp3"},
                ),
                _FakeResponse(status=200),
                _FakeResponse(status=200, body=_MP3_BODY),
            ]
        )
        source = _FakeSource(
            stream_urls=["https://audius.example/v1/tracks/abc123/stream"],
            settings=settings,
        )
        service = _make_service(settings, tracks, http, source)

        path = await service.get_playable_path(track)

        assert path.is_absolute(), "must return an absolute filesystem path"
        assert path.is_file()
        assert path.stat().st_size == len(_MP3_BODY)
        assert path.read_bytes() == _MP3_BODY
        assert source.get_stream_calls == 1
        # Resolved URL persisted on the catalog row for next time.
        assert track.stream_url == "https://audius.example/v1/tracks/abc123/stream"
        # file_path persisted as storage-RELATIVE (repo convention)…
        assert track.file_path is not None
        stored = await tracks.get(track.id)
        assert stored is not None and stored.file_path is not None
        assert not Path(stored.file_path).is_absolute()
        # …and the download followed the redirect chain to the CDN.
        assert http.requested_urls == [
            "https://audius.example/v1/tracks/abc123/stream",
            "https://cdn.example.com/s1.mp3",
            "https://cdn.example.com/s1.mp3",
        ]

    async def test_second_play_uses_cached_file_no_new_resolution(
        self, settings, tracks
    ) -> None:
        track = await _make_track(tracks, stream_url=None)
        http = _FakeHttpSession(_audio_responses(["https://cdn.example.com/s1.mp3"]))
        source = _FakeSource(
            stream_urls=["https://audius.example/v1/tracks/abc123/stream"],
            settings=settings,
        )
        service = _make_service(settings, tracks, http, source)

        first = await service.get_playable_path(track)
        second = await service.get_playable_path(track)

        assert second == first
        assert source.get_stream_calls == 1, "cached file must skip re-resolution"
        assert http.request_count == 2, "exactly one download (2 HTTP GETs)"

    async def test_no_stream_and_no_source_raises_clear_error(
        self, settings, tracks
    ) -> None:
        track = await _make_track(tracks, stream_url=None, file_path=None)
        service = _make_service(settings, tracks, _FakeHttpSession([]), _FakeSource(settings=settings))

        with pytest.raises(DownloadError, match="neither a local file nor a resolvable"):
            await service.get_playable_path(track)

    async def test_source_error_surfaces_as_download_error(
        self, settings, tracks
    ) -> None:
        track = await _make_track(tracks, stream_url=None)
        source = _FakeSource(error=MusicSourceError("provider down"), settings=settings)
        service = _make_service(settings, tracks, _FakeHttpSession([]), source)

        with pytest.raises(DownloadError, match="neither a local file nor a resolvable"):
            await service.get_playable_path(track)

    async def test_unconfigured_source_is_skipped(self, settings, tracks) -> None:
        track = await _make_track(tracks, stream_url=None)
        source = _FakeSource(stream_urls=["https://x.example/s.mp3"], configured=False, settings=settings)
        service = _make_service(settings, tracks, _FakeHttpSession([]), source)

        with pytest.raises(DownloadError):
            await service.get_playable_path(track)
        assert source.get_stream_calls == 0

    async def test_resolve_stream_url_public_wrapper(self, settings, tracks) -> None:
        track = await _make_track(tracks, stream_url="https://stored.example/a.mp3")
        source = _FakeSource(settings=settings)
        service = _make_service(settings, tracks, _FakeHttpSession([]), source)

        # Stored URL returned directly — source not consulted.
        assert (
            await service.resolve_stream_url(track)
            == "https://stored.example/a.mp3"
        )
        assert source.get_stream_calls == 0

        # Missing URL → resolved through the source and persisted.
        track2 = await _make_track(
            tracks, source_id="xyz", stream_url=None
        )
        source._stream_urls = ["https://fresh.example/b.mp3"]
        assert await service.resolve_stream_url(track2) == "https://fresh.example/b.mp3"
        assert source.get_stream_calls == 1
        assert track2.stream_url == "https://fresh.example/b.mp3"


# ---------------------------------------------------------------------------
# Root cause 2 — absolute path contract
# ---------------------------------------------------------------------------
class TestAbsolutePathContract:
    async def test_returned_path_is_absolute_and_outside_cwd_relative(
        self, settings, tracks, tmp_path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The old bug: returning ``updated.file_path`` (relative string)."""
        track = await _make_track(
            tracks, stream_url="https://cdn.example.com/song.mp3"
        )
        http = _FakeHttpSession(_audio_responses(["https://cdn.example.com/song.mp3"]))
        service = _make_service(settings, tracks, http)

        monkeypatch.chdir(tmp_path)  # prove no CWD dependence
        path = await service.get_playable_path(track)

        assert isinstance(path, Path)
        assert path.is_absolute()
        assert path.is_file()

    async def test_returned_path_is_resolved_not_the_db_string(
        self, settings, tracks
    ) -> None:
        track = await _make_track(
            tracks, stream_url="https://cdn.example.com/song.mp3"
        )
        http = _FakeHttpSession(_audio_responses(["https://cdn.example.com/song.mp3"]))
        service = _make_service(settings, tracks, http)

        path = await service.get_playable_path(track)

        assert path != track.file_path  # not the relative string
        assert str(path).endswith(Path(track.file_path).name)
        assert path == service._storage.resolve(track.file_path)


# ---------------------------------------------------------------------------
# Expired / failing URLs
# ---------------------------------------------------------------------------
class TestExpiredUrlReResolution:
    async def test_expired_stored_url_is_re_resolved_once(self, settings, tracks) -> None:
        """Signed CDN URLs expire: one fresh resolution + retry must happen."""
        track = await _make_track(
            tracks, stream_url="https://cdn.example.com/expired.mp3?sig=old"
        )
        # 1st URL: probe(200) + download(410 Gone). 2nd URL: probe + download OK.
        http = _FakeHttpSession(
            [
                _FakeResponse(status=200),
                _FakeResponse(status=410, body=b"gone"),
                _FakeResponse(status=200),
                _FakeResponse(status=200, body=_MP3_BODY),
            ]
        )
        source = _FakeSource(
            stream_urls=["https://cdn.example.com/fresh.mp3?sig=new"],
            settings=settings,
        )
        service = _make_service(settings, tracks, http, source)

        path = await service.get_playable_path(track)

        assert path.is_file()
        assert path.read_bytes() == _MP3_BODY
        assert source.get_stream_calls == 1
        assert "https://cdn.example.com/fresh.mp3?sig=new" in http.requested_urls

    async def test_same_url_twice_raises_original_error(self, settings, tracks) -> None:
        track = await _make_track(
            tracks, stream_url="https://cdn.example.com/dead.mp3"
        )
        http = _FakeHttpSession(
            [_FakeResponse(status=200), _FakeResponse(status=404, body=b"nope")]
        )
        source = _FakeSource(
            stream_urls=["https://cdn.example.com/dead.mp3"], settings=settings
        )
        service = _make_service(settings, tracks, http, source)

        with pytest.raises(DownloadError):
            await service.get_playable_path(track)

    async def test_retry_only_once_then_fails(self, settings, tracks) -> None:
        track = await _make_track(tracks, stream_url="https://cdn.example.com/a.mp3")
        # Both attempts fail with 410.
        http = _FakeHttpSession(
            [
                _FakeResponse(status=200),
                _FakeResponse(status=410),
                _FakeResponse(status=200),
                _FakeResponse(status=410),
            ]
        )
        source = _FakeSource(
            stream_urls=["https://cdn.example.com/b.mp3"], settings=settings
        )
        service = _make_service(settings, tracks, http, source)

        with pytest.raises(DownloadError):
            await service.get_playable_path(track)
        # No third resolution attempt.
        assert source.get_stream_calls == 1


# ---------------------------------------------------------------------------
# Content validation
# ---------------------------------------------------------------------------
class TestContentValidation:
    async def test_html_error_page_rejected(self, settings, tracks) -> None:
        """200-status HTML bodies must never reach the voice pipeline."""
        html = b"<!DOCTYPE html><html><body>Bandwidth limit</body></html>"
        track = await _make_track(tracks, stream_url="https://cdn.example.com/x.mp3")
        http = _FakeHttpSession(_audio_responses(["https://cdn.example.com/x.mp3"], body=html))
        service = _make_service(settings, tracks, http)

        with pytest.raises(InvalidAudioError):
            await service.get_playable_path(track)
        # Nothing persisted, no partial file left behind.
        stored = await tracks.get(track.id)
        assert stored is not None and stored.file_path is None
        downloads = (settings.storage_dir / "downloads")
        assert not any(p.name.endswith(".part") for p in downloads.iterdir())

    async def test_empty_download_rejected(self, settings, tracks) -> None:
        track = await _make_track(tracks, stream_url="https://cdn.example.com/e.mp3")
        http = _FakeHttpSession(
            _audio_responses(["https://cdn.example.com/e.mp3"], body=b"")
        )
        service = _make_service(settings, tracks, http)

        with pytest.raises(InvalidAudioError, match="empty"):
            await service.get_playable_path(track)

    async def test_failed_download_keeps_previous_good_file(
        self, settings, tracks
    ) -> None:
        """A failed re-download must not destroy the previously cached file."""
        track = await _make_track(tracks, stream_url=None)
        # First: healthy download.
        http = _FakeHttpSession(_audio_responses(["https://cdn.example.com/ok.mp3"]))
        source = _FakeSource(stream_urls=["https://cdn.example.com/ok.mp3"], settings=settings)
        service = _make_service(settings, tracks, http, source)
        good = await service.get_playable_path(track)

        # Now simulate a broken local cache file and a dead remote: the old
        # bytes survive because the temp file is validated BEFORE renaming.
        good.write_bytes(b"ID3corrupted-not-really")
        # (header still says ID3 so it validates — use a truly broken header)
        good.write_bytes(b"XXXX-not-audio")
        http2 = _FakeHttpSession(
            [
                _FakeResponse(status=200),
                _FakeResponse(status=500, body=b"err"),
                _FakeResponse(status=200),
                _FakeResponse(status=500, body=b"err"),
            ]
        )
        service2 = _make_service(settings, tracks, http2, _FakeSource(stream_urls=["https://cdn.example.com/dead.mp3"], settings=settings))
        with pytest.raises(DownloadError):
            await service2.get_playable_path(track)

    async def test_broken_cached_file_triggers_redownload(
        self, settings, tracks
    ) -> None:
        track = await _make_track(tracks, stream_url=None)
        http = _FakeHttpSession(_audio_responses(["https://cdn.example.com/1.mp3"]))
        source = _FakeSource(stream_urls=["https://cdn.example.com/1.mp3"], settings=settings)
        service = _make_service(settings, tracks, http, source)
        path = await service.get_playable_path(track)

        # Corrupt the cached file → next call must re-download successfully.
        path.write_bytes(b"not audio at all")
        http3 = _FakeHttpSession(_audio_responses(["https://cdn.example.com/2.mp3"]))
        source3 = _FakeSource(stream_urls=["https://cdn.example.com/2.mp3"], settings=settings)
        service3 = _make_service(settings, tracks, http3, source3)
        again = await service3.get_playable_path(track)
        assert again == path
        assert path.read_bytes() == _MP3_BODY


# ---------------------------------------------------------------------------
# Local file fast paths
# ---------------------------------------------------------------------------
class TestLocalFileFastPath:
    async def test_valid_local_file_short_circuits(self, settings, tracks) -> None:
        storage = StorageService(settings.storage_dir)
        storage.save("music/upload-1.mp3", _MP3_BODY)
        track = await _make_track(tracks, file_path="music/upload-1.mp3")
        http = _FakeHttpSession([])  # any request fails the test
        service = _make_service(settings, tracks, http)

        path = await service.get_playable_path(track)
        assert path == storage.resolve("music/upload-1.mp3")
        assert http.request_count == 0

    async def test_legacy_absolute_path_supported(self, settings, tracks, tmp_path) -> None:
        external = tmp_path / "external-song.mp3"
        external.write_bytes(_MP3_BODY)
        track = await _make_track(tracks, file_path=str(external))
        service = _make_service(settings, tracks, _FakeHttpSession([]))

        path = await service.get_playable_path(track)
        assert path == external

    async def test_empty_local_file_is_not_trusted(self, settings, tracks) -> None:
        storage = StorageService(settings.storage_dir)
        storage.save("music/broken.mp3", b"")
        track = await _make_track(
            tracks, file_path="music/broken.mp3", stream_url=None
        )
        # No source can resolve → clear error (not a silent empty-file play).
        service = _make_service(settings, tracks, _FakeHttpSession([]))
        with pytest.raises(DownloadError):
            await service.get_playable_path(track)


# ---------------------------------------------------------------------------
# Concurrency & temp-file safety
# ---------------------------------------------------------------------------
class TestConcurrency:
    async def test_concurrent_calls_download_once(self, settings, tracks) -> None:
        """Per-track lock + re-check: N concurrent plays = 1 download."""
        track = await _make_track(tracks, stream_url="https://cdn.example.com/c.mp3")
        http = _FakeHttpSession(_audio_responses(["https://cdn.example.com/c.mp3"]))
        service = _make_service(settings, tracks, http)

        paths = await asyncio.gather(
            *(service.get_playable_path(track) for _ in range(5))
        )
        assert all(p == paths[0] for p in paths)
        assert http.request_count == 2, "exactly one download happened"

    async def test_no_part_files_left_behind(self, settings, tracks) -> None:
        track = await _make_track(tracks, stream_url="https://cdn.example.com/p.mp3")
        http = _FakeHttpSession(
            [_FakeResponse(status=200), _FakeResponse(status=404, body=b"")]
        )
        service = _make_service(settings, tracks, http)
        with pytest.raises(DownloadError):
            await service.get_playable_path(track)

        downloads = settings.storage_dir / "downloads"
        leftovers = [p for p in downloads.iterdir() if p.name.endswith(".part")]
        assert leftovers == []

    async def test_unique_temp_names_allow_parallel_different_tracks(
        self, settings, tracks
    ) -> None:
        """Two different tracks downloading at once use distinct temp files."""
        t1 = await _make_track(tracks, source_id="a1", stream_url="https://cdn.example.com/a.mp3")
        t2 = await _make_track(
            tracks, source="jamendo", source_id="j9", stream_url="https://cdn.example.com/j.mp3"
        )
        http = _FakeHttpSession(
            _audio_responses(["https://cdn.example.com/a.mp3"])
            + _audio_responses(["https://cdn.example.com/j.mp3"])
        )
        service = _make_service(settings, tracks, http)

        p1, p2 = await asyncio.gather(
            service.get_playable_path(t1), service.get_playable_path(t2)
        )
        assert p1 != p2
        assert p1.is_file() and p2.is_file()


# ---------------------------------------------------------------------------
# AudiusSource — the concrete provider end of the pipeline
# ---------------------------------------------------------------------------
class TestAudiusSourceIntegration:
    """The real AudiusSource class against a scripted HTTP session.

    ``_host`` is pre-seeded to skip discovery; ``get_stream()`` must return
    the documented stream endpoint which the downloader then fetches
    (302 → media CDN), completing the search→playback chain for tracks
    whose search results deliberately carry ``stream_url=None``.
    """

    def _source(self, settings: Settings, http: _FakeHttpSession):
        from app.music.sources.audius import AudiusSource

        source = AudiusSource(settings, http)  # type: ignore[arg-type]
        source._host = "https://audius-discovery.example"
        return source

    async def test_search_results_have_no_stream_url_by_design(
        self, settings, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        http = _FakeHttpSession([])
        source = self._source(settings, http)

        async def fake_search_payload(path, params, **kwargs):
            return {
                "data": [
                    {
                        "id": "track-xyz",
                        "title": "Sunset Drive",
                        "duration": 213,
                        "play_count": 1000,
                        "user": {"name": "DJ Aurora", "handle": "djaurora"},
                    }
                ]
            }

        monkeypatch.setattr(source, "_request", fake_search_payload)
        results = await source.search("sunset drive")

        assert len(results) == 1
        assert results[0].source == "audius"
        assert results[0].source_id == "track-xyz"
        assert results[0].stream_url is None, (
            "Audius search payloads carry no media URL — playback must go "
            "through get_stream()"
        )

    async def test_get_stream_returns_endpoint_url(self, settings) -> None:
        http = _FakeHttpSession([])
        source = self._source(settings, http)

        info = await source.get_stream("track-xyz")

        assert info is not None
        assert info.is_local is False
        assert info.url_or_path == (
            "https://audius-discovery.example"
            "/v1/tracks/track-xyz/stream?app_name=MusicBot"
        )

    async def test_full_chain_search_result_to_playable_file(
        self, settings, tracks, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Search result (no URL) → resolver → get_playable_path → file."""
        http = _FakeHttpSession(
            [
                # discovery probe is skipped (host pre-seeded); the stream
                # endpoint 302s to the CDN, then the media file downloads.
                _FakeResponse(
                    status=302,
                    headers={"Location": "https://cdn.example.com/media.mp3"},
                ),
                _FakeResponse(status=200),
                _FakeResponse(status=200, body=_MP3_BODY),
            ]
        )
        source = self._source(settings, http)

        async def fake_search_payload(path, params, **kwargs):
            return {
                "data": [
                    {
                        "id": "track-xyz",
                        "title": "Sunset Drive",
                        "duration": 213,
                        "user": {"name": "DJ Aurora"},
                    }
                ]
            }

        monkeypatch.setattr(source, "_request", fake_search_payload)

        from app.database.base import Base  # noqa: F401 — already imported
        from app.database.repositories.music import (
            AlbumRepository,
            ArtistRepository,
            GenreRepository,
        )
        from app.music.resolver import TrackResolver

        resolver = TrackResolver(
            tracks,
            ArtistRepository(tracks.sessions),
            AlbumRepository(tracks.sessions),
            GenreRepository(tracks.sessions),
        )
        service = MusicService(
            sources=[source],
            aggregator=_PassThroughAggregator(source),
            resolver=resolver,
            tracks=tracks,
            metadata=None,  # type: ignore[arg-type]
            storage=StorageService(settings.storage_dir),
            cache=MemoryCache(),
            events=EventBus(),
            settings=settings,
            http=http,  # type: ignore[arg-type]
        )

        # 1. search → resolver persists the Audius track with stream_url=None
        found = await service.search("sunset drive")
        assert len(found) == 1
        assert found[0].source == "audius"
        assert found[0].stream_url is None

        # 2. playback: get_stream() is consulted, media downloads, path is real
        path = await service.get_playable_path(found[0])
        assert path.is_absolute()
        assert path.is_file()
        assert path.read_bytes() == _MP3_BODY

        # 3. The resolved stream URL was persisted for subsequent plays.
        stored = await tracks.get(found[0].id)
        assert stored is not None
        assert stored.stream_url is not None
        assert "stream" in stored.stream_url


# ---------------------------------------------------------------------------
# Header sniffing unit tests
# ---------------------------------------------------------------------------
class TestAudioHeaderSniffing:
    @pytest.mark.parametrize(
        ("head", "expected"),
        [
            (b"ID3\x04\x00\x00\x00\x00", True),           # tagged MP3
            (b"\xff\xfb\x90\x00\x00", True),              # raw MP3 frame sync
            (b"\xff\xf1\x4c\x80", True),                  # ADTS AAC
            (b"OggS\x00\x02...", True),                   # Ogg container
            (b"fLaC\x00\x00\x00\x22", True),              # FLAC
            (b"RIFF\x24\x08\x08\x00WAVE", True),          # WAV
            (b"\x00\x00\x00\x20ftypM4A ", True),          # M4A
            (b"\x30\x26\xb2\x75\x8e\x66", True),          # WMA
            (b"MThd\x00\x00\x00\x06", True),              # MIDI
            (b"MAC \x96\x0f", True),                      # APE
            (b"<!DOCTYPE html>", False),                  # HTML error page
            (b'{"error":1}', False),                      # JSON error body
            (b"\x89PNG\r\n\x1a\n", False),                # image
            (b"\x1f\x8b\x08\x00", False),                 # gzip
            (b"XXXX", False),                             # garbage
            (b"", False),                                 # empty
            (b"ID3", False),                              # too short
        ],
    )
    def test_header_recognition(self, head: bytes, expected: bool) -> None:
        assert _recognized_audio_header(head) is expected

    def test_validate_missing_file(self, tmp_path: Path) -> None:
        with pytest.raises(InvalidAudioError, match="not accessible"):
            _validate_audio_file(tmp_path / "nope.mp3")

    def test_validate_empty_file(self, tmp_path: Path) -> None:
        empty = tmp_path / "empty.mp3"
        empty.write_bytes(b"")
        with pytest.raises(InvalidAudioError, match="empty"):
            _validate_audio_file(empty)

    def test_validate_good_file(self, tmp_path: Path) -> None:
        good = tmp_path / "good.mp3"
        good.write_bytes(_MP3_BODY)
        _validate_audio_file(good)  # no exception

    def test_validate_garbage_file(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad.mp3"
        bad.write_bytes(b"<html>oops</html>")
        with pytest.raises(InvalidAudioError, match="not recognizable audio"):
            _validate_audio_file(bad)

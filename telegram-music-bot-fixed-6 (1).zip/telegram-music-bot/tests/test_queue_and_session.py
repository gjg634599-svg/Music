"""Queue manager and playback session tests."""

from __future__ import annotations

import asyncio

import pytest

from app.errors import TrackNotFoundError, ValidationError
from app.playback.events import EventBus
from app.playback.queue import QueueOwner, QueueManager
from app.playback.session import SessionManager

from .conftest import build_services


@pytest.fixture
async def queue(services) -> QueueManager:
    return services.queue


@pytest.fixture
def user_owner() -> QueueOwner:
    return QueueOwner(kind="user", id=101)


@pytest.fixture
def group_owner() -> QueueOwner:
    return QueueOwner(kind="group", id=-100999)


class TestQueueOwner:
    def test_topic(self, user_owner: QueueOwner) -> None:
        assert user_owner.topic() == "user:101"

    def test_invalid_kind_rejected(self) -> None:
        with pytest.raises(ValidationError):
            QueueOwner(kind="channel", id=1)

    def test_owner_equality(self) -> None:
        assert QueueOwner(kind="user", id=1) == QueueOwner(kind="user", id=1)
        assert QueueOwner(kind="user", id=1) != QueueOwner(kind="group", id=1)


class TestQueueManager:
    async def test_add_and_pop_order(self, queue, db_setup, user_owner) -> None:
        a, b, c = db_setup.track_ids[:3]
        assert await queue.add(user_owner, a, added_by=101) == 1
        assert await queue.add(user_owner, b, added_by=101) == 2
        assert await queue.add(user_owner, c, added_by=101) == 3

        first = await queue.pop_next(user_owner)
        second = await queue.pop_next(user_owner)
        third = await queue.pop_next(user_owner)
        assert (first.track_id, second.track_id, third.track_id) == (a, b, c)
        assert await queue.pop_next(user_owner) is None

    async def test_peek_does_not_consume(self, queue, db_setup, user_owner) -> None:
        a, b = db_setup.track_ids[:2]
        await queue.add(user_owner, a)
        await queue.add(user_owner, b)

        peeked = await queue.peek_next(user_owner)
        assert peeked is not None and peeked.track_id == a
        assert await queue.size(user_owner) == 2

    async def test_front_insert(self, queue, db_setup, user_owner) -> None:
        a, b, c = db_setup.track_ids[:3]
        await queue.add(user_owner, a)
        await queue.add(user_owner, b)
        await queue.add(user_owner, c, front=True)  # jumps the queue

        assert await queue.size(user_owner) == 3
        items = await queue.get_queue(user_owner)
        assert [item.track_id for item in items] == [c, a, b]

    async def test_shuffle_keeps_size(self, queue, db_setup, user_owner) -> None:
        for track_id in db_setup.track_ids:
            await queue.add(user_owner, track_id)
        size_before = await queue.size(user_owner)

        size_after = await queue.shuffle(user_owner)
        assert size_after == size_before == len(db_setup.track_ids)

        items = await queue.get_queue(user_owner)
        assert sorted(item.track_id for item in items) == sorted(db_setup.track_ids)

    async def test_clear(self, queue, db_setup, user_owner) -> None:
        for track_id in db_setup.track_ids[:3]:
            await queue.add(user_owner, track_id)
        assert await queue.clear(user_owner) == 3
        assert await queue.size(user_owner) == 0
        assert await queue.clear(user_owner) == 0

    async def test_remove(self, queue, db_setup, user_owner) -> None:
        a, b = db_setup.track_ids[:2]
        await queue.add(user_owner, a)
        item = await queue.peek_next(user_owner)
        await queue.add(user_owner, b)

        assert await queue.remove(user_owner, item.id) is True
        assert await queue.size(user_owner) == 1
        assert await queue.remove(user_owner, item.id) is False

    async def test_add_unknown_track_rejected(self, queue, user_owner) -> None:
        with pytest.raises(TrackNotFoundError):
            await queue.add(user_owner, 999_999)

    async def test_owners_are_isolated(self, queue, db_setup, user_owner, group_owner) -> None:
        a, b = db_setup.track_ids[:2]
        await queue.add(user_owner, a)
        await queue.add(group_owner, b)

        assert await queue.size(user_owner) == 1
        assert await queue.size(group_owner) == 1
        assert (await queue.pop_next(user_owner)).track_id == a
        assert await queue.size(group_owner) == 1

    async def test_queue_empty_event_on_drain(
        self, services, db_setup, mk_sessions, user_owner
    ) -> None:
        events = services.events
        received: list = []

        async def on_queue_empty(event) -> None:  # noqa: ANN001
            received.append(event)

        events.subscribe("queue_empty:user:101", on_queue_empty)
        a = db_setup.track_ids[0]
        await services.queue.add(user_owner, a)
        await services.queue.pop_next(user_owner)

        assert received and received[0].name == "queue_empty:user:101"


class TestSessionManager:
    async def test_get_or_create_personal(self, services, user_owner) -> None:
        sessions = SessionManager(
            services.sessions_repo, services.tracks_repo, services.events
        )
        session = await sessions.get(user_owner)
        assert session.session_type == "personal"
        assert session.user_id == 101
        assert session.status == "idle"

    async def test_get_or_create_group(self, services, group_owner) -> None:
        sessions = SessionManager(
            services.sessions_repo, services.tracks_repo, services.events
        )
        session = await sessions.get(group_owner)
        assert session.session_type == "group"
        assert session.group_id == -100999

    async def test_set_now_playing_persists(self, services, db_setup, user_owner) -> None:
        track_id = db_setup.track_ids[0]
        await services.sessions_manager.set_now_playing(
            user_owner, track_id, queue_item_id=None, message_id=55, chat_id=101
        )

        # A fresh manager sees the persisted state.
        fresh = SessionManager(
            services.sessions_repo, services.tracks_repo, EventBus()
        )
        session = await fresh.get(user_owner)
        assert session.current_track_id == track_id
        assert session.now_playing_message_id == 55
        assert session.control_chat_id == 101

    async def test_preference_setters(self, services, user_owner) -> None:
        manager = services.sessions_manager
        assert await manager.set_repeat(user_owner, "one") == "one"
        assert await manager.set_shuffle(user_owner, True) is True
        assert await manager.set_autoplay(user_owner, False) is False
        assert await manager.set_volume(user_owner, 250) == 100  # clamped

        session = await manager.get(user_owner)
        assert (session.repeat_mode, session.shuffle, session.autoplay, session.volume) == (
            "one",
            True,
            False,
            100,
        )

        with pytest.raises(ValidationError):
            await manager.set_repeat(user_owner, "sideways")

    async def test_update_status_freezes_position(self, services, user_owner) -> None:
        manager = services.sessions_manager
        await manager.set_now_playing(
            user_owner, 1, queue_item_id=None, message_id=None, chat_id=None
        )
        paused = await manager.update_status(user_owner, "paused", position_seconds=7)
        assert paused.status == "paused"

        resumed = await manager.update_status(user_owner, "playing")
        assert resumed.status == "playing"

        with pytest.raises(ValidationError):
            await manager.update_status(user_owner, "warping")

    async def test_timer_publishes_track_end(self, services, user_owner) -> None:
        manager = services.sessions_manager
        events = services.events
        await manager.get(user_owner)

        await manager.start_timer(user_owner, 0.05)
        event = await asyncio.wait_for(
            events.wait_for("track_end:user:101", timeout=2), 2
        )
        assert event.name == "track_end:user:101"

    async def test_cancelled_timer_does_not_publish(self, services, user_owner) -> None:
        manager = services.sessions_manager
        events = services.events
        await manager.get(user_owner)

        await manager.start_timer(user_owner, 0.05)
        await manager.cancel_timer(user_owner)
        with pytest.raises((asyncio.TimeoutError, TimeoutError)):
            await asyncio.wait_for(
                events.wait_for("track_end:user:101", timeout=0.3), 0.4
            )

    async def test_stale_timer_superseded_by_new_one(
        self, services, user_owner
    ) -> None:
        """Starting a second timer invalidates the first (token guard)."""
        manager = services.sessions_manager
        events = services.events
        await manager.get(user_owner)

        await manager.start_timer(user_owner, 0.05)
        await manager.start_timer(user_owner, 5)  # supersedes the short timer

        with pytest.raises((asyncio.TimeoutError, TimeoutError)):
            await asyncio.wait_for(
                events.wait_for("track_end:user:101", timeout=0.4), 0.5
            )
        await manager.cancel_timer(user_owner)

    async def test_cleanup_cancels_timers(self, services, user_owner) -> None:
        manager = services.sessions_manager
        await manager.get(user_owner)
        await manager.start_timer(user_owner, 30)
        await manager.cleanup()
        data = manager._runtime.get(user_owner.topic())
        assert data is None or data.timer is None or data.timer.done()

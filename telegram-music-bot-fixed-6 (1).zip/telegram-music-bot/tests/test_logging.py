"""Logging regression tests (production incident: parameterized records).

Verifies that the structured logging pipeline renders every record style
used by the application and its dependencies — aiogram polling/update
records, Telethon connection records, plain and parameterized messages,
mapping interpolation, exception tracebacks — **without** the
``TypeError: not all arguments converted during string formatting`` /
``--- Logging error ---`` failures seen in production.

The bug's root cause: ``SecretRedactingFilter`` rendered ``record.msg``
via ``getMessage()`` and then dereferenced the nonexistent
``logging.Mapping`` attribute; the resulting ``AttributeError`` was
swallowed by a bare ``except`` and the record was left with a rendered
message plus its original arguments, so every later ``getMessage()``
call raised ``TypeError``.
"""

from __future__ import annotations

import io
import logging
import sys

import pytest

from app.logging import (
    SecretRedactingFilter,
    StructuredFormatter,
    log_extra,
    redact,
    redact_text,
    render_message,
)


@pytest.fixture
def capture() -> io.StringIO:
    """A fresh stream each test."""
    return io.StringIO()


@pytest.fixture
def logger(capture: io.StringIO) -> logging.Logger:
    """A logger wired to our formatter+filter writing into *capture*."""
    handler = logging.StreamHandler(capture)
    handler.setFormatter(StructuredFormatter())
    handler.addFilter(SecretRedactingFilter())
    log = logging.getLogger("test.logging")
    log.handlers.clear()
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)
    log.propagate = False
    return log


def _lines(capture: io.StringIO) -> list[str]:
    return [line for line in capture.getvalue().splitlines() if line]


# ----------------------------------------------------------------------
# 1. Standard parameterized messages (the production failure)
# ----------------------------------------------------------------------
class TestParameterizedMessages:
    def test_plain_message(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("Connected")
        assert "INFO test.logging Connected" in capture.getvalue()

    def test_positional_args(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("Connected to %s as %s", "localhost", "admin")
        assert "Connected to localhost as admin" in capture.getvalue()

    def test_single_arg(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("Received update %s", 234254247)
        assert "Received update 234254247" in capture.getvalue()

    def test_args_survive_for_other_handlers(
        self, capture: io.StringIO
    ) -> None:
        """Two handlers must both be able to format the same record."""
        stream2 = io.StringIO()
        h1 = logging.StreamHandler(capture)
        h2 = logging.StreamHandler(stream2)
        for handler in (h1, h2):
            handler.setFormatter(StructuredFormatter())
            handler.addFilter(SecretRedactingFilter())
        log = logging.getLogger("test.twohandlers")
        log.handlers.clear()
        log.addHandler(h1)
        log.addHandler(h2)
        log.setLevel(logging.INFO)
        log.propagate = False

        log.info("Run polling for bot @%s id=%s - %r", "Filvenmusic_bot", 8041509872, "Filven music")

        for stream in (capture, stream2):
            rendered = stream.getvalue()
            assert "Run polling for bot @Filvenmusic_bot id=8041509872 - 'Filven music'" in rendered
            assert "TypeError" not in rendered
            assert "--- Logging error ---" not in rendered

    def test_record_not_mutated_by_filter(self) -> None:
        """The filter must leave msg/args of positional records untouched."""
        record = logging.LogRecord(
            "test", logging.INFO, __file__, 1, "Connecting to %s...", ("tcp",), None
        )
        secret_filter = SecretRedactingFilter()
        assert secret_filter.filter(record) is True
        assert record.msg == "Connecting to %s..."
        assert record.args == ("tcp",)
        assert "Connecting to tcp..." == render_message(record)


# ----------------------------------------------------------------------
# 2. Real-world aiogram / Telethon message formats
# ----------------------------------------------------------------------
class TestThirdPartyFormats:
    def test_aiogram_polling_start(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info(
            "Run polling for bot @%s id=%s - %r",
            "Filvenmusic_bot", 8041509872, "Filven music",
        )
        rendered = capture.getvalue()
        assert "Run polling for bot @Filvenmusic_bot id=8041509872 - 'Filven music'" in rendered
        assert "Logging error" not in rendered

    def test_aiogram_update_handled(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info(
            "Update id=%s is handled. Duration %d ms by bot id=%s",
            234254247, 2846.679727983428, 8041509872,
        )
        assert "Update id=234254247 is handled. Duration 2846 ms by bot id=8041509872" in capture.getvalue()

    def test_aiogram_polling_stop(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("Polling stopped for bot id=%s", 8041509872)
        assert "Polling stopped for bot id=8041509872" in capture.getvalue()

    def test_telethon_connection(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("Connecting to %s...", "MTTelegramTcpTransport")
        assert "Connecting to MTTelegramTcpTransport..." in capture.getvalue()

    def test_debug_level_records(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.debug("Update id=%s is handled by bot id=%s", 1, 2)
        assert "Update id=1 is handled by bot id=2" in capture.getvalue()


# ----------------------------------------------------------------------
# 3. Mapping interpolation and structured context
# ----------------------------------------------------------------------
class TestMappingAndStructured:
    def test_mapping_args_interpolate(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("Signed in as %(user)s with %(roles)s roles", {"user": "alice", "roles": 2})
        assert "Signed in as alice with 2 roles" in capture.getvalue()

    def test_mapping_args_redacted_by_key(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("auth token=%(token)s user=%(user)s", {"token": "super-secret", "user": "bob"})
        rendered = capture.getvalue()
        assert "super-secret" not in rendered
        assert "***REDACTED***" in rendered
        assert "user=bob" in rendered

    def test_extra_fields_rendered(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("playback.start", extra=log_extra(group_id=-100123, track_id=123))
        line = capture.getvalue()
        assert "playback.start" in line
        assert "group_id=-100123" in line
        assert "track_id=123" in line

    def test_extra_fields_redacted(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("auth.attempt", extra=log_extra(token="abc123", user="dave"))
        rendered = capture.getvalue()
        assert "abc123" not in rendered
        assert "token=***REDACTED***" in rendered
        assert "user=dave" in rendered

    def test_json_format(self, capture: io.StringIO) -> None:
        handler = logging.StreamHandler(capture)
        handler.setFormatter(StructuredFormatter(fmt="json"))
        handler.addFilter(SecretRedactingFilter())
        log = logging.getLogger("test.json")
        log.handlers.clear()
        log.addHandler(handler)
        log.setLevel(logging.INFO)
        log.propagate = False
        log.info("hello %s", "world", extra=log_extra(city="Tehran"))
        rendered = capture.getvalue()
        assert '"msg": "hello world"' in rendered
        assert '"city": "Tehran"' in rendered


# ----------------------------------------------------------------------
# 4. Exception tracebacks
# ----------------------------------------------------------------------
class TestExceptions:
    def test_traceback_appended(self, logger: logging.Logger, capture: io.StringIO) -> None:
        try:
            raise ValueError("boom %s", "x")
        except ValueError:
            logger.exception("handler failed for update %s", 42)
        rendered = capture.getvalue()
        assert "handler failed for update 42" in rendered
        assert "Traceback (most recent call last)" in rendered
        assert "ValueError" in rendered

    def test_traceback_with_parameterized_message(
        self, logger: logging.Logger, capture: io.StringIO
    ) -> None:
        try:
            1 / 0
        except ZeroDivisionError:
            logger.error("update %s crashed in %s", 7, "playback", exc_info=True)
        rendered = capture.getvalue()
        assert "update 7 crashed in playback" in rendered
        assert "ZeroDivisionError" in rendered


# ----------------------------------------------------------------------
# 5. Secret redaction on the rendered text (pattern layer)
# ----------------------------------------------------------------------
class TestRenderedSecretRedaction:
    def test_bot_token_masked(self, logger: logging.Logger, capture: io.StringIO) -> None:
        token = "8041509872:" + "A" * 35
        logger.info("using token %s", token)
        rendered = capture.getvalue()
        assert token not in rendered
        assert "***REDACTED***" in rendered

    def test_api_hash_masked(self, logger: logging.Logger, capture: io.StringIO) -> None:
        api_hash = "a1b2c3d4" * 4  # 32 hex chars
        logger.info("configured with hash %s", api_hash)
        rendered = capture.getvalue()
        assert api_hash not in rendered

    def test_session_string_masked(self, logger: logging.Logger, capture: io.StringIO) -> None:
        session_string = "1" + "A" * 300  # long base64-ish blob
        logger.info("loaded session %s", session_string)
        rendered = capture.getvalue()
        assert session_string not in rendered

    def test_phone_number_masked(self, logger: logging.Logger, capture: io.StringIO) -> None:
        logger.info("login attempt for %+d", 989123456789)
        rendered = capture.getvalue()
        assert "+989123456789" not in rendered
        assert "***REDACTED***" in rendered

    def test_key_value_leak_masked(self) -> None:
        assert "api_key" in redact_text("config api_key=deadbeefdeadbeefdeadbeefdeadbeef")
        assert "deadbeefdeadbeefdeadbeefdeadbeef" not in redact_text(
            "config api_key=deadbeefdeadbeefdeadbeefdeadbeef"
        )

    def test_redact_text_idempotent(self) -> None:
        once = redact_text("token=123456789:" + "A" * 35)
        assert redact_text(once) == once

    def test_redact_mapping_keys_preserved(self) -> None:
        out = redact({"token": "t", "count": 3})
        assert out == {"token": "***REDACTED***", "count": 3}


# ----------------------------------------------------------------------
# 6. Malformed records never crash OUR pipeline
#
# Malformed records are exercised through the formatter directly:
# emitting them through the logging framework would make *pytest's own*
# capturing handler (a plain stdlib formatter) raise — which is stdlib
# behaviour for malformed records, not something this project controls.
# In production the stdlib prints ``--- Logging error ---`` and continues.
# ----------------------------------------------------------------------
class TestMalformedRecords:
    def test_placeholder_mismatch_renders_fallback(self) -> None:
        record = logging.LogRecord(
            "t", logging.INFO, __file__, 1, "Broken template %s %s", ("only-one",), None
        )
        formatter = StructuredFormatter()
        out = formatter.format(record)  # must not raise
        assert "Broken template %s %s" in out
        assert "unformattable" in out

    def test_percent_literal_with_args(self) -> None:
        record = logging.LogRecord(
            "t", logging.INFO, __file__, 1, "100% done", ("unused-arg",), None
        )
        out = StructuredFormatter().format(record)
        assert "unformattable" in out
        assert "100% done" in out

    def test_wellformed_records_never_use_fallback(
        self, logger: logging.Logger, capture: io.StringIO, capsys: pytest.CaptureFixture
    ) -> None:
        logger.info("Run polling for bot @%s id=%s - %r", "Filvenmusic_bot", 8041509872, "Filven music")
        captured = capsys.readouterr()
        assert "--- Logging error ---" not in captured.err
        assert captured.err == ""
        assert "unformattable" not in capture.getvalue()


# ----------------------------------------------------------------------
# 7. render_message unit checks
# ----------------------------------------------------------------------
class TestRenderMessage:
    def test_normal_record(self) -> None:
        record = logging.LogRecord(
            "t", logging.INFO, __file__, 1, "v=%s", (1,), None
        )
        assert render_message(record) == "v=1"

    def test_malformed_record_no_raise(self) -> None:
        record = logging.LogRecord(
            "t", logging.INFO, __file__, 1, "v=%s %s", (1,), None
        )
        out = render_message(record)  # must not raise
        assert "v=%s %s" in out

    def test_mapping_record(self) -> None:
        # Logger._log unwraps a single mapping argument; mimic that here.
        record = logging.LogRecord(
            "t", logging.INFO, __file__, 1, "%(a)s", ({"a": 5},), None
        )
        assert record.args == {"a": 5}
        assert render_message(record) == "5"


# ----------------------------------------------------------------------
# 8. Full setup_logging path (the real production configuration)
# ----------------------------------------------------------------------
class TestSetupLogging:
    def test_setup_renders_parameterized_records(self, capsys: pytest.CaptureFixture) -> None:
        from app.logging import setup_logging

        setup_logging("INFO", "text", force=True)
        log = logging.getLogger("aiogram")
        log.propagate = True
        log.info("Run polling for bot @%s id=%s - %r", "Filvenmusic_bot", 8041509872, "Filven music")
        captured = capsys.readouterr()
        assert "Run polling for bot @Filvenmusic_bot id=8041509872 - 'Filven music'" in captured.err
        assert "--- Logging error ---" not in captured.err
        assert "TypeError" not in captured.err
        # Restore quiet state for other tests.
        logging.getLogger().handlers.clear()
        logging.getLogger("aiogram").propagate = False

    def test_setup_is_idempotent(self) -> None:
        from app.logging import setup_logging

        setup_logging("INFO", "text", force=True)
        root = logging.getLogger()
        count = len(root.handlers)
        setup_logging("DEBUG", "json")  # ignored — already configured
        assert len(logging.getLogger().handlers) == count
        setup_logging("INFO", "text", force=True)  # restore
        assert len(logging.getLogger().handlers) == 1


# Silence the module-level import of `sys` linter when unused elsewhere.
_ = sys

"""Handler-module smoke tests + AdminGuardMiddleware behaviour.

Part 1 — every module under ``app/bot/handlers`` (incl. the ``admin``
subpackage) and ``app/bot/callbacks`` exposes ``router`` + ``register()``
where applicable, and ``register()`` really attaches its router to a parent.

Notes on the app's real wiring (verified, not bugs):

* ``app.bot.callbacks.group`` / ``app.bot.callbacks.admin`` are thin
  re-exports of the owning handlers' routers — the SAME router object. aiogram
  routers are single-parent, so each unique router is attached exactly once
  per test session (``register-once`` helper below).
* ``app.bot.handlers.admin`` submodules expose routers but no ``register``:
  the package ``__init__`` aggregates all of them (asserted below).
* ``app.bot.handlers.admin.states`` is the FSM states container (AdminFSM) —
  the only intentionally router-less module.

Part 2 — ``AdminGuardMiddleware``: a non-admin pressing any ``adm:`` button
is dropped with a uniform denial answer (handler never runs); an admin
passes; non-``adm:`` callbacks are untouched even for non-admins.
"""

from __future__ import annotations

import importlib
import pkgutil
from types import SimpleNamespace
from typing import Any

import pytest
from aiogram import Router
from aiogram.types import CallbackQuery, User

from app.bot.middleware.auth import ADMIN_PANEL_DENIED, AdminGuardMiddleware

HANDLER_PACKAGE = "app.bot.handlers"
ADMIN_PACKAGE = "app.bot.handlers.admin"
CALLBACK_PACKAGE = "app.bot.callbacks"


def _iter_modules(package_name: str, *, skip: frozenset[str]) -> list[str]:
    package = importlib.import_module(package_name)
    modules: list[str] = []
    for module_info in pkgutil.iter_modules(package.__path__):
        if module_info.name in skip:
            continue
        modules.append(f"{package_name}.{module_info.name}")
    return modules


def _top_level_router_modules() -> list[str]:
    """Handlers + callbacks modules that individually own a register().

    The ``admin`` subpackage is covered by ``TestAdminPackageAggregation``.
    """
    return _iter_modules(HANDLER_PACKAGE, skip=frozenset({"__init__", "admin"})) + _iter_modules(
        CALLBACK_PACKAGE, skip=frozenset({"__init__"})
    )


def _admin_submodules() -> list[str]:
    return _iter_modules(ADMIN_PACKAGE, skip=frozenset({"__init__", "states"}))


#: Routers already attached during this session (aiogram routers are
#: single-parent; shared re-export routers must not be attached twice).
_ATTACHED: set[int] = set()


def _register_once(module) -> tuple[Router, int] | None:
    """register() the module's router into a scratch parent — at most once
    per unique router object (returns the parent + prior sub-router count,
    or ``None`` for an already-attached shared re-export).
    """
    key = id(module.router)
    if key in _ATTACHED:
        return None
    _ATTACHED.add(key)
    parent = Router(name=f"scratch-for-{module.router.name}")
    before = len(parent.sub_routers)
    module.register(parent)
    return parent, before


def _has_handlers(router: Router) -> bool:
    """Direct handlers anywhere in the router tree?"""
    if any(observer.handlers for observer in router.observers.values()):
        return True
    return any(_has_handlers(sub) for sub in router.sub_routers)


# ---------------------------------------------------------------------------
# Part 1 — router + register contract
# ---------------------------------------------------------------------------
class TestRouterModules:
    def test_module_list_is_not_trivially_empty(self) -> None:
        assert len(_top_level_router_modules()) >= 13
        assert len(_admin_submodules()) >= 10

    @pytest.mark.parametrize("module_name", _top_level_router_modules())
    def test_module_exposes_router_and_register(self, module_name: str) -> None:
        module = importlib.import_module(module_name)
        router = getattr(module, "router", None)
        assert isinstance(router, Router), f"{module_name} has no Router"
        assert callable(getattr(module, "register", None)), (
            f"{module_name} has no register()"
        )

    @pytest.mark.parametrize("module_name", _top_level_router_modules())
    def test_register_attaches_to_parent(self, module_name: str) -> None:
        module = importlib.import_module(module_name)
        outcome = _register_once(module)
        if outcome is None:
            # Shared re-export router (callbacks.group / callbacks.admin) — its
            # owner module already attached the very same object.
            assert callable(module.register)
            return
        parent, before = outcome
        assert len(parent.sub_routers) == before + 1, (
            f"{module_name}.register() did not include its router"
        )

    @pytest.mark.parametrize("module_name", _top_level_router_modules())
    def test_every_router_module_registers_observers(self, module_name: str) -> None:
        """A router tree that observes nothing would silently drop updates."""
        module = importlib.import_module(module_name)
        _register_once(module)  # ensure wired (no-op for shared re-exports)
        assert _has_handlers(module.router), f"{module_name}.router has no handlers"


class TestAdminPackageAggregation:
    def test_admin_package_exposes_router_and_register(self) -> None:
        package = importlib.import_module(ADMIN_PACKAGE)
        assert isinstance(package.router, Router)
        assert callable(package.register)

    @pytest.mark.parametrize("module_name", _admin_submodules())
    def test_admin_submodule_exposes_router(self, module_name: str) -> None:
        """Admin submodules carry routers aggregated by the package register()."""
        module = importlib.import_module(module_name)
        assert isinstance(getattr(module, "router", None), Router), (
            f"{module_name} has no Router"
        )

    @pytest.mark.parametrize("module_name", _admin_submodules())
    def test_admin_submodule_has_handlers(self, module_name: str) -> None:
        module = importlib.import_module(module_name)
        observers = [
            name for name, observer in module.router.observers.items() if observer.handlers
        ]
        assert observers, f"{module_name}.router registers no handlers"

    def test_admin_register_aggregates_every_submodule(self) -> None:
        """register() attaches the admin router AND includes every sub-router."""
        package = importlib.import_module(ADMIN_PACKAGE)
        outcome = _register_once(package)  # may already be attached via callbacks.admin
        if outcome is not None:
            parent, _ = outcome
            assert package.router in parent.sub_routers
        included = {id(sub) for sub in package.router.sub_routers}
        assert included, "admin register() included no sub-routers"
        for module_name in _admin_submodules():
            module = importlib.import_module(module_name)
            assert id(module.router) in included, (
                f"{module_name} was not aggregated by {ADMIN_PACKAGE}.register()"
            )
        # The aggregated tree must actually observe something.
        assert _has_handlers(package.router)

    def test_admin_fsm_states_module_exists(self) -> None:
        """``states`` is the one non-router module — it must define AdminFSM."""
        states = importlib.import_module(f"{ADMIN_PACKAGE}.states")
        assert hasattr(states, "AdminFSM")


# ---------------------------------------------------------------------------
# Part 2 — AdminGuardMiddleware
# ---------------------------------------------------------------------------
class RecorderCallback(CallbackQuery):
    """A real CallbackQuery whose ``answer`` records instead of calling the API.

    aiogram models are frozen pydantic models, so the recorder list is stored
    via ``object.__setattr__`` (attribute *reads* work normally).
    """

    def __init__(self, data: str, *, user_id: int = 101) -> None:
        super().__init__(
            id="cb-smoke-1",
            from_user=User(id=user_id, is_bot=False, first_name="Alice"),
            chat_instance="test-instance",
            data=data,
        )
        object.__setattr__(self, "answers", [])

    async def answer(self, text: str | None = None, **kwargs: Any) -> bool:
        answers: list[dict[str, Any]] = object.__getattribute__(self, "answers")
        answers.append({"text": text, **kwargs})
        return True


def _services(is_admin: bool) -> SimpleNamespace:
    async def _check(user_id: int) -> bool:
        return is_admin

    return SimpleNamespace(
        admin=SimpleNamespace(
            permissions=SimpleNamespace(is_admin=_check),
        )
    )


async def _run_guard(
    callback: RecorderCallback, services: SimpleNamespace
) -> tuple[Any, list]:
    """Run the middleware; return (result, handler_calls)."""
    calls: list = []

    async def handler(event, data):  # noqa: ANN001
        calls.append(event)
        return "handled"

    middleware = AdminGuardMiddleware(ttl=0)  # no caching between cases
    result = await middleware(handler, callback, {"services": services})
    return result, calls


class TestAdminGuardMiddleware:
    async def test_non_admin_adm_callback_dropped_with_denial(self) -> None:
        callback = RecorderCallback("adm:home", user_id=101)
        result, calls = await _run_guard(callback, _services(is_admin=False))

        assert result is None
        assert calls == []  # handler NOT called
        assert callback.answers, "the denial must answer the callback"
        answer = callback.answers[0]
        assert answer["text"] == ADMIN_PANEL_DENIED
        assert answer.get("show_alert") is True

    async def test_admin_adm_callback_passes(self) -> None:
        callback = RecorderCallback("adm:home", user_id=101)
        result, calls = await _run_guard(callback, _services(is_admin=True))

        assert result == "handled"
        assert len(calls) == 1
        assert callback.answers == []  # no denial for admins

    async def test_non_admin_adm_subroute_also_dropped(self) -> None:
        for data in ("adm:bc:send", "adm:user:42:block:yes", "adm:vc:acc:3:del:yes"):
            callback = RecorderCallback(data, user_id=777)
            result, calls = await _run_guard(callback, _services(is_admin=False))
            assert result is None and calls == []
            assert callback.answers

    async def test_non_adm_callback_untouched_for_non_admin(self) -> None:
        """Regular user callbacks (trk:, q:, grp:…) are not the guard's business."""
        for data in ("trk:play:42", "q:skip", "grp:queue", "nav:home"):
            callback = RecorderCallback(data, user_id=101)
            result, calls = await _run_guard(callback, _services(is_admin=False))
            assert result == "handled"
            assert len(calls) == 1
            assert callback.answers == []

    async def test_missing_services_fails_closed_for_adm(self) -> None:
        """No container in scope → deny adm: callbacks (fail closed)."""
        callback = RecorderCallback("adm:stats", user_id=101)
        calls: list = []

        async def handler(event, data):  # noqa: ANN001
            calls.append(event)
            return "handled"

        middleware = AdminGuardMiddleware(ttl=0)
        result = await middleware(handler, callback, {})
        assert result is None
        assert calls == []
        assert callback.answers

    async def test_denial_is_uniform_across_callbacks(self) -> None:
        """Every denied adm: press gets the identical message (no admin leak)."""
        seen: set[str] = set()
        for data in ("adm:home", "adm:bc:new", "adm:set:autoplay:1"):
            callback = RecorderCallback(data, user_id=202)
            _, calls = await _run_guard(callback, _services(is_admin=False))
            assert calls == []
            seen.add(callback.answers[0]["text"])
        assert seen == {ADMIN_PANEL_DENIED}

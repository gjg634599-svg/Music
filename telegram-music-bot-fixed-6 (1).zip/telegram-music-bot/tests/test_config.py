"""Configuration validation tests (app.config)."""

from __future__ import annotations

import pytest

from app.config import ConfigError, Settings, load_settings

# A .env that does not exist keeps load_settings from re-importing values the
# test is trying to remove from the environment.
NO_ENV_FILE = "/nonexistent/.env"

VALID_TOKEN = "1234567890:AAF-test-token-abcdefghijklmnopqrstuvwxyz"


def _load(monkeypatch: pytest.MonkeyPatch, **env: str) -> Settings:
    """load_settings with a fully controlled environment."""
    keep = {
        "BOT_TOKEN": VALID_TOKEN,
        "DATABASE_URL": "sqlite+aiosqlite:///:memory:",
    }
    keep.update(env)
    for key in (
        "BOT_TOKEN",
        "DATABASE_URL",
        "TELEGRAM_API_ID",
        "TELEGRAM_API_HASH",
        "VOICE_SESSION_ENCRYPTION_KEY",
        "ADMIN_IDS",
        "REDIS_URL",
        "AUTOPLAY_ENABLED",
    ):
        monkeypatch.delenv(key, raising=False)
    for key, value in keep.items():
        monkeypatch.setenv(key, value)
    return load_settings(env_file=NO_ENV_FILE)


class TestBotToken:
    def test_missing_bot_token_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("BOT_TOKEN", raising=False)
        with pytest.raises(ConfigError, match="BOT_TOKEN"):
            load_settings(env_file=NO_ENV_FILE)

    def test_short_bot_token_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        with pytest.raises(ConfigError, match="token"):
            _load(monkeypatch, BOT_TOKEN="123:short")

    def test_dummy_bot_token_accepted(self, monkeypatch: pytest.MonkeyPatch) -> None:
        settings = _load(monkeypatch)
        assert settings.bot_token == VALID_TOKEN


class TestDatabaseUrl:
    def test_postgresql_without_asyncpg_rejected(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        with pytest.raises(ConfigError, match="DATABASE_URL"):
            _load(
                monkeypatch,
                DATABASE_URL="postgresql://user:pass@localhost:5432/musicbot",
            )

    def test_plain_sqlite_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        with pytest.raises(ConfigError, match="aiosqlite"):
            _load(monkeypatch, DATABASE_URL="sqlite:///./musicbot.db")

    def test_prisma_style_url_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        with pytest.raises(ConfigError, match="DATABASE_URL"):
            _load(monkeypatch, DATABASE_URL="file:./dev.db")

    def test_async_sqlite_accepted(self, monkeypatch: pytest.MonkeyPatch) -> None:
        settings = _load(monkeypatch, DATABASE_URL="sqlite+aiosqlite:///./x.db")
        assert settings.database_url == "sqlite+aiosqlite:///./x.db"

    def test_async_postgres_accepted(self, monkeypatch: pytest.MonkeyPatch) -> None:
        settings = _load(
            monkeypatch,
            DATABASE_URL="postgresql+asyncpg://u:p@db:5432/musicbot",
        )
        assert settings.database_url.startswith("postgresql+asyncpg://")


class TestValidMinimalSettings:
    def test_minimal_settings_ok(self, monkeypatch: pytest.MonkeyPatch) -> None:
        settings = _load(monkeypatch)
        assert settings.bot_token == VALID_TOKEN
        assert settings.database_url == "sqlite+aiosqlite:///:memory:"
        assert settings.autoplay_enabled is True
        assert settings.group_silent_mode is True
        assert settings.redis_enabled is False
        assert settings.is_admin(1) is False

    def test_admin_ids_parsed(self, monkeypatch: pytest.MonkeyPatch) -> None:
        settings = _load(monkeypatch, ADMIN_IDS="1, 2;3")
        assert settings.admin_ids == (1, 2, 3)
        assert settings.is_admin(2) is True

    def test_bad_admin_ids_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        with pytest.raises(ConfigError, match="ADMIN_IDS"):
            _load(monkeypatch, ADMIN_IDS="one,two")

    def test_api_id_without_hash_rejected(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        with pytest.raises(ConfigError, match="TELEGRAM_API_HASH"):
            _load(monkeypatch, TELEGRAM_API_ID="12345")


class TestVoiceEnabled:
    def test_voice_disabled_without_credentials(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        settings = _load(monkeypatch)
        assert settings.voice_enabled is False

    def test_voice_needs_all_three_credentials(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        partial = _load(monkeypatch, TELEGRAM_API_ID="12345", TELEGRAM_API_HASH="hash")
        assert partial.voice_enabled is False

        full = _load(
            monkeypatch,
            TELEGRAM_API_ID="12345",
            TELEGRAM_API_HASH="hash",
            VOICE_SESSION_ENCRYPTION_KEY="k" * 44,
        )
        assert full.voice_enabled is True


class TestVoiceAutoJoinSettings:
    """Private-group automatic joining configuration (Task: invite links)."""

    def test_defaults_enable_auto_join(self, monkeypatch: pytest.MonkeyPatch) -> None:
        settings = _load(monkeypatch)
        assert settings.voice.auto_join_enabled is True
        assert settings.voice.join_cooldown_seconds == 300
        assert settings.voice.invite_link_cache_seconds == 600
        assert settings.voice.membership_cache_seconds == 600

    def test_auto_join_can_be_disabled(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        settings = _load(monkeypatch, VOICE_AUTO_JOIN_ENABLED="false")
        assert settings.voice.auto_join_enabled is False

    def test_custom_values_parsed(self, monkeypatch: pytest.MonkeyPatch) -> None:
        settings = _load(
            monkeypatch,
            VOICE_AUTO_JOIN_ENABLED="0",
            VOICE_JOIN_COOLDOWN_SECONDS="120",
            VOICE_INVITE_LINK_CACHE_SECONDS="90",
            VOICE_MEMBERSHIP_CACHE_SECONDS="45",
        )
        assert settings.voice.auto_join_enabled is False
        assert settings.voice.join_cooldown_seconds == 120
        assert settings.voice.invite_link_cache_seconds == 90
        assert settings.voice.membership_cache_seconds == 45

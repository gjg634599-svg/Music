"""Library (likes) and playlist service tests."""

from __future__ import annotations

import pytest

from app.errors import PermissionDeniedError, TrackNotFoundError, ValidationError
from app.playback.queue import QueueOwner
from app.users.playlists import IMPORT_FALLBACK_TITLE, parse_export_text

from .conftest import build_services


class TestLikes:
    async def test_toggle_like_roundtrip(self, services, db_setup) -> None:
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]

        assert await services.library.toggle_like(101, track_id) is True
        assert await services.library.is_liked(101, track_id) is True

        assert await services.library.toggle_like(101, track_id) is False
        assert await services.library.is_liked(101, track_id) is False

    async def test_likes_are_per_user(self, services, db_setup) -> None:
        track_id = db_setup.track_ids_by_title["Velvet Night"]
        await services.library.toggle_like(101, track_id)

        assert await services.library.is_liked(101, track_id) is True
        assert await services.library.is_liked(102, track_id) is False

    async def test_liked_tracks_listing(self, services, db_setup) -> None:
        a = db_setup.track_ids_by_title["Neon Sunrise"]
        b = db_setup.track_ids_by_title["Static Bloom"]
        await services.library.toggle_like(101, a)
        await services.library.toggle_like(101, b)

        liked = await services.library.liked_tracks(101)
        assert {track.id for track in liked} == {a, b}
        assert await services.library.liked_track_ids(101) == {a, b}

    async def test_toggle_like_unknown_track_rejected(self, services, db_setup) -> None:
        with pytest.raises(TrackNotFoundError):
            await services.library.toggle_like(101, 999_999)

    async def test_toggle_like_unknown_user_rejected(self, services, db_setup) -> None:
        with pytest.raises(ValidationError):
            await services.library.toggle_like(555, db_setup.track_ids[0])


class TestPlaylists:
    async def test_create_and_add_tracks(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(
            db_setup.user_101, "Road Trip", description="fast songs"
        )
        a = db_setup.track_ids_by_title["Circuit Breaker"]
        b = db_setup.track_ids_by_title["Static Bloom"]

        assert await services.playlists_service.add_track(playlist.id, a) is True
        assert await services.playlists_service.add_track(playlist.id, b) is True

        tracks = await services.playlists_service.tracks(playlist.id)
        assert [track.id for track in tracks] == [a, b]

    async def test_duplicate_add_rejected(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(db_setup.user_101, "Mix")
        a = db_setup.track_ids[0]
        await services.playlists_service.add_track(playlist.id, a)

        assert await services.playlists_service.add_track(playlist.id, a) is False
        assert len(await services.playlists_service.tracks(playlist.id)) == 1

    async def test_remove_track(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(db_setup.user_101, "Mix")
        a = db_setup.track_ids[0]
        await services.playlists_service.add_track(playlist.id, a)

        assert await services.playlists_service.remove_track(playlist.id, a) is True
        assert await services.playlists_service.remove_track(playlist.id, a) is False
        assert await services.playlists_service.tracks(playlist.id) == []

    async def test_my_playlists_scoped_to_owner(self, services, db_setup) -> None:
        mine = await services.playlists_service.create(db_setup.user_101, "Mine")
        theirs = await services.playlists_service.create(db_setup.user_102, "Theirs")

        assert [p.id for p in await services.playlists_service.my_playlists(db_setup.user_101)] == [mine.id]
        assert [p.id for p in await services.playlists_service.my_playlists(db_setup.user_102)] == [theirs.id]

    async def test_rename_and_delete_ownership(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(db_setup.user_101, "First")

        renamed = await services.playlists_service.rename(
            playlist.id, db_setup.user_101, "Renamed"
        )
        assert renamed.title == "Renamed"

        with pytest.raises(PermissionDeniedError):
            await services.playlists_service.rename(playlist.id, db_setup.user_102, "Steal")
        with pytest.raises(PermissionDeniedError):
            await services.playlists_service.delete(playlist.id, db_setup.user_102)

        assert await services.playlists_service.delete(playlist.id, db_setup.user_101) is True
        assert await services.playlists_service.get(playlist.id) is None

    async def test_queue_playlist_adds_all_tracks(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(db_setup.user_101, "All")
        for track_id in db_setup.track_ids:
            await services.playlists_service.add_track(playlist.id, track_id)

        owner = QueueOwner(kind="user", id=101)
        queue = services.queue
        added = await services.playlists_service.queue_playlist(owner, playlist.id, queue)

        assert added == len(db_setup.track_ids)
        assert await queue.size(owner) == len(db_setup.track_ids)
        items = await queue.get_queue(owner)
        assert [item.track_id for item in items] == db_setup.track_ids

    async def test_queue_empty_playlist_rejected(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(db_setup.user_101, "Empty")
        with pytest.raises(ValidationError):
            await services.playlists_service.queue_playlist(
                QueueOwner(kind="user", id=101), playlist.id, services.queue
            )

    async def test_playlist_get_eager_loads_artist(self, services, db_setup) -> None:
        """Regression: repo.get() must eager-load track artists.

        Before the fix, ``track.artist`` lazy-loaded after session close and
        ``artist_name()`` silently returned '' — playlist pages showed no
        artist names.
        """
        playlist = await services.playlists_service.create(db_setup.user_101, "Artists")
        a = db_setup.track_ids_by_title["Neon Sunrise"]
        await services.playlists_service.add_track(playlist.id, a)

        fetched = await services.playlists_service.get(playlist.id)
        track = [item.track for item in fetched.items][0]
        # direct attribute access must work on the detached row
        assert track.artist is not None
        assert track.artist.name == "Test Artist"


class TestPlaylistExport:
    async def test_export_renders_tracks_and_total(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(
            db_setup.user_101, "Road Trip", description="fast songs"
        )
        a = db_setup.track_ids_by_title["Neon Sunrise"]      # 30 s
        b = db_setup.track_ids_by_title["Retro Sunrise"]     # 31 s
        await services.playlists_service.add_track(playlist.id, a)
        await services.playlists_service.add_track(playlist.id, b)

        text = await services.playlists_service.export_text(playlist.id, db_setup.user_101)

        assert "Road Trip" in text
        assert "fast songs" in text
        assert "Neon Sunrise" in text
        assert "Retro Sunrise" in text
        assert "Test Artist" in text
        assert "(0:30)" in text
        assert "(0:31)" in text
        assert "2 tracks" in text
        assert "1:01" in text  # 30 + 31 seconds
        assert "playlist export" in text

    async def test_export_escapes_html(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(
            db_setup.user_101, "<b>Road & Trip</b>"
        )
        a = db_setup.track_ids_by_title["Neon Sunrise"]
        await services.playlists_service.add_track(playlist.id, a)

        text = await services.playlists_service.export_text(playlist.id, db_setup.user_101)

        assert "&lt;b&gt;Road &amp; Trip&lt;/b&gt;" in text
        assert "<script>" not in text

    async def test_export_empty_playlist_rejected(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(db_setup.user_101, "Empty")
        with pytest.raises(ValidationError):
            await services.playlists_service.export_text(playlist.id, db_setup.user_101)

    async def test_export_unknown_playlist_rejected(self, services, db_setup) -> None:
        with pytest.raises(ValidationError):
            await services.playlists_service.export_text(999999, db_setup.user_101)

    async def test_export_foreign_playlist_denied(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(db_setup.user_101, "Mine")
        a = db_setup.track_ids[0]
        await services.playlists_service.add_track(playlist.id, a)
        with pytest.raises(PermissionDeniedError):
            await services.playlists_service.export_text(playlist.id, db_setup.user_102)

    async def test_export_truncates_long_playlists(
        self, services, db_setup, mk_sessions
    ) -> None:
        from app.database.models import Track

        # create tracks with long titles so the export must exceed 4000 chars
        long_title = "T" * 240
        async with mk_sessions() as session:
            async with session.begin():
                for i in range(20):
                    session.add(
                        Track(
                            title=f"{long_title} #{i:02d}",
                            normalized_title=f"long-{i:02d}",
                            artist_id=db_setup.artist_id,
                            duration_seconds=60,
                            source="local",
                            source_id=f"export-long-{i}",
                            is_playable=True,
                        )
                    )

        playlist = await services.playlists_service.create(db_setup.user_101, "Long")
        # fetch fresh ids of the long tracks (by unique source_id prefix)
        from sqlalchemy import select as sa_select

        async with mk_sessions() as session:
            rows = (
                await session.execute(
                    sa_select(Track.id).where(
                        Track.source_id.like("export-long-%")
                    )
                )
            ).scalars().all()
        assert len(rows) == 20
        for track_id in rows:
            await services.playlists_service.add_track(playlist.id, int(track_id))

        text = await services.playlists_service.export_text(playlist.id, db_setup.user_101)
        assert len(text) <= 4000
        assert text.endswith("tracks")  # footer kept visible after truncation
        assert "…" in text


class TestPlaylistImport:
    """Playlist import: parser (pure) + import_text service (fake search)."""

    # ------------------------------------------------------------------
    # Parser
    # ------------------------------------------------------------------
    def test_parse_full_export_format(self) -> None:
        text = (
            "📋 <b>Road &amp; Trip</b> · playlist export\n"
            "<i>fast &amp; loud</i>\n"
            "\n"
            "1. Neon Sunrise — Test Artist <i>(0:30)</i>\n"
            "2. Retro Sunrise <i>(0:31)</i>\n"
            "3. Velvet Night — Test Artist\n"
            "\n"
            "⏱️ Total 1:34 · 3 tracks"
        )
        title, description, lines = parse_export_text(text)

        assert title == "Road & Trip"
        assert description == "fast & loud"
        assert len(lines) == 3
        assert lines[0].number == 1
        assert lines[0].title == "Neon Sunrise"
        assert lines[0].artist == "Test Artist"
        assert lines[0].duration == "0:30"
        assert lines[1].artist is None
        assert lines[1].duration == "0:31"
        assert lines[2].duration is None

    def test_parse_plain_numbered_list(self) -> None:
        title, description, lines = parse_export_text(
            "1. Song One - Artist A\n2) Song Two – Artist B"
        )

        assert title == ""
        assert description is None
        assert [(line.title, line.artist) for line in lines] == [
            ("Song One", "Artist A"),
            ("Song Two", "Artist B"),
        ]

    def test_parse_skips_junk_and_unnumbered_lines(self) -> None:
        _, _, lines = parse_export_text(
            "some intro text\n"
            "1. Real Song — Real Artist\n"
            "a plain unnumbered line\n"
            "2. Another — Artist\n"
            "⏱️ Total 2:00 · 2 tracks"
        )

        assert len(lines) == 2

    def test_parse_caps_at_limit(self) -> None:
        text = "\n".join(f"{i}. Song {i}" for i in range(1, 80))
        _, _, lines = parse_export_text(text)

        assert len(lines) == 50

    def test_parse_title_only_line_without_artist(self) -> None:
        _, _, lines = parse_export_text("1. Just A Title")

        assert lines[0].title == "Just A Title"
        assert lines[0].artist is None

    # ------------------------------------------------------------------
    # import_text (DB-backed, fake search)
    # ------------------------------------------------------------------
    def _catalog_search(self, db_setup, services):
        """A fake search returning every seeded track for any query."""

        async def _search(query: str, limit: int = 5):
            tracks = []
            for track_id in db_setup.track_ids:
                track = await services.tracks_repo.get(track_id)
                if track is not None:
                    tracks.append(track)
            return tracks

        return _search

    async def test_round_trip_export_then_import(self, services, db_setup) -> None:
        original = await services.playlists_service.create(
            db_setup.user_101, "Road Trip", description="fast songs"
        )
        a = db_setup.track_ids_by_title["Neon Sunrise"]
        b = db_setup.track_ids_by_title["Velvet Night"]
        c = db_setup.track_ids_by_title["Static Bloom"]
        for track_id in (a, b, c):
            await services.playlists_service.add_track(original.id, track_id)

        text = await services.playlists_service.export_text(original.id, db_setup.user_101)
        result = await services.playlists_service.import_text(
            db_setup.user_101, text, self._catalog_search(db_setup, services)
        )

        assert result.playlist.title == "Road Trip"
        assert result.playlist.description == "fast songs"
        assert result.playlist.user_id == db_setup.user_101
        assert [track.id for track in result.matched] == [a, b, c]
        assert result.unmatched == []
        assert await services.playlists_service.track_ids(result.playlist.id) == [a, b, c]

    async def test_import_plain_list_fallback_title(
        self, services, db_setup
    ) -> None:
        text = "1. Neon Sunrise — Test Artist\n2. Velvet Night — Test Artist"
        result = await services.playlists_service.import_text(
            db_setup.user_101, text, self._catalog_search(db_setup, services)
        )

        assert result.playlist.title == IMPORT_FALLBACK_TITLE
        assert len(result.matched) == 2

    async def test_import_reports_unmatched_lines(self, services, db_setup) -> None:
        async def search(query: str, limit: int = 5):
            if "Missing" in query:
                return []
            track = await services.tracks_repo.get(db_setup.track_ids_by_title["Neon Sunrise"])
            return [track]

        text = "1. Neon Sunrise — Test Artist\n2. Missing Song — Nobody"
        result = await services.playlists_service.import_text(db_setup.user_101, text, search)

        assert len(result.matched) == 1
        assert len(result.unmatched) == 1
        assert result.unmatched[0].title == "Missing Song"

    async def test_import_picks_exact_match_over_partial(
        self, services, db_setup
    ) -> None:
        async def search(query: str, limit: int = 5):
            # Both "Neon Sunrise" and "Retro Sunrise" are candidates for a
            # query containing "sunrise" — the exact title must win.
            tracks = []
            for title in ("Retro Sunrise", "Neon Sunrise"):
                track = await services.tracks_repo.get(db_setup.track_ids_by_title[title])
                if track is not None:
                    tracks.append(track)
            return tracks

        text = "1. Neon Sunrise — Test Artist"
        result = await services.playlists_service.import_text(db_setup.user_101, text, search)

        assert [track.id for track in result.matched] == [
            db_setup.track_ids_by_title["Neon Sunrise"]
        ]

    async def test_import_no_matches_creates_nothing(self, services, db_setup) -> None:
        async def search(query: str, limit: int = 5):
            return []

        before = await services.playlists_service.my_playlists(db_setup.user_101)
        with pytest.raises(ValidationError):
            await services.playlists_service.import_text(
                db_setup.user_101, "1. Nothing — Here", search
            )
        after = await services.playlists_service.my_playlists(db_setup.user_101)

        assert after == before

    async def test_import_garbage_text_rejected(self, services, db_setup) -> None:
        async def search(query: str, limit: int = 5):
            raise AssertionError("search must not be called without parsed lines")

        with pytest.raises(ValidationError):
            await services.playlists_service.import_text(
                db_setup.user_101, "hello there\nno tracks at all", search
            )

    async def test_import_deduplicates_repeated_lines(self, services, db_setup) -> None:
        text = (
            "1. Neon Sunrise — Test Artist\n"
            "2. Neon Sunrise — Test Artist\n"
            "3. Velvet Night — Test Artist"
        )
        result = await services.playlists_service.import_text(
            db_setup.user_101, text, self._catalog_search(db_setup, services)
        )

        assert len(result.matched) == 2  # the duplicate line collapses
        assert await services.playlists_service.track_ids(result.playlist.id) == [
            db_setup.track_ids_by_title["Neon Sunrise"],
            db_setup.track_ids_by_title["Velvet Night"],
        ]

    async def test_import_tolerates_search_failure(self, services, db_setup) -> None:
        async def search(query: str, limit: int = 5):
            if "Neon" in query:
                raise RuntimeError("source outage")
            track = await services.tracks_repo.get(db_setup.track_ids_by_title["Velvet Night"])
            return [track]

        text = "1. Neon Sunrise — Test Artist\n2. Velvet Night — Test Artist"
        result = await services.playlists_service.import_text(db_setup.user_101, text, search)

        assert len(result.matched) == 1
        assert len(result.unmatched) == 1
        assert result.unmatched[0].title == "Neon Sunrise"

    async def test_import_html_entities_round_trip(self, services, db_setup) -> None:
        playlist = await services.playlists_service.create(
            db_setup.user_101, "A & B <Mix>"
        )
        a = db_setup.track_ids_by_title["Neon Sunrise"]
        await services.playlists_service.add_track(playlist.id, a)
        text = await services.playlists_service.export_text(playlist.id, db_setup.user_101)

        result = await services.playlists_service.import_text(
            db_setup.user_101, text, self._catalog_search(db_setup, services)
        )

        assert result.playlist.title == "A & B <Mix>"


class TestHistoryService:
    async def test_record_and_history(self, services, db_setup) -> None:
        a = db_setup.track_ids_by_title["Neon Sunrise"]
        await services.history_service.record(101, a, context="personal")
        await services.history_service.record(
            102, a, context="personal", completed=True, duration_played=30
        )

        rows = await services.history_service.history(101)
        assert rows and rows[0].track_id == a

        user_102_rows = await services.history_service.history(102)
        assert user_102_rows[0].completed is True
        assert user_102_rows[0].duration_played == 30

    async def test_record_search(self, services, db_setup) -> None:
        await services.history_service.record_search(101, "neon", 5)
        rows = await services.history_service.search_history(101)
        assert rows and rows[0].query == "neon"
        assert rows[0].results_count == 5

    async def test_recent_tracks(self, services, db_setup) -> None:
        a, b = db_setup.track_ids[:2]
        await services.history_service.record(101, a, context="personal")
        await services.history_service.record(101, b, context="personal")

        recent = await services.library.recent_tracks(101, limit=5)
        assert {track.id for track in recent} == {a, b}

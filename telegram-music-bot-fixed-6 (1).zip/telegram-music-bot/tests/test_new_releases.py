"""New releases browse (/new) — repository, service, keyboard and render tests.

Covers the round-6 feature: ``TrackRepository.recent`` / ``count_playable``,
``MusicService.new_releases``, the ``new_releases_keyboard`` and the
``lib:new`` screen renderers in the library handler.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from typing import Any

from app.bot.commands import private_commands
from app.bot.handlers.library import NEW_PAGE_SIZE, _render_new
from app.bot.keyboards.library import library_home_keyboard, new_releases_keyboard
from app.cache.redis import MemoryCache
from app.database.base import Base
from app.database.models import Track
from app.database.repositories.music import TrackRepository
from app.playback.events import EventBus
from app.music.service import MusicService

from .conftest import FakeCallback, FakeMessage

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
_BASE = datetime(2026, 1, 1, tzinfo=UTC)


def _mk_track(index: int, *, created_at: datetime, playable: bool = True) -> Track:
    """A detached-track stand-in with the attributes the renderers touch."""
    track = SimpleNamespace(
        id=index,
        title=f"Track {index}",
        artist=SimpleNamespace(name="Test Artist"),
        duration_seconds=30 + index,
        created_at=created_at,
        is_playable=playable,
    )
    return track  # type: ignore[return-value]


class _StubMusic:
    """Duck-typed MusicService for renderer tests (no DB required).

    When explicit ``tracks`` are given they are windowed like the repo does;
    otherwise ``total`` synthetic tracks are generated on demand.
    """

    def __init__(self, tracks: list[Any] | None = None, total: int | None = None) -> None:
        self._tracks = tracks
        self._total = total if total is not None else len(tracks or [])
        self.calls: list[dict[str, int]] = []

    async def new_releases(self, *, limit: int, offset: int) -> tuple[list[Any], int]:
        self.calls.append({"limit": limit, "offset": offset})
        if self._tracks is not None:
            return self._tracks[offset : offset + limit], self._total
        count = max(0, self._total - offset)
        window = [
            _mk_track(offset + i + 1, created_at=_BASE + timedelta(minutes=i))
            for i in range(min(count, limit))
        ]
        return window, self._total


class _FakeState:
    """Minimal FSMContext fake (get_data / update_data)."""

    def __init__(self, data: dict[str, Any] | None = None) -> None:
        self._data: dict[str, Any] = dict(data or {})

    async def get_data(self) -> dict[str, Any]:
        return dict(self._data)

    async def update_data(self, **kwargs: Any) -> None:
        self._data.update(kwargs)

    async def set_state(self, state: Any) -> None:  # pragma: no cover - unused
        self._data["_state"] = state


def _svc(music: Any) -> SimpleNamespace:
    return SimpleNamespace(music=music)


async def _stamp_tracks(
    mk_sessions: Any, track_ids: list[int], created: list[datetime]
) -> None:
    """Overwrite created_at on seeded tracks (deterministic ordering)."""
    async with mk_sessions() as session:
        for track_id, when in zip(track_ids, created, strict=True):
            track = await session.get(Track, track_id)
            assert track is not None
            track.created_at = when
        await session.commit()


# ---------------------------------------------------------------------------
# Repository layer
# ---------------------------------------------------------------------------
class TestTrackRepositoryRecent:
    async def test_recent_orders_newest_first(self, services, db_setup, mk_sessions) -> None:
        ids = db_setup.track_ids
        await _stamp_tracks(
            mk_sessions,
            ids,
            [_BASE + timedelta(days=i) for i in range(len(ids))],
        )

        rows = await services.tracks_repo.recent(limit=len(ids))
        assert [row.id for row in rows] == list(reversed(ids))

    async def test_recent_tiebreaks_by_id_desc(self, services, db_setup, mk_sessions) -> None:
        """Same created_at → higher id (later insert) wins."""
        ids = db_setup.track_ids
        await _stamp_tracks(mk_sessions, ids, [_BASE] * len(ids))

        rows = await services.tracks_repo.recent(limit=len(ids))
        assert [row.id for row in rows] == list(reversed(ids))

    async def test_recent_offset_pagination(self, services, db_setup, mk_sessions) -> None:
        ids = db_setup.track_ids
        await _stamp_tracks(
            mk_sessions, ids, [_BASE + timedelta(days=i) for i in range(len(ids))]
        )

        page1 = await services.tracks_repo.recent(limit=3, offset=0)
        page2 = await services.tracks_repo.recent(limit=3, offset=3)
        assert [row.id for row in page1] == list(reversed(ids))[:3]
        assert [row.id for row in page2] == list(reversed(ids))[3:6]
        assert page1[0].id not in {row.id for row in page2}

    async def test_recent_excludes_unplayable_by_default(
        self, services, db_setup
    ) -> None:
        newest = db_setup.track_ids[-1]
        await services.tracks_repo.update(newest, is_playable=False)

        rows = await services.tracks_repo.recent(limit=100)
        assert newest not in {row.id for row in rows}

        rows_all = await services.tracks_repo.recent(limit=100, playable_only=False)
        assert newest in {row.id for row in rows_all}

    async def test_count_playable_excludes_unplayable(self, services, db_setup) -> None:
        total = await services.tracks_repo.count_playable()
        assert total == len(db_setup.track_ids)

        await services.tracks_repo.update(db_setup.track_ids[0], is_playable=False)
        assert await services.tracks_repo.count_playable() == total - 1

    async def test_recent_empty_catalog(self, engine, mk_sessions) -> None:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        repo = TrackRepository(mk_sessions)

        assert await repo.recent() == []
        assert await repo.count_playable() == 0

    async def test_recent_eager_loads_artist(self, services, db_setup) -> None:
        rows = await services.tracks_repo.recent(limit=1)
        assert rows[0].artist is not None
        assert rows[0].artist.name == "Test Artist"


# ---------------------------------------------------------------------------
# Service layer
# ---------------------------------------------------------------------------
def _music_service(tracks_repo: TrackRepository) -> MusicService:
    """MusicService with real repo + dummy collaborators (new_releases only
    touches ``_tracks``)."""
    return MusicService(
        sources=[],
        aggregator=SimpleNamespace(),  # type: ignore[arg-type]
        resolver=SimpleNamespace(),  # type: ignore[arg-type]
        tracks=tracks_repo,
        metadata=SimpleNamespace(),  # type: ignore[arg-type]
        storage=SimpleNamespace(),  # type: ignore[arg-type]
        cache=MemoryCache(),
        events=EventBus(),
    )


class TestMusicServiceNewReleases:
    async def test_new_releases_returns_tracks_and_total(
        self, services, db_setup
    ) -> None:
        music = _music_service(services.tracks_repo)
        tracks, total = await music.new_releases(limit=5)

        assert total == len(db_setup.track_ids)
        assert len(tracks) == 5
        # newest seeded id first (server_default timestamps + id tiebreak)
        assert tracks[0].id == max(db_setup.track_ids)

    async def test_new_releases_offset_windows(
        self, services, db_setup, mk_sessions
    ) -> None:
        ids = db_setup.track_ids
        await _stamp_tracks(
            mk_sessions, ids, [_BASE + timedelta(days=i) for i in range(len(ids))]
        )
        music = _music_service(services.tracks_repo)

        first, total = await music.new_releases(limit=3, offset=0)
        second, _ = await music.new_releases(limit=3, offset=3)

        assert total == len(ids)
        assert [t.id for t in first] == list(reversed(ids))[:3]
        assert [t.id for t in second] == list(reversed(ids))[3:6]

    async def test_new_releases_clamps_limit(self, services, db_setup) -> None:
        music = _music_service(services.tracks_repo)

        huge, _ = await music.new_releases(limit=10_000)
        assert len(huge) <= 100
        tiny, _ = await music.new_releases(limit=0)
        assert len(tiny) == 1  # clamped to minimum 1


# ---------------------------------------------------------------------------
# Keyboard
# ---------------------------------------------------------------------------
class TestNewReleasesKeyboard:
    def test_number_buttons_two_per_row(self) -> None:
        kb = new_releases_keyboard(1, 3, [11, 12, 13, 14, 15])
        number_rows = [
            row for row in kb.inline_keyboard if all(b.text.isdigit() for b in row)
        ]
        assert [len(row) for row in number_rows] == [2, 2, 1]
        assert number_rows[0][0].text == "1"
        assert number_rows[2][0].text == "5"

    def test_first_page_shows_only_next(self) -> None:
        kb = new_releases_keyboard(1, 3, [11])
        nav = kb.inline_keyboard[-2]
        assert [b.text for b in nav] == ["📄 1/3", "➡️"]
        assert nav[-1].callback_data == "lib:new:2"

    def test_middle_page_shows_both(self) -> None:
        kb = new_releases_keyboard(2, 3, [11])
        nav = kb.inline_keyboard[-2]
        assert [b.text for b in nav] == ["⬅️", "📄 2/3", "➡️"]
        assert nav[0].callback_data == "lib:new:1"
        assert nav[-1].callback_data == "lib:new:3"

    def test_last_page_shows_only_prev(self) -> None:
        kb = new_releases_keyboard(3, 3, [11])
        nav = kb.inline_keyboard[-2]
        assert [b.text for b in nav] == ["⬅️", "📄 3/3"]
        assert nav[0].callback_data == "lib:new:2"

    def test_single_page_has_no_nav_row(self) -> None:
        kb = new_releases_keyboard(1, 1, [11, 12])
        assert kb.inline_keyboard[-1][0].text == "🔙 Back"

    def test_back_button_targets_library_home(self) -> None:
        kb = new_releases_keyboard(1, 1, [11])
        assert kb.inline_keyboard[-1][0].callback_data == "lib:home"

    def test_callback_data_within_telegram_limit(self) -> None:
        kb = new_releases_keyboard(12, 99, [1_000_000, 2, 3, 4, 5, 6, 7, 8])
        for row in kb.inline_keyboard:
            for button in row:
                assert len(button.callback_data.encode()) <= 64


# ---------------------------------------------------------------------------
# Screen renderers + handler callbacks
# ---------------------------------------------------------------------------
class TestNewReleasesRender:
    async def test_header_shows_total_and_lines_numbered(self) -> None:
        tracks = [_mk_track(i, created_at=_BASE + timedelta(minutes=i)) for i in (1, 2, 3)]
        text, keyboard = await _render_new(_svc(_StubMusic(tracks, total=17)), 1)

        assert "NEW RELEASES" in text
        assert "17" in text
        assert text.count("🎵") == 3
        assert "1." in text and "2." in text and "3." in text
        assert keyboard is not None

    async def test_page_beyond_total_clamps_to_last(self) -> None:
        stub = _StubMusic(total=9)
        text, _ = await _render_new(_svc(stub), page=99)

        # 9 tracks / 8 per page → page 99 clamps to page 2 (offset 8)
        assert "2 of 2" in text
        # the out-of-range fetch is followed by a corrected refetch
        assert len(stub.calls) == 2
        assert stub.calls[1]["offset"] == 8

    async def test_empty_catalog_state(self) -> None:
        text, keyboard = await _render_new(_svc(_StubMusic([], total=0)), 1)

        assert "NEW RELEASES" in text
        assert "catalog is empty" in text
        assert keyboard.inline_keyboard[-1][0].callback_data == "lib:home"

    async def test_multi_page_footer(self) -> None:
        tracks = [_mk_track(1, created_at=_BASE)]
        text, _ = await _render_new(_svc(_StubMusic(tracks, total=25)), 1)

        assert "freshest first" in text
        assert "1 of 4" in text  # 25 tracks / 8 per page


class TestNewReleasesHandlerCallbacks:
    async def test_lib_new_first_page_edits_screen(self) -> None:
        from app.bot.handlers.library import on_new_releases

        tracks = [_mk_track(i, created_at=_BASE) for i in (5, 6)]
        services = _svc(_StubMusic(tracks, total=2))
        callback = FakeCallback("lib:new")

        await on_new_releases(callback, services, _FakeState())  # type: ignore[arg-type]

        assert len(callback.message.edited) == 1
        text, kwargs = callback.message.edited[0]
        assert "NEW RELEASES" in text
        assert kwargs.get("reply_markup") is not None
        assert callback.answers  # every callback is answered

    async def test_lib_new_page_n(self) -> None:
        from app.bot.handlers.library import on_new_releases_page

        services = _svc(_StubMusic(total=17))
        callback = FakeCallback("lib:new:2")

        await on_new_releases_page(callback, services)  # type: ignore[arg-type]

        text, _ = callback.message.edited[0]
        assert "2 of 3" in text  # 17 tracks / 8 per page
        assert "9." in text  # second page starts at track 9

    async def test_cmd_new_sends_fresh_message(self) -> None:
        from app.bot.handlers.library import cmd_new

        services = _svc(_StubMusic(total=1))
        message = FakeMessage(text="/new", chat_type="private")

        await cmd_new(message, services)  # type: ignore[arg-type]

        assert len(message.answered) == 1
        text, kwargs = message.answered[0]
        assert "NEW RELEASES" in text
        assert kwargs.get("parse_mode") == "HTML"


# ---------------------------------------------------------------------------
# Wiring / registration
# ---------------------------------------------------------------------------
class TestNewReleasesWiring:
    def test_new_command_in_private_menu(self) -> None:
        commands = private_commands()
        names = [c.command for c in commands]
        assert "new" in names

    def test_new_in_default_commands_template(self) -> None:
        from app.database.defaults import DEFAULT_MESSAGES

        assert "/new — new releases" in DEFAULT_MESSAGES["commands"]

    def test_library_hub_has_new_releases_button(self) -> None:
        kb = library_home_keyboard()
        flat = [b for row in kb.inline_keyboard for b in row]
        new = [b for b in flat if b.text == "🆕 New Releases"]
        assert len(new) == 1
        assert new[0].callback_data == "lib:new"
        # the hub still carries all previous destinations
        texts = {b.text for b in flat}
        assert {"❤️ Liked Songs", "📋 My Playlists", "🕘 Recently Played"} <= texts

    def test_router_registers_new_callbacks(self) -> None:
        from app.bot.handlers.library import router

        callbacks = {h.callback.__name__ for h in router.callback_query.handlers}
        messages = {h.callback.__name__ for h in router.message.handlers}
        assert {"on_new_releases", "on_new_releases_page"} <= callbacks
        assert "cmd_new" in messages

    def test_page_size_is_telegram_friendly(self) -> None:
        assert NEW_PAGE_SIZE == 8

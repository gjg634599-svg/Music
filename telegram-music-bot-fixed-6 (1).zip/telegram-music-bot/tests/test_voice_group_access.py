"""Tests for private-group membership verification + automatic invite joining.

Covers :mod:`app.voice.group_access` (the ``GroupAccessService``) and its
integration into :class:`app.voice.manager.VoiceManager`:

* membership checks (supergroup participant request, basic-chat full info,
  unresolvable entities);
* the full auto-join workflow: bot exports the link, the MTProto account
  imports it (``ImportChatInviteRequest``), membership is re-verified;
* every documented failure mode — invalid/expired/revoked links, banned
  accounts, join-request approval, missing bot permissions, flood waits;
* cooldowns, link caching, membership caching and single-flight joins;
* manager wiring: ``play()`` enforces access before streaming, typed
  ``VoiceGroupAccessError`` with user-safe messages.

All Telegram interactions run against fake clients implementing the small
Telethon surface the service uses (``get_entity`` / ``__call__`` /
``get_me``) — no network, no real account. Live-Telegram behaviour is
documented as NOT TESTED in docs/TELEGRAM_COMPATIBILITY_AUDIT.md.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest
from telethon import errors, functions, types

from app.cache.redis import LockManager, MemoryCache
from app.config import Settings, VoiceSettings
from app.database.repositories.voice import VoiceRepository
from app.errors import VoiceGroupAccessError
from app.playback.events import EventBus
from app.voice.group_access import (
    GroupAccessService,
    extract_invite_hash,
    extract_public_username,
    to_telethon_entity_id,
)
from app.voice.manager import VoiceManager

GROUP = -1001234567890
GROUP_ENTITY_ID = -1001234567890  # marked channel id (kept as-is)
BASIC_GROUP = -654321
BASIC_GROUP_ID = 654321
ME_ID = 42
_T0 = datetime(2024, 1, 1, tzinfo=timezone.utc)


def _participant(user_id: int = ME_ID) -> types.ChannelParticipant:
    """A minimal channel participant row."""
    return types.ChannelParticipant(user_id=user_id, date=_T0)


def _settings(
    *,
    auto_join: bool = True,
    cooldown: int = 300,
    link_ttl: int = 600,
    membership_ttl: int = 600,
) -> Settings:
    return Settings(
        bot_token="123456789:" + "A" * 33,
        telegram_api_id=1,
        telegram_api_hash="hash",
        voice=VoiceSettings(
            encryption_key="k" * 44,
            auto_join_enabled=auto_join,
            join_cooldown_seconds=cooldown,
            invite_link_cache_seconds=link_ttl,
            membership_cache_seconds=membership_ttl,
        ),
    )


class FakeClock:
    """Controllable monotonic clock."""

    def __init__(self, start: float = 1000.0) -> None:
        self.now = start

    def __call__(self) -> float:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += seconds


def _channel_entity(chat_id: int = GROUP_ENTITY_ID) -> types.Channel:
    return types.Channel(
        id=1234567890,
        title="Private Group",
        photo=None,
        date=_T0,
        megagroup=True,
    )


def _chat_entity(chat_id: int = BASIC_GROUP_ID) -> types.Chat:
    return types.Chat(
        id=chat_id,
        title="Basic Group",
        photo=None,
        date=_T0,
        version=1,
        participants_count=10,
    )


class FakeTelethonClient:
    """Duck-typed Telethon client scripting the MTProto surface we use.

    ``requests`` records every raw call for assertions. Handlers are keyed
    by request class; values are callables ``(request) -> result`` or
    exception instances to raise.
    """

    def __init__(
        self,
        *,
        entities: dict[int, object] | None = None,
        me_id: int = ME_ID,
    ) -> None:
        self._entities = dict(entities or {})
        self._me_id = me_id
        self._handlers: dict[type, object] = {}
        self.requests: list[object] = []
        self.get_entity_calls: list[object] = []

    # -- surface used by the service ------------------------------------
    async def get_entity(self, entity_id):
        self.get_entity_calls.append(entity_id)
        if isinstance(entity_id, str):
            # username lookup: map through an alias dict if provided
            alias = self._entities.get(entity_id)
            if alias is not None:
                return alias
            raise ValueError(f"no entity for username {entity_id}")
        if entity_id in self._entities:
            return self._entities[entity_id]
        raise ValueError(f"Could not find the input entity for {entity_id}")

    async def get_me(self):
        return SimpleNamespace(id=self._me_id)

    async def __call__(self, request):
        self.requests.append(request)
        for cls, handler in self._handlers.items():
            if isinstance(request, cls):
                if isinstance(handler, Exception):
                    raise handler
                if callable(handler):
                    return handler(request)
                return handler
        raise AssertionError(f"unexpected request: {type(request).__name__}")

    # -- scripting helpers ------------------------------------------------
    def on(self, request_cls: type, handler: object) -> "FakeTelethonClient":
        self._handlers[request_cls] = handler
        return self

    def add_entity(self, key: int, entity: object) -> None:
        self._entities[key] = entity

    @property
    def request_types(self) -> list[str]:
        return [type(r).__name__ for r in self.requests]


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------
class TestIdNormalization:
    def test_marked_supergroup_id_kept(self) -> None:
        assert to_telethon_entity_id(-1001234567890) == -1001234567890

    def test_basic_group_id_unnegated(self) -> None:
        assert to_telethon_entity_id(-654321) == 654321

    def test_positive_id_unchanged(self) -> None:
        assert to_telethon_entity_id(1234567890) == 1234567890


class TestInviteHashExtraction:
    @pytest.mark.parametrize(
        "link",
        [
            "https://t.me/+AbCdEf123",
            "https://t.me/joinchat/AbCdEf123",
            "https://telegram.me/joinchat/AbCdEf123",
            "tg://join?invite=AbCdEf123",
        ],
    )
    def test_valid_shapes(self, link: str) -> None:
        assert extract_invite_hash(link) == "AbCdEf123"

    @pytest.mark.parametrize(
        "link",
        [
            "",
            "https://example.com/+AbCdEf123",
            "https://t.me/publicgroup",
            "https://t.me/+",
            "https://t.me/joinchat/",
            "tg://join",
            "https://t.me/c/1234567890/5",
        ],
    )
    def test_invalid_shapes(self, link: str) -> None:
        assert extract_invite_hash(link) is None


class TestPublicUsernameExtraction:
    def test_public_group(self) -> None:
        assert extract_public_username("https://t.me/mygroup") == "mygroup"

    def test_invite_link_is_not_public(self) -> None:
        assert extract_public_username("https://t.me/+AbCdEf") is None

    def test_joinchat_is_not_public(self) -> None:
        assert extract_public_username("https://t.me/joinchat/AbCdEf") is None

    def test_empty(self) -> None:
        assert extract_public_username("") is None


# ---------------------------------------------------------------------------
# Membership checks
# ---------------------------------------------------------------------------
class TestMembershipChecks:
    async def test_supergroup_member(self) -> None:
        client = FakeTelethonClient(
            entities={GROUP_ENTITY_ID: _channel_entity()}
        )
        client.on(
            functions.channels.GetParticipantRequest,
            lambda req: _participant(),
        )
        clock = FakeClock()
        service = GroupAccessService(_settings(), None, clock=clock)

        assert await service.check_membership(client, GROUP) is True

    async def test_supergroup_not_member(self) -> None:
        client = FakeTelethonClient(
            entities={GROUP_ENTITY_ID: _channel_entity()}
        )
        client.on(
            functions.channels.GetParticipantRequest,
            errors.UserNotParticipantError(request=None),
        )
        service = GroupAccessService(_settings(), None, clock=FakeClock())

        assert await service.check_membership(client, GROUP) is False

    async def test_unresolvable_entity_is_none(self) -> None:
        """Account never saw the group → unknown (treated as non-member)."""
        client = FakeTelethonClient()  # no entities
        service = GroupAccessService(_settings(), None, clock=FakeClock())

        assert await service.check_membership(client, GROUP) is None

    async def test_basic_chat_member_in_participants(self) -> None:
        participants = types.ChatParticipants(
            chat_id=BASIC_GROUP_ID,
            version=1,
            participants=[
                types.ChatParticipant(user_id=ME_ID, inviter_id=1, date=_T0)
            ],
        )
        full = SimpleNamespace(
            full_chat=SimpleNamespace(id=BASIC_GROUP_ID, participants=participants)
        )
        client = FakeTelethonClient(entities={BASIC_GROUP_ID: _chat_entity()})
        client.on(functions.messages.GetFullChatRequest, full)
        service = GroupAccessService(_settings(), None, clock=FakeClock())

        assert await service.check_membership(client, BASIC_GROUP) is True

    async def test_basic_chat_not_in_participants(self) -> None:
        participants = types.ChatParticipants(
            chat_id=BASIC_GROUP_ID, version=1, participants=[]
        )
        full = SimpleNamespace(
            full_chat=SimpleNamespace(id=BASIC_GROUP_ID, participants=participants)
        )
        client = FakeTelethonClient(entities={BASIC_GROUP_ID: _chat_entity()})
        client.on(functions.messages.GetFullChatRequest, full)
        service = GroupAccessService(_settings(), None, clock=FakeClock())

        assert await service.check_membership(client, BASIC_GROUP) is False

    async def test_membership_result_cached_per_account(self) -> None:
        client = FakeTelethonClient(
            entities={GROUP_ENTITY_ID: _channel_entity()}
        )
        client.on(
            functions.channels.GetParticipantRequest,
            lambda req: _participant(),
        )
        clock = FakeClock()
        service = GroupAccessService(_settings(), None, clock=clock)

        assert await service.check_membership(client, GROUP, account_id=7) is True
        assert await service.check_membership(client, GROUP, account_id=7) is True
        # Only ONE participant RPC — second came from cache.
        assert client.request_types.count("GetParticipantRequest") == 1

        # Cache expiry re-checks.
        clock.advance(601)
        assert await service.check_membership(client, GROUP, account_id=7) is True
        assert client.request_types.count("GetParticipantRequest") == 2

        # Other accounts don't share the cache entry.
        assert await service.check_membership(client, GROUP, account_id=8) is True
        assert client.request_types.count("GetParticipantRequest") == 3


# ---------------------------------------------------------------------------
# ensure_access — the auto-join workflow
# ---------------------------------------------------------------------------
def _member_client() -> FakeTelethonClient:
    client = FakeTelethonClient(entities={GROUP_ENTITY_ID: _channel_entity()})
    client.on(
        functions.channels.GetParticipantRequest,
        lambda req: _participant(),
    )
    return client


def _joinable_client() -> FakeTelethonClient:
    """Starts unresolvable; after the invite import the entity appears."""
    client = FakeTelethonClient()  # group unknown → membership None

    state = {"imported": False}

    def _import(req: functions.messages.ImportChatInviteRequest):
        state["imported"] = True
        # Joining caches the entity in the session → now resolvable+member.
        client.add_entity(GROUP_ENTITY_ID, _channel_entity())
        client.on(
            functions.channels.GetParticipantRequest,
            lambda r: _participant(),
        )
        return SimpleNamespace(updates=[])

    client.on(functions.messages.ImportChatInviteRequest, _import)
    return client


class TestEnsureAccess:
    async def test_member_short_circuits_without_invitation(self) -> None:
        """Already a member → no provider call, no link, no import."""
        provider_calls: list[int] = []

        async def provider(group_id: int) -> str | None:
            provider_calls.append(group_id)
            return "https://t.me/+never"

        client = _member_client()
        clock = FakeClock()
        service = GroupAccessService(_settings(), provider, clock=clock)

        outcome = await service.ensure_access(client, GROUP, account_id=7)

        assert outcome.ok and not outcome.joined and outcome.status == "member"
        assert provider_calls == []
        assert client.request_types == ["GetParticipantRequest"]

    async def test_auto_join_disabled_fails_without_provider_call(self) -> None:
        client = FakeTelethonClient()  # unknown entity → not member

        async def provider(group_id: int) -> str | None:
            raise AssertionError("must not be called when disabled")

        service = GroupAccessService(
            _settings(auto_join=False), provider, clock=FakeClock()
        )
        outcome = await service.ensure_access(client, GROUP)

        assert not outcome.ok
        assert outcome.status == "auto_join_disabled"
        assert outcome.user_message and "Add it manually" in outcome.user_message

    async def test_successful_join_via_invite_link(self) -> None:
        """The happy path: export → import → verify → joined."""
        exported: list[int] = []

        async def provider(group_id: int) -> str | None:
            exported.append(group_id)
            return "https://t.me/+AbCdEf123"

        client = _joinable_client()
        clock = FakeClock()
        service = GroupAccessService(_settings(), provider, clock=clock)

        outcome = await service.ensure_access(client, GROUP, account_id=7)

        assert outcome.ok and outcome.joined
        assert exported == [GROUP]
        imports = [
            r
            for r in client.requests
            if isinstance(r, functions.messages.ImportChatInviteRequest)
        ]
        assert len(imports) == 1
        assert imports[0].hash == "AbCdEf123"

    async def test_already_participant_counts_as_access(self) -> None:
        client = FakeTelethonClient()

        def _import(req):
            # Telegram says "already there" → entity becomes resolvable.
            client.add_entity(GROUP_ENTITY_ID, _channel_entity())
            client.on(
                functions.channels.GetParticipantRequest,
                lambda r: _participant(),
            )
            raise errors.UserAlreadyParticipantError(request=None)

        client.on(functions.messages.ImportChatInviteRequest, _import)
        async def provider(group_id: int) -> str | None:
            return "https://t.me/joinchat/AbCdEf123"

        service = GroupAccessService(_settings(), provider, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert outcome.ok
        assert not outcome.joined  # we didn't join NOW — we already were

    async def test_invalid_link_fails_and_sets_cooldown(self) -> None:
        client = FakeTelethonClient()
        client.on(
            functions.messages.ImportChatInviteRequest,
            errors.InviteHashInvalidError(request=None),
        )

        async def provider(group_id: int) -> str | None:
            return "https://t.me/+BadHash"

        clock = FakeClock()
        service = GroupAccessService(_settings(), provider, clock=clock)

        first = await service.ensure_access(client, GROUP)
        assert not first.ok and first.status == "invite_link_invalid"
        assert "invalid or revoked" in (first.user_message or "")

        # Cooldown active: second call does NOT hit the provider again.
        provider_calls = []

        async def provider2(group_id: int) -> str | None:
            provider_calls.append(group_id)
            return "https://t.me/+GoodHash"

        service.set_invite_provider(provider2)
        second = await service.ensure_access(client, GROUP)
        assert not second.ok and second.status == "cooldown"
        assert provider_calls == []

        # After the cooldown expires a fresh attempt is allowed.
        clock.advance(301)
        third = await service.ensure_access(client, GROUP)
        assert third.status != "cooldown"
        assert provider_calls == [GROUP]

    async def test_expired_link_reexports_once(self) -> None:
        client = FakeTelethonClient()
        links = ["https://t.me/+Expired1", "https://t.me/+Fresh2"]
        exports: list[str] = []

        async def provider(group_id: int) -> str | None:
            exports.append(links[min(len(exports), len(links) - 1)])
            return exports[-1]

        def _import(req: functions.messages.ImportChatInviteRequest):
            if req.hash == "Expired1":
                raise errors.InviteHashExpiredError(request=None)
            # Fresh link works: entity appears, member.
            client.add_entity(GROUP_ENTITY_ID, _channel_entity())
            client.on(
                functions.channels.GetParticipantRequest,
                lambda r: _participant(),
            )
            return SimpleNamespace(updates=[])

        client.on(functions.messages.ImportChatInviteRequest, _import)

        clock = FakeClock()
        service = GroupAccessService(_settings(), provider, clock=clock)
        outcome = await service.ensure_access(client, GROUP)

        assert outcome.ok and outcome.joined
        assert exports == ["https://t.me/+Expired1", "https://t.me/+Fresh2"]

    async def test_expired_link_without_fresh_one_fails(self) -> None:
        client = FakeTelethonClient()
        client.on(
            functions.messages.ImportChatInviteRequest,
            errors.InviteHashExpiredError(request=None),
        )

        async def provider(group_id: int) -> str | None:
            return "https://t.me/+SameLink"  # same link every time

        service = GroupAccessService(_settings(), provider, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert not outcome.ok and outcome.status == "invite_link_expired"
        assert "expired" in (outcome.user_message or "")

    async def test_banned_account_fails_with_actionable_message(self) -> None:
        client = FakeTelethonClient()
        client.on(
            functions.messages.ImportChatInviteRequest,
            errors.UserBannedInChannelError(request=None),
        )

        async def provider(group_id: int) -> str | None:
            return "https://t.me/+Banned"

        service = GroupAccessService(_settings(), provider, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert not outcome.ok and outcome.status == "account_banned"
        assert "banned or restricted" in (outcome.user_message or "")

    async def test_join_request_pending_when_membership_not_verified(self) -> None:
        """Import 'succeeds' but the account still isn't a participant →
        a join request is awaiting admin approval."""
        client = FakeTelethonClient()
        # Import succeeds but entity stays unresolvable (request pending).
        client.on(
            functions.messages.ImportChatInviteRequest,
            lambda req: SimpleNamespace(updates=[]),
        )

        async def provider(group_id: int) -> str | None:
            return "https://t.me/+NeedsApproval"

        service = GroupAccessService(_settings(), provider, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert not outcome.ok and outcome.status == "approval_pending"
        assert "admin must approve" in (outcome.user_message or "")

    async def test_invite_request_sent_error_maps_to_approval(self) -> None:
        client = FakeTelethonClient()
        client.on(
            functions.messages.ImportChatInviteRequest,
            errors.InviteRequestSentError(request=None),
        )

        async def provider(group_id: int) -> str | None:
            return "https://t.me/+Requests"

        service = GroupAccessService(_settings(), provider, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert not outcome.ok and outcome.status == "approval_pending"

    async def test_flood_wait_reports_retry_time(self) -> None:
        client = FakeTelethonClient()
        client.on(
            functions.messages.ImportChatInviteRequest,
            errors.FloodWaitError(request=None, capture=42),
        )

        async def provider(group_id: int) -> str | None:
            return "https://t.me/+Flooded"

        service = GroupAccessService(_settings(), provider, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert not outcome.ok and outcome.status == "flood_limited"
        assert outcome.retry_after_seconds == 42

    async def test_missing_provider_fails_invite_unavailable(self) -> None:
        client = FakeTelethonClient()
        service = GroupAccessService(_settings(), None, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert not outcome.ok and outcome.status == "invite_unavailable"
        assert "admin with" in (outcome.user_message or "")

    async def test_provider_returning_none_fails(self) -> None:
        """Bot lacks invite-export permission → provider returns None."""
        client = FakeTelethonClient()

        async def provider(group_id: int) -> str | None:
            return None

        service = GroupAccessService(_settings(), provider, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert not outcome.ok and outcome.status == "invite_unavailable"

    async def test_provider_raising_is_contained(self) -> None:
        client = FakeTelethonClient()

        async def provider(group_id: int) -> str | None:
            raise RuntimeError("boom")

        service = GroupAccessService(_settings(), provider, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert not outcome.ok and outcome.status == "invite_unavailable"

    async def test_public_username_link_joins_via_join_channel(self) -> None:
        client = FakeTelethonClient()
        client.add_entity("publicgroup", _channel_entity())

        def _join(req: functions.channels.JoinChannelRequest):
            client.add_entity(GROUP_ENTITY_ID, _channel_entity())
            client.on(
                functions.channels.GetParticipantRequest,
                lambda r: _participant(),
            )
            return SimpleNamespace(updates=[])

        client.on(functions.channels.JoinChannelRequest, _join)

        async def provider(group_id: int) -> str | None:
            return "https://t.me/publicgroup"

        service = GroupAccessService(_settings(), provider, clock=FakeClock())
        outcome = await service.ensure_access(client, GROUP)

        assert outcome.ok and outcome.joined
        assert "JoinChannelRequest" in client.request_types
        assert "ImportChatInviteRequest" not in client.request_types

    async def test_invite_link_is_cached_across_joins(self) -> None:
        """Successful links are reused — no repeated exports (flood safety)."""
        client = _joinable_client()
        exports: list[int] = []

        async def provider(group_id: int) -> str | None:
            exports.append(group_id)
            return "https://t.me/+Reusable"

        clock = FakeClock()
        service = GroupAccessService(_settings(), provider, clock=clock)
        await service.ensure_access(client, GROUP, account_id=7)

        # Second call: already a member now — but force a second join by
        # using a *different* group id with the same provider link flow is
        # overkill; instead verify the link cache directly.
        link = await service._invite_link(GROUP)
        assert link == "https://t.me/+Reusable"
        assert exports == [GROUP], "cached link must not re-export"

    async def test_concurrent_ensure_access_single_flight(self) -> None:
        """Two concurrent ensure_access calls → exactly one import."""
        client = _joinable_client()
        imports: list[str] = []

        async def provider(group_id: int) -> str | None:
            await asyncio.sleep(0.01)  # simulate Bot API latency
            return "https://t.me/+Concurrent"

        clock = FakeClock()
        service = GroupAccessService(_settings(), provider, clock=clock)
        outcomes = await asyncio.gather(
            service.ensure_access(client, GROUP, account_id=7),
            service.ensure_access(client, GROUP, account_id=7),
        )
        imports = [
            r
            for r in client.requests
            if isinstance(r, functions.messages.ImportChatInviteRequest)
        ]
        assert all(o.ok for o in outcomes)
        assert len(imports) == 1, "join must be single-flight per group"
        assert sum(1 for o in outcomes if o.joined) == 1

    async def test_forget_group_resets_all_state(self) -> None:
        client = FakeTelethonClient()
        client.on(
            functions.messages.ImportChatInviteRequest,
            errors.InviteHashInvalidError(request=None),
        )

        async def provider(group_id: int) -> str | None:
            return "https://t.me/+Reset"

        clock = FakeClock()
        service = GroupAccessService(_settings(), provider, clock=clock)
        await service.ensure_access(client, GROUP)
        assert service.cooldown_remaining(GROUP) > 0

        service.forget_group(GROUP)
        assert service.cooldown_remaining(GROUP) == 0
        assert service._link_cache == {}


# ---------------------------------------------------------------------------
# VoiceManager integration
# ---------------------------------------------------------------------------
class AccessStubAccount:
    """Stub account exposing ``raw_client`` (the surface manager needs)."""

    def __init__(self, model, transport, raw_client) -> None:
        self.model = model
        self._transport = transport
        self.raw_client = raw_client
        self._active = 0

    @property
    def label(self) -> str:
        return self.model.label

    @property
    def is_connected(self) -> bool:
        return True

    @property
    def transport(self):
        return self._transport

    @property
    def active_sessions(self) -> int:
        return self._active

    @active_sessions.setter
    def active_sessions(self, value: int) -> None:
        self._active = max(0, int(value))

    @property
    def max_sessions(self) -> int:
        return int(self.model.max_sessions or 0)


class PlayTransport:
    """Transport recording play calls without py-tgcalls."""

    def __init__(self) -> None:
        self.played: list[tuple[int, Path]] = []

    async def join(self, group_tg_id: int) -> None: ...

    async def play(self, group_tg_id: int, path: Path, *args, **kwargs) -> None:
        self.played.append((group_tg_id, Path(path)))

    async def leave(self, group_tg_id: int) -> None: ...

    async def pause(self, group_tg_id: int) -> None: ...

    async def resume(self, group_tg_id: int) -> None: ...

    async def set_volume(self, group_tg_id: int, volume: int) -> None: ...

    async def is_connected(self, group_tg_id: int) -> bool:
        return any(g == group_tg_id for g, _ in self.played)


@pytest.fixture
async def voice_manager_env(db_setup, mk_sessions, tmp_path):
    """A real VoiceManager with one stub account + fake MTProto client."""
    repo = VoiceRepository(mk_sessions)
    events = EventBus()
    cache = MemoryCache()
    locks = LockManager(cache)
    settings = _settings()
    manager = VoiceManager(repo, settings, None, cache, locks, events)

    row = await repo.create(
        "acct-1", "encrypted-session", max_sessions=2, priority=0
    )
    transport = PlayTransport()
    client = _member_client()
    account = AccessStubAccount(row, transport, client)
    manager._accounts[int(row.id)] = account

    return SimpleNamespace(
        repo=repo, events=events, manager=manager, account=account,
        transport=transport, client=client, row=row, settings=settings,
    )


class TestManagerIntegration:
    async def test_play_denied_raises_typed_error_with_user_message(
        self, voice_manager_env
    ) -> None:
        env = voice_manager_env
        # Make membership fail hard: import raises invalid-hash.
        env.client.on(
            functions.messages.ImportChatInviteRequest,
            errors.InviteHashInvalidError(request=None),
        )

        async def provider(group_id: int) -> str | None:
            return "https://t.me/+Nope"

        env.manager.set_invite_provider(provider)

        # Blow the membership cache so the check runs again.
        env.manager.group_access._membership_cache.clear()
        env.manager.group_access._blocked.clear()

        # Make membership return False (not None) so join is attempted:
        env.client.add_entity(GROUP_ENTITY_ID, _channel_entity())
        env.client.on(
            functions.channels.GetParticipantRequest,
            errors.UserNotParticipantError(request=None),
        )

        audio = tmp_path_audio(voice_manager_env)
        with pytest.raises(VoiceGroupAccessError) as exc_info:
            await env.manager.play(GROUP, audio)
        assert "invalid or revoked" in exc_info.value.user_message
        assert env.transport.played == []

    async def test_play_member_proceeds_to_streaming(
        self, voice_manager_env
    ) -> None:
        env = voice_manager_env
        audio = tmp_path_audio(voice_manager_env)
        await env.manager.play(GROUP, audio)
        assert env.transport.played == [(GROUP, Path(audio))]

    async def test_play_without_raw_client_skips_check(
        self, voice_manager_env
    ) -> None:
        """Stub accounts without a raw client keep the old behaviour."""
        env = voice_manager_env
        env.account.raw_client = None
        audio = tmp_path_audio(voice_manager_env)
        await env.manager.play(GROUP, audio)
        assert env.transport.played == [(GROUP, Path(audio))]

    async def test_set_invite_provider_reaches_the_service(
        self, voice_manager_env
    ) -> None:
        env = voice_manager_env

        async def provider(group_id: int) -> str | None:
            return None

        env.manager.set_invite_provider(provider)
        assert env.manager.group_access._invite_provider is provider

    async def test_check_account_group_access_reports_member(
        self, voice_manager_env
    ) -> None:
        env = voice_manager_env
        info = await env.manager.check_account_group_access(
            int(env.row.id), GROUP
        )
        assert info is not None
        assert info["membership"] == "member"
        assert info["auto_join_enabled"] is True
        assert info["account_id"] == int(env.row.id)

    async def test_check_account_group_access_unknown_account(
        self, voice_manager_env
    ) -> None:
        env = voice_manager_env
        assert await env.manager.check_account_group_access(999, GROUP) is None

    async def test_check_account_group_access_offline(
        self, voice_manager_env
    ) -> None:
        env = voice_manager_env
        env.account.raw_client = None
        info = await env.manager.check_account_group_access(
            int(env.row.id), GROUP
        )
        assert info is not None and info["membership"] == "offline"


def tmp_path_audio(env) -> Path:
    """A tiny valid audio file for play() calls."""
    audio = Path(env.manager._settings.storage_dir) if hasattr(
        env.manager, "_settings"
    ) else None
    import tempfile

    tmp = Path(tempfile.mkdtemp()) / "demo.mp3"
    tmp.write_bytes(b"ID3" + b"\x00" * 64)
    return tmp


# ---------------------------------------------------------------------------
# Admin handler smoke tests (FSM fakes — no aiogram Dispatcher needed)
# ---------------------------------------------------------------------------
class FakeFSMContext:
    """Duck-typed aiogram FSMContext storing state in a dict."""

    def __init__(self) -> None:
        self.state: str | None = None
        self.data: dict = {}
        self.cleared = 0

    async def update_data(self, **kwargs) -> None:
        self.data.update(kwargs)

    async def get_data(self) -> dict:
        return dict(self.data)

    async def set_state(self, state) -> None:
        self.state = getattr(state, "state", state)

    async def clear(self) -> None:
        self.cleared += 1
        self.state = None
        self.data = {}


class _Permissions:
    def __init__(self, allowed: bool = True) -> None:
        self.allowed = allowed

    async def has(self, user_id: int, permission: str) -> bool:
        return self.allowed


class _Audit:
    def __init__(self) -> None:
        self.entries: list[tuple] = []

    async def log(self, *args, **kwargs) -> None:
        self.entries.append((args, kwargs))


class _FakeAdminService:
    def __init__(self, allowed: bool = True) -> None:
        self.permissions = _Permissions(allowed)
        self.audit = _Audit()


class _FakeVoice:
    def __init__(self, result: dict | None) -> None:
        self._result = result
        self.calls: list[tuple[int, int]] = []

    async def check_account_group_access(self, account_id: int, group_id: int):
        self.calls.append((account_id, group_id))
        return self._result


class TestAdminAccessHandlers:
    async def test_prompt_sets_state_and_account(self) -> None:
        from app.bot.handlers.admin import voice as admin_voice
        from app.bot.handlers.admin.states import VoiceAccessFSM
        from tests.conftest import FakeCallback

        callback = FakeCallback("adm:vc:acc:5:access", chat_type="private")
        services = SimpleNamespace(admin=_FakeAdminService(), voice=_FakeVoice(None))
        state = FakeFSMContext()

        await admin_voice.voice_account_access_prompt(callback, services, state)

        assert state.data["access_account_id"] == 5
        assert state.state == VoiceAccessFSM.waiting_group_id.state
        assert callback.answers  # answered
        assert "GROUP ACCESS CHECK" in callback.message.edited[-1][0]

    async def test_check_reports_membership(self) -> None:
        from app.bot.handlers.admin import voice as admin_voice
        from tests.conftest import FakeMessage

        message = FakeMessage(text="-1001234567890", chat_type="private")
        voice = _FakeVoice(
            {
                "account_id": 5,
                "label": "acct-1",
                "group_id": -1001234567890,
                "membership": "member",
                "auto_join_enabled": True,
                "cooldown_seconds": 0,
            }
        )
        admin = _FakeAdminService()
        services = SimpleNamespace(admin=admin, voice=voice)
        state = FakeFSMContext()
        await state.update_data(access_account_id=5)

        await admin_voice.voice_account_access_check(message, services, state)

        assert voice.calls == [(5, -1001234567890)]
        assert state.cleared == 1
        assert admin.audit.entries, "access check is audited"
        text = message.answered[-1][0]
        assert "GROUP ACCESS" in text and "member" in text

    async def test_check_rejects_non_numeric(self) -> None:
        from app.bot.handlers.admin import voice as admin_voice
        from tests.conftest import FakeMessage

        message = FakeMessage(text="not a group id", chat_type="private")
        voice = _FakeVoice(None)
        services = SimpleNamespace(admin=_FakeAdminService(), voice=voice)
        state = FakeFSMContext()
        await state.update_data(access_account_id=5)

        await admin_voice.voice_account_access_check(message, services, state)

        assert voice.calls == []  # never reached the manager
        assert "doesn't look like" in message.answered[-1][0]

    async def test_check_cancel_aborts(self) -> None:
        from app.bot.handlers.admin import voice as admin_voice
        from tests.conftest import FakeMessage

        message = FakeMessage(text="/cancel", chat_type="private")
        voice = _FakeVoice(None)
        services = SimpleNamespace(admin=_FakeAdminService(), voice=voice)
        state = FakeFSMContext()
        await state.update_data(access_account_id=5)

        await admin_voice.voice_account_access_check(message, services, state)

        assert voice.calls == []
        assert "cancelled" in message.answered[-1][0]

    async def test_check_permission_denied_clears_state(self) -> None:
        from app.bot.handlers.admin import voice as admin_voice
        from tests.conftest import FakeMessage

        message = FakeMessage(text="-1001234567890", chat_type="private")
        voice = _FakeVoice(None)
        services = SimpleNamespace(admin=_FakeAdminService(allowed=False), voice=voice)
        state = FakeFSMContext()
        await state.update_data(access_account_id=5)

        await admin_voice.voice_account_access_check(message, services, state)

        assert voice.calls == []
        assert state.cleared == 1
        assert message.answered == []  # silently dropped (admin router handles)

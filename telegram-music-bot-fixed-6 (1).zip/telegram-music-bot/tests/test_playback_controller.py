"""PlaybackController end-to-end tests with fake gateways on sqlite.

Real: QueueManager, SessionManager, AutoplayService, RecommendationEngine.
Fake: music gateway (returns a track + tmp file path), voice gateway
(records play/pause/resume/release), history + analytics recorders, and a
fake bot whose send_audio returns a message with audio.file_id.
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from app.playback.controller import PlaybackController
from app.playback.events import EventBus
from app.playback.queue import QueueOwner, QueueManager
from app.playback.session import SessionManager
from app.recommendation.engine import RecommendationEngine
from app.playback.autoplay import AutoplayService

from .conftest import build_services


class FakeMusicGateway:
    """MusicGateway protocol fake backed by the seeded tracks."""

    def __init__(self, tracks_repo, tmp_path: Path) -> None:
        self._tracks = tracks_repo
        self._tmp = tmp_path
        self.playable_requests: list[int] = []

    async def get_track(self, track_id: int):
        return await self._tracks.get_by_id(int(track_id))

    async def get_playable_path(self, track) -> Path:
        self.playable_requests.append(int(track.id))
        path = self._tmp / f"track-{track.id}.mp3"
        path.write_bytes(b"ID3fake-audio-bytes")
        return path

    async def ensure_audio_file_id(self, track, bot) -> str | None:
        return f"cached-file-id-{track.id}"


class FakeVoiceGateway:
    """VoiceGateway protocol fake recording every control call."""

    def __init__(self, *, enabled: bool = True) -> None:
        self.enabled = enabled
        self.played: list[tuple[int, Path]] = []
        self.paused: list[int] = []
        self.resumed: list[int] = []
        self.stopped: list[int] = []
        self.released: list[int] = []
        self.volume: list[tuple[int, int]] = []

    async def play(self, group_tg_id: int, path: Path) -> None:
        self.played.append((group_tg_id, Path(path)))

    async def pause(self, group_tg_id: int) -> None:
        self.paused.append(group_tg_id)

    async def resume(self, group_tg_id: int) -> None:
        self.resumed.append(group_tg_id)

    async def stop(self, group_tg_id: int) -> None:
        self.stopped.append(group_tg_id)

    async def release(self, group_tg_id: int) -> None:
        self.released.append(group_tg_id)

    async def set_volume(self, group_tg_id: int, volume: int) -> None:
        self.volume.append((group_tg_id, volume))

    async def is_voice_enabled(self) -> bool:
        return self.enabled


class FakeHistoryGateway:
    def __init__(self) -> None:
        self.records: list[dict] = []

    async def record(
        self,
        user_tg_id,
        track_id,
        *,
        context,
        group_id=None,
        completed=False,
        skipped=False,
        duration_played=0,
    ) -> None:
        self.records.append(
            {
                "user_tg_id": user_tg_id,
                "track_id": track_id,
                "context": context,
                "group_id": group_id,
                "completed": completed,
                "skipped": skipped,
                "duration_played": duration_played,
            }
        )


class FakeAnalyticsRecorder:
    def __init__(self) -> None:
        self.events: list[tuple] = []

    async def track(self, event_type, user_id=None, group_id=None, track_id=None, payload=None) -> None:
        self.events.append((event_type, user_id, group_id, track_id, payload))


class FakeBot:
    """Bot fake: send_audio returns a message carrying audio.file_id."""

    def __init__(self) -> None:
        self.audio_sent: list[tuple[int, object, dict]] = []
        self.messages_sent: list[tuple[int, str, dict]] = []
        self.edits: list[tuple[int, int, str]] = []
        self._next_id = 1000

    def _message(self, chat_id: int, **extra) -> SimpleNamespace:
        self._next_id += 1
        return SimpleNamespace(
            message_id=self._next_id,
            chat=SimpleNamespace(id=chat_id, type="private"),
            **extra,
        )

    async def send_audio(self, chat_id: int, audio=None, **kwargs) -> SimpleNamespace:
        self.audio_sent.append((chat_id, audio, kwargs))
        message = self._message(chat_id, audio=SimpleNamespace(file_id="tg-file-id-1"))
        return message

    async def send_message(self, chat_id: int, text: str, **kwargs) -> SimpleNamespace:
        self.messages_sent.append((chat_id, text, kwargs))
        return self._message(chat_id)

    async def edit_message_text(
        self, text: str, chat_id=None, message_id=None, **kwargs
    ) -> SimpleNamespace:
        self.edits.append((chat_id, message_id, text))
        return SimpleNamespace(message_id=message_id, text=text)


class _StatusMessage:
    """Transient group status message ("Searching… → Loading track…") fake."""

    def __init__(self, *, message_id: int = 555) -> None:
        self.message_id = message_id
        self.edited: list[tuple[str, dict]] = []

    async def edit_text(self, text: str, **kwargs) -> "_StatusMessage":
        self.edited.append((text, kwargs))
        return self


@pytest.fixture
async def controller_bundle(db_setup, mk_sessions, tmp_path):
    """Real queue/session/autoplay/engine + fake gateways + fake bot."""
    services = build_services(mk_sessions)
    events = EventBus()
    queue = QueueManager(services.queue_repo, services.tracks_repo, events)
    sessions = SessionManager(services.sessions_repo, services.tracks_repo, events)
    engine = RecommendationEngine(
        services.tracks_repo, services.profiles, services.settings_repo, services.cache
    )
    autoplay = AutoplayService(engine, queue, services.analytics_repo)

    music = FakeMusicGateway(services.tracks_repo, tmp_path)
    voice = FakeVoiceGateway()
    history = FakeHistoryGateway()
    analytics = FakeAnalyticsRecorder()
    bot = FakeBot()

    autoplay_flag_state = {"enabled": True}

    async def autoplay_flag() -> bool:
        return autoplay_flag_state["enabled"]

    controller = PlaybackController(
        queue=queue,
        autoplay=autoplay,
        music=music,
        voice=voice,
        sessions=sessions,
        events=events,
        analytics=analytics,
        history=history,
        autoplay_enabled=autoplay_flag,
        default_autoplay=True,
    )
    bundle = SimpleNamespace(
        services=services,
        events=events,
        queue=queue,
        sessions=sessions,
        controller=controller,
        music=music,
        voice=voice,
        history=history,
        analytics=analytics,
        bot=bot,
        autoplay_flag=autoplay_flag_state,
    )
    try:
        yield bundle
    finally:
        await controller.cleanup()


@pytest.fixture
def user_owner() -> QueueOwner:
    return QueueOwner(kind="user", id=101)


@pytest.fixture
def group_owner() -> QueueOwner:
    return QueueOwner(kind="group", id=-100999)


class TestPersonalPlayback:
    async def test_play_now_sends_audio_and_control_message(
        self, controller_bundle, db_setup, user_owner
    ) -> None:
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]

        await b.controller.play_now(user_owner, 101, b.bot, track_id, 101)

        # The audio file was sent to the chat...
        assert len(b.bot.audio_sent) == 1
        assert b.bot.audio_sent[0][0] == 101
        # ...and a Now Playing control message followed.
        assert len(b.bot.messages_sent) == 1
        assert "NOW PLAYING" in b.bot.messages_sent[0][1]
        # Session state persisted.
        session = await b.sessions.get(user_owner)
        assert session.current_track_id == track_id
        assert session.status == "playing"
        # History + analytics were recorded.
        assert b.history.records and b.history.records[0]["track_id"] == track_id
        assert ("track_play", 101, None, track_id) in [
            (e[0], e[1], e[2], e[3]) for e in b.analytics.events
        ]

    async def test_next_advances_to_queued_track(
        self, controller_bundle, db_setup, user_owner
    ) -> None:
        b = controller_bundle
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user_owner, 101, b.bot, first, 101)
        await b.queue.add(user_owner, second, added_by=101)

        await b.controller.next(user_owner, 101, b.bot, manual=True, skip=False)

        assert len(b.bot.audio_sent) == 2
        session = await b.sessions.get(user_owner)
        assert session.current_track_id == second

    async def test_skip_records_history_skip(
        self, controller_bundle, db_setup, user_owner
    ) -> None:
        b = controller_bundle
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user_owner, 101, b.bot, first, 101)
        await b.queue.add(user_owner, second, added_by=101)

        await b.controller.next(user_owner, 101, b.bot, manual=True, skip=True)

        skip_records = [r for r in b.history.records if r["skipped"]]
        assert skip_records and skip_records[0]["track_id"] == first
        assert any(e[0] == "track_skip" for e in b.analytics.events)

    async def test_enqueue_starts_playback_when_idle(
        self, controller_bundle, db_setup, user_owner
    ) -> None:
        b = controller_bundle
        a, c = db_setup.track_ids_by_title["Neon Sunrise"], db_setup.track_ids_by_title[
            "Static Bloom"
        ]

        size = await b.controller.enqueue(user_owner, 101, b.bot, a, 101)
        assert size == 0  # popped immediately and started playing
        assert len(b.bot.audio_sent) == 1

        size = await b.controller.enqueue(user_owner, 101, b.bot, c, 101)
        assert size == 1  # queued while a track is playing
        assert len(b.bot.audio_sent) == 1

    async def test_autoplay_refills_when_queue_empty(
        self, controller_bundle, db_setup, user_owner
    ) -> None:
        b = controller_bundle
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user_owner, 101, b.bot, first, 101)
        await b.sessions.set_autoplay(user_owner, True)

        await b.controller.next(user_owner, 101, b.bot, manual=True, skip=False)

        # Autoplay added a recommendation and it is now playing.
        session = await b.sessions.get(user_owner)
        assert session.current_track_id is not None
        assert session.current_track_id != first
        assert session.status == "playing"
        assert len(b.bot.audio_sent) == 2

    async def test_autoplay_disabled_stops_and_notifies(
        self, controller_bundle, db_setup, user_owner
    ) -> None:
        b = controller_bundle
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user_owner, 101, b.bot, first, 101)
        # Session-level autoplay off → no refill.
        await b.sessions.set_autoplay(user_owner, False)

        await b.controller.next(user_owner, 101, b.bot, manual=True, skip=False)

        session = await b.sessions.get(user_owner)
        assert session.current_track_id is None or session.status == "idle"
        finished_texts = [text for (_c, _m, text) in b.bot.edits]
        assert any("QUEUE FINISHED" in text for text in finished_texts)

    async def test_global_autoplay_flag_blocks_refill(
        self, controller_bundle, db_setup, user_owner
    ) -> None:
        b = controller_bundle
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user_owner, 101, b.bot, first, 101)
        await b.sessions.set_autoplay(user_owner, True)
        b.autoplay_flag["enabled"] = False  # controller-level kill switch

        await b.controller.next(user_owner, 101, b.bot, manual=True, skip=False)

        session = await b.sessions.get(user_owner)
        assert session.status == "idle"
        assert len(b.bot.audio_sent) == 1  # nothing new played

    async def test_pause_and_resume(
        self, controller_bundle, db_setup, user_owner
    ) -> None:
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user_owner, 101, b.bot, track_id, 101)

        await b.controller.pause(user_owner, b.bot)
        session = await b.sessions.get(user_owner)
        assert session.status == "paused"

        await b.controller.resume(user_owner, 101, b.bot)
        session = await b.sessions.get(user_owner)
        assert session.status == "playing"

    async def test_stop_parks_session_idle(self, controller_bundle, db_setup, user_owner) -> None:
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Neon Sunrise"]
        await b.controller.play_now(user_owner, 101, b.bot, track_id, 101)

        await b.controller.stop(user_owner, b.bot)
        session = await b.sessions.get(user_owner)
        assert session.status == "idle"
        assert session.current_track_id is None

    async def test_track_end_event_auto_advances(
        self, controller_bundle, db_setup, user_owner
    ) -> None:
        b = controller_bundle
        first = db_setup.track_ids_by_title["Neon Sunrise"]
        second = db_setup.track_ids_by_title["Velvet Night"]
        await b.controller.play_now(user_owner, 101, b.bot, first, 101)
        await b.queue.add(user_owner, second, added_by=101)

        # Simulate the duration timer firing.
        await b.events.publish("track_end:user:101")
        await b.events.publish("track_end:user:101")  # duplicate → throttled

        session = await b.sessions.get(user_owner)
        assert session.current_track_id == second


class TestGroupPlayback:
    async def test_group_play_now_calls_voice_play(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]

        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)

        assert len(b.voice.played) == 1
        assert b.voice.played[0][0] == -100999
        assert b.voice.played[0][1].exists()
        # Control message sent to the group chat.
        assert b.bot.messages_sent and b.bot.messages_sent[0][0] == -100999
        session = await b.sessions.get(group_owner)
        assert session.current_track_id == track_id
        assert b.history.records[0]["context"] == "group"
        assert b.history.records[0]["group_id"] == -100999
        assert ("group_play", 101, -100999, track_id) in [
            (e[0], e[1], e[2], e[3]) for e in b.analytics.events
        ]

    async def test_group_pause_resume_voice(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)

        await b.controller.pause(group_owner, b.bot)
        await b.controller.resume(group_owner, -100999, b.bot)

        assert b.voice.paused == [-100999]
        assert b.voice.resumed == [-100999]

    async def test_group_stop_releases_voice(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]
        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)

        await b.controller.stop(group_owner, b.bot)

        assert b.voice.stopped == [-100999]
        assert b.voice.released == [-100999]

    async def test_voice_unavailable_notifies(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        b = controller_bundle
        b.voice.enabled = False
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]

        await b.controller.play_now(group_owner, -100999, b.bot, track_id, 101)

        assert b.voice.played == []
        assert b.bot.messages_sent, "the user must be told why playback failed"

    async def test_enqueue_edits_status_into_now_playing(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        """The group "Loading track…" status becomes the Now Playing control."""
        b = controller_bundle
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]
        status = _StatusMessage(message_id=555)

        size = await b.controller.enqueue(
            group_owner, -100999, b.bot, track_id, 101, edit_message=status
        )

        assert size == 0  # popped and started
        assert len(b.voice.played) == 1
        # The status message was edited into the Now Playing screen — no
        # second message was sent to the chat.
        assert len(status.edited) == 1
        assert "NOW PLAYING" in status.edited[0][0]
        assert b.bot.messages_sent == []
        # The control message id now points at the edited status message.
        session = await b.sessions.get(group_owner)
        assert session.now_playing_message_id == 555

    async def test_play_failure_surfaces_on_status_message(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        """A failed group play edits the status into the error text (no extra message)."""
        b = controller_bundle
        b.voice.enabled = False
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]
        status = _StatusMessage(message_id=556)

        await b.controller.play_now(
            group_owner, -100999, b.bot, track_id, 101, edit_message=status
        )

        assert b.voice.played == []
        # The error surfaced on the transient status message...
        assert len(status.edited) == 1
        assert "voice engine" in status.edited[0][0].lower()
        # ...and no duplicate notification was sent to the chat.
        assert b.bot.messages_sent == []

    async def test_play_failure_falls_back_when_status_edit_fails(
        self, controller_bundle, db_setup, group_owner
    ) -> None:
        """Uneditable status message → classic control-message error path."""
        b = controller_bundle
        b.voice.enabled = False
        track_id = db_setup.track_ids_by_title["Circuit Breaker"]

        class _Broken:
            async def edit_text(self, *args, **kwargs):
                raise RuntimeError("message too old")

        await b.controller.play_now(
            group_owner, -100999, b.bot, track_id, 101, edit_message=_Broken()
        )

        assert b.bot.messages_sent, "the user must still be told why playback failed"

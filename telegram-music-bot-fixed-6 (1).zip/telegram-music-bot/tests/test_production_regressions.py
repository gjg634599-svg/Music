"""Regression tests for the two production failures from the round-4 log.

1. ``voice.transport.play_failed ... error="got an unexpected keyword
   argument 'loop'"`` — ``NativeTransport.play()`` passed ``loop=False``
   to ``MediaStream``; py-tgcalls 2.3.3's ``MediaStream.__init__`` has no
   such parameter, so EVERY playback attempt died at the final transport
   step (search → resolve → download all succeeded first).

2. ``groups.reply_failed ... can't parse entities: Unsupported start tag
   "song" at byte offset 18`` — ``USAGE_PLAY`` contained a raw
   ``<song name>`` placeholder while every group reply is sent with
   ``parse_mode="HTML"``; Telegram rejected the whole message.

Both are locked here against the real installed libraries (py-tgcalls
imported for real; the Telegram parser behavior reproduced with Python's
html.parser, which fires ``handle_starttag`` for the same unknown tags
Telegram rejects).
"""

from __future__ import annotations

import ast
import importlib
import inspect
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

import pytest

from app.errors import VoiceChatMissingError, VoiceError
from app.voice import transport as voice_transport
from app.voice.transport import NativeTransport

GROUP_ID = -1001234567890
AUDIO_PATH = Path("/tmp/regression-track.mp3")


# ----------------------------------------------------------------------
# 1. Transport play() call shape (the `loop` TypeError)
# ----------------------------------------------------------------------
class RecordingCalls:
    """Fake PyTgCalls app mirroring the *installed* 2.3.3 ``play`` contract.

    The signature deliberately has no ``**kwargs``: any stray keyword the
    transport tries to forward (the historical ``loop=``) raises the same
    ``TypeError`` the real library produced in production.
    """

    def __init__(self) -> None:
        self.calls: list[tuple[Any, Any, Any]] = []

    async def play(self, chat_id: Any, stream: Any = None, config: Any = None) -> None:
        self.calls.append((chat_id, stream, config))


class ExplodingCalls(RecordingCalls):
    """Fake app whose ``play`` raises a raw library-style error."""

    def __init__(self, exc: Exception) -> None:
        super().__init__()
        self._exc = exc

    async def play(self, chat_id: Any, stream: Any = None, config: Any = None) -> None:
        raise self._exc


def _transport_with(calls: RecordingCalls) -> NativeTransport:
    transport = NativeTransport(client=object())
    transport._started = True
    transport._calls = calls
    return transport


@pytest.mark.skipif(
    not voice_transport.PYTGCALLS_AVAILABLE, reason="py-tgcalls not installed"
)
class TestTransportPlayApiShape:
    def test_installed_media_stream_has_no_loop_parameter(self) -> None:
        """The installed MediaStream must not accept ``loop`` (documents the
        exact incompatibility that killed production playback)."""
        from pytgcalls.types import MediaStream

        params = inspect.signature(MediaStream.__init__).parameters
        assert "loop" not in params, (
            "installed py-tgcalls MediaStream grew a `loop` parameter — "
            "revisit app/voice/transport.py play() for the new API"
        )

    async def test_play_constructs_stream_without_forbidden_kwargs(self) -> None:
        """The exact production statement must succeed against the REAL
        MediaStream class: constructing it inside play() is where the
        ``TypeError: got an unexpected keyword argument 'loop'`` fired."""
        calls = RecordingCalls()
        transport = _transport_with(calls)
        # Before the fix this raised TypeError from MediaStream(..., loop=False).
        await transport.play(GROUP_ID, AUDIO_PATH)
        assert len(calls.calls) == 1

    async def test_play_passes_group_id_stream_and_config_positionally(self) -> None:
        from pytgcalls.types import GroupCallConfig, MediaStream

        calls = RecordingCalls()
        transport = _transport_with(calls)
        await transport.play(GROUP_ID, AUDIO_PATH)
        chat_id, stream, config = calls.calls[0]
        assert chat_id == GROUP_ID
        assert isinstance(stream, MediaStream), "real MediaStream instance expected"
        assert isinstance(config, GroupCallConfig)
        assert config.auto_start is False, (
            "auto_start must stay off: a missing voice chat must surface as "
            "VoiceChatMissingError, not a userbot attempt to create the call"
        )

    async def test_play_marks_group_joined_only_on_success(self) -> None:
        calls = ExplodingCalls(RuntimeError("boom"))
        transport = _transport_with(calls)
        with pytest.raises(VoiceError):
            await transport.play(GROUP_ID, AUDIO_PATH)
        assert not await transport.is_connected(GROUP_ID)

        ok = _transport_with(RecordingCalls())
        await ok.play(GROUP_ID, AUDIO_PATH)
        assert await ok.is_connected(GROUP_ID)

    async def test_play_failure_is_typed_not_leaky(self) -> None:
        """Raw library errors are wrapped in VoiceError (bounded message)."""
        calls = ExplodingCalls(RuntimeError("got an unexpected keyword argument 'loop'"))
        transport = _transport_with(calls)
        with pytest.raises(VoiceError) as excinfo:
            await transport.play(GROUP_ID, AUDIO_PATH)
        # Not misclassified as chat-missing or auth.
        assert not isinstance(excinfo.value, VoiceChatMissingError)


@pytest.mark.skipif(
    not voice_transport.PYTGCALLS_AVAILABLE, reason="py-tgcalls not installed"
)
class TestTransportErrorClassification:
    async def test_no_active_group_call_is_chat_missing(self) -> None:
        """py-tgcalls 2.x raises ``NoActiveGroupCall`` (renders as
        'No active group call') when the group has no live voice chat and
        auto_start is disabled — it must map to VoiceChatMissingError so
        users get the actionable 'start a voice chat' guidance."""
        calls = ExplodingCalls(RuntimeError("No active group call"))
        transport = _transport_with(calls)
        with pytest.raises(VoiceChatMissingError):
            await transport.play(GROUP_ID, AUDIO_PATH)

    async def test_no_active_group_call_exception_class_classified(self) -> None:
        from pytgcalls.exceptions import NoActiveGroupCall

        calls = ExplodingCalls(NoActiveGroupCall())
        transport = _transport_with(calls)
        with pytest.raises(VoiceChatMissingError):
            await transport.play(GROUP_ID, AUDIO_PATH)

    def test_chat_missing_markers_cover_installed_exception(self) -> None:
        from pytgcalls.exceptions import NoActiveGroupCall

        rendered = str(NoActiveGroupCall()).lower()
        assert any(
            marker.lower() in rendered
            for marker in voice_transport._CHAT_MISSING_MARKERS
        ), "NoActiveGroupCall text must be covered by _CHAT_MISSING_MARKERS"


# ----------------------------------------------------------------------
# 2. HTML-safe group texts (the "Unsupported start tag song" rejection)
# ----------------------------------------------------------------------
#: Tags Telegram's HTML parse mode actually supports.
TELEGRAM_TAGS = frozenset(
    {
        "b", "strong", "i", "em", "u", "ins", "s", "strike", "del",
        "a", "code", "pre", "tg-spoiler", "tg-emoji", "blockquote",
    }
)


class _TelegramTagChecker(HTMLParser):
    """Reproduces Telegram's unknown-start-tag rejection locally.

    Telegram answers ``can't parse entities: Unsupported start tag "X"``
    for any ``<X ...>`` outside its supported set; html.parser fires
    ``handle_starttag`` for exactly those tags (entity-escaped ``&lt;``
    placeholders never reach this path).
    """

    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.unsupported: list[str] = []

    def handle_starttag(self, tag: str, attrs: Any) -> None:  # noqa: ARG002
        if tag.lower() not in TELEGRAM_TAGS:
            self.unsupported.append(tag)


def _unsupported_tags(text: str) -> list[str]:
    checker = _TelegramTagChecker()
    checker.feed(text)
    checker.close()
    return checker.unsupported


class TestGroupUsageTextsAreHtmlSafe:
    """Byte-for-byte reproduction of the production failure."""

    def test_usage_play_no_longer_contains_raw_song_tag(self) -> None:
        from app.bot.handlers import groups

        # The production error: 'Unsupported start tag "song" at byte offset 18'
        # came from USAGE_PLAY's raw "<song name>" placeholder.
        assert "<song" not in groups.USAGE_PLAY
        assert "&lt;song name&gt;" in groups.USAGE_PLAY

    def test_usage_texts_parse_clean_like_telegram(self) -> None:
        from app.bot.handlers import groups

        for text in (groups.USAGE_PLAY, groups.USAGE_SEARCH, groups.USAGE_VOLUME):
            bad = _unsupported_tags(text)
            assert not bad, f"Telegram would reject {text!r} (tags: {bad})"

    def test_volume_placeholder_is_escaped(self) -> None:
        from app.bot.handlers import groups

        # "<0-100>" is not a letter-start tag so html.parser stays quiet —
        # lock the escape explicitly. The volume range is 0-100 (human
        # percent; the voice engine maps it to its own 0-200 scale).
        assert "&lt;0-100&gt;" in groups.USAGE_VOLUME
        assert "<0-100>" not in groups.USAGE_VOLUME


class _ModuleConstantScanner(ast.NodeVisitor):
    """Collect module-level uppercase string constants of a module."""

    def __init__(self) -> None:
        self.constants: dict[str, str] = {}
        self._module_level = True

    def visit_Assign(self, node: ast.Assign) -> None:  # noqa: N802
        if not self._module_level:
            return
        for target in node.targets:
            if (
                isinstance(target, ast.Name)
                and target.id.isupper()
                and isinstance(node.value, ast.Constant)
                and isinstance(node.value.value, str)
            ):
                self.constants[target.id] = node.value.value

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:  # noqa: N802
        pass  # skip function bodies

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:  # noqa: N802
        pass  # skip function bodies

    def visit_ClassDef(self, node: ast.ClassDef) -> None:  # noqa: N802
        pass  # skip class bodies


class TestHandlerModuleConstantsAreTelegramHtmlSafe:
    """Every module-level text constant of the group router must survive
    Telegram's HTML parser — they are all sent with parse_mode='HTML'."""

    def test_groups_module_constants_are_safe(self) -> None:
        groups = importlib.import_module("app.bot.handlers.groups")
        source = inspect.getsource(groups)
        scanner = _ModuleConstantScanner()
        scanner.visit(ast.parse(source))
        assert scanner.constants, "scanner must find the group text constants"
        offenders: dict[str, list[str]] = {}
        for name, text in scanner.constants.items():
            bad = _unsupported_tags(text)
            if bad:
                offenders[name] = bad
        assert not offenders, (
            "Module-level texts Telegram would reject: "
            f"{ {k: v for k, v in offenders.items()} }"
        )


class TestGroupsRouterHasNoDuplicateCommandRegistrations:
    """The duplicated ``/new`` handler (registered twice with identical
    bodies) is dead router weight — lock it away for good."""

    def test_each_command_registered_once(self) -> None:
        groups = importlib.import_module("app.bot.handlers.groups")
        seen: dict[str, int] = {}
        for message_handler in groups.router.message.handlers:
            for filter_obj in message_handler.filters:
                # aiogram wraps each filter in FilterObject; the Command
                # lives on .callback and exposes .commands (tuple of names).
                command_filter = getattr(filter_obj, "callback", None)
                commands = getattr(command_filter, "commands", None)
                if commands:
                    for name in commands:
                        seen[name] = seen.get(name, 0) + 1
        assert seen, "scanner must find the Command registrations"
        duplicates = {name: count for name, count in seen.items() if count > 1}
        assert not duplicates, f"commands registered more than once: {duplicates}"

"""Regression + integration tests for the DM→group playback workflow.

Covers the complete user journey (search in DM → Play → group link →
play in the group's voice chat) with every failure mode, the
pending-operation state model (isolation, expiry, idempotency), the
Back/Cancel/X distinct semantics, the DM group controls (``dmc:``) and
the group-control-keyboard fix in the playback controller.

All Telegram/MTProto/voice interactions run against fakes — no network,
no real Telethon client, no PyTgCalls.
"""

from __future__ import annotations

import asyncio
import datetime
import time
from types import SimpleNamespace
from typing import Any

import pytest
from telethon.tl.types import (
    Channel,
    ChannelFull,
    ChannelParticipant,
    ChannelParticipantAdmin,
    Chat,
    ChatFull,
    ChatInvite,
    ChatInviteAlready,
    ChatParticipantAdmin,
    ChatParticipantCreator,
    ChatParticipants,
    ChatPhotoEmpty,
)

from app.config import Settings
from app.errors import BotError, PlaybackError
from app.playback.controller import PlaybackController
from app.playback.queue import QueueOwner
from app.voice.group_access import (
    GroupAccessService,
    GroupLinkResolution,
    from_telethon_chat,
    to_telethon_entity_id,
)

# ---------------------------------------------------------------------------
# Telethon fakes
# ---------------------------------------------------------------------------
_GROUP_ID = -1001234567890
_BASIC_ID = -4242


def _mk_channel(channel_id: int = 1234567890, title: str = "Test Group") -> Channel:
    return Channel(
        id=channel_id,
        title=title,
        megagroup=True,
        broadcast=False,
        photo=ChatPhotoEmpty(),
        date=datetime.datetime(2024, 1, 1),
        creator=False,
    )


def _mk_broadcast(channel_id: int = 7654321) -> Channel:
    return Channel(
        id=channel_id,
        title="A Channel",
        megagroup=False,
        broadcast=True,
        photo=ChatPhotoEmpty(),
        date=datetime.datetime(2024, 1, 1),
        creator=False,
    )


def _mk_basic_chat(chat_id: int = 4242) -> Chat:
    return Chat(
        id=chat_id,
        title="Basic Group",
        participants_count=10,
        date=0,
        version=0,
        photo=ChatPhotoEmpty(),
    )


class _FakeClient:
    """Duck-typed Telethon client with scripted RPC + entity resolution."""

    def __init__(
        self,
        *,
        entities: dict[Any, Any] | None = None,
        rpc: dict[type, Any] | None = None,
        rpc_errors: dict[type, Exception] | None = None,
        self_id: int = 999,
    ) -> None:
        self._entities = entities or {}
        self._rpc = rpc or {}
        self._rpc_errors = rpc_errors or {}
        self._self_id = self_id
        self.calls: list[Any] = []

    async def get_entity(self, key: Any) -> Any:
        if key in self._entities:
            return self._entities[key]
        if isinstance(key, str) and key.lstrip("@") in self._entities:
            return self._entities[key.lstrip("@")]
        raise ValueError(f"No entity for {key!r}")

    async def get_me(self) -> Any:
        return SimpleNamespace(id=self._self_id)

    async def __call__(self, request: Any) -> Any:
        self.calls.append(request)
        error = self._rpc_errors.get(type(request))
        if error is not None:
            raise error
        handler = self._rpc.get(type(request))
        if handler is None:
            raise RuntimeError(f"unexpected request: {request!r}")
        return handler(request) if callable(handler) else handler


def _settings(tmp_path) -> Settings:
    return Settings(
        bot_token="123456789:" + "A" * 33,
        storage_dir=tmp_path / "storage",
    )


def _access_service(settings: Settings) -> GroupAccessService:
    service = GroupAccessService(settings, None)
    service.set_invite_provider(None)
    return service


# ---------------------------------------------------------------------------
# Unit: id conversion helpers
# ---------------------------------------------------------------------------
class TestIdConversion:
    def test_from_telethon_channel_is_marked_supergroup_id(self) -> None:
        assert from_telethon_chat(_mk_channel()) == _GROUP_ID

    def test_from_telethon_basic_chat_is_negated(self) -> None:
        assert from_telethon_chat(_mk_basic_chat(4242)) == _BASIC_ID

    def test_from_telethon_other_entities_return_none(self) -> None:
        assert from_telethon_chat(SimpleNamespace()) is None

    def test_roundtrip_marked_id(self) -> None:
        assert to_telethon_entity_id(_GROUP_ID) == _GROUP_ID
        assert to_telethon_entity_id(_BASIC_ID) == 4242


# ---------------------------------------------------------------------------
# Unit: resolve_target
# ---------------------------------------------------------------------------
class TestResolveTarget:
    async def test_public_group_link_resolves(self, tmp_path) -> None:
        access = _access_service(_settings(tmp_path))
        client = _FakeClient(entities={"musicgroup": _mk_channel()})
        result = await access.resolve_target(client, "https://t.me/musicgroup")
        assert result.ok and result.status == "ok"
        assert result.group_tg_id == _GROUP_ID
        assert result.title == "Test Group"
        assert result.chat_type == "supergroup"
        assert result.joined is False

    async def test_bare_username_resolves(self, tmp_path) -> None:
        access = _access_service(_settings(tmp_path))
        client = _FakeClient(entities={"musicgroup": _mk_channel()})
        result = await access.resolve_target(client, "@musicgroup")
        assert result.ok and result.group_tg_id == _GROUP_ID

    async def test_basic_chat_link_resolves(self, tmp_path) -> None:
        access = _access_service(_settings(tmp_path))
        client = _FakeClient(entities={"oldgroup": _mk_basic_chat()})
        result = await access.resolve_target(client, "https://t.me/oldgroup")
        assert result.ok and result.group_tg_id == _BASIC_ID
        assert result.chat_type == "group"

    async def test_broadcast_channel_rejected_as_not_group(self, tmp_path) -> None:
        access = _access_service(_settings(tmp_path))
        client = _FakeClient(entities={"news": _mk_broadcast()})
        result = await access.resolve_target(client, "https://t.me/news")
        assert not result.ok and result.status == "not_group"
        assert result.user_message

    async def test_unknown_username_is_not_found(self, tmp_path) -> None:
        access = _access_service(_settings(tmp_path))
        client = _FakeClient(entities={})
        result = await access.resolve_target(client, "https://t.me/ghostgroup")
        assert not result.ok and result.status == "not_found"

    async def test_garbage_link_is_invalid(self, tmp_path) -> None:
        access = _access_service(_settings(tmp_path))
        client = _FakeClient()
        for junk in ("", "not a link", "https://example.com/x", "spotify:track:1"):
            result = await access.resolve_target(client, junk)
            assert not result.ok and result.status == "invalid_link", junk

    async def test_invite_already_member_returns_chat(self, tmp_path) -> None:
        from telethon.tl.functions.messages import CheckChatInviteRequest

        access = _access_service(_settings(tmp_path))
        channel = _mk_channel()
        client = _FakeClient(
            entities={},
            rpc={CheckChatInviteRequest: ChatInviteAlready(chat=channel)},
        )
        result = await access.resolve_target(client, "https://t.me/+AbCdEf")
        assert result.ok and result.group_tg_id == _GROUP_ID
        assert result.joined is False

    async def test_invite_import_joins_and_rechecks(self, tmp_path) -> None:
        from telethon.tl.functions.messages import (
            CheckChatInviteRequest,
            ImportChatInviteRequest,
        )

        access = _access_service(_settings(tmp_path))
        channel = _mk_channel()
        check_count = {"n": 0}

        def check(request: Any) -> Any:
            check_count["n"] += 1
            # First check: preview (not yet member). After import: joined.
            if check_count["n"] == 1:
                return ChatInvite(
                    title="Invited Group",
                    photo=None,
                    participants_count=7,
                    color=None,
                    channel=None,
                    broadcast=False,
                    public=False,
                    megagroup=True,
                    request_needed=False,
                    verified=False,
                    scam=False,
                    fake=False,
                )
            return ChatInviteAlready(chat=channel)

        client = _FakeClient(
            entities={},
            rpc={
                CheckChatInviteRequest: check,
                ImportChatInviteRequest: SimpleNamespace(updates=[]),
            },
        )
        result = await access.resolve_target(client, "https://t.me/+AbCdEf")
        assert result.ok and result.group_tg_id == _GROUP_ID
        assert result.joined is True

    async def test_broadcast_invite_preview_rejected(self, tmp_path) -> None:
        from telethon.tl.functions.messages import CheckChatInviteRequest

        access = _access_service(_settings(tmp_path))
        preview = ChatInvite(
            title="Channel Invite",
            photo=None,
            participants_count=1000,
            color=None,
            channel=None,
            broadcast=True,
            public=True,
            megagroup=False,
            request_needed=False,
            verified=False,
            scam=False,
            fake=False,
        )
        client = _FakeClient(
            entities={}, rpc={CheckChatInviteRequest: preview}
        )
        result = await access.resolve_target(client, "https://t.me/joinchat/xyz")
        assert not result.ok and result.status == "not_group"

    async def test_invite_request_sent_is_approval_pending(self, tmp_path) -> None:
        from telethon.errors import InviteRequestSentError
        from telethon.tl.functions.messages import (
            CheckChatInviteRequest,
            ImportChatInviteRequest,
        )

        access = _access_service(_settings(tmp_path))
        preview = ChatInvite(
            title="Approval Group",
            photo=None,
            participants_count=7,
            color=None,
            channel=None,
            broadcast=False,
            public=False,
            megagroup=True,
            request_needed=True,
            verified=False,
            scam=False,
            fake=False,
        )
        client = _FakeClient(
            entities={},
            rpc={CheckChatInviteRequest: preview},
            rpc_errors={ImportChatInviteRequest: InviteRequestSentError(request=None)},
        )
        result = await access.resolve_target(client, "tg://join?invite=AbCdEf")
        assert not result.ok and result.status == "approval_pending"
        assert result.user_message

    async def test_expired_invite_hash(self, tmp_path) -> None:
        from telethon.errors import InviteHashExpiredError
        from telethon.tl.functions.messages import CheckChatInviteRequest

        access = _access_service(_settings(tmp_path))
        client = _FakeClient(
            entities={},
            rpc_errors={CheckChatInviteRequest: InviteHashExpiredError(request=None)},
        )
        result = await access.resolve_target(client, "https://t.me/+deadbeef")
        assert not result.ok and result.status == "invite_link_expired"

    async def test_allow_join_false_reports_disabled(self, tmp_path) -> None:
        from telethon.tl.functions.messages import CheckChatInviteRequest

        access = _access_service(_settings(tmp_path))
        preview = ChatInvite(
            title="Some Group",
            photo=None,
            participants_count=7,
            color=None,
            channel=None,
            broadcast=False,
            public=False,
            megagroup=True,
            request_needed=False,
            verified=False,
            scam=False,
            fake=False,
        )
        client = _FakeClient(entities={}, rpc={CheckChatInviteRequest: preview})
        result = await access.resolve_target(
            client, "https://t.me/+AbCdEf", allow_join=False
        )
        assert not result.ok and result.status == "auto_join_disabled"


# ---------------------------------------------------------------------------
# Unit: check_voice_chat / check_user_membership
# ---------------------------------------------------------------------------
def _full_chat(group_call: Any) -> Any:
    return SimpleNamespace(
        full_chat=SimpleNamespace(groupcall=group_call, participants=None)
    )


class TestPrerequisiteChecks:
    async def test_voice_chat_present_true(self, tmp_path) -> None:
        from telethon.tl.functions.channels import GetFullChannelRequest

        access = _access_service(_settings(tmp_path))
        client = _FakeClient(
            entities={_GROUP_ID: _mk_channel()},
            rpc={GetFullChannelRequest: _full_chat(SimpleNamespace(id=1))},
        )
        assert await access.check_voice_chat(client, _GROUP_ID) is True

    async def test_voice_chat_missing_false(self, tmp_path) -> None:
        from telethon.tl.functions.channels import GetFullChannelRequest

        access = _access_service(_settings(tmp_path))
        client = _FakeClient(
            entities={_GROUP_ID: _mk_channel()},
            rpc={GetFullChannelRequest: _full_chat(None)},
        )
        assert await access.check_voice_chat(client, _GROUP_ID) is False

    async def test_voice_chat_unknown_returns_none(self, tmp_path) -> None:
        access = _access_service(_settings(tmp_path))
        client = _FakeClient(entities={})  # unresolvable entity
        assert await access.check_voice_chat(client, _GROUP_ID) is None

    async def test_basic_chat_group_call_check(self, tmp_path) -> None:
        from telethon.tl.functions.messages import GetFullChatRequest

        access = _access_service(_settings(tmp_path))
        client = _FakeClient(
            entities={4242: _mk_basic_chat()},
            rpc={GetFullChatRequest: _full_chat(SimpleNamespace(id=5))},
        )
        assert await access.check_voice_chat(client, _BASIC_ID) is True

    async def test_user_member_admin_supergroup(self, tmp_path) -> None:
        from telethon.tl.functions.channels import GetParticipantRequest

        access = _access_service(_settings(tmp_path))
        client = _FakeClient(
            entities={_GROUP_ID: _mk_channel()},
            rpc={
                GetParticipantRequest: SimpleNamespace(
                    participant=ChannelParticipantAdmin(
                        user_id=55, date=0, admin_rights=None,
                        promoted_by=1, rank="admin",
                    )
                )
            },
        )
        assert await access.check_user_membership(client, _GROUP_ID, 55) == (True, True)

    async def test_user_member_plain_supergroup(self, tmp_path) -> None:
        from telethon.tl.functions.channels import GetParticipantRequest

        access = _access_service(_settings(tmp_path))
        client = _FakeClient(
            entities={_GROUP_ID: _mk_channel()},
            rpc={
                GetParticipantRequest: SimpleNamespace(
                    participant=ChannelParticipant(user_id=66, date=0)
                )
            },
        )
        assert await access.check_user_membership(client, _GROUP_ID, 66) == (True, False)

    async def test_user_not_member_supergroup(self, tmp_path) -> None:
        from telethon.errors import UserNotParticipantError
        from telethon.tl.functions.channels import GetParticipantRequest

        access = _access_service(_settings(tmp_path))
        client = _FakeClient(
            entities={_GROUP_ID: _mk_channel()},
            rpc_errors={GetParticipantRequest: UserNotParticipantError(request=None)},
        )
        assert await access.check_user_membership(client, _GROUP_ID, 66) == (False, False)

    async def test_user_membership_basic_chat_scan(self, tmp_path) -> None:
        from telethon.tl.functions.messages import GetFullChatRequest

        access = _access_service(_settings(tmp_path))
        full = SimpleNamespace(
            full_chat=SimpleNamespace(
                groupcall=None,
                participants=ChatParticipants(
                    chat_id=4242,
                    version=1,
                    participants=[
                        ChatParticipantCreator(user_id=1, rank='owner'),
                        ChatParticipantAdmin(user_id=55, inviter_id=1, date=0, rank='admin'),
                    ],
                ),
            )
        )
        client = _FakeClient(
            entities={4242: _mk_basic_chat()},
            rpc={GetFullChatRequest: full},
        )
        assert await access.check_user_membership(client, _BASIC_ID, 55) == (True, True)
        assert await access.check_user_membership(client, _BASIC_ID, 1) == (True, True)
        assert await access.check_user_membership(client, _BASIC_ID, 77) == (False, False)


# ---------------------------------------------------------------------------
# Controller keyboard regression (wrong-target button bug)
# ---------------------------------------------------------------------------
class TestGroupControlKeyboard:
    def test_group_keyboard_uses_grp_callbacks_only(self) -> None:
        keyboard = PlaybackController._player_keyboard(paused=False, group=True)
        datas = [
            button.callback_data
            for row in keyboard.inline_keyboard
            for button in row
        ]
        assert datas and all(d.startswith("grp:") for d in datas)
        assert not any(d.startswith("np:") for d in datas)
        assert "grp:pause" in datas and "grp:skip" in datas
        assert "grp:stop" in datas and "grp:queue" in datas

    def test_group_paused_keyboard_offers_resume(self) -> None:
        keyboard = PlaybackController._player_keyboard(paused=True, group=True)
        datas = [
            button.callback_data
            for row in keyboard.inline_keyboard
            for button in row
        ]
        assert "grp:resume" in datas

    def test_personal_keyboard_still_uses_np_callbacks(self) -> None:
        keyboard = PlaybackController._player_keyboard(paused=False, group=False)
        datas = [
            button.callback_data
            for row in keyboard.inline_keyboard
            for button in row
        ]
        assert "np:pause" in datas and "np:next" in datas
        assert not any(d.startswith("grp:") for d in datas)


# ---------------------------------------------------------------------------
# Handler-level tests (direct invocation with fakes)
# ---------------------------------------------------------------------------
class FakeMessage:
    """Duck-typed aiogram Message."""

    def __init__(self, chat_id: int = 777, text: str = "") -> None:
        self.chat = SimpleNamespace(id=chat_id, type="private")
        self.text = text
        self.message_id = 1
        self.edits: list[tuple[str, Any]] = []
        self.deleted = False
        self.answers: list[str] = []

    async def edit_text(self, text: str, **kwargs: Any) -> None:
        self.edits.append((text, kwargs.get("reply_markup")))

    async def answer(self, text: str, **kwargs: Any) -> None:
        self.answers.append(text)

    async def delete(self) -> None:
        self.deleted = True


class FakeCallback:
    """Duck-typed aiogram CallbackQuery."""

    def __init__(
        self,
        data: str,
        *,
        user_id: int = 55,
        chat_id: int = 777,
        message: FakeMessage | None = None,
    ) -> None:
        self.data = data
        self.from_user = SimpleNamespace(id=user_id, username="tester", first_name="T")
        self.message = message or FakeMessage(chat_id)
        self.bot = SimpleNamespace(
            username="testbot",
            get_chat=_raise_get_chat,
        )
        self.answered: list[tuple[str, bool]] = []

    async def answer(self, text: str | None = None, show_alert: bool = False, **kw: Any) -> None:
        self.answered.append((text or "", show_alert))


async def _raise_get_chat(chat_id: int) -> None:
    raise RuntimeError("bot not in chat")


class FakeState:
    """FSMContext fake with per-user data."""

    def __init__(self, data: dict[str, Any] | None = None) -> None:
        self._data = dict(data or {})
        self._state: Any = None

    async def get_data(self) -> dict[str, Any]:
        return dict(self._data)

    async def update_data(self, **kwargs: Any) -> None:
        self._data.update(kwargs)

    async def set_data(self, data: dict[str, Any]) -> None:
        self._data = dict(data)

    async def set_state(self, state: Any) -> None:
        self._state = state

    async def get_state(self) -> Any:
        return self._state

    async def clear(self) -> None:
        self._data = {}
        self._state = None


class FakePlayback:
    """Playback service fake recording the exact calls made."""

    def __init__(self, *, active: bool = False, error: BotError | None = None) -> None:
        self.active = active
        self.error = error
        self.play_now_calls: list[dict[str, Any]] = []
        self.enqueue_calls: list[dict[str, Any]] = []
        self.pause_calls: list[QueueOwner] = []
        self.resume_calls: list[QueueOwner] = []
        self.next_calls: list[QueueOwner] = []
        self.stop_calls: list[QueueOwner] = []

    async def now_playing(self, owner: QueueOwner) -> dict[str, Any]:
        if not self.active:
            return {"status": "idle", "track": None}
        return {
            "status": "playing",
            "track": SimpleNamespace(
                title="Current Song",
                artist=None,
                duration_seconds=100,
                source="audius",
                id=99,
            ),
            "position_seconds": 5,
            "queue_size": 0,
            "shuffle": False,
            "repeat_mode": "off",
            "autoplay": False,
        }

    async def play_now(self, owner, chat_id, bot, track_id, user_tg_id, **kw) -> None:
        if self.error is not None:
            raise self.error
        self.play_now_calls.append(
            dict(owner=owner, chat_id=chat_id, track_id=track_id, user=user_tg_id)
        )

    async def enqueue(self, owner, chat_id, bot, track_id, user_tg_id) -> int:
        if self.error is not None:
            raise self.error
        self.enqueue_calls.append(
            dict(owner=owner, chat_id=chat_id, track_id=track_id, user=user_tg_id)
        )
        return 3

    async def pause(self, owner, bot) -> None:
        self.pause_calls.append(owner)

    async def resume(self, owner, chat_id, bot) -> None:
        self.resume_calls.append(owner)

    async def next(self, owner, chat_id, bot, **kw) -> None:
        self.next_calls.append(owner)

    async def stop(self, owner, bot) -> None:
        self.stop_calls.append(owner)


def _services(
    *,
    playback: FakePlayback | None = None,
    resolve: Any = None,
    voice_chat: bool | None = True,
    access_ok: bool = True,
    membership: tuple[bool, bool] | None = (True, False),
    permission: bool = True,
    groups: list[Any] | None = None,
) -> SimpleNamespace:
    playback = playback or FakePlayback()
    resolution = resolve or GroupLinkResolution(
        ok=True, status="ok", group_tg_id=_GROUP_ID,
        title="Test Group", chat_type="supergroup",
    )
    access = SimpleNamespace(
        check_voice_chat=async_return(voice_chat),
        ensure_access=async_return(
            SimpleNamespace(ok=access_ok, joined=False, status="member", user_message=None)
            if access_ok
            else SimpleNamespace(
                ok=False, joined=False, status="account_banned",
                user_message="banned msg",
            )
        ),
        check_user_membership=async_return(membership),
        resolve_target=async_return(resolution),
    )
    voice = SimpleNamespace(
        has_accounts=lambda: True,
        pick_client=lambda: (
            SimpleNamespace(model=SimpleNamespace(id=1)),
            object(),
        ),
        group_access=access,
        release=async_return(None),
    )
    return SimpleNamespace(
        music=SimpleNamespace(
            get_track=async_return(
                SimpleNamespace(
                    id=12, title="Hindi Song", artist=None,
                    duration_seconds=180, source="audius", source_id="DxRhR",
                )
            )
        ),
        voice=voice,
        permissions=SimpleNamespace(can=async_return(permission)),
        library=SimpleNamespace(is_liked=async_return(False)),
        groups=SimpleNamespace(
            groups_of_user=async_return(groups or []),
            register_group=async_return(SimpleNamespace(
                id=1, telegram_id=_GROUP_ID, title="Test Group"
            )),
            sync_member=async_return(None),
            groups=SimpleNamespace(groups_of_user=async_return(groups or [])),
        ),
        users=SimpleNamespace(
            get_or_create=async_return(SimpleNamespace(id=5))
        ),
        playback=playback,
        queue=SimpleNamespace(get_queue=async_return([])),
    )


def async_return(value: Any):
    async def _inner(*args: Any, **kwargs: Any) -> Any:
        return value

    return _inner


# ---------------------------------------------------------------------------
# Chooser / navigation semantics
# ---------------------------------------------------------------------------
class TestChooserAndNavigation:
    async def test_play_opens_destination_chooser(self) -> None:
        from app.bot.handlers.dm_play import on_track_destination

        services = _services(groups=[SimpleNamespace(telegram_id=_GROUP_ID, title="My Group")])
        callback = FakeCallback("trk:dest:12")
        state = FakeState({"search_query": "hindi", "search_page": 0})
        await on_track_destination(callback, services, state)
        text, markup = callback.message.edits[-1]
        assert "WHERE SHOULD THIS PLAY" in text
        assert "Hindi Song" in text
        datas = [b.callback_data for row in markup.inline_keyboard for b in row]
        assert f"dm:grp:12:{_GROUP_ID}" in datas
        assert "dm:link:12" in datas          # send-a-link option
        assert "trk:play:12" in datas         # legacy personal playback kept
        assert "trk:12" in datas              # Back to the track page
        assert "dm:cancel" in datas
        # Pending operation stored, search state preserved.
        assert state._data["dmop_track_id"] == 12
        assert state._data["dmop_source"] == "audius"
        assert state._data["dmop_source_id"] == "DxRhR"
        assert state._data["search_query"] == "hindi"

    async def test_back_from_link_prompt_returns_to_chooser(self) -> None:
        from app.bot.handlers.dm_play import on_dm_back, on_dm_link_prompt

        services = _services()
        callback = FakeCallback("dm:link:12")
        state = FakeState({"dmop_track_id": 12, "dmop_stage": "chooser"})
        await on_dm_link_prompt(callback, services, state)
        assert state._state is not None  # waiting_link entered
        assert state._data["dmop_stage"] == "awaiting_link"

        back = FakeCallback("dm:back:12")
        await on_dm_back(back, services, state)
        text, _ = back.message.edits[-1]
        assert "WHERE SHOULD THIS PLAY" in text
        assert state._data["dmop_stage"] == "chooser"

    async def test_back_from_chooser_returns_to_track_page(self) -> None:
        from app.bot.handlers.dm_play import on_dm_back

        services = _services()
        state = FakeState(
            {"dmop_track_id": 12, "dmop_stage": "chooser", "search_page": 0}
        )
        callback = FakeCallback("dm:back:12")
        await on_dm_back(callback, services, state)
        text, markup = callback.message.edits[-1]
        assert "Hindi Song" in text
        datas = [b.callback_data for row in markup.inline_keyboard for b in row]
        assert "trk:dest:12" in datas  # Play → chooser again
        # Back never executes anything.
        assert services.playback.play_now_calls == []

    async def test_cancel_clears_only_dm_operation(self) -> None:
        from app.bot.handlers.dm_play import on_dm_cancel

        services = _services()
        state = FakeState(
            {
                "dmop_track_id": 12,
                "dmop_stage": "awaiting_link",
                "search_query": "hindi",
                "search_ids": [12],
            }
        )
        from app.bot.handlers.dm_play import DmPlayFSM  # real state object
        state._state = DmPlayFSM.waiting_link
        callback = FakeCallback("dm:cancel")
        await on_dm_cancel(callback, state)
        text, _ = callback.message.edits[-1]
        assert "CANCELLED" in text
        # dmop keys gone; search state intact.
        assert not any(k.startswith("dmop_") for k in state._data)
        assert state._data["search_query"] == "hindi"
        assert state._data["search_ids"] == [12]
        assert state._state is None
        # Cancel never touches playback.
        assert services.playback.play_now_calls == []

    async def test_close_deletes_message_and_keeps_playback(self) -> None:
        from app.bot.handlers.dm_play import on_dm_close

        services = _services()
        state = FakeState({"dmop_track_id": 12})
        callback = FakeCallback("dm:close")
        await on_dm_close(callback, state)
        assert callback.message.deleted is True
        assert services.playback.stop_calls == []

    async def test_expired_operation_shows_recovery(self) -> None:
        from app.bot.handlers.dm_play import DM_OPERATION_TTL, on_dm_group_pick

        services = _services()
        state = FakeState(
            {
                "dmop_track_id": 12,
                "dmop_created": int(time.time()) - DM_OPERATION_TTL - 1,
            }
        )
        callback = FakeCallback(f"dm:grp:12:{_GROUP_ID}")
        await on_dm_group_pick(callback, services, state)
        text, _ = callback.message.edits[-1]
        assert "EXPIRED" in text
        assert services.playback.play_now_calls == []


# ---------------------------------------------------------------------------
# Link submission → execution
# ---------------------------------------------------------------------------
class TestLinkSubmission:
    async def _submit(self, services, state, link="https://t.me/musicgroup"):
        from app.bot.handlers.dm_play import on_group_link

        message = FakeMessage(text=link)
        message.from_user = SimpleNamespace(id=55, username="t", first_name="T")
        message.bot = SimpleNamespace(username="testbot")
        await on_group_link(message, services, state)
        return message

    async def test_happy_path_plays_in_target_group(self) -> None:
        services = _services()
        state = FakeState(
            {
                "dmop_track_id": 12,
                "dmop_created": int(time.time()),
                "dmop_requester": 55,
            }
        )
        message = await self._submit(services, state)
        # play_now routed to the GROUP owner with the DM chat as control chat
        # (the fake bot is not a group member).
        calls = services.playback.play_now_calls
        assert len(calls) == 1
        assert calls[0]["owner"].kind == "group"
        assert calls[0]["owner"].id == _GROUP_ID
        assert calls[0]["track_id"] == 12
        assert calls[0]["user"] == 55
        # Honest confirmation with group name + DM controls.
        text, markup = message.edits[-1]
        assert "NOW PLAYING IN THE GROUP" in text
        assert "Test Group" in text
        datas = [b.callback_data for row in markup.inline_keyboard for b in row]
        assert f"dmc:{_GROUP_ID}:pause" in datas
        assert f"dmc:{_GROUP_ID}:next" in datas
        assert "dm:close" in datas
        # Pending operation cleared after success.
        assert not any(k.startswith("dmop_") for k in state._data)

    async def test_active_session_enqueues_instead_of_playing(self) -> None:
        services = _services(playback=FakePlayback(active=True))
        state = FakeState(
            {"dmop_track_id": 12, "dmop_created": int(time.time()), "dmop_requester": 55}
        )
        message = await self._submit(services, state)
        assert services.playback.play_now_calls == []
        calls = services.playback.enqueue_calls
        assert len(calls) == 1 and calls[0]["owner"].id == _GROUP_ID
        text, _ = message.edits[-1]
        assert "ADDED TO THE QUEUE" in text and "#3" in text

    async def test_invalid_link_keeps_track_and_reprompts(self) -> None:
        bad = GroupLinkResolution(ok=False, status="invalid_link", user_message="bad link msg")
        services = _services(resolve=bad)
        state = FakeState(
            {"dmop_track_id": 12, "dmop_created": int(time.time()), "dmop_requester": 55}
        )
        message = await self._submit(services, state, link="not a link")
        # The selected track is NOT lost.
        assert state._data["dmop_track_id"] == 12
        assert state._data["dmop_stage"] == "awaiting_link"
        text, markup = message.edits[-1]
        assert "bad link msg" in text
        datas = [b.callback_data for row in markup.inline_keyboard for b in row]
        assert "dm:link:12" in datas and "dm:back:12" in datas
        assert services.playback.play_now_calls == []

    async def test_missing_voice_chat_blocks_with_actionable_error(self) -> None:
        services = _services(voice_chat=False)
        state = FakeState(
            {"dmop_track_id": 12, "dmop_created": int(time.time()), "dmop_requester": 55}
        )
        message = await self._submit(services, state)
        text, markup = message.edits[-1]
        assert "voice chat" in text
        assert services.playback.play_now_calls == []
        datas = [b.callback_data for row in markup.inline_keyboard for b in row]
        assert "dm:link:12" in datas  # Retry offered

    async def test_user_not_member_is_denied(self) -> None:
        services = _services(membership=(False, False))
        state = FakeState(
            {"dmop_track_id": 12, "dmop_created": int(time.time()), "dmop_requester": 55}
        )
        message = await self._submit(services, state)
        text, _ = message.edits[-1]
        assert "not a member" in text
        assert services.playback.play_now_calls == []

    async def test_permission_denied_is_reported(self) -> None:
        services = _services(permission=False)
        state = FakeState(
            {"dmop_track_id": 12, "dmop_created": int(time.time()), "dmop_requester": 55}
        )
        message = await self._submit(services, state)
        text, _ = message.edits[-1]
        assert "permission" in text
        assert services.playback.play_now_calls == []

    async def test_playback_failure_never_claims_success(self) -> None:
        services = _services(
            playback=FakePlayback(error=PlaybackError("boom", user_message="❌ Couldn't play this track."))
        )
        state = FakeState(
            {"dmop_track_id": 12, "dmop_created": int(time.time()), "dmop_requester": 55}
        )
        message = await self._submit(services, state)
        text, _ = message.edits[-1]
        assert "Couldn't play" in text
        assert "NOW PLAYING" not in text

    async def test_expired_operation_recovery(self) -> None:
        from app.bot.handlers.dm_play import DM_OPERATION_TTL

        services = _services()
        state = FakeState(
            {
                "dmop_track_id": 12,
                "dmop_created": int(time.time()) - DM_OPERATION_TTL - 5,
                "dmop_requester": 55,
            }
        )
        message = await self._submit(services, state)
        assert any("EXPIRED" in t for t in message.answers)
        assert services.playback.play_now_calls == []

    async def test_duplicate_submission_is_suppressed(self) -> None:
        from app.bot.handlers import dm_play as module

        services = _services()
        state = FakeState(
            {"dmop_track_id": 12, "dmop_created": int(time.time()), "dmop_requester": 55}
        )
        lock = asyncio.Lock()
        module._EXECUTION_LOCKS[55] = lock
        try:
            async with lock:  # simulate an in-flight execution
                message = await self._submit(services, state)
                assert any("previous request" in t for t in message.answers)
                assert services.playback.play_now_calls == []
        finally:
            module._EXECUTION_LOCKS.pop(55, None)

    async def test_cancel_command_while_waiting(self) -> None:
        from app.bot.handlers.dm_play import on_group_link_cancel

        state = FakeState({"dmop_track_id": 12})
        from app.bot.handlers.dm_play import DmPlayFSM  # real state object
        state._state = DmPlayFSM.waiting_link
        message = FakeMessage()
        await on_group_link_cancel(message, state)
        assert not any(k.startswith("dmop_") for k in state._data)
        assert state._state is None
        assert any("CANCELLED" in t for t in message.answers)


# ---------------------------------------------------------------------------
# Group picker callback
# ---------------------------------------------------------------------------
class TestGroupPicker:
    async def test_known_group_button_plays(self) -> None:
        from app.bot.handlers.dm_play import on_dm_group_pick

        services = _services()
        state = FakeState({"dmop_track_id": 12, "dmop_created": int(time.time())})
        callback = FakeCallback(f"dm:grp:12:{_GROUP_ID}")
        await on_dm_group_pick(callback, services, state)
        calls = services.playback.play_now_calls
        assert len(calls) == 1
        assert calls[0]["owner"].id == _GROUP_ID
        assert calls[0]["track_id"] == 12

    async def test_unknown_group_button_fails_safely(self) -> None:
        from app.bot.handlers.dm_play import on_dm_group_pick

        services = _services(membership=(False, False))  # verification denies
        state = FakeState({"dmop_track_id": 12, "dmop_created": int(time.time())})
        callback = FakeCallback("dm:grp:12:-100999999")
        await on_dm_group_pick(callback, services, state)
        assert services.playback.play_now_calls == []


# ---------------------------------------------------------------------------
# DM group controls (dmc:)
# ---------------------------------------------------------------------------
class TestDmControls:
    async def _control(self, action: str, *, permission: bool = True, playback=None):
        from app.bot.handlers.dm_play import on_dm_control

        services = _services(playback=playback, permission=permission)
        callback = FakeCallback(f"dmc:{_GROUP_ID}:{action}")
        await on_dm_control(callback, services)
        return callback, services

    async def test_pause_pauses_target_group(self) -> None:
        playback = FakePlayback()
        callback, services = await self._control("pause", playback=playback)
        assert playback.pause_calls == [QueueOwner(kind="group", id=_GROUP_ID)]

    async def test_next_skips_target_group(self) -> None:
        playback = FakePlayback()
        callback, services = await self._control("next", playback=playback)
        assert playback.next_calls == [QueueOwner(kind="group", id=_GROUP_ID)]

    async def test_stop_stops_and_releases_only_target_group(self) -> None:
        playback = FakePlayback()
        callback, services = await self._control("stop", playback=playback)
        assert playback.stop_calls == [QueueOwner(kind="group", id=_GROUP_ID)]
        text, _ = callback.message.edits[-1]
        assert "STOPPED" in text

    async def test_denied_permission_blocks_control(self) -> None:
        playback = FakePlayback()
        callback, services = await self._control("pause", permission=False, playback=playback)
        assert playback.pause_calls == []
        assert any("permission" in (a[0] or "") for a in callback.answered)

    async def test_close_deletes_message(self) -> None:
        callback, services = await self._control("close")
        assert callback.message.deleted is True

    async def test_invalid_action_rejected(self) -> None:
        from app.bot.handlers.dm_play import on_dm_control

        services = _services()
        callback = FakeCallback(f"dmc:{_GROUP_ID}:explode")
        await on_dm_control(callback, services)
        assert any("Invalid" in (a[0] or "") for a in callback.answered)
        assert services.playback.pause_calls == []

    async def test_queue_view_renders_group_queue(self) -> None:
        from app.bot.handlers.dm_play import on_dm_control

        services = _services()
        item = SimpleNamespace(
            id=1, track_id=99, track=SimpleNamespace(
                title="Queued Song", artist=None, duration_seconds=200, source="audius"
            )
        )
        services.queue = SimpleNamespace(get_queue=async_return([item]))
        callback = FakeCallback(f"dmc:{_GROUP_ID}:queue")
        await on_dm_control(callback, services)
        text, markup = callback.message.edits[-1]
        assert "GROUP QUEUE" in text and "Queued Song" in text

"""Group status-message UX — one message per /play and /search request.

Round-4 continuation: production logs showed a group ``/play`` spanning
~36 s (7 s search + 23 s download) with zero user feedback, and group
``/search`` dead air of 7–10 s. The fix is a single status message per
request: posted before any provider call ("🔎 Searching…"), edited to
"⬇️ Loading track…" when a match is found, and finally edited into the
Now Playing control (``edit_message`` passthrough), the queue
confirmation, or the failure text.

Design rules honored (see ``app/bot/search_progress.py``): group messages
never animate — exactly one message, edited in place; every failure path
still answers the user (edit fallback → fresh reply).
"""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest

from app.bot.handlers import groups as groups_module
from app.errors import BotError

from .conftest import FakeMessage

# ---------------------------------------------------------------------------
# Stubs
# ---------------------------------------------------------------------------
def _mk_track(index: int, *, title: str | None = None, artist: str | None = None) -> SimpleNamespace:
    return SimpleNamespace(
        id=index,
        title=title or f"Track {index}",
        artist=SimpleNamespace(name=artist if artist is not None else "Test Artist"),
        duration_seconds=180 + index,
    )


class _SearchMusic:
    """MusicService stub whose search() returns canned results."""

    def __init__(
        self, results: list[Any] | None = None, error: Exception | None = None
    ) -> None:
        self.results = list(results or [])
        self.error = error
        self.calls: list[dict[str, Any]] = []

    async def search(self, query: str, limit: int = 10) -> list[Any]:
        self.calls.append({"query": query, "limit": limit})
        if self.error is not None:
            raise self.error
        return self.results


class _StubPlayback:
    """Playback stub recording enqueue/now_playing with the edit_message."""

    def __init__(self, *, size: int = 3, active: bool = True, error: Exception | None = None) -> None:
        self.size = size
        self.active = active
        self.error = error
        self.enqueued: list[dict[str, Any]] = []

    async def now_playing(self, owner: Any) -> dict[str, Any]:
        return {"status": "playing" if self.active else "idle", "track": _mk_track(1)}

    async def enqueue(
        self,
        owner: Any,
        chat_id: int,
        bot: Any,
        track_id: int,
        user_tg_id: int,
        *,
        edit_message: Any = None,
    ) -> int:
        if self.error is not None:
            raise self.error
        self.enqueued.append(
            {
                "owner": (owner.kind, owner.id),
                "track_id": track_id,
                "user_tg_id": user_tg_id,
                "edit_message": edit_message,
            }
        )
        return self.size


class _Recorder:
    def __init__(self, result: Any = None) -> None:
        self.result = result
        self.calls: list[dict[str, Any]] = []

    async def __call__(self, *args: Any, **kwargs: Any) -> Any:
        self.calls.append({"args": args, "kwargs": kwargs})
        return self.result


def _services(
    music: Any,
    *,
    playback: Any = None,
    allowed: bool = True,
) -> SimpleNamespace:
    user_row = SimpleNamespace(id=1)
    group_row = SimpleNamespace(id=10)
    return SimpleNamespace(
        music=music,
        playback=playback or _StubPlayback(),
        users=SimpleNamespace(get_or_create=_Recorder(user_row)),
        groups=SimpleNamespace(
            get_or_create=_Recorder(group_row),
            sync_member=_Recorder(None),
        ),
        permissions=SimpleNamespace(can=_Recorder(allowed)),
        analytics=SimpleNamespace(track=_Recorder(None)),
        admin=SimpleNamespace(appearance=SimpleNamespace(message=_Recorder("custom text"))),
    )


class _RecordingMessage(FakeMessage):
    """FakeMessage remembering every message it spawns via answer/reply."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.spawned: list[FakeMessage] = []

    async def answer(self, text: str, **kwargs: Any) -> FakeMessage:
        sent = await super().answer(text, **kwargs)
        self.spawned.append(sent)
        return sent


def _group_message(text: str) -> _RecordingMessage:
    message = _RecordingMessage(text=text, chat_type="group", chat_id=-777, user_id=555)
    message.bot = SimpleNamespace()
    return message


@pytest.fixture()
def admin_cache():
    saved = dict(groups_module._ADMIN_CACHE)
    groups_module._ADMIN_CACHE.clear()
    yield groups_module._ADMIN_CACHE
    groups_module._ADMIN_CACHE.clear()
    groups_module._ADMIN_CACHE.update(saved)


def _seed_admin(cache: dict, chat_id: int, user_id: int, is_admin: bool) -> None:
    from time import monotonic

    cache[(chat_id, user_id)] = (monotonic(), is_admin)


# ---------------------------------------------------------------------------
# Status text renderers
# ---------------------------------------------------------------------------
class TestStatusTexts:
    def test_searching_text_escapes_query(self) -> None:
        text = groups_module._searching_text("<script>x & y</script>")
        assert "<script>" not in text
        assert "&lt;script&gt;" in text
        assert "<b>Searching…</b>" in text

    def test_searching_text_truncates_long_query(self) -> None:
        text = groups_module._searching_text("a" * 300)
        assert "a" * 300 not in text
        assert ("Query: " + "a" * 79 + "…") in text

    def test_loading_text_escapes_title_and_artist(self) -> None:
        track = _mk_track(1, title='My <song> & "more"', artist="A & B")
        text = groups_module._loading_text(track)
        assert "<song>" not in text
        assert "&lt;song&gt;" in text
        assert "Loading track…" in text

    def test_loading_text_without_artist_has_no_dangling_dash(self) -> None:
        track = _mk_track(2, artist="")
        text = groups_module._loading_text(track)
        assert not text.rstrip().endswith("—")


# ---------------------------------------------------------------------------
# _edit_or_say fallbacks
# ---------------------------------------------------------------------------
class TestEditOrSay:
    async def test_falls_back_to_say_when_status_is_none(self) -> None:
        message = _group_message("/play x")

        await groups_module._edit_or_say(message, None, "outcome text")

        assert len(message.answered) == 1
        assert message.answered[0][0] == "outcome text"

    async def test_falls_back_to_say_when_edit_fails(self) -> None:
        message = _group_message("/play x")

        class _BrokenStatus:
            async def edit_text(self, *args: Any, **kwargs: Any) -> None:
                raise RuntimeError("message is too old")

        await groups_module._edit_or_say(message, _BrokenStatus(), "outcome text")

        assert len(message.answered) == 1
        assert message.answered[0][0] == "outcome text"

    async def test_edit_used_when_possible(self) -> None:
        message = _group_message("/play x")
        status = _RecordingMessage(text="status", chat_type="group", chat_id=-777)

        await groups_module._edit_or_say(message, status, "outcome text")

        assert message.answered == []  # no duplicate reply
        assert len(status.edited) == 1
        assert status.edited[0][0] == "outcome text"
        assert status.edited[0][1].get("parse_mode") == "HTML"


# ---------------------------------------------------------------------------
# /search — status message lifecycle
# ---------------------------------------------------------------------------
class TestCmdSearchStatusFlow:
    async def test_ack_posted_before_search_then_edited_into_results(
        self,
    ) -> None:
        from app.bot.handlers.groups import cmd_search

        music = _SearchMusic(results=[_mk_track(5), _mk_track(6)])
        message = _group_message("/search hindi")

        await cmd_search(message, SimpleNamespace(args="hindi"), _services(music))

        # 1) exactly one message was posted — the immediate acknowledgement.
        assert len(message.answered) == 1
        ack_text, ack_kwargs = message.answered[0]
        assert "Searching…" in ack_text
        assert "hindi" in ack_text
        assert ack_kwargs.get("parse_mode") == "HTML"
        # The search itself was triggered.
        assert music.calls == [{"query": "hindi", "limit": groups_module.SEARCH_RESULTS_LIMIT}]
        # 2) the same message was edited into the results screen (no second message).
        status = message.spawned[0]
        assert len(message.answered) == 1
        assert len(status.edited) == 1
        result_text, result_kwargs = status.edited[0]
        assert "Results" in result_text
        assert result_kwargs.get("reply_markup") is not None

    async def test_no_results_edits_status(self) -> None:
        from app.bot.handlers.groups import cmd_search

        music = _SearchMusic(results=[])
        message = _group_message("/search zzz")

        await cmd_search(message, SimpleNamespace(args="zzz"), _services(music))

        status = message.spawned[0]
        assert len(status.edited) == 1
        # admin-customizable no-results text won the fallback.
        assert status.edited[0][0] == "custom text"

    async def test_search_error_edits_status_with_user_message(self) -> None:
        from app.bot.handlers.groups import cmd_search

        music = _SearchMusic(error=BotError("boom"))
        message = _group_message("/search zzz")

        await cmd_search(message, SimpleNamespace(args="zzz"), _services(music))

        status = message.spawned[0]
        assert len(status.edited) == 1
        assert status.edited[0][0] == music.error.user_message

    async def test_empty_query_shows_usage_only(self) -> None:
        from app.bot.handlers.groups import USAGE_SEARCH, cmd_search

        music = _SearchMusic()
        message = _group_message("/search")

        await cmd_search(message, SimpleNamespace(args=""), _services(music))

        assert len(message.answered) == 1
        assert message.answered[0][0] == USAGE_SEARCH
        # The usage reply is the whole story — nothing was searched, nothing edited.
        assert music.calls == []
        assert message.spawned[0].edited == []


# ---------------------------------------------------------------------------
# /play — status message lifecycle
# ---------------------------------------------------------------------------
class TestCmdPlayStatusFlow:
    async def test_searching_loading_and_confirmation_share_one_message(
        self, admin_cache
    ) -> None:
        from app.bot.handlers.groups import cmd_play

        _seed_admin(admin_cache, -777, 555, True)
        track = _mk_track(9, title="Hindi Song", artist="Great Artist")
        music = _SearchMusic(results=[track])
        playback = _StubPlayback(size=4, active=True)  # queued behind current
        message = _group_message("/play hindi song")

        await cmd_play(message, SimpleNamespace(args="hindi song"), _services(music, playback=playback))

        # 1) one ack message posted before the provider call.
        assert len(message.answered) == 1
        assert "Searching…" in message.answered[0][0]
        # 2) the controller received the status message as edit_message so
        #    it can turn it into the Now Playing control when playback starts.
        assert len(playback.enqueued) == 1
        call = playback.enqueued[0]
        assert call["track_id"] == 9
        assert call["edit_message"] is message.spawned[0]
        # 3) queued branch: the status message became the confirmation.
        status = message.spawned[0]
        edits = [text for text, _kw in status.edited]
        assert len(edits) == 2
        assert "Loading track…" in edits[0]
        assert "Hindi Song" in edits[0]
        assert "Added to queue" in edits[1]
        assert "#4 in queue" in edits[1]

    async def test_no_results_edits_status(self, admin_cache) -> None:
        from app.bot.handlers.groups import NOT_FOUND_TEXT, cmd_play

        _seed_admin(admin_cache, -777, 555, True)
        music = _SearchMusic(results=[])
        message = _group_message("/play zzz")

        await cmd_play(message, SimpleNamespace(args="zzz"), _services(music))

        status = message.spawned[0]
        assert [text for text, _kw in status.edited] == [NOT_FOUND_TEXT]

    async def test_search_error_edits_status_with_user_message(
        self, admin_cache
    ) -> None:
        from app.bot.handlers.groups import cmd_play

        _seed_admin(admin_cache, -777, 555, True)
        music = _SearchMusic(error=BotError("source down"))
        message = _group_message("/play zzz")

        await cmd_play(message, SimpleNamespace(args="zzz"), _services(music))

        status = message.spawned[0]
        assert [text for text, _kw in status.edited] == [music.error.user_message]

    async def test_enqueue_error_edits_status_after_loading(self, admin_cache) -> None:
        from app.bot.handlers.groups import cmd_play

        _seed_admin(admin_cache, -777, 555, True)
        music = _SearchMusic(results=[_mk_track(3)])
        playback = _StubPlayback(error=BotError("queue exploded"))
        message = _group_message("/play x")

        await cmd_play(message, SimpleNamespace(args="x"), _services(music, playback=playback))

        status = message.spawned[0]
        edits = [text for text, _kw in status.edited]
        assert len(edits) == 2
        assert "Loading track…" in edits[0]
        assert edits[1] == playback.error.user_message

    async def test_empty_query_shows_usage_only(self, admin_cache) -> None:
        from app.bot.handlers.groups import USAGE_PLAY, cmd_play

        music = _SearchMusic()
        _seed_admin(admin_cache, -777, 555, True)
        message = _group_message("/play")

        await cmd_play(message, SimpleNamespace(args=""), _services(music))

        assert len(message.answered) == 1
        assert message.answered[0][0] == USAGE_PLAY
        # The usage reply is the whole story — nothing was searched, nothing edited.
        assert music.calls == []
        assert message.spawned[0].edited == []

    async def test_permission_denied_posts_no_status(self, admin_cache) -> None:
        from app.bot.handlers.groups import PERMISSION_DENIED, cmd_play

        _seed_admin(admin_cache, -777, 555, True)
        music = _SearchMusic(results=[_mk_track(1)])
        message = _group_message("/play x")

        await cmd_play(
            message, SimpleNamespace(args="x"), _services(music, allowed=False)
        )

        # The denial is answered directly — no search was run, no status edits.
        assert len(message.answered) == 1
        assert message.answered[0][0] == PERMISSION_DENIED
        assert music.calls == []
        assert message.spawned[0].edited == []

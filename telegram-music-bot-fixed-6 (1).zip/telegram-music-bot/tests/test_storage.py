"""StorageService tests: sandboxing, CRUD and tmp cleanup (tmp_path based)."""

from __future__ import annotations

import io
import os
import time
from pathlib import Path

import pytest

from app.errors import ValidationError
from app.storage import StorageService


@pytest.fixture
def storage(tmp_path: Path) -> StorageService:
    return StorageService(tmp_path / "storage")


class TestSandbox:
    def test_dotdot_traversal_raises(self, storage: StorageService) -> None:
        with pytest.raises(ValidationError):
            storage.resolve("../../etc/passwd")

    def test_nested_traversal_raises(self, storage: StorageService) -> None:
        with pytest.raises(ValidationError):
            storage.resolve("music/../../secret.txt")

    def test_absolute_path_outside_raises(self, storage: StorageService) -> None:
        with pytest.raises(ValidationError):
            storage.resolve("/etc/passwd")

    def test_symlink_escape_raises(self, storage: StorageService, tmp_path: Path) -> None:
        """A symlink planted inside storage that points outside must not resolve."""
        outside = tmp_path / "outside.txt"
        outside.write_text("secret")
        link = storage.root / "escape"
        link.symlink_to(outside.parent)
        with pytest.raises(ValidationError):
            storage.resolve("escape/outside.txt")

    def test_inner_paths_resolve(self, storage: StorageService) -> None:
        resolved = storage.resolve("music/a/b.mp3")
        assert resolved.is_relative_to(storage.root)


class TestCrud:
    def test_save_bytes_and_get(self, storage: StorageService) -> None:
        target = storage.save("music/track.mp3", b"ID3-body")
        assert target.exists()
        assert storage.get("music/track.mp3") == target
        assert storage.exists("music/track.mp3") is True
        assert storage.size("music/track.mp3") == len(b"ID3-body")

    def test_save_from_path(self, storage: StorageService, tmp_path: Path) -> None:
        src = tmp_path / "src.mp3"
        src.write_bytes(b"12345")
        storage.save("music/copy.mp3", src)
        assert storage.get("music/copy.mp3").read_bytes() == b"12345"

    def test_save_from_file_object(self, storage: StorageService) -> None:
        storage.save("music/stream.bin", io.BytesIO(b"abcde"))
        assert storage.size("music/stream.bin") == 5

    def test_get_missing_returns_none(self, storage: StorageService) -> None:
        assert storage.get("music/nope.mp3") is None
        assert storage.exists("music/nope.mp3") is False

    def test_delete(self, storage: StorageService) -> None:
        storage.save("music/gone.mp3", b"x")
        assert storage.delete("music/gone.mp3") is True
        assert storage.exists("music/gone.mp3") is False
        assert storage.delete("music/gone.mp3") is False  # already gone

    def test_exists_swallows_traversal(self, storage: StorageService) -> None:
        """exists() must not raise on hostile input (it returns False)."""
        assert storage.exists("../etc/passwd") is False

    def test_parent_directories_auto_created(self, storage: StorageService) -> None:
        storage.save("downloads/2024/01/a.mp3", b"x")
        assert (storage.root / "downloads" / "2024" / "01" / "a.mp3").exists()


class TestDomainDirs:
    def test_dirs_created_once(self, storage: StorageService) -> None:
        for name in (storage.music_dir(), storage.tmp_dir(),
                     storage.downloads_dir(), storage.artwork_dir()):
            assert name.is_dir()
            assert name.is_relative_to(storage.root)


class TestUniqueName:
    def test_sanitized_and_unique(self, storage: StorageService) -> None:
        first = storage.unique_name("..\\..\\evil name.mp3", prefix="up-")
        second = storage.unique_name("../../evil name.mp3", prefix="up-")
        assert first != second
        assert first.startswith("up-")
        assert ".." not in first and "/" not in first and "\\" not in first
        assert first.endswith("evil name.mp3")


class TestCleanupTmp:
    def test_removes_old_keeps_fresh(self, storage: StorageService) -> None:
        old = storage.save("tmp/old.mp3", b"old")
        fresh = storage.save("tmp/fresh.mp3", b"fresh")
        # Age the old file far beyond the cutoff.
        aged = time.time() - 7200
        os.utime(old, (aged, aged))

        removed = storage.cleanup_tmp(max_age_seconds=3600)
        assert removed == 1
        assert old.exists() is False
        assert fresh.exists() is True

    def test_noop_when_nothing_stale(self, storage: StorageService) -> None:
        storage.save("tmp/fresh.mp3", b"x")
        assert storage.cleanup_tmp(max_age_seconds=3600) == 0

    def test_only_files_in_tmp_touched(self, storage: StorageService) -> None:
        music = storage.save("music/keep.mp3", b"x")
        aged = time.time() - 7200
        os.utime(music, (aged, aged))
        storage.cleanup_tmp(max_age_seconds=3600)
        assert music.exists() is True

"""Shared pytest fixtures for the Telegram Music Bot test suite.

Design rules (task 4-a):

* Tests NEVER need a real BOT_TOKEN, Telegram, Telethon, Redis or network:
  every database is an in-memory SQLite (function-scoped, StaticPool), every
  Telegram object is a lightweight fake.
* ``os.environ`` defaults are forced at import time — BEFORE any ``app.*``
  import — because the sandbox may carry a Prisma-style ``DATABASE_URL``.
* ``db_setup`` seeds a small deterministic catalog; ``services`` builds the
  real repository + service layer (no Telegram needed).
"""

from __future__ import annotations

import os
from types import SimpleNamespace
from typing import Any

# ---------------------------------------------------------------------------
# Environment bootstrap — runs BEFORE any app import (pytest imports this
# conftest before test modules). Keeps tests hermetic.
# ---------------------------------------------------------------------------
os.environ["BOT_TOKEN"] = "123456789:" + "A" * 33
os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
os.environ.pop("REDIS_URL", None)
os.environ.pop("TELEGRAM_API_ID", None)
os.environ.pop("TELEGRAM_API_HASH", None)
os.environ.pop("VOICE_SESSION_ENCRYPTION_KEY", None)
os.environ.pop("ADMIN_IDS", None)

import pytest  # noqa: E402
from sqlalchemy.ext.asyncio import (  # noqa: E402
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import StaticPool  # noqa: E402

from app.cache.redis import MemoryCache, RateLimiter  # noqa: E402
from app.database import models  # noqa: E402,F401  (populate Base.metadata)
from app.database.base import Base  # noqa: E402
from app.database.models import (  # noqa: E402
    Album,
    Artist,
    Genre,
    Track,
)
from app.database.repositories.analytics import AnalyticsRepository  # noqa: E402
from app.database.repositories.groups import (  # noqa: E402
    GroupMemberRepository,
    GroupRepository,
    GroupSettingsRepository,
)
from app.database.repositories.library import (  # noqa: E402
    LikedTrackRepository,
    ListeningHistoryRepository,
)
from app.database.repositories.music import (  # noqa: E402
    AlbumRepository,
    ArtistRepository,
    GenreRepository,
    TrackRepository,
)
from app.database.repositories.playback import (  # noqa: E402
    PlaybackSessionRepository,
    QueueRepository,
)
from app.database.repositories.playlists import PlaylistRepository  # noqa: E402
from app.database.repositories.settings import (  # noqa: E402
    BotButtonRepository,
    BotSettingsRepository,
)
from app.database.repositories.users import (  # noqa: E402
    SearchHistoryRepository,
    UserPreferenceRepository,
    UserRepository,
)
from app.groups.permissions import GroupPermissions  # noqa: E402
from app.groups.service import GroupService  # noqa: E402
from app.groups.settings import GroupSettingsService  # noqa: E402
from app.music.normalizer import normalize_text  # noqa: E402
from app.playback.autoplay import AutoplayService  # noqa: E402
from app.playback.events import EventBus  # noqa: E402
from app.playback.queue import QueueManager  # noqa: E402
from app.playback.session import SessionManager  # noqa: E402
from app.recommendation.engine import RecommendationEngine  # noqa: E402
from app.recommendation.profile import ProfileBuilder  # noqa: E402
from app.users.history import HistoryService  # noqa: E402
from app.users.library import LibraryService  # noqa: E402
from app.users.playlists import PlaylistService  # noqa: E402
from app.users.service import UserService  # noqa: E402
from app.users.stats import UserStatsService  # noqa: E402


# ---------------------------------------------------------------------------
# Telegram fakes (SimpleNamespace-based, with async recording methods)
# ---------------------------------------------------------------------------
class FakeMessage:
    """Duck-typed aiogram ``Message`` recording answer/edit/delete calls."""

    def __init__(
        self,
        *,
        text: str | None = None,
        caption: str | None = None,
        chat_id: int = 101,
        chat_type: str = "private",
        user_id: int = 101,
        username: str = "alice",
        first_name: str = "Alice",
        entities: list | None = None,
        caption_entities: list | None = None,
        reply_to_message: Any = None,
        message_id: int = 42,
        photo: list | None = None,
        video: Any = None,
        sticker: Any = None,
        audio: Any = None,
        document: Any = None,
        animation: Any = None,
        voice: Any = None,
        **extra: Any,
    ) -> None:
        self.message_id = message_id
        self.text = text
        self.caption = caption
        self.entities = entities
        self.caption_entities = caption_entities
        self.reply_to_message = reply_to_message
        self.photo = photo
        self.video = video
        self.sticker = sticker
        self.audio = audio
        self.document = document
        self.animation = animation
        self.voice = voice
        self.chat = SimpleNamespace(
            id=chat_id,
            type=chat_type,
            title=None if chat_type == "private" else "Test Chat",
        )
        self.from_user = SimpleNamespace(
            id=user_id,
            username=username,
            first_name=first_name,
            language_code="en",
            is_bot=False,
        )
        self.answered: list[tuple[str, dict]] = []
        self.edited: list[tuple[str, dict]] = []
        self.deleted_count = 0
        self.sent_audio: list[tuple[Any, dict]] = []
        self.sent_messages: list[tuple[str, dict]] = []
        self.delete_message_calls = 0
        for key, value in extra.items():
            setattr(self, key, value)

    async def answer(self, text: str, **kwargs: Any) -> "FakeMessage":
        self.answered.append((text, kwargs))
        return FakeMessage(
            text=text,
            chat_id=self.chat.id,
            chat_type=self.chat.type,
            user_id=self.from_user.id,
            message_id=self.message_id + 1,
        )

    async def answer_photo(self, photo: Any, caption: str | None = None, **kw: Any) -> "FakeMessage":
        self.answered.append((f"<photo> {caption or ''}", kw))
        return FakeMessage(chat_id=self.chat.id, chat_type=self.chat.type, user_id=self.from_user.id)

    async def send_message(self, text: str, **kwargs: Any) -> "FakeMessage":
        """Bot-style send recorder (message as chat handle)."""
        self.sent_messages.append((text, kwargs))
        return FakeMessage(
            text=text,
            chat_id=self.chat.id,
            chat_type=self.chat.type,
            user_id=self.from_user.id,
            message_id=self.message_id + 1,
        )

    async def send_audio(
        self, audio: Any, caption: str | None = None, **kwargs: Any
    ) -> "FakeMessage":
        """Bot-style send_audio recorder — returns a message carrying a file id."""
        file_id = getattr(audio, "file_id", None) or (audio if isinstance(audio, str) else "audio-file-id")
        self.sent_audio.append((audio, {**{"caption": caption}, **kwargs}))
        sent = FakeMessage(
            chat_id=self.chat.id,
            chat_type=self.chat.type,
            user_id=self.from_user.id,
            message_id=self.message_id + 1,
        )
        sent.audio = SimpleNamespace(file_id=file_id)
        return sent

    async def edit_text(self, text: str, **kwargs: Any) -> "FakeMessage":
        self.edited.append((text, kwargs))
        return self

    async def delete(self) -> bool:
        self.deleted_count += 1
        return True

    async def delete_message(self) -> bool:
        """Alias recorder (some code paths use Telegram's delete_message API)."""
        self.delete_message_calls += 1
        self.deleted_count += 1
        return True

    async def reply(self, text: str, **kwargs: Any) -> "FakeMessage":
        return await self.answer(text, **kwargs)


class FakeCallback:
    """Duck-typed aiogram ``CallbackQuery`` recording answer/edit calls."""

    def __init__(
        self,
        data: str,
        *,
        user_id: int = 101,
        chat_id: int = 101,
        chat_type: str = "private",
        message: FakeMessage | None = None,
        username: str = "alice",
        first_name: str = "Alice",
    ) -> None:
        self.id = "cb-1"
        self.data = data
        self.from_user = SimpleNamespace(
            id=user_id,
            username=username,
            first_name=first_name,
            language_code="en",
            is_bot=False,
        )
        self.message = message or FakeMessage(
            chat_id=chat_id, chat_type=chat_type, user_id=user_id
        )
        self.answers: list[tuple[str | None, bool]] = []
        self.edits: list[str] = []

    @property
    def chat(self) -> SimpleNamespace:
        return self.message.chat

    async def answer(
        self, text: str | None = None, show_alert: bool = False, **kwargs: Any
    ) -> bool:
        self.answers.append((text, show_alert))
        return True

    async def edit_text(self, text: str, **kwargs: Any) -> FakeMessage:
        self.edits.append(text)
        return self.message


def entity(entity_type: str) -> SimpleNamespace:
    """A minimal Telegram message-entity fake."""
    return SimpleNamespace(type=entity_type, offset=0, length=1)


@pytest.fixture
def fake_message() -> type[FakeMessage]:
    """Factory fixture — ``fake_message(text="/play ...")`` returns a fake."""
    return FakeMessage


@pytest.fixture
def fake_callback() -> type[FakeCallback]:
    """Factory fixture — ``fake_callback("np:pause")`` returns a fake."""
    return FakeCallback


# ---------------------------------------------------------------------------
# Database fixtures (function-scoped, isolated)
# ---------------------------------------------------------------------------
@pytest.fixture
async def engine() -> AsyncEngine:
    """A fresh in-memory SQLite engine (StaticPool — one shared connection)."""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )
    try:
        yield engine
    finally:
        await engine.dispose()


@pytest.fixture
async def mk_sessions(engine: AsyncEngine) -> async_sessionmaker[AsyncSession]:
    """Session factory bound to the test engine."""
    return async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


@pytest.fixture
async def db_setup(
    engine: AsyncEngine, mk_sessions: async_sessionmaker[AsyncSession]
) -> SimpleNamespace:
    """Create all tables and seed a small deterministic catalog.

    Seeded content: 1 artist, 1 album, 3 genres, 8 tracks (varied popularity,
    tempo, genre), users 101/102 (with preferences), group -100999 (with
    settings) and the default bot settings + dashboard buttons.
    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with mk_sessions() as session:
        async with session.begin():
            artist = Artist(
                name="Test Artist", normalized_name=normalize_text("Test Artist")
            )
            album = Album(
                title="Test Album",
                normalized_title=normalize_text("Test Album"),
                artist=artist,
            )
            genres = {
                name: Genre(name=name, normalized_name=name)
                for name in ("synthwave", "electronic", "ambient")
            }
            # (title, genre, popularity, tempo, duration)
            track_specs = [
                ("Neon Sunrise", "synthwave", 80, 120, 30),
                ("Retro Sunrise", "synthwave", 10, 118, 31),
                ("Popular Anthem", "electronic", 95, 128, 32),
                ("Velvet Night", "synthwave", 30, 90, 33),
                ("Circuit Breaker", "electronic", 45, 140, 34),
                ("Rainy Digits", "ambient", 20, 85, 35),
                ("Crystal Meadow", "ambient", 55, 92, 36),
                ("Static Bloom", "electronic", 60, 132, 37),
            ]
            tracks: list[Track] = []
            for index, (title, genre_name, popularity, tempo, duration) in enumerate(
                track_specs, start=1
            ):
                track = Track(
                    title=title,
                    normalized_title=normalize_text(title),
                    artist=artist,
                    album=album,
                    duration_seconds=duration,
                    tempo=tempo,
                    popularity=popularity,
                    source="local",
                    source_id=f"test-{index}",
                    is_playable=True,
                )
                track.genres.append(genres[genre_name])
                tracks.append(track)
            session.add_all([artist, album, *genres.values(), *tracks])

    users = UserRepository(mk_sessions)
    user_101 = await users.get_or_create(101, username="alice", first_name="Alice")
    user_102 = await users.get_or_create(102, username="bob", first_name="Bob")

    groups = GroupRepository(mk_sessions)
    group = await groups.get_or_create(-100999, title="Test Group")

    settings_repo = BotSettingsRepository(mk_sessions)
    await settings_repo.ensure_defaults()
    await BotButtonRepository(mk_sessions).ensure_defaults()

    return SimpleNamespace(
        artist=artist,
        artist_id=int(artist.id),
        album=album,
        album_id=int(album.id),
        genres=genres,
        genre_ids={name: int(genre.id) for name, genre in genres.items()},
        tracks=tracks,
        track_ids=[int(track.id) for track in tracks],
        track_ids_by_title={track.title: int(track.id) for track in tracks},
        track_by_id={int(track.id): track for track in tracks},
        user_101=int(user_101.id),
        user_102=int(user_102.id),
        tg_101=101,
        tg_102=102,
        group=group,
        group_db_id=int(group.id),
        group_tg_id=-100999,
    )


# ---------------------------------------------------------------------------
# Service bundle (real repositories + services, no Telegram required)
# ---------------------------------------------------------------------------
def build_services(
    mk_sessions: async_sessionmaker[AsyncSession],
    *,
    autoplay_enabled: bool = True,
) -> SimpleNamespace:
    """Assemble the real DB-backed service layer used by the tests."""
    events = EventBus()
    cache = MemoryCache()

    users_repo = UserRepository(mk_sessions)
    prefs_repo = UserPreferenceRepository(mk_sessions)
    search_repo = SearchHistoryRepository(mk_sessions)
    liked_repo = LikedTrackRepository(mk_sessions)
    history_repo = ListeningHistoryRepository(mk_sessions)
    playlists_repo = PlaylistRepository(mk_sessions)
    groups_repo = GroupRepository(mk_sessions)
    members_repo = GroupMemberRepository(mk_sessions)
    group_settings_repo = GroupSettingsRepository(mk_sessions)
    analytics_repo = AnalyticsRepository(mk_sessions)
    queue_repo = QueueRepository(mk_sessions)
    sessions_repo = PlaybackSessionRepository(mk_sessions)
    tracks_repo = TrackRepository(mk_sessions)
    artists_repo = ArtistRepository(mk_sessions)
    albums_repo = AlbumRepository(mk_sessions)
    genres_repo = GenreRepository(mk_sessions)
    settings_repo = BotSettingsRepository(mk_sessions)

    profiles = ProfileBuilder(history_repo, liked_repo, tracks=tracks_repo)
    reco_engine = RecommendationEngine(tracks_repo, profiles, settings_repo, cache)

    async def _autoplay_flag() -> bool:
        return autoplay_enabled

    autoplay = AutoplayService(
        reco_engine,
        QueueManager(queue_repo, tracks_repo, events),
        analytics_repo,
        default_enabled=autoplay_enabled,
        enabled_check=_autoplay_flag,
    )

    return SimpleNamespace(
        events=events,
        cache=cache,
        limiter=RateLimiter(cache),
        users_repo=users_repo,
        prefs_repo=prefs_repo,
        search_repo=search_repo,
        liked_repo=liked_repo,
        history_repo=history_repo,
        playlists_repo=playlists_repo,
        groups_repo=groups_repo,
        members_repo=members_repo,
        group_settings_repo=group_settings_repo,
        analytics_repo=analytics_repo,
        queue_repo=queue_repo,
        sessions_repo=sessions_repo,
        tracks_repo=tracks_repo,
        artists_repo=artists_repo,
        albums_repo=albums_repo,
        genres_repo=genres_repo,
        settings_repo=settings_repo,
        users=UserService(users_repo, prefs_repo, members_repo, groups_repo),
        library=LibraryService(liked_repo, tracks_repo, users_repo, history_repo),
        history_service=HistoryService(
            history_repo, users_repo, search_repo, analytics_repo
        ),
        playlists_service=PlaylistService(playlists_repo),
        stats=UserStatsService(
            history_repo, liked_repo, tracks_repo, artists_repo, users_repo
        ),
        groups_service=GroupService(groups_repo, members_repo),
        group_settings_service=GroupSettingsService(group_settings_repo),
        permissions=GroupPermissions(group_settings_repo, members_repo),
        queue=QueueManager(queue_repo, tracks_repo, events),
        sessions_manager=SessionManager(sessions_repo, tracks_repo, events),
        profiles=profiles,
        reco_engine=reco_engine,
        autoplay=autoplay,
    )


@pytest.fixture
async def services(
    db_setup: SimpleNamespace, mk_sessions: async_sessionmaker[AsyncSession]
) -> SimpleNamespace:
    """The real service bundle on the seeded in-memory database."""
    return build_services(mk_sessions)

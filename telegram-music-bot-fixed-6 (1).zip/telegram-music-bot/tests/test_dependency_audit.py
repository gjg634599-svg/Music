"""Dependency & runtime compatibility audit tests.

Verifies that the *installed* optional voice-engine dependencies actually
match the APIs the project's transport layer calls — the py-tgcalls 1.x
pin previously resolved to a library whose API (``join_group_call`` /
``pause_stream`` / ...) never matched :class:`NativeTransport`
(``play`` / ``pause`` / ``resume`` / ``leave_call``), and whose unbounded
``ntgcalls`` requirement silently broke against ntgcalls 3.x.
"""

from __future__ import annotations

import importlib.metadata as md

import pytest

from app.voice import transport as voice_transport


class TestVoiceDependencyCompatibility:
    def test_py_tgcalls_pin_is_bounded(self) -> None:
        """requirements.txt must pin the py-tgcalls 2.x API line."""
        requirements = _read_requirements()
        pins = [
            line
            for line in requirements
            if line.strip().startswith("py-tgcalls")
        ]
        assert pins, "py-tgcalls requirement missing"
        pin = pins[0]
        assert ">=2.2" in pin and "<3" in pin, (
            f"py-tgcalls pin must select the 2.x API line, got: {pin!r}"
        )

    def test_installed_py_tgcalls_matches_transport_api(self) -> None:
        """When py-tgcalls is installed, every method NativeTransport calls
        must exist on the PyTgCalls class (or be explicitly optional)."""
        try:
            from pytgcalls import PyTgCalls
        except Exception:  # pragma: no cover — optional dependency
            pytest.skip("py-tgcalls not installed in this environment")

        methods = set()
        for cls in PyTgCalls.__mro__:
            methods.update(m for m in dir(cls) if not m.startswith("_"))
        # Hard requirements of NativeTransport.
        for name in ("start", "play", "pause", "resume", "leave_call"):
            assert name in methods, (
                f"installed py-tgcalls lacks .{name}() — API mismatch with "
                "app/voice/transport.py"
            )
        # Volume is optional by design (set_volume OR change_volume_call).
        assert "set_volume" in methods or "change_volume_call" in methods

    def test_installed_py_tgcalls_pins_compatible_ntgcalls(self) -> None:
        """The installed py-tgcalls must declare a bounded ntgcalls range."""
        try:
            requires = md.requires("py-tgcalls") or []
        except md.PackageNotFoundError:  # pragma: no cover — optional dep
            pytest.skip("py-tgcalls not installed in this environment")
        ntgcalls_requirements = [r for r in requires if r.startswith("ntgcalls")]
        assert ntgcalls_requirements, (
            "py-tgcalls does not declare an ntgcalls requirement"
        )
        # The declared range must exclude the incompatible 3.x line
        # (py-tgcalls 1.2.9's unbounded spec is what broke the engine).
        spec = ntgcalls_requirements[0]
        assert "<" in spec, f"ntgcalls requirement is unbounded: {spec!r}"

    def test_transport_module_importable(self) -> None:
        """The guarded import never breaks the module itself."""
        assert hasattr(voice_transport, "NativeTransport")
        assert isinstance(voice_transport.PYTGCALLS_AVAILABLE, bool)

    def test_telethon_version_compatible(self) -> None:
        """Telethon 1.45+ provides the sign_in/password API the login uses."""
        try:
            import telethon
        except Exception:  # pragma: no cover — optional dependency
            pytest.skip("telethon not installed in this environment")
        version = tuple(
            int(part)
            for part in telethon.__version__.split(".")[:2]
        )
        assert version >= (1, 36), (
            f"telethon {telethon.__version__} is below the tested 1.36+ line"
        )


def _read_requirements() -> list[str]:
    from pathlib import Path

    path = Path(__file__).resolve().parent.parent / "requirements.txt"
    return path.read_text(encoding="utf-8").splitlines()

"""Security validation tests: URL SSRF checks, filenames, uploads, callbacks.

The DNS layer is faked via ``monkeypatch`` on :func:`socket.getaddrinfo` —
these tests never touch the network.
"""

from __future__ import annotations

import socket

import pytest

from app.errors import UnsupportedUrlError, ValidationError
from app.security.validation import (
    MAX_CALLBACK_LENGTH,
    is_direct_audio_url,
    sanitize_filename,
    validate_audio_upload,
    validate_callback_data,
    validate_url,
)


def _fake_getaddrinfo(ip: str):
    """A getaddrinfo replacement resolving every host to *ip*."""

    def resolver(host, *args, **kwargs):  # noqa: ANN002,ANN003,ARG001
        return [
            (
                socket.AF_INET,  # family
                socket.SOCK_STREAM,  # type
                socket.IPPROTO_TCP,  # proto
                "",  # canonname
                (ip, 0),  # sockaddr
            )
        ]

    return resolver


# ---------------------------------------------------------------------------
# validate_url — scheme and shape
# ---------------------------------------------------------------------------
class TestUrlScheme:
    def test_javascript_scheme_rejected(self) -> None:
        with pytest.raises(UnsupportedUrlError, match="[Ss]cheme"):
            validate_url("javascript:alert(1)")

    def test_data_scheme_rejected(self) -> None:
        with pytest.raises(UnsupportedUrlError):
            validate_url("data:text/html,hello")

    def test_ftp_scheme_rejected(self) -> None:
        with pytest.raises(UnsupportedUrlError):
            validate_url("ftp://files.example.com/song.mp3")

    def test_file_scheme_rejected(self) -> None:
        with pytest.raises(UnsupportedUrlError):
            validate_url("file:///etc/passwd")

    def test_empty_url_rejected(self) -> None:
        with pytest.raises(UnsupportedUrlError):
            validate_url("")
        with pytest.raises(UnsupportedUrlError):
            validate_url("   ")

    def test_oversized_url_rejected(self) -> None:
        huge = "https://example.com/" + "a" * 1200
        assert len(huge) > 1024
        with pytest.raises(UnsupportedUrlError, match="long"):
            validate_url(huge)

    def test_no_hostname_rejected(self) -> None:
        with pytest.raises(UnsupportedUrlError, match="hostname"):
            validate_url("https:///just/a/path")

    def test_credentials_in_url_rejected(self) -> None:
        with pytest.raises(UnsupportedUrlError, match="[Cc]redentials"):
            validate_url("https://user:pass@example.com/song.mp3")


# ---------------------------------------------------------------------------
# validate_url — SSRF protection (faked DNS)
# ---------------------------------------------------------------------------
class TestUrlSsrf:
    def test_public_host_allowed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        url = validate_url("https://music.example.com/track.mp3")
        assert url == "https://music.example.com/track.mp3"

    def test_private_10_host_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("10.0.0.5"))
        with pytest.raises(ValidationError, match="[Pp]rivate"):
            validate_url("https://intranet.example.com/secret.mp3")

    def test_loopback_127_host_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("127.0.0.1"))
        with pytest.raises(ValidationError, match="[Pp]rivate"):
            validate_url("https://loopback.example.com/x.mp3")

    def test_192_168_host_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("192.168.1.10"))
        with pytest.raises(ValidationError):
            validate_url("https://router.example.com/x.mp3")

    def test_localhost_rejected_without_dns(self) -> None:
        """``localhost`` is rejected by name before any DNS lookup."""
        with pytest.raises(ValidationError, match="[Ll]ocal"):
            validate_url("http://localhost:8080/admin")

    def test_localhost_localdomain_rejected(self) -> None:
        with pytest.raises(ValidationError):
            validate_url("http://localhost.localdomain/x")

    def test_direct_private_ip_rejected(self) -> None:
        for ip in ("127.0.0.1", "10.1.2.3", "192.168.0.1", "172.16.5.4", "169.254.1.1"):
            with pytest.raises(ValidationError):
                validate_url(f"http://{ip}/stream.mp3")

    def test_direct_public_ip_allowed(self) -> None:
        assert validate_url("http://8.8.8.8/stream.mp3") == "http://8.8.8.8/stream.mp3"

    def test_ipv6_loopback_rejected(self) -> None:
        with pytest.raises(ValidationError):
            validate_url("http://[::1]/x.mp3")

    def test_unresolvable_host_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        def boom(host, *args, **kwargs):  # noqa: ANN002,ANN003,ARG001
            raise OSError("name resolution failed")

        monkeypatch.setattr(socket, "getaddrinfo", boom)
        with pytest.raises(ValidationError, match="[Rr]esolve"):
            validate_url("https://nonexistent.invalid/song.mp3")

    def test_allow_private_opt_in(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Local development may explicitly allow private addresses."""
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("10.0.0.5"))
        url = validate_url("http://10.0.0.5:8000/x.mp3", allow_private=True)
        assert url == "http://10.0.0.5:8000/x.mp3"


# ---------------------------------------------------------------------------
# is_direct_audio_url
# ---------------------------------------------------------------------------
class TestDirectAudioUrl:
    def test_audio_extensions_recognized(self) -> None:
        for ext in (".mp3", ".m4a", ".ogg", ".opus", ".flac", ".wav"):
            assert is_direct_audio_url(f"https://cdn.example.com/a/b/track{ext}") is True

    def test_extension_case_insensitive(self) -> None:
        assert is_direct_audio_url("https://x.example.com/SONG.MP3") is True

    def test_query_string_after_extension(self) -> None:
        assert is_direct_audio_url("https://x.example.com/a.mp3?token=abc") is True

    def test_page_url_not_direct(self) -> None:
        assert is_direct_audio_url("https://x.example.com/track/12345") is False

    def test_html_url_not_direct(self) -> None:
        assert is_direct_audio_url("https://x.example.com/watch?v=abc") is False


# ---------------------------------------------------------------------------
# resolve_direct_audio — regression for the production NameError
# (log 2026-10-11 07:57:36: bot.link_resolve_failed error="name
#  'UnsupportedUrlError' is not defined" — the symbol was used in
#  url_resolver.py but never imported, so every non-direct-audio link
#  leaked a NameError instead of the user-facing BotError)
# ---------------------------------------------------------------------------
class TestResolveDirectAudioErrors:
    """Non-audio URLs must raise UnsupportedUrlError — never a NameError."""

    @staticmethod
    def _settings():
        class _Settings:
            http_timeout = 5
            max_audio_size_mb = 45

        return _Settings()

    async def test_page_url_raises_unsupported_not_nameerror(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.music.sources.url_resolver import resolve_direct_audio

        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        # Pre-fix this raised NameError (missing import) — pytest.raises would
        # then fail loudly with the NameError, locking the regression.
        with pytest.raises(UnsupportedUrlError, match="[Dd]irect audio"):
            await resolve_direct_audio(
                "https://audius.co/track/some-page", self._settings(), None, None
            )

    async def test_stream_url_without_extension_raises_unsupported(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.music.sources.url_resolver import resolve_direct_audio

        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        with pytest.raises(UnsupportedUrlError):
            await resolve_direct_audio(
                "https://api.audius.co/v1/tracks/abc/stream", self._settings(), None, None
            )

    def test_error_symbols_are_imported(self) -> None:
        """AST guard: every BotError name used in url_resolver must be imported.

        Protects against reintroducing use-without-import regressions for any
        of the error classes this module is documented to raise.
        """
        import ast
        import inspect

        from app.music.sources import url_resolver

        tree = ast.parse(inspect.getsource(url_resolver))
        imported: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                imported.update(a.asname or a.name for a in node.names)
            elif isinstance(node, ast.Import):
                imported.update((a.asname or a.name).split(".")[0] for a in node.names)
        error_names = {
            "UnsupportedUrlError",
            "UnauthorizedSourceError",
            "DownloadError",
            "FileTooLargeError",
            "ValidationError",
        }
        used = {
            n.id
            for n in ast.walk(tree)
            if isinstance(n, ast.Name)
            and isinstance(n.ctx, ast.Load)
            and n.id in error_names
        }
        missing = used - imported
        assert not missing, f"used but not imported in url_resolver: {missing}"


# ---------------------------------------------------------------------------
# sanitize_filename
# ---------------------------------------------------------------------------
class TestSanitizeFilename:
    def test_traversal_is_flattened(self) -> None:
        safe = sanitize_filename("../../etc/passwd")
        assert safe == "passwd"
        assert "/" not in safe and ".." not in safe

    def test_windows_traversal_is_flattened(self) -> None:
        safe = sanitize_filename("..\\..\\Windows\\system32\\evil.dll")
        assert safe == "evil.dll"
        assert "\\" not in safe and "/" not in safe

    def test_control_and_special_characters_replaced(self) -> None:
        # Consecutive specials collapse into a single underscore ([...]+).
        safe = sanitize_filename("my song: <beat>?.mp3")
        assert safe == "my song_ _beat_.mp3"

    def test_empty_falls_back(self) -> None:
        assert sanitize_filename("") == "audio"
        assert sanitize_filename(None) == "audio"

    def test_only_dots_falls_back(self) -> None:
        assert sanitize_filename("..") == "audio"

    def test_length_capped(self) -> None:
        assert len(sanitize_filename("x" * 500, max_length=64)) <= 64


# ---------------------------------------------------------------------------
# validate_audio_upload
# ---------------------------------------------------------------------------
class TestAudioUploadValidation:
    def test_valid_upload_passes(self) -> None:
        validate_audio_upload(
            mime_type="audio/mpeg",
            file_name="song.mp3",
            size=5 * 1024 * 1024,
            max_size_bytes=45 * 1024 * 1024,
        )

    def test_no_extension_no_mime_passes(self) -> None:
        validate_audio_upload(
            mime_type=None, file_name=None, size=1024, max_size_bytes=45 * 1024 * 1024
        )

    def test_size_cap_enforced(self) -> None:
        cap = 45 * 1024 * 1024
        with pytest.raises(ValidationError, match="large"):
            validate_audio_upload(
                mime_type="audio/mpeg",
                file_name="song.mp3",
                size=cap + 1,
                max_size_bytes=cap,
            )

    def test_empty_file_rejected(self) -> None:
        with pytest.raises(ValidationError):
            validate_audio_upload(
                mime_type="audio/mpeg", file_name="song.mp3", size=0, max_size_bytes=1000
            )

    def test_bad_extension_rejected(self) -> None:
        with pytest.raises(ValidationError, match="format"):
            validate_audio_upload(
                mime_type="application/octet-stream",
                file_name="setup.exe",
                size=1024,
                max_size_bytes=10_000_000,
            )

    def test_non_audio_mime_rejected(self) -> None:
        with pytest.raises(ValidationError):
            validate_audio_upload(
                mime_type="application/zip",
                file_name=None,
                size=1024,
                max_size_bytes=10_000_000,
            )

    def test_any_audio_mime_namespace_accepted(self) -> None:
        validate_audio_upload(
            mime_type="audio/x-fancy-new-codec",
            file_name=None,
            size=1024,
            max_size_bytes=10_000_000,
        )


# ---------------------------------------------------------------------------
# validate_callback_data
# ---------------------------------------------------------------------------
class TestCallbackDataValidation:
    def test_registry_patterns_valid(self) -> None:
        for data in (
            "nav:home",
            "trk:play:42",
            "q:rm:17",
            "pl:trk:3:9",
            "adm:bc:hist:2",
            "grp:set:volume:50",
            "np:pause",
            "lib:liked:3",
            "set:autoplay",
        ):
            assert validate_callback_data(data) == data

    def test_empty_rejected(self) -> None:
        with pytest.raises(ValidationError, match="[Ee]mpty"):
            validate_callback_data("")
        with pytest.raises(ValidationError):
            validate_callback_data(None)

    def test_malformed_rejected(self) -> None:
        for bad in (
            "trk:",  # empty segment
            "TRK:play:1",  # uppercase prefix
            "trk:play:1:",  # trailing colon
            "trk:play:1:2:3:4:5",  # too many segments
            "no spaces allowed",
            "cmd<>injection",
        ):
            with pytest.raises(ValidationError, match="[Mm]alformed"):
                validate_callback_data(bad)

    def test_too_long_rejected(self) -> None:
        long_data = "trk:play:" + "1" * 64
        assert len(long_data) > MAX_CALLBACK_LENGTH
        with pytest.raises(ValidationError, match="long"):
            validate_callback_data(long_data)


# ---------------------------------------------------------------------------
# Redirect safety — every redirect destination is re-validated (SSRF)
# ---------------------------------------------------------------------------
class TestRedirectSafety:
    """follow_redirects_safely must re-validate EVERY hop."""

    async def test_no_redirect_returns_url(self) -> None:
        from app.music.sources.url_resolver import follow_redirects_safely

        http = _FakeSession([_FakeResponse(200)])
        final = await follow_redirects_safely(
            "https://cdn.example.com/song.mp3", http, _timeout()
        )
        assert final == "https://cdn.example.com/song.mp3"
        assert len(http.requests) == 1

    async def test_single_valid_redirect_followed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.music.sources.url_resolver import follow_redirects_safely

        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        http = _FakeSession(
            [
                _FakeResponse(302, headers={"Location": "https://media.example.com/file.mp3"}),
                _FakeResponse(200),
            ]
        )
        final = await follow_redirects_safely(
            "https://cdn.example.com/song.mp3", http, _timeout()
        )
        assert final == "https://media.example.com/file.mp3"
        assert http.requests[1].endswith("media.example.com/file.mp3")

    async def test_redirect_to_private_host_rejected(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A public redirector bouncing to 169.254.169.254 must be blocked."""
        from app.music.sources.url_resolver import follow_redirects_safely

        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        http = _FakeSession(
            [
                _FakeResponse(302, headers={"Location": "http://169.254.169.254/latest/meta-data"}),
            ]
        )
        from app.errors import DownloadError

        with pytest.raises(ValidationError):
            await follow_redirects_safely(
                "https://redirector.example.com/song.mp3", http, _timeout()
            )
        # The private URL was never requested.
        assert all("169.254" not in url for url in http.requests)

    async def test_redirect_to_localhost_name_rejected(self) -> None:
        from app.music.sources.url_resolver import follow_redirects_safely

        http = _FakeSession(
            [_FakeResponse(302, headers={"Location": "http://localhost:8080/secret"})]
        )
        with pytest.raises(ValidationError):
            await follow_redirects_safely(
                "https://redirector.example.com/song.mp3", http, _timeout()
            )

    async def test_redirect_chain_each_hop_validated(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.music.sources.url_resolver import follow_redirects_safely

        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        http = _FakeSession(
            [
                _FakeResponse(302, headers={"Location": "https://a.example.com/1.mp3"}),
                _FakeResponse(302, headers={"Location": "https://b.example.com/2.mp3"}),
                _FakeResponse(200),
            ]
        )
        final = await follow_redirects_safely(
            "https://origin.example.com/song.mp3", http, _timeout()
        )
        assert final == "https://b.example.com/2.mp3"
        assert len(http.requests) == 3

    async def test_too_many_redirects_rejected(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.errors import DownloadError
        from app.music.sources.url_resolver import follow_redirects_safely

        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        # A redirect loop public → public, more than the allowed hops.
        responses = [
            _FakeResponse(302, headers={"Location": f"https://hop{i}.example.com/x.mp3"})
            for i in range(10)
        ]
        http = _FakeSession(responses)
        with pytest.raises(DownloadError, match="[Rr]edirect"):
            await follow_redirects_safely(
                "https://origin.example.com/song.mp3", http, _timeout(), max_redirects=3
            )

    async def test_redirect_without_location_rejected(self) -> None:
        from app.errors import DownloadError
        from app.music.sources.url_resolver import follow_redirects_safely

        http = _FakeSession([_FakeResponse(302, headers={})])
        with pytest.raises(DownloadError, match="Location"):
            await follow_redirects_safely(
                "https://origin.example.com/song.mp3", http, _timeout()
            )

    async def test_relative_redirect_resolved_against_current(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.music.sources.url_resolver import follow_redirects_safely

        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        http = _FakeSession(
            [
                _FakeResponse(302, headers={"Location": "/files/song.mp3"}),
                _FakeResponse(200),
            ]
        )
        final = await follow_redirects_safely(
            "https://cdn.example.com/get/song", http, _timeout()
        )
        assert final == "https://cdn.example.com/files/song.mp3"

    async def test_stream_download_uses_manual_redirects(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path
    ) -> None:
        """stream_download must not follow automatic redirects."""
        import inspect

        from app.music.sources import url_resolver

        source = inspect.getsource(url_resolver._stream_once)
        assert "allow_redirects=False" in source
        assert "follow_redirects_safely" in source

    async def test_audio_processor_uses_manual_redirects(self) -> None:
        import inspect

        from app.audio import processor

        source = inspect.getsource(processor.AudioProcessor._download)
        assert "allow_redirects=False" in source
        assert "follow_redirects_safely" in source


# -- tiny aiohttp duck-types ------------------------------------------------
def _timeout():
    import aiohttp

    return aiohttp.ClientTimeout(total=5)


class _FakeResponse:
    def __init__(self, status: int, headers: dict | None = None) -> None:
        self.status = status
        self.headers = headers or {}

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc_info):
        return False

    async def text(self) -> str:
        return ""

    async def json(self, **kwargs):
        return {}


class _FakeSession:
    """aiohttp.ClientSession duck-type with scripted responses."""

    def __init__(self, responses: list[_FakeResponse]) -> None:
        self._responses = list(responses)
        self.requests: list[str] = []

    def get(self, url: str, **kwargs):
        self.requests.append(url)
        if not self._responses:
            raise AssertionError(f"unexpected extra request: {url}")
        return self._responses.pop(0)

"""In-memory cache, rate limiter and lock manager tests (app.cache.redis)."""

from __future__ import annotations

import asyncio

import pytest

from app.cache.redis import LockManager, MemoryCache, RateLimiter


@pytest.fixture
def cache() -> MemoryCache:
    return MemoryCache()


class TestMemoryCache:
    async def test_set_get_roundtrip(self, cache: MemoryCache) -> None:
        await cache.set("k", {"a": 1})
        assert await cache.get("k") == {"a": 1}

    async def test_missing_key_is_none(self, cache: MemoryCache) -> None:
        assert await cache.get("nope") is None

    async def test_delete(self, cache: MemoryCache) -> None:
        await cache.set("k", "v")
        await cache.delete("k")
        assert await cache.get("k") is None
        await cache.delete("k")  # idempotent

    async def test_overwrite(self, cache: MemoryCache) -> None:
        await cache.set("k", "first")
        await cache.set("k", "second")
        assert await cache.get("k") == "second"

    async def test_ttl_expiry(self, cache: MemoryCache) -> None:
        await cache.set("ephemeral", "v", ttl=0.05)
        assert await cache.get("ephemeral") == "v"
        await asyncio.sleep(0.08)
        assert await cache.get("ephemeral") is None

    async def test_no_ttl_never_expires(self, cache: MemoryCache) -> None:
        await cache.set("eternal", "v")  # ttl=None
        await asyncio.sleep(0.02)
        assert await cache.get("eternal") == "v"

    async def test_get_or_set_caches_factory(self, cache: MemoryCache) -> None:
        calls = []

        async def factory() -> str:
            calls.append(1)
            return "computed"

        first = await cache.get_or_set("derived", factory, ttl=5)
        second = await cache.get_or_set("derived", factory, ttl=5)
        assert first == second == "computed"
        assert len(calls) == 1  # factory ran once

    async def test_get_or_set_accepts_plain_value(self, cache: MemoryCache) -> None:
        assert await cache.get_or_set("plain", "static") == "static"

    async def test_ping_and_close(self, cache: MemoryCache) -> None:
        assert await cache.ping() is True
        await cache.set("k", "v")
        await cache.close()
        assert await cache.get("k") is None


class TestIncr:
    async def test_first_incr_is_one(self, cache: MemoryCache) -> None:
        assert await cache.incr("counter", ttl=60) == 1

    async def test_increments(self, cache: MemoryCache) -> None:
        await cache.incr("counter", ttl=60)
        await cache.incr("counter", ttl=60)
        assert await cache.incr("counter", ttl=60) == 3

    async def test_independent_keys(self, cache: MemoryCache) -> None:
        await cache.incr("a", ttl=60)
        assert await cache.incr("b", ttl=60) == 1

    async def test_resets_after_ttl(self, cache: MemoryCache) -> None:
        await cache.incr("counter", ttl=0.05)
        await cache.incr("counter", ttl=0.05)
        await asyncio.sleep(0.08)
        assert await cache.incr("counter", ttl=60) == 1


class TestRateLimiter:
    async def test_allows_up_to_limit(self) -> None:
        limiter = RateLimiter(MemoryCache())
        for _ in range(3):
            assert await limiter.check("user:1", limit=3, window_seconds=60) is True

    async def test_blocks_over_limit(self) -> None:
        limiter = RateLimiter(MemoryCache())
        for _ in range(3):
            await limiter.check("user:2", limit=3, window_seconds=60)
        assert await limiter.check("user:2", limit=3, window_seconds=60) is False

    async def test_windows_are_isolated_per_key(self) -> None:
        limiter = RateLimiter(MemoryCache())
        assert await limiter.check("a", limit=1, window_seconds=60) is True
        assert await limiter.check("b", limit=1, window_seconds=60) is True
        assert await limiter.check("a", limit=1, window_seconds=60) is False

    async def test_remaining(self) -> None:
        limiter = RateLimiter(MemoryCache())
        await limiter.check("user:3", limit=5, window_seconds=60)
        await limiter.check("user:3", limit=5, window_seconds=60)
        assert await limiter.remaining("user:3", limit=5, window_seconds=60) == 3


class TestLockManager:
    async def test_double_acquire_returns_none(self) -> None:
        locks = LockManager(MemoryCache())
        first = await locks.try_acquire("failover:1", ttl=30)
        assert first is not None
        assert await locks.try_acquire("failover:1", ttl=30) is None

    async def test_reacquire_after_release(self) -> None:
        locks = LockManager(MemoryCache())
        lock = await locks.try_acquire("job:1", ttl=30)
        assert lock is not None
        await lock.release()
        assert await locks.try_acquire("job:1", ttl=30) is not None

    async def test_different_locks_coexist(self) -> None:
        locks = LockManager(MemoryCache())
        assert await locks.try_acquire("a", ttl=30) is not None
        assert await locks.try_acquire("b", ttl=30) is not None

    async def test_context_manager_releases_on_exit(self) -> None:
        locks = LockManager(MemoryCache())
        async with locks.acquire("ctx:1", ttl=30) as lock:
            assert lock is not None
            # still held inside the block
            assert await locks.try_acquire("ctx:1", ttl=30) is None
        assert await locks.try_acquire("ctx:1", ttl=30) is not None

    async def test_context_manager_yields_none_when_taken(self) -> None:
        locks = LockManager(MemoryCache())
        async with locks.acquire("ctx:2", ttl=30):
            async with locks.acquire("ctx:2", ttl=30) as second:
                assert second is None

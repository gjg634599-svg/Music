"""STRICT SILENT GROUP MODE — the mandated test matrix.

Spec: "Test cases must include: normal text → no response, photo → no
response, video → no response, sticker → no response, link → no response,
mention → no response by default, reply → no response, /play → response,
/queue → response, /skip → response, inline button → response".

Both the pure gate (``app.groups.silent_mode``) and the middleware
(``GroupSilentMiddleware``) are covered. Callback queries are NOT gated by
the message middleware — asserted via the groups router exposing
``callback_query`` handlers.
"""

from __future__ import annotations

from types import SimpleNamespace

from app.bot.middleware.group_silent import GroupSilentMiddleware
from app.groups.silent_mode import (
    is_callback,
    is_explicit_interaction,
    should_process_group_message,
)

GROUP = dict(chat_id=-100999, chat_type="supergroup")
PRIVATE = dict(chat_id=101, chat_type="private")


def group_message(**kwargs) -> SimpleNamespace:
    """A group-chat message-like object."""
    return SimpleNamespace(
        chat=SimpleNamespace(id=GROUP["chat_id"], type=GROUP["chat_type"]),
        **kwargs,
    )


def command_entity() -> SimpleNamespace:
    return SimpleNamespace(type="bot_command", offset=0, length=5)


# ---------------------------------------------------------------------------
# Pure gate — the mandated matrix
# ---------------------------------------------------------------------------
class TestPureGate:
    def test_normal_text_is_not_processed(self) -> None:
        assert should_process_group_message(group_message(text="hello world")) is False

    def test_photo_is_not_processed(self) -> None:
        assert (
            should_process_group_message(
                group_message(photo=[SimpleNamespace(file_id="p1")], caption=None)
            )
            is False
        )

    def test_video_is_not_processed(self) -> None:
        assert (
            should_process_group_message(
                group_message(video=SimpleNamespace(file_id="v1"))
            )
            is False
        )

    def test_sticker_is_not_processed(self) -> None:
        assert (
            should_process_group_message(
                group_message(sticker=SimpleNamespace(file_id="s1"))
            )
            is False
        )

    def test_link_is_not_processed(self) -> None:
        assert (
            should_process_group_message(
                group_message(
                    text="https://example.com/song",
                    entities=[SimpleNamespace(type="url", offset=0, length=24)],
                )
            )
            is False
        )

    def test_mention_is_not_processed_by_default(self) -> None:
        assert (
            should_process_group_message(
                group_message(
                    text="@musicbot play something",
                    entities=[SimpleNamespace(type="mention", offset=0, length=10)],
                )
            )
            is False
        )

    def test_reply_is_not_processed(self) -> None:
        assert (
            should_process_group_message(
                group_message(
                    text="this is a reply",
                    reply_to_message=SimpleNamespace(text="original"),
                )
            )
            is False
        )

    def test_play_command_is_processed(self) -> None:
        assert (
            should_process_group_message(
                group_message(
                    text="/play neon sunrise",
                    entities=[command_entity()],
                )
            )
            is True
        )

    def test_queue_command_is_processed(self) -> None:
        assert (
            should_process_group_message(
                group_message(text="/queue", entities=[command_entity()])
            )
            is True
        )

    def test_skip_command_is_processed(self) -> None:
        assert (
            should_process_group_message(
                group_message(text="/skip", entities=[command_entity()])
            )
            is True
        )

    def test_caption_command_is_processed(self) -> None:
        """Media with a command in the caption is an explicit interaction."""
        assert (
            should_process_group_message(
                group_message(
                    photo=[SimpleNamespace(file_id="p1")],
                    caption="/play",
                    caption_entities=[command_entity()],
                )
            )
            is True
        )

    def test_none_message_is_not_processed(self) -> None:
        assert should_process_group_message(None) is False


# ---------------------------------------------------------------------------
# Middleware — same matrix through GroupSilentMiddleware
# ---------------------------------------------------------------------------
class TestMiddleware:
    async def _run(self, message: SimpleNamespace) -> tuple[bool, list]:
        """Run the middleware; return (handler_called, calls)."""
        calls: list = []

        async def handler(event, data):  # noqa: ANN001
            calls.append(event)
            return "ok"

        middleware = GroupSilentMiddleware()
        result = await middleware(handler, message, {})
        return result == "ok" and bool(calls), calls

    async def test_normal_text_dropped(self) -> None:
        called, calls = await self._run(group_message(text="hello"))
        assert called is False and calls == []

    async def test_photo_dropped(self) -> None:
        called, calls = await self._run(
            group_message(photo=[SimpleNamespace(file_id="p1")])
        )
        assert called is False and calls == []

    async def test_video_dropped(self) -> None:
        called, calls = await self._run(
            group_message(video=SimpleNamespace(file_id="v1"))
        )
        assert called is False and calls == []

    async def test_sticker_dropped(self) -> None:
        called, calls = await self._run(
            group_message(sticker=SimpleNamespace(file_id="s1"))
        )
        assert called is False and calls == []

    async def test_link_dropped(self) -> None:
        called, calls = await self._run(
            group_message(
                text="https://example.com",
                entities=[SimpleNamespace(type="url", offset=0, length=19)],
            )
        )
        assert called is False and calls == []

    async def test_mention_dropped_by_default(self) -> None:
        called, calls = await self._run(
            group_message(
                text="@musicbot hi",
                entities=[SimpleNamespace(type="mention", offset=0, length=10)],
            )
        )
        assert called is False and calls == []

    async def test_reply_dropped(self) -> None:
        called, calls = await self._run(
            group_message(
                text="a reply",
                reply_to_message=SimpleNamespace(text="original"),
            )
        )
        assert called is False and calls == []

    async def test_play_command_passes(self) -> None:
        called, _ = await self._run(
            group_message(text="/play neon", entities=[command_entity()])
        )
        assert called is True

    async def test_queue_command_passes(self) -> None:
        called, _ = await self._run(
            group_message(text="/queue", entities=[command_entity()])
        )
        assert called is True

    async def test_skip_command_passes(self) -> None:
        called, _ = await self._run(
            group_message(text="/skip", entities=[command_entity()])
        )
        assert called is True

    async def test_private_text_passes(self) -> None:
        """Private chats are never gated (search queries live there)."""
        called, _ = await self._run(
            SimpleNamespace(
                chat=SimpleNamespace(id=101, type="private"), text="hello"
            )
        )
        assert called is True

    async def test_service_message_dropped(self) -> None:
        """left_chat_member etc. never carry command entities → dropped."""
        called, calls = await self._run(
            group_message(
                text="", left_chat_member=SimpleNamespace(id=42)
            )
        )
        assert called is False and calls == []


# ---------------------------------------------------------------------------
# Inline buttons (callback queries) are NOT gated by the message middleware
# ---------------------------------------------------------------------------
class TestCallbacksNotGated:
    def test_is_callback_helper(self) -> None:
        assert is_callback(SimpleNamespace(data="grp:queue")) is True
        assert is_callback(None) is False

    def test_is_explicit_interaction_for_callbacks(self) -> None:
        callback_like = SimpleNamespace(data="q:skip")
        update_like = SimpleNamespace(
            callback_query=SimpleNamespace(data="q:skip"), message=None
        )
        message_like = SimpleNamespace(text="hi", data=None)
        assert is_explicit_interaction(callback_like) is True
        assert is_explicit_interaction(update_like) is True
        assert is_explicit_interaction(message_like) is False

    async def test_callback_like_event_passes_middleware(self) -> None:
        """The middleware only inspects chat.type — callback-like events
        (no chat attribute) pass through untouched."""
        calls: list = []

        async def handler(event, data):  # noqa: ANN001
            calls.append(event)
            return "ok"

        middleware = GroupSilentMiddleware()
        callback_like = SimpleNamespace(data="grp:queue")
        result = await middleware(handler, callback_like, {})
        assert result == "ok" and len(calls) == 1

    def test_groups_router_has_callback_handlers(self) -> None:
        """Callbacks are handled by aiogram callback_query handlers instead —
        the groups router must expose them (e.g. for grp:queue)."""
        from app.bot.handlers import groups as groups_handlers

        handlers = groups_handlers.router.callback_query.handlers
        assert len(handlers) >= 10, "groups router must register callback_query handlers"

    async def test_grp_queue_callback_reaches_a_handler(self) -> None:
        """A grp:queue callback in a group chat matches exactly one registered
        callback handler (callbacks are explicit interactions — never gated)."""
        from app.bot.handlers import groups as groups_handlers

        event = SimpleNamespace(
            data="grp:queue",
            message=SimpleNamespace(
                chat=SimpleNamespace(id=-100999, type="supergroup"),
                from_user=SimpleNamespace(id=101, is_bot=False, first_name="A"),
            ),
            from_user=SimpleNamespace(id=101, is_bot=False, first_name="A"),
        )
        matched = []
        for handler in groups_handlers.router.callback_query.handlers:
            result = await handler.check(event)
            ok = result[0] if isinstance(result, tuple) else bool(result)
            if ok:
                matched.append(handler.callback)
        assert len(matched) == 1
        assert getattr(matched[0], "__name__", "") == "cb_queue"


# ---------------------------------------------------------------------------
# Command targeting — /play@OtherBot must be dropped (middleware path)
# ---------------------------------------------------------------------------
class FakeBotInfo:
    """Duck-typed aiogram Bot with the cached ``me()`` alias (mirrors the
    real Bot: the first call fetches, later calls return the cache)."""

    def __init__(self, username: str) -> None:
        self._username = username
        self._cached_me: SimpleNamespace | None = None
        self.me_calls = 0

    async def me(self):  # noqa: ANN202
        if self._cached_me is None:
            self.me_calls += 1
            self._cached_me = SimpleNamespace(username=self._username)
        return self._cached_me


def command_entity_at(text: str, command: str) -> SimpleNamespace:
    offset = text.find(command)
    return SimpleNamespace(
        type="bot_command", offset=offset, length=len(command)
    )


class TestCommandTargeting:
    async def _run(self, message, data):  # noqa: ANN001
        calls: list = []

        async def handler(event, payload):  # noqa: ANN001
            calls.append(event)
            return "ok"

        middleware = GroupSilentMiddleware()
        result = await middleware(handler, message, data)
        return result == "ok" and bool(calls)

    async def test_command_for_this_bot_passes(self) -> None:
        bot = FakeBotInfo("Filvenmusic_bot")
        message = group_message(
            text="/play@Filvenmusic_bot bang bang",
            entities=[command_entity_at("/play@Filvenmusic_bot bang bang", "/play@Filvenmusic_bot")],
        )
        assert await self._run(message, {"bot": bot}) is True

    async def test_unqualified_command_passes(self) -> None:
        bot = FakeBotInfo("Filvenmusic_bot")
        message = group_message(
            text="/play bang bang",
            entities=[command_entity_at("/play bang bang", "/play")],
        )
        assert await self._run(message, {"bot": bot}) is True

    async def test_command_for_other_bot_dropped(self) -> None:
        bot = FakeBotInfo("Filvenmusic_bot")
        message = group_message(
            text="/play@SomeOtherBot song",
            entities=[command_entity_at("/play@SomeOtherBot song", "/play@SomeOtherBot")],
        )
        assert await self._run(message, {"bot": bot}) is False

    async def test_unknown_bot_username_stays_permissive(self) -> None:
        """Without a resolvable bot username the gate stays permissive —
        aiogram's own Command filters then reject the mismatch."""
        message = group_message(
            text="/play@SomeOtherBot song",
            entities=[command_entity_at("/play@SomeOtherBot song", "/play@SomeOtherBot")],
        )
        assert await self._run(message, {}) is True

    async def test_bot_me_failure_stays_permissive(self) -> None:
        class BrokenBot:
            async def me(self):  # noqa: ANN202
                raise RuntimeError("no api")

        message = group_message(
            text="/play song",
            entities=[command_entity_at("/play song", "/play")],
        )
        assert await self._run(message, {"bot": BrokenBot()}) is True

    async def test_bot_username_cached(self) -> None:
        """bot.me() is aiogram's cached alias — one call, reused."""
        bot = FakeBotInfo("Filvenmusic_bot")
        for _ in range(3):
            message = group_message(
                text="/play x",
                entities=[command_entity_at("/play x", "/play")],
            )
            await self._run(message, {"bot": bot})
        assert bot.me_calls == 1

    async def test_caption_command_for_other_bot_dropped(self) -> None:
        bot = FakeBotInfo("Filvenmusic_bot")
        message = group_message(
            photo=[SimpleNamespace(file_id="p1")],
            caption="/queue@OtherBot",
            caption_entities=[command_entity_at("/queue@OtherBot", "/queue@OtherBot")],
        )
        assert await self._run(message, {"bot": bot}) is False

    async def test_private_command_for_other_bot_passes_gate(self) -> None:
        """Private chats are never gated by this middleware."""
        bot = FakeBotInfo("Filvenmusic_bot")
        message = SimpleNamespace(
            chat=SimpleNamespace(id=101, type="private"),
            text="/play@OtherBot hi",
            entities=[command_entity_at("/play@OtherBot hi", "/play@OtherBot")],
        )
        assert await self._run(message, {"bot": bot}) is True


class TestCommandEntityTexts:
    def test_extracts_command_from_text(self) -> None:
        from app.groups.silent_mode import command_entity_texts

        message = group_message(
            text="/play@bot song",
            entities=[SimpleNamespace(type="bot_command", offset=0, length=9)],
        )
        assert command_entity_texts(message) == ["/play@bot"]

    def test_extracts_command_from_caption(self) -> None:
        from app.groups.silent_mode import command_entity_texts

        message = group_message(
            caption="/queue",
            caption_entities=[SimpleNamespace(type="bot_command", offset=0, length=6)],
        )
        assert command_entity_texts(message) == ["/queue"]

    def test_ignores_non_command_entities(self) -> None:
        from app.groups.silent_mode import command_entity_texts

        message = group_message(
            text="plain text",
            entities=[SimpleNamespace(type="bold", offset=0, length=6)],
        )
        assert command_entity_texts(message) == []

    def test_none_message(self) -> None:
        from app.groups.silent_mode import command_entity_texts

        assert command_entity_texts(None) == []


class TestMiddlewareRegistration:
    def test_silent_gate_registered_before_rate_limit(self) -> None:
        """The silent-group gate must run BEFORE rate limiting and after
        update logging (bot.py registration order, verified against the
        production wiring — aiogram routers are single-parent so a second
        create_dispatcher() cannot be built in-process after the smoke
        tests attached the module routers)."""
        import inspect

        from app.bot import bot as bot_module

        source = inspect.getsource(bot_module.create_dispatcher)
        order = {
            "logging": source.index("LoggingMiddleware()"),
            "silent": source.index("GroupSilentMiddleware()"),
            "maintenance": source.index("MaintenanceMiddleware()"),
            "rate": source.index("RateLimitMiddleware()"),
        }
        assert order["logging"] < order["silent"], "logging must run first"
        assert order["silent"] < order["maintenance"], "silent gate before maintenance"
        assert order["maintenance"] < order["rate"], "gates before rate limiting"
        assert "CallbackRateLimitMiddleware()" in source

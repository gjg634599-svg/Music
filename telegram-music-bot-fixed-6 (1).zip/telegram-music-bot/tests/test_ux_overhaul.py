"""UX overhaul tests (round 4).

Locks the UI/UX patterns introduced after benchmarking established
Telegram music bots and music-player interfaces:

* shared Now Playing renderer (header / playhead bar / state badges /
  requester attribution / queue count) — one layout everywhere;
* stateful control buttons (Shuffle / Repeat show their current mode);
* persistent group control panel (shuffle, repeat, volume steps);
* queue views with per-entry durations, requester mentions and total time;
* search results that are never a dead end (New Search / Home row);
* command aliases (/p /q /np /next);
* admin-customizable default texts stay Telegram-HTML-safe.
"""

from __future__ import annotations

import importlib
from types import SimpleNamespace
from typing import Any

import pytest

from app.bot.keyboards.group import (
    group_controls_keyboard,
    group_queue_keyboard,
    group_search_results_keyboard,
)
from app.bot.keyboards.queue import now_playing_keyboard, queue_keyboard
from app.bot.keyboards.track import search_results_keyboard
from app.database import defaults
from app.playback.controller import PlaybackController
from app.playback.queue import QueueOwner
from app.utils import (
    PayloadBadges,
    format_duration,
    now_playing_text,
    progress_bar,
    queue_total_line,
    user_link,
)

from tests.test_production_regressions import _unsupported_tags

OWNER = QueueOwner(kind="user", id=42)
GROUP = QueueOwner(kind="group", id=-100123)


def _track(**overrides: Any) -> SimpleNamespace:
    base = SimpleNamespace(
        title="Test Song",
        artist=SimpleNamespace(name="Test Artist"),
        duration_seconds=240,
    )
    for key, value in overrides.items():
        setattr(base, key, value)
    return base


def _session(**overrides: Any) -> SimpleNamespace:
    base = SimpleNamespace(shuffle=False, repeat_mode="off", autoplay=False)
    for key, value in overrides.items():
        setattr(base, key, value)
    return base


def _datas(keyboard: Any) -> list[str]:
    return [
        button.callback_data
        for row in keyboard.inline_keyboard
        for button in row
    ]


def _labels(keyboard: Any) -> list[str]:
    return [button.text for row in keyboard.inline_keyboard for button in row]


# ----------------------------------------------------------------------
# Shared Now Playing renderer
# ----------------------------------------------------------------------
class TestNowPlayingText:
    def test_basic_layout(self) -> None:
        text = now_playing_text(
            _track(), position=60, paused=False, session=_session(), queue_size=3
        )
        assert "🎵 <b>NOW PLAYING</b>" in text
        assert "<b>Test Song</b>" in text
        assert "🎤 Test Artist" in text
        assert "●" in text  # playhead marker
        assert "1:00 / 4:00" in text
        assert "📋 3 in queue" in text

    def test_paused_header(self) -> None:
        text = now_playing_text(_track(), position=0, paused=True, session=None)
        assert "⏸ <b>PAUSED</b>" in text

    def test_state_badges_render_human_labels(self) -> None:
        text = now_playing_text(
            _track(), session=_session(shuffle=True, repeat_mode="one", autoplay=True)
        )
        assert "🔀 Shuffle" in text
        assert "🔁 Repeat: One" in text
        assert "🤖 Autoplay" in text

    def test_off_modes_show_no_badges(self) -> None:
        text = now_playing_text(_track(), session=_session())
        assert "Shuffle" not in text
        assert "Repeat" not in text
        assert "Autoplay" not in text

    def test_requester_line_rendered(self) -> None:
        mention = user_link(555, "Alice")
        text = now_playing_text(_track(), session=None, requester=mention)
        assert "👤 Requested by" in text
        assert "tg://user?id=555" in text

    def test_title_and_artist_are_escaped(self) -> None:
        evil = _track(title="<b>BOOM & </b>", artist=SimpleNamespace(name="<script>"))
        text = now_playing_text(evil, session=None)
        assert "<script>" not in text
        assert "&lt;b&gt;BOOM &amp;" in text
        assert _unsupported_tags(text) == []

    def test_custom_header_overrides_default(self) -> None:
        text = now_playing_text(
            _track(), session=None, header="🎵 <b>NOW PLAYING IN THE GROUP</b>"
        )
        assert text.startswith("🎵 <b>NOW PLAYING IN THE GROUP</b>")
        assert "<b>Test Song</b>" in text

    def test_unknown_duration_renders_no_bar(self) -> None:
        text = now_playing_text(
            _track(duration_seconds=0), position=5, session=None
        )
        assert "●" not in text

    def test_none_track_idle_text(self) -> None:
        assert now_playing_text(None) == "ℹ️ Nothing is playing right now."

    def test_position_clamped_to_duration(self) -> None:
        text = now_playing_text(
            _track(duration_seconds=60), position=999, session=None
        )
        assert "1:00 / 1:00" in text
        assert "●" in text


class TestPayloadBadges:
    def test_reads_badges_from_payload(self) -> None:
        badges = PayloadBadges(
            {"shuffle": True, "repeat_mode": "all", "autoplay": False}
        )
        assert badges.shuffle is True
        assert badges.repeat_mode == "all"
        assert badges.autoplay is False

    def test_missing_keys_default_off(self) -> None:
        badges = PayloadBadges({})
        assert badges.shuffle is False
        assert badges.repeat_mode == "off"
        assert badges.autoplay is False

    def test_drives_the_shared_renderer(self) -> None:
        payload = {"shuffle": True, "repeat_mode": "all"}
        text = now_playing_text(_track(), session=PayloadBadges(payload))
        assert "🔀 Shuffle" in text and "🔁 Repeat: All" in text


# ----------------------------------------------------------------------
# Progress bar
# ----------------------------------------------------------------------
class TestProgressBar:
    def test_playhead_present(self) -> None:
        bar = progress_bar(50, 200)
        assert "●" in bar and "▬" in bar and "─" in bar

    def test_zero_position_all_empty(self) -> None:
        assert progress_bar(0, 200).startswith("●")

    def test_full_position_all_filled(self) -> None:
        assert progress_bar(200, 200).endswith("●")

    def test_unknown_duration_flat_bar(self) -> None:
        bar = progress_bar(10, 0)
        assert "●" not in bar and set(bar) == {"─"}

    def test_bar_length_constant(self) -> None:
        for position in (0, 37, 100, 200, 9999):
            assert len(progress_bar(position, 200)) == len(progress_bar(0, 200))


# ----------------------------------------------------------------------
# Queue totals and user links
# ----------------------------------------------------------------------
class TestQueueTotalLine:
    def test_minutes_format(self) -> None:
        line = queue_total_line([180, 120, 60])
        assert line == "📋 3 in queue · ≈ 6 min"

    def test_hours_format(self) -> None:
        line = queue_total_line([3600, 3600])
        assert "2h 0m" in line

    def test_unknown_durations_skipped(self) -> None:
        line = queue_total_line([None, 0, 300])
        assert line == "📋 3 in queue · ≈ 5 min"

    def test_no_durations_count_only(self) -> None:
        assert queue_total_line([None, None]) == "📋 2 in queue"

    def test_remaining_of_current_added(self) -> None:
        line = queue_total_line([60], remaining_of_current=59)
        assert "≈ 2 min" in line


class TestUserLink:
    def test_deep_link_with_name(self) -> None:
        link = user_link(555, "Alice")
        assert link == '<a href="tg://user?id=555">Alice</a>'

    def test_fallback_label(self) -> None:
        assert user_link(555, None) == '<a href="tg://user?id=555">Member</a>'
        assert user_link(None, "Bob") == "Bob"

    def test_escaped(self) -> None:
        link = user_link(555, "<b>")
        assert "<b>" not in link


# ----------------------------------------------------------------------
# Stateful keyboards
# ----------------------------------------------------------------------
class TestPersonalNowPlayingKeyboard:
    def test_shuffle_and_repeat_labels_reflect_state(self) -> None:
        keyboard = now_playing_keyboard(
            paused=False, liked=False, shuffle=True, repeat_mode="one"
        )
        labels = _labels(keyboard)
        assert "🔀 Shuffle: On" in labels
        assert "🔁 Repeat: One" in labels

    def test_off_state_labels(self) -> None:
        labels = _labels(now_playing_keyboard(paused=False, liked=False))
        assert "🔀 Shuffle: Off" in labels
        assert "🔁 Repeat: Off" in labels

    def test_namespace_is_np(self) -> None:
        datas = _datas(now_playing_keyboard(paused=False, liked=False))
        assert datas and all(d.startswith("np:") for d in datas)


class TestPersonalQueueKeyboard:
    def test_repeat_button_present(self) -> None:
        datas = _datas(queue_keyboard(shuffle=True, repeat_mode="all"))
        assert "q:rep" in datas
        assert "q:shuf" in datas
        assert "q:skip" in datas
        assert "q:clear" in datas
        assert "nav:home" in datas

    def test_stateful_labels(self) -> None:
        labels = _labels(queue_keyboard(shuffle=True, repeat_mode="all"))
        assert "🔀 Shuffle: On" in labels
        assert "🔁 Repeat: All" in labels


class TestGroupControlsKeyboard:
    def test_full_panel_present(self) -> None:
        datas = _datas(
            group_controls_keyboard(
                paused=False, shuffle=True, repeat_mode="all", volume=100
            )
        )
        for expected in (
            "grp:pause", "grp:skip", "grp:shuf", "grp:rep",
            "grp:vol:dn", "grp:vol:up", "grp:queue", "grp:stop",
        ):
            assert expected in datas, f"missing {expected}"

    def test_volume_labels_show_target_values(self) -> None:
        labels = _labels(
            group_controls_keyboard(paused=False, volume=100)
        )
        # Volume is a human percent (0-100) — the label caps at 100.
        assert "🔉 Vol − 75" in labels
        assert "🔊 Vol + 100" in labels

    def test_volume_labels_clamped(self) -> None:
        labels = _labels(group_controls_keyboard(paused=False, volume=10))
        assert "🔉 Vol − 0" in labels
        assert "🔊 Vol + 35" in labels
        # Values above 100 are clamped to the 0-100 percent range.
        labels = _labels(group_controls_keyboard(paused=False, volume=195))
        assert "🔊 Vol + 100" in labels

    def test_stateful_labels(self) -> None:
        labels = _labels(
            group_controls_keyboard(paused=True, shuffle=True, repeat_mode="one")
        )
        assert "▶️ Resume" in labels
        assert "🔀 Shuffle On" in labels
        assert "🔁 Repeat: One" in labels

    def test_all_callbacks_are_grp_namespaced(self) -> None:
        datas = _datas(group_controls_keyboard(paused=False))
        assert datas and all(d.startswith("grp:") for d in datas)


class TestGroupQueueKeyboard:
    def test_repeat_present_and_stateful(self) -> None:
        datas = _datas(group_queue_keyboard(shuffle=False, repeat_mode="off"))
        assert "grp:rep" in datas and "grp:shuf" in datas
        labels = _labels(group_queue_keyboard(shuffle=True, repeat_mode="all"))
        assert "🔀 Shuffle: On" in labels
        assert "🔁 Repeat: All" in labels


class TestControllerPlayerKeyboard:
    def test_group_panel_carries_shuf_rep_volume(self) -> None:
        datas = _datas(
            PlaybackController._player_keyboard(
                paused=False, group=True, shuffle=True, repeat_mode="all", volume=100
            )
        )
        for expected in ("grp:shuf", "grp:rep", "grp:vol:dn", "grp:vol:up"):
            assert expected in datas
        assert all(d.startswith("grp:") for d in datas)

    def test_personal_panel_stateful(self) -> None:
        datas = _datas(
            PlaybackController._player_keyboard(
                paused=False, group=False, shuffle=True, repeat_mode="one"
            )
        )
        assert all(d.startswith("np:") for d in datas)
        labels = _labels(
            PlaybackController._player_keyboard(
                paused=False, group=False, shuffle=True, repeat_mode="one"
            )
        )
        assert "🔀 Shuffle: On" in labels
        assert "🔁 Repeat: One" in labels


# ----------------------------------------------------------------------
# Search results are never a dead end
# ----------------------------------------------------------------------
class TestSearchResultsKeyboard:
    def test_navigation_row_present_single_page(self) -> None:
        datas = _datas(search_results_keyboard(0, 1, [10, 11, 12]))
        assert "dash:search" in datas, "New Search escape hatch missing"
        assert "nav:home" in datas, "Home escape hatch missing"

    def test_navigation_row_present_multi_page(self) -> None:
        datas = _datas(search_results_keyboard(1, 3, [13, 14]))
        assert "sch:pg:0" in datas and "sch:pg:2" in datas
        assert "dash:search" in datas and "nav:home" in datas


class TestGroupSearchResultsKeyboard:
    def test_followup_row_present(self) -> None:
        tracks = [SimpleNamespace(id=10, title="A", artist=None)]
        datas = _datas(group_search_results_keyboard(tracks))
        assert "trk:10" in datas
        assert "grp:np" in datas and "grp:queue" in datas

    def test_numbered_rows_single_per_row(self) -> None:
        tracks = [
            SimpleNamespace(id=i, title=f"T{i}", artist=None) for i in (1, 2, 3)
        ]
        keyboard = group_search_results_keyboard(tracks)
        rows = keyboard.inline_keyboard
        assert all(len(row) == 1 for row in rows[:-1])
        assert len(rows[-1]) == 2  # the follow-up row


# ----------------------------------------------------------------------
# Command aliases (Jockie/Pancake pattern)
# ----------------------------------------------------------------------
def _group_commands() -> dict[str, int]:
    """{command_name: registration_count} across the groups router."""
    groups = importlib.import_module("app.bot.handlers.groups")
    seen: dict[str, int] = {}
    for message_handler in groups.router.message.handlers:
        for filter_obj in message_handler.filters:
            # aiogram wraps each filter in FilterObject; the Command lives
            # on .callback and exposes .commands (tuple of names).
            command_filter = getattr(filter_obj, "callback", None)
            commands = getattr(command_filter, "commands", None)
            if commands:
                for name in commands:
                    seen[name] = seen.get(name, 0) + 1
    return seen


class TestGroupCommandAliases:
    def test_aliases_registered(self) -> None:
        registered = _group_commands()
        for alias in ("p", "q", "np", "next"):
            assert alias in registered, f"alias /{alias} not registered"
        for canonical in ("play", "queue", "nowplaying", "skip"):
            assert canonical in registered

    def test_no_command_registered_twice(self) -> None:
        registered = _group_commands()
        duplicates = {name: count for name, count in registered.items() if count > 1}
        assert not duplicates, f"commands registered more than once: {duplicates}"


# ----------------------------------------------------------------------
# New group callbacks are wired
# ----------------------------------------------------------------------
class TestGroupCallbacksWired:
    def test_rep_and_volume_handlers_registered(self) -> None:
        """The new buttons must have real handlers (callback contract)."""
        import inspect

        groups = importlib.import_module("app.bot.handlers.groups")
        source = inspect.getsource(groups)
        assert 'F.data == "grp:rep"' in source, "grp:rep handler missing"
        assert 'r"^grp:vol:(dn|up)$"' in source, "grp:vol step handler missing"

    def test_volume_step_constant_in_bounds(self) -> None:
        groups = importlib.import_module("app.bot.handlers.groups")
        assert 0 < groups.VOLUME_STEP <= 50


# ----------------------------------------------------------------------
# Queue view renderers
# ----------------------------------------------------------------------
def _async_return(value: Any):
    async def _inner(*args: Any, **kwargs: Any) -> Any:
        return value

    return _inner


def _queue_item(
    item_id: int, track_id: int, title: str, duration: int, added_by: int | None
) -> SimpleNamespace:
    return SimpleNamespace(
        id=item_id,
        track_id=track_id,
        added_by=added_by,
        track=SimpleNamespace(
            title=title,
            artist=SimpleNamespace(name="Ar"),
            duration_seconds=duration,
        ),
    )


class TestPersonalQueueView:
    @pytest.mark.asyncio
    async def test_durations_and_total_rendered(self) -> None:
        from app.bot.handlers.playback import render_queue_view

        items = [
            _queue_item(1, 101, "A", 120, None),
            _queue_item(2, 102, "B", 180, None),
        ]
        services = SimpleNamespace(
            playback=SimpleNamespace(
                now_playing=_async_return(
                    {
                        "track": _track(),
                        "status": "playing",
                        "position_seconds": 10,
                        "queue_size": 2,
                        "shuffle": True,
                        "repeat_mode": "all",
                        "autoplay": False,
                    }
                )
            ),
            queue=SimpleNamespace(get_queue=_async_return(items)),
            music=SimpleNamespace(get_track=_async_return(None)),
            sessions=SimpleNamespace(
                get=_async_return(_session(shuffle=True, repeat_mode="all"))
            ),
        )
        text, markup = await render_queue_view(services, OWNER)
        assert "⏭ <b>Up next</b>" in text
        assert f"· {format_duration(120)}" in text
        assert f"· {format_duration(180)}" in text
        assert "≈ 5 min" in text
        assert "Page 1/1" in text
        # Stateful toggles on the attached keyboard
        labels = _labels(markup)
        assert "🔀 Shuffle: On" in labels
        assert "🔁 Repeat: All" in labels

    @pytest.mark.asyncio
    async def test_empty_queue_invites_action(self) -> None:
        from app.bot.handlers.playback import render_queue_view

        services = SimpleNamespace(
            playback=SimpleNamespace(
                now_playing=_async_return({"track": None, "status": "idle"})
            ),
            queue=SimpleNamespace(get_queue=_async_return([])),
            music=SimpleNamespace(get_track=_async_return(None)),
            sessions=SimpleNamespace(get=_async_return(_session())),
        )
        text, _ = await render_queue_view(services, OWNER)
        assert "Queue is empty" in text
        assert "0 in queue" in text


class TestGroupQueueView:
    @pytest.mark.asyncio
    async def test_requester_mentions_and_durations(self) -> None:
        from app.bot.handlers.groups import _queue_view

        items = [
            _queue_item(1, 101, "A", 120, 555),
            _queue_item(2, 102, "B", 240, 777),
        ]
        services = SimpleNamespace(
            playback=SimpleNamespace(
                now_playing=_async_return(
                    {
                        "track": _track(),
                        "status": "playing",
                        "position_seconds": 10,
                        "queue_size": 2,
                        "shuffle": False,
                        "repeat_mode": "off",
                        "autoplay": True,
                    }
                )
            ),
            queue=SimpleNamespace(get_queue=_async_return(items)),
            users=SimpleNamespace(
                get=_async_return(SimpleNamespace(first_name="Alice"))
            ),
            sessions=SimpleNamespace(get=_async_return(_session())),
        )
        text, markup = await _queue_view(services, GROUP)
        assert "⏭ <b>Up next</b>" in text
        assert "tg://user?id=555" in text and "Alice" in text
        assert "tg://user?id=777" in text
        assert "≈ 6 min" in text
        datas = _datas(markup)
        assert "grp:rep" in datas

    @pytest.mark.asyncio
    async def test_unknown_requester_falls_back_to_member(self) -> None:
        from app.bot.handlers.groups import _queue_view

        items = [_queue_item(1, 101, "A", 60, 999)]
        services = SimpleNamespace(
            playback=SimpleNamespace(now_playing=_async_return({"track": None})),
            queue=SimpleNamespace(get_queue=_async_return(items)),
            users=SimpleNamespace(get=_async_return(None)),
            sessions=SimpleNamespace(get=_async_return(_session())),
        )
        text, _ = await _queue_view(services, GROUP)
        assert "tg://user?id=999" in text
        assert ">Member<" in text


class TestGroupsNpTextUsesSharedRenderer:
    def test_badges_via_payload(self) -> None:
        from app.bot.handlers.groups import READY_TEXT, _np_text

        assert _np_text({"track": None}) == READY_TEXT
        text = _np_text(
            {
                "track": _track(),
                "status": "playing",
                "position_seconds": 30,
                "queue_size": 4,
                "shuffle": True,
                "repeat_mode": "all",
                "autoplay": False,
            }
        )
        assert "🎵 <b>NOW PLAYING</b>" in text
        assert "🔀 Shuffle" in text and "🔁 Repeat: All" in text
        assert "●" in text and "📋 4 in queue" in text


# ----------------------------------------------------------------------
# Default texts stay Telegram-HTML-safe
# ----------------------------------------------------------------------
class TestDefaultsAreTelegramHtmlSafe:
    def test_all_default_messages_parse_clean(self) -> None:
        offenders = {
            key: _unsupported_tags(text)
            for key, text in defaults.DEFAULT_MESSAGES.items()
            if _unsupported_tags(text)
        }
        assert not offenders, f"Telegram would reject: {offenders}"

    def test_start_message_has_quick_start_steps(self) -> None:
        text = defaults.DEFAULT_MESSAGES["start"]
        assert "{name}" in text  # placeholder preserved
        assert "1️⃣" in text and "2️⃣" in text and "3️⃣" in text

    def test_commands_message_documents_aliases(self) -> None:
        text = defaults.DEFAULT_MESSAGES["commands"]
        assert "(or /p)" in text and "(or /q)" in text
        assert "(or /np)" in text and "(or /next)" in text

    def test_no_results_message_guides_recovery(self) -> None:
        assert "spelling" in defaults.DEFAULT_MESSAGES["error_no_results"].lower()

    def test_empty_queue_message_invites_action(self) -> None:
        assert "autoplay" in defaults.DEFAULT_MESSAGES["empty_queue"].lower()


class TestTrackPageText:
    def test_duration_and_provider_on_one_line(self) -> None:
        from app.bot.handlers.search import track_page_text

        text = track_page_text(_track(source="audius"))
        assert "⏱ 4:00 · 🎼 Audius" in text

    def test_no_meta_line_when_unknown(self) -> None:
        from app.bot.handlers.search import track_page_text

        text = track_page_text(_track(duration_seconds=0, source=None))
        assert "⏱" not in text and "🎼" not in text

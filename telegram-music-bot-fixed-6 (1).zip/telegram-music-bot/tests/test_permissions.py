"""Group permission matrix tests (app.groups.permissions)."""

from __future__ import annotations

import pytest

from app.errors import ValidationError
from app.groups.permissions import GroupPermissions
from app.groups.service import GroupService

from .conftest import build_services

GROUP_TG = -100999
USER_A = 101  # regular member
USER_B = 102  # will become a DJ
ADMIN_USER = 777  # Telegram chat admin (never stored as member necessarily)


async def _set_mode(services, mode: str):
    return await services.group_settings_service.update(GROUP_TG, permission_mode=mode)


@pytest.fixture
async def seeded(services, db_setup):
    """A group with two synced members (A regular, B flagged DJ later)."""
    group_service = GroupService(services.groups_repo, services.members_repo)
    group = await group_service.get_or_create(
        __import__("types").SimpleNamespace(
            id=GROUP_TG, title="Perm Group", type="supergroup"
        )
    )
    await group_service.sync_member(group.id, db_setup.user_101, USER_A)
    await group_service.sync_member(group.id, db_setup.user_102, USER_B)
    return group


class TestPermissionMatrix:
    async def test_everyone_mode_allows_regular_member(self, services, seeded) -> None:
        await _set_mode(services, "everyone")
        assert await services.permissions.can(GROUP_TG, USER_A, "play") is True
        assert await services.permissions.can(GROUP_TG, USER_A, "skip") is True
        assert await services.permissions.can(GROUP_TG, USER_A, "queue") is True

    async def test_everyone_mode_settings_still_admin_only(
        self, services, seeded
    ) -> None:
        await _set_mode(services, "everyone")
        assert await services.permissions.can(GROUP_TG, USER_A, "settings") is False
        assert await services.permissions.can(GROUP_TG, USER_A, "dj_manage") is False
        assert (
            await services.permissions.can(
                GROUP_TG, USER_A, "settings", is_chat_admin=True
            )
            is True
        )

    async def test_admins_mode_only_chat_admins(self, services, seeded) -> None:
        await _set_mode(services, "admins")
        assert await services.permissions.can(GROUP_TG, USER_A, "play") is False
        assert (
            await services.permissions.can(GROUP_TG, USER_A, "play", is_chat_admin=True)
            is True
        )
        assert await services.permissions.can(GROUP_TG, USER_A, "skip") is False
        assert (
            await services.permissions.can(
                GROUP_TG, USER_A, "queue", is_chat_admin=True
            )
            is True
        )

    async def test_dj_mode_admin_or_dj(self, services, seeded) -> None:
        await _set_mode(services, "dj")
        # Regular member: denied.
        assert await services.permissions.can(GROUP_TG, USER_A, "play") is False
        # Chat admin: always allowed.
        assert (
            await services.permissions.can(GROUP_TG, USER_A, "play", is_chat_admin=True)
            is True
        )
        # Promote B to DJ → allowed.
        assert await services.permissions.set_dj(GROUP_TG, USER_B, True) is True
        assert await services.permissions.can(GROUP_TG, USER_B, "play") is True
        # Demote again → denied.
        await services.permissions.set_dj(GROUP_TG, USER_B, False)
        assert await services.permissions.can(GROUP_TG, USER_B, "play") is False

    async def test_set_dj_requires_synced_member(self, services, seeded) -> None:
        with pytest.raises(ValidationError):
            await services.permissions.set_dj(GROUP_TG, 987_654, True)

    async def test_unknown_action_denied(self, services, seeded) -> None:
        await _set_mode(services, "everyone")
        assert await services.permissions.can(GROUP_TG, USER_A, "nuke") is False

    async def test_unregistered_group_defaults_to_everyone(self, services, seeded) -> None:
        assert await services.permissions.can(-999111, USER_A, "play") is True
        # ...but settings stay admin-only even for unknown groups.
        assert await services.permissions.can(-999111, USER_A, "settings") is False

    async def test_chat_admin_can_do_everything_in_any_mode(self, services, seeded) -> None:
        for mode in ("everyone", "admins", "dj"):
            await _set_mode(services, mode)
            for action in ("play", "pause", "resume", "stop", "queue", "settings"):
                assert (
                    await services.permissions.can(
                        GROUP_TG, ADMIN_USER, action, is_chat_admin=True
                    )
                    is True
                ), (mode, action)

    async def test_list_members(self, services, seeded, db_setup) -> None:
        members = await services.permissions.list_members(GROUP_TG)
        assert {m.telegram_user_id for m in members} >= {USER_A, USER_B}

    async def test_settings_update_whitelist(self, services, seeded) -> None:
        settings = await services.group_settings_service.update(
            GROUP_TG, permission_mode="dj", volume=42, autoplay_enabled=False
        )
        assert settings.permission_mode == "dj"
        assert settings.volume == 42
        assert settings.autoplay_enabled is False

        from app.errors import ValidationError as AppValidationError

        with pytest.raises(AppValidationError):
            await services.group_settings_service.update(GROUP_TG, bogus_field=1)


class TestPermissionsIsolation:
    async def test_fresh_bundle_has_default_everyone_mode(
        self, db_setup, mk_sessions
    ) -> None:
        """Each test builds its own bundle — modes never leak between tests."""
        services = build_services(mk_sessions)
        settings = await services.group_settings_repo.get_or_create(GROUP_TG)
        assert settings.permission_mode == "everyone"
        permissions = GroupPermissions(
            services.group_settings_repo, services.members_repo
        )
        assert await permissions.can(GROUP_TG, USER_A, "play") is True

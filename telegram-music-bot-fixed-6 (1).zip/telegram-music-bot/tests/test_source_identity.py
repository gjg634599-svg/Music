"""Regression tests for the confirmed source-identity corruption bug.

Production failure (search ``hindi``):

    repo.track.created track_id=12 source=local
    music.resolver.resolved track_id=12 source=local created=true
    playback.controller playback.group_play_failed
    error="Track 12 has neither a local file nor a resolvable stream URL
           (source='local')"

Root cause chain (all links regression-locked here):

1. ``LocalSource._to_result`` stamped EVERY catalog row with
   ``source="local"`` + ``source_id=str(row.id)`` (the DB primary key!),
   destroying the row's true provider identity (e.g. ``audius`` + the
   Audius track id).
2. The resolver then upserted by the corrupted identity
   (``get_by_source('local', '<orig pk>')``) and MISSED, creating a dead
   duplicate row — the ``track_id=12 source=local`` from the log.
3. Playback routed stream resolution by the corrupted ``source='local'``
   to the LocalSource, which looked up the original row by primary key
   and found no file/stream → ``DownloadError``.

Also covered: the local-stream re-check fix in ``get_playable_path``
(the ``is_local`` branch persists ``file_path`` and returns ``None`` —
the caller must re-check the local fast path before raising) and the
legacy-duplicate self-healing that keeps pre-fix rows playable.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from app.cache.redis import MemoryCache
from app.config import Settings
from app.database.base import Base
from app.database.models.music import Track
from app.database.repositories.music import (
    AlbumRepository,
    ArtistRepository,
    GenreRepository,
    TrackRepository,
)
from app.errors import DownloadError
from app.music.models import StreamInfo
from app.music.resolver import TrackResolver
from app.music.search import SearchAggregator
from app.music.service import MusicService, _is_legacy_duplicate
from app.music.sources.local import LocalSource
from app.playback.events import EventBus
from app.storage import StorageService

from tests.test_music_download import (
    _FakeHttpSession,
    _FakeResponse,
    _MP3_BODY,
)

# ---------------------------------------------------------------------------
# Fakes
# ---------------------------------------------------------------------------


class _FakeAudiusSource:
    """Audius-shaped source: search returns ``stream_url=None`` by design."""

    name = "audius"

    def __init__(self, *, track_id: str = "DxRhR") -> None:
        self.settings = None
        self.http = None
        self._track_id = track_id
        self.get_stream_calls: list[str] = []

    def is_configured(self) -> bool:
        return True

    async def search(self, query: str, limit: int = 10) -> list:
        from app.music.models import TrackResult

        return [
            TrackResult(
                title="Hindi Song",
                artist="Test Artist",
                album=None,
                duration_seconds=180,
                source="audius",
                source_id=self._track_id,
                stream_url=None,  # Audius search payload carries no media URL
            )
        ]

    async def get_track(self, source_id: str):
        return None

    async def get_stream(self, source_id: str) -> StreamInfo | None:
        self.get_stream_calls.append(source_id)
        return StreamInfo(
            url_or_path=f"https://audius.example.test/v1/tracks/{source_id}/stream",
            is_local=False,
        )


class _NoStreamSource(_FakeAudiusSource):
    """A provider whose stream is unavailable right now."""

    async def get_stream(self, source_id: str) -> StreamInfo | None:
        self.get_stream_calls.append(source_id)
        return None


class _LocalAnswerSource(_FakeAudiusSource):
    """A 'local' adapter answering with a storage-relative file path."""

    name = "local"

    def __init__(self, file_path: str) -> None:
        super().__init__()
        self._file_path = file_path

    async def search(self, query: str, limit: int = 10) -> list:
        return []

    async def get_stream(self, source_id: str) -> StreamInfo | None:
        self.get_stream_calls.append(source_id)
        return StreamInfo(url_or_path=self._file_path, is_local=True)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def settings(tmp_path: Path) -> Settings:
    return Settings(
        bot_token="123456789:" + "A" * 33,
        storage_dir=tmp_path / "storage",
        max_audio_size_mb=45,
        http_timeout=5,
    )


@pytest.fixture()
async def db(tmp_path: Path):
    from sqlalchemy.ext.asyncio import (
        AsyncSession,
        async_sessionmaker,
        create_async_engine,
    )
    from sqlalchemy.pool import StaticPool

    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    await engine.dispose()


@pytest.fixture()
async def tracks(db) -> TrackRepository:
    return TrackRepository(db)


@pytest.fixture()
async def artists(db) -> ArtistRepository:
    return ArtistRepository(db)


@pytest.fixture()
async def albums(db) -> AlbumRepository:
    return AlbumRepository(db)


@pytest.fixture()
async def genres(db) -> GenreRepository:
    return GenreRepository(db)


@pytest.fixture()
def storage(settings: Settings) -> StorageService:
    return StorageService(settings.storage_dir)


@pytest.fixture(autouse=True)
def _no_dns(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("app.music.service.validate_url", lambda url: url)
    monkeypatch.setattr(
        "app.music.sources.url_resolver.validate_url", lambda url: url
    )


async def _seed_row(tracks: TrackRepository, artists: ArtistRepository | None = None, **overrides) -> Track:
    fields = dict(
        title="Hindi Song",
        source="audius",
        source_id="DxRhR",
        stream_url=None,
        is_playable=True,
    )
    fields.update(overrides)
    if artists is not None and "artist_id" not in overrides:
        artist = await artists.get_or_create("Test Artist")
        fields["artist_id"] = artist.id
    return await tracks.create(**fields)


def _audius_http() -> _FakeHttpSession:
    """HTTP script for one successful Audius stream download."""
    return _FakeHttpSession(
        [
            _FakeResponse(status=200),  # redirect probe (no Location header)
            _FakeResponse(status=200, body=_MP3_BODY),  # the audio payload
        ]
    )


def _make_service(
    settings: Settings,
    tracks: TrackRepository,
    artists: ArtistRepository,
    albums: AlbumRepository,
    genres: GenreRepository,
    http: _FakeHttpSession,
    sources: list,
) -> MusicService:
    """A real MusicService with the REAL resolver and REAL LocalSource."""
    resolver = TrackResolver(tracks, artists, albums, genres)
    aggregator = SearchAggregator(list(sources), MemoryCache())
    return MusicService(
        sources=list(sources),
        aggregator=aggregator,
        resolver=resolver,
        tracks=tracks,
        metadata=None,  # type: ignore[arg-type]
        storage=StorageService(settings.storage_dir),
        cache=MemoryCache(),
        events=EventBus(),
        settings=settings,
        http=http,  # type: ignore[arg-type]
    )


# ---------------------------------------------------------------------------
# 1. Provider identity preserved by LocalSource._to_result
# ---------------------------------------------------------------------------
class TestToResultIdentity:
    def test_catalog_row_keeps_provider_source_and_id(self) -> None:
        row = Track(
            id=7,
            title="Hindi Song",
            source="audius",
            source_id="DxRhR",
            file_path=None,
            stream_url=None,
        )
        result = LocalSource._to_result(row)
        assert result.source == "audius"
        assert result.source_id == "DxRhR"
        # The database primary key stays available for UI callbacks only.
        assert result.extra["track_id"] == 7

    def test_upload_row_keeps_upload_identity(self) -> None:
        row = Track(
            id=8,
            title="My Upload",
            source="upload",
            source_id="deadbeef",
            file_path="uploads/u-8.mp3",
        )
        result = LocalSource._to_result(row)
        assert result.source == "upload"
        assert result.source_id == "deadbeef"
        assert result.extra["track_id"] == 8
        assert result.extra["file_path"] == "uploads/u-8.mp3"

    def test_genuine_local_row_keeps_local_identity(self) -> None:
        row = Track(
            id=9, title="Local File", source="local", source_id="9",
            file_path="downloads/track-9.mp3",
        )
        result = LocalSource._to_result(row)
        assert result.source == "local"
        assert result.source_id == "9"
        assert result.stream_url is None


# ---------------------------------------------------------------------------
# 2. Local search returns the ORIGINAL provider identity
# ---------------------------------------------------------------------------
class TestLocalSearchIdentity:
    async def test_catalog_search_returns_audius_identity(
        self, settings, tracks, artists, storage
    ) -> None:
        await _seed_row(tracks, artists)
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        results = await local.search("hindi")
        assert len(results) == 1
        assert results[0].source == "audius"
        assert results[0].source_id == "DxRhR"

    async def test_legacy_dead_row_search_returns_original(
        self, settings, tracks, artists, storage
    ) -> None:
        """The production scenario: original Audius row + dead duplicate."""
        original = await _seed_row(tracks, artists)  # row 1: source=audius, DxRhR
        # Dead duplicate exactly as the old resolver created it:
        # source='local', source_id = str(original PK).
        await tracks.create(
            title="Hindi Song",
            source="local",
            source_id=str(original.id),
            stream_url=None,
            is_playable=True,
        )
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        results = await local.search("hindi")
        # One result, and it is the ORIGINAL Audius row — not a 'local' row.
        assert len(results) == 1
        assert results[0].source == "audius"
        assert results[0].source_id == "DxRhR"
        assert results[0].extra["track_id"] == original.id

    async def test_dead_row_without_original_is_skipped(
        self, settings, tracks
    ) -> None:
        await tracks.create(
            title="Ghost",
            source="local",
            source_id="999",  # no row 999 exists
            stream_url=None,
            is_playable=True,
        )
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        results = await local.search("ghost")
        assert results == []

    async def test_unplayable_plain_local_row_without_media_is_skipped(
        self, settings, tracks
    ) -> None:
        """'local' rows with neither file, URL nor pointer cannot play."""
        await tracks.create(
            title="Empty Shell",
            source="local",
            source_id="test-1",  # non-numeric: not a legacy pointer
            stream_url=None,
            is_playable=True,
        )
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        assert await local.search("empty") == []

    async def test_fileless_remote_row_is_returned(
        self, settings, tracks
    ) -> None:
        """Remote rows without a URL stay searchable (adapter resolves)."""
        await _seed_row(tracks, title="No URL Yet")
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        results = await local.search("no url")
        assert len(results) == 1
        assert results[0].source == "audius"


# ---------------------------------------------------------------------------
# 3. The production failure: search → resolver → playback
# ---------------------------------------------------------------------------
class TestSearchToPlaybackPipeline:
    async def test_repeated_search_creates_no_duplicate_rows(
        self, settings, tracks, artists, albums, genres
    ) -> None:
        """Search 'hindi' twice with the SAME Audius result → ONE row."""
        audius = _FakeAudiusSource()
        service = _make_service(
            settings, tracks, artists, albums, genres,
            _FakeHttpSession([]), [audius],
        )
        first = await service.search("hindi")
        second = await service.search("hindi")
        # Different cache keys? Aggregator caches per (query, limit) — the
        # second call hits the cache, but both must resolve to ONE row.
        ids_first = [t.id for t in first]
        ids_second = [t.id for t in second]
        assert ids_first == ids_second
        assert len(ids_first) == 1
        row = await tracks.get(ids_first[0])
        assert row.source == "audius"
        assert row.source_id == "DxRhR"

    async def test_cached_audius_row_in_catalog_does_not_become_local(
        self, settings, tracks, artists, albums, genres
    ) -> None:
        """THE production regression: catalog row returned through the local
        source must keep its Audius identity so the resolver reuses the
        existing row instead of creating a dead 'local' duplicate."""
        # Pre-existing Audius row in the catalog (from an earlier search).
        original = await _seed_row(tracks, artists)

        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        audius = _NoStreamSource()  # fresh search would find it too
        service = _make_service(
            settings, tracks, artists, albums, genres,
            _FakeHttpSession([]), [local, audius],
        )
        # Fresh search so the aggregator does NOT use the 5-minute cache
        # for the second call below.
        found = await service.search("hindi")
        assert len(found) == 1
        assert found[0].id == original.id
        assert found[0].source == "audius"
        # No dead 'local' duplicate was created.
        all_rows = await tracks.search_catalog("hindi", limit=10)
        assert len(all_rows) == 1
        assert all_rows[0].source == "audius"

    async def test_full_chain_routes_stream_to_audius_adapter(
        self, settings, tracks, artists, albums, genres, storage
    ) -> None:
        """search → resolver → get_playable_path asks the AUDIUS adapter
        with the PROVIDER id — the exact broken link in production."""
        audius = _FakeAudiusSource()
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        service = _make_service(
            settings, tracks, artists, albums, genres,
            _audius_http(), [local, audius],
        )
        found = await service.search("hindi")
        assert len(found) == 1
        track = found[0]
        assert track.source == "audius"

        path = await service.get_playable_path(track)
        assert path.is_absolute()
        assert path.is_file() and path.stat().st_size > 0
        # The Audius adapter was called with the PROVIDER id, never the
        # database primary key.
        assert audius.get_stream_calls == ["DxRhR"]

    async def test_playback_failure_not_masked_as_success(
        self, settings, tracks, artists, albums, genres
    ) -> None:
        """When no adapter can resolve the stream, the caller gets a typed
        DownloadError (never a fake success) — and the error mentions the
        actual provider."""
        audius = _NoStreamSource()
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        service = _make_service(
            settings, tracks, artists, albums, genres,
            _FakeHttpSession([]), [local, audius],
        )
        found = await service.search("hindi")
        with pytest.raises(DownloadError):
            await service.get_playable_path(found[0])
        assert audius.get_stream_calls == ["DxRhR"]


# ---------------------------------------------------------------------------
# 4. Legacy dead-row playback self-healing
# ---------------------------------------------------------------------------
class TestLegacyDuplicateHealing:
    async def test_queued_dead_row_resolves_through_original_provider(
        self, settings, tracks, artists, albums, genres, storage
    ) -> None:
        """A dead 'local' row already queued (pre-fix production data)
        plays by delegating to the original row's provider — and both
        rows are healed with the resolved URL."""
        original = await _seed_row(tracks, artists)  # row 1: audius / DxRhR
        dead = await tracks.create(
            title="Hindi Song",
            source="local",
            source_id=str(original.id),
            stream_url=None,
            is_playable=True,
        )

        audius = _FakeAudiusSource()
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        service = _make_service(
            settings, tracks, artists, albums, genres,
            _audius_http(), [local, audius],
        )

        path = await service.get_playable_path(dead)
        assert path.is_absolute() and path.is_file()
        # Provider id used for resolution:
        assert audius.get_stream_calls == ["DxRhR"]

        # Both rows self-healed with the stream URL.
        reloaded_dead = await tracks.get(dead.id)
        reloaded_original = await tracks.get(original.id)
        assert reloaded_dead.stream_url and reloaded_dead.stream_url.startswith("https://")
        assert reloaded_original.stream_url == reloaded_dead.stream_url

    async def test_healed_dead_row_plays_directly_next_time(
        self, settings, tracks, artists, albums, genres, storage
    ) -> None:
        original = await _seed_row(tracks, artists)
        dead = await tracks.create(
            title="Hindi Song",
            source="local",
            source_id=str(original.id),
            stream_url=None,
            is_playable=True,
        )
        audius = _FakeAudiusSource()
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        service = _make_service(
            settings, tracks, artists, albums, genres,
            _audius_http() , [local, audius],
        )
        await service.get_playable_path(dead)  # first play heals
        # Second play: the healed row carries stream_url — the provider is
        # not even consulted again (the URL is already on the row).
        assert audius.get_stream_calls == ["DxRhR"]
        http2 = _FakeHttpSession(
            [
                _FakeResponse(status=200),
                _FakeResponse(status=200, body=_MP3_BODY),
            ]
        )
        service2 = _make_service(
            settings, tracks, artists, albums, genres, http2, [local, audius]
        )
        dead2 = await tracks.get(dead.id)
        path = await service2.get_playable_path(dead2)
        assert path.is_file()
        assert audius.get_stream_calls == ["DxRhR"]  # no extra get_stream call

    async def test_local_file_original_copies_path_onto_dead_row(
        self, settings, tracks, artists, storage
    ) -> None:
        """Dead row pointing at an original WITH a local file: the file
        path is copied onto the dead row (the re-check fix makes the
        caller pick it up instead of failing)."""
        # An original row with a real local file on disk.
        rel = "uploads/u-1.mp3"
        target = storage.resolve(rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(_MP3_BODY)
        original = await _seed_row(
            tracks, source="upload", source_id="hash1", file_path=rel
        )
        dead = await tracks.create(
            title="Hindi Song",
            source="local",
            source_id=str(original.id),
            stream_url=None,
            is_playable=True,
        )
        # No remote adapters at all — resolution must succeed locally.
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        service = MusicService(
            sources=[local],
            aggregator=SearchAggregator([local], MemoryCache()),
            resolver=TrackResolver(tracks, artists, albums, genres),
            tracks=tracks,
            metadata=None,  # type: ignore[arg-type]
            storage=storage,
            cache=MemoryCache(),
            events=EventBus(),
            settings=settings,
            http=_FakeHttpSession([]),  # type: ignore[arg-type]
        )
        path = await service.get_playable_path(dead)
        assert path.is_absolute() and path.is_file()
        reloaded = await tracks.get(dead.id)
        assert reloaded.file_path == rel


# ---------------------------------------------------------------------------
# 5. The local-stream re-check fix
# ---------------------------------------------------------------------------
class TestLocalStreamRecheck:
    async def test_local_adapter_answer_returns_path_not_error(
        self, settings, tracks, artists, storage
    ) -> None:
        """The ``is_local`` branch persists file_path and returns None —
        the caller MUST re-check the local fast path before raising
        DownloadError (previously it raised unconditionally)."""
        rel = "downloads/track-5.mp3"
        target = storage.resolve(rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(_MP3_BODY)

        # A 'local'-source track whose stream must come from the adapter.
        track = await _seed_row(
            tracks, title="From Adapter", source="local", source_id="77",
            file_path=None, stream_url=None,
        )
        # The adapter answers with the storage-relative file path (like the
        # legacy pointer path does through LocalSource.get_stream).
        source = _LocalAnswerSource(rel)
        service = MusicService(
            sources=[source],
            aggregator=SearchAggregator([source], MemoryCache()),
            resolver=TrackResolver(tracks, artists, albums, genres),
            tracks=tracks,
            metadata=None,  # type: ignore[arg-type]
            storage=storage,
            cache=MemoryCache(),
            events=EventBus(),
            settings=settings,
            http=_FakeHttpSession([]),  # type: ignore[arg-type]
        )
        path = await service.get_playable_path(track)
        assert path.is_absolute() and path.is_file()
        assert source.get_stream_calls == ["77"]


# ---------------------------------------------------------------------------
# 6. new_releases legacy filtering
# ---------------------------------------------------------------------------
class TestNewReleasesFilter:
    def test_is_legacy_duplicate_shape(self) -> None:
        dead = Track(
            id=12, title="X", source="local", source_id="11",
            file_path=None, stream_url=None,
        )
        original = Track(
            id=11, title="X", source="audius", source_id="DxRhR",
            file_path=None, stream_url=None,
        )
        upload = Track(
            id=13, title="U", source="upload", source_id="h1",
            file_path="uploads/u.mp3",
        )
        plain_local = Track(
            id=14, title="L", source="local", source_id="14",
            file_path=None, stream_url=None,
        )
        assert _is_legacy_duplicate(dead)
        assert not _is_legacy_duplicate(original)
        assert not _is_legacy_duplicate(upload)
        assert not _is_legacy_duplicate(plain_local)  # points at itself

    async def test_new_releases_hides_legacy_dead_rows(
        self, settings, tracks, artists, albums, genres
    ) -> None:
        original = await _seed_row(tracks, title="Keep Me")
        await tracks.create(
            title="Keep Me",
            source="local",
            source_id=str(original.id),
            stream_url=None,
            is_playable=True,
        )
        local = LocalSource(settings, http=None, sessions=tracks._session)  # type: ignore[arg-type]
        service = _make_service(
            settings, tracks, artists, albums, genres,
            _FakeHttpSession([]), [local],
        )
        rows, total = await service.new_releases(limit=10)
        assert [row.id for row in rows] == [original.id]

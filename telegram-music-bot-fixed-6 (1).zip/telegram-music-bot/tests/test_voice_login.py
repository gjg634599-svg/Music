"""Voice-account login wizard tests (no network, no real Telethon auth).

The :class:`~app.voice.login.VoiceLoginService` state machine is exercised
end-to-end with a duck-typed fake Telethon client: admin binding, phone
validation, login codes (valid / invalid / expired / 2FA), passwords,
duplicates, encrypted persistence, cancellation, expiry and cleanup.

The CLI fallback (scripts/add_voice_account.py) reuses the same service
class, which is asserted by import.
"""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from app.config import Settings, VoiceSettings
from app.database.repositories.voice import VoiceRepository
from app.security.encryption import SessionCipher
from app.voice.login import (
    LOGIN_IDLE_TIMEOUT_SECONDS,
    LoginState,
    VoiceLoginService,
    mask_phone,
    normalize_phone,
    validate_code,
)

ADMIN = 4242
PHONE = "+989123456789"
SECRET_SESSION = "fake-session-string-never-logged"

FERNET_KEY = SessionCipher.__module__  # placeholder replaced below


def _settings(*, voice_enabled: bool = True) -> Settings:
    return Settings(
        bot_token="123456789:" + "A" * 33,
        telegram_api_id=123456 if voice_enabled else None,
        telegram_api_hash="a" * 32 if voice_enabled else None,
        voice=VoiceSettings(encryption_key=_fernet_key()),
    )


_FERNET = None


def _fernet_key() -> str:
    global _FERNET
    if _FERNET is None:
        from cryptography.fernet import Fernet

        _FERNET = Fernet.generate_key().decode()
    return _FERNET


class FakeTelethonClient:
    """Duck-typed Telethon client scripting the whole login flow."""

    def __init__(
        self,
        *,
        needs_password: bool = False,
        sign_in_error: Exception | None = None,
        send_code_error: Exception | None = None,
        me: SimpleNamespace | None = None,
        authorize_on_sign_in: bool = True,
    ) -> None:
        self.needs_password = needs_password
        self._sign_in_error = sign_in_error
        self._send_code_error = send_code_error
        self._me = me or SimpleNamespace(id=999000111, username="voice_acc")
        self._authorize_on_sign_in = authorize_on_sign_in
        self.connected = False
        self.disconnected = False
        self.calls: list[tuple[str, dict]] = []
        self.session = SimpleNamespace(marker="fake")

    # -- connection -----------------------------------------------------
    async def connect(self) -> None:
        self.calls.append(("connect", {}))
        self.connected = True

    async def disconnect(self) -> None:
        self.calls.append(("disconnect", {}))
        self.connected = False
        self.disconnected = True

    def is_connected(self) -> bool:
        return self.connected

    # -- auth flow --------------------------------------------------------
    async def send_code_request(self, phone: str) -> None:
        self.calls.append(("send_code_request", {"phone": phone}))
        if self._send_code_error is not None:
            raise self._send_code_error

    async def sign_in(self, phone: str | None = None, code: str | None = None,
                      password: str | None = None) -> None:
        self.calls.append(("sign_in", {"phone": phone, "code": code, "password": password}))
        if self._sign_in_error is not None:
            raise self._sign_in_error
        if password is None and self.needs_password:
            raise _fake_error("SessionPasswordNeededError")

    async def is_user_authorized(self) -> bool:
        return self._authorize_on_sign_in and not (
            self.needs_password and not any(
                call[0] == "sign_in" and call[1].get("password") for call in self.calls
            )
        )

    async def get_me(self) -> SimpleNamespace:
        self.calls.append(("get_me", {}))
        return self._me


def _fake_error(name: str, seconds: int | None = None) -> Exception:
    """Create an exception whose class *name* matches a Telethon error."""
    cls = type(name, (Exception,), {})
    exc = cls()
    if seconds is not None:
        exc.seconds = seconds  # type: ignore[attr-defined]
    return exc


@pytest.fixture
def cipher() -> SessionCipher:
    return SessionCipher(_fernet_key())


@pytest.fixture
def factory_hooks():
    """Track on_account_saved invocations."""
    return SimpleNamespace(called=0)

    async def hook() -> None:
        factory_hooks.called += 1

    factory_hooks.hook = hook  # type: ignore[attr-defined]
    return factory_hooks


def make_service(
    mk_sessions,
    *,
    settings: Settings | None = None,
    client: FakeTelethonClient | None = None,
    cipher: SessionCipher | None = None,
    on_saved=None,
) -> VoiceLoginService:
    """Build the service wired to the fake client factory."""
    settings = settings or _settings()
    if cipher is None:
        cipher = SessionCipher(_fernet_key())
    client = client or FakeTelethonClient()
    service = VoiceLoginService(
        settings,
        mk_sessions,
        cipher,
        client_factory=lambda StringSession, cfg: client,
        on_account_saved=on_saved,
    )
    # The fake session cannot be exported by Telethon's StringSession.
    service._export_session = lambda c: SECRET_SESSION  # type: ignore[method-assign]
    return service


# ----------------------------------------------------------------------
# Input validation
# ----------------------------------------------------------------------
class TestValidation:
    def test_phone_normalized(self) -> None:
        assert normalize_phone("+98 912 345 6789") == "+989123456789"
        assert normalize_phone("989123456789") == "+989123456789"
        assert normalize_phone(" +1-555-123-4567 ") == "+15551234567"

    def test_phone_invalid(self) -> None:
        from app.errors import ValidationError

        with pytest.raises(ValidationError):
            normalize_phone("not-a-phone")
        with pytest.raises(ValidationError):
            normalize_phone("")
        with pytest.raises(ValidationError):
            normalize_phone("12345")  # too short

    def test_bot_token_rejected(self) -> None:
        from app.errors import ValidationError

        with pytest.raises(ValidationError):
            normalize_phone("8041509872:" + "A" * 35)

    def test_code_validation(self) -> None:
        assert validate_code("12345") == "12345"
        assert validate_code(" 12 345 ") == "12345"
        from app.errors import ValidationError

        with pytest.raises(ValidationError):
            validate_code("abcde")
        with pytest.raises(ValidationError):
            validate_code("")

    def test_mask_phone(self) -> None:
        assert mask_phone("+989123456789") == "+98***89"
        assert "***" in mask_phone("12345")


# ----------------------------------------------------------------------
# State machine: happy path
# ----------------------------------------------------------------------
class TestHappyPath:
    async def test_full_flow_without_2fa(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient()
        service = make_service(mk_sessions, client=client, cipher=cipher)

        began = await service.begin(ADMIN)
        assert began.state is LoginState.WAITING_FOR_PHONE

        phone_result = await service.submit_phone(ADMIN, PHONE)
        assert phone_result.state is LoginState.WAITING_FOR_CODE
        assert client.calls[0][0] == "connect"
        assert client.calls[-1] == ("send_code_request", {"phone": PHONE})

        code_result = await service.submit_code(ADMIN, "54321")
        assert code_result.state is LoginState.COMPLETED
        assert code_result.telegram_id == 999000111
        assert code_result.username == "voice_acc"

        # The temp client is disconnected and the context is gone.
        assert client.disconnected is True
        assert service.active_state(ADMIN) is None

        # Account persisted, encrypted with our cipher.
        repo = VoiceRepository(mk_sessions)
        accounts = await repo.list_accounts()
        assert len(accounts) == 1
        assert accounts[0].telegram_id == 999000111
        assert accounts[0].username == "voice_acc"
        assert accounts[0].status == "offline"
        assert accounts[0].phone_hint == "+98***89"
        assert accounts[0].session_encrypted != SECRET_SESSION
        assert cipher.decrypt(accounts[0].session_encrypted) == SECRET_SESSION

    async def test_full_flow_with_2fa(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient(needs_password=True)
        service = make_service(mk_sessions, client=client, cipher=cipher)

        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        result = await service.submit_code(ADMIN, "11111")
        assert result.state is LoginState.WAITING_FOR_2FA

        final = await service.submit_password(ADMIN, "correct horse battery")
        assert final.state is LoginState.COMPLETED
        sign_in_calls = [call for call in client.calls if call[0] == "sign_in"]
        assert len(sign_in_calls) == 2
        assert sign_in_calls[0][1]["code"] == "11111"
        assert sign_in_calls[1][1]["password"] == "correct horse battery"
        assert any(call[0] == "get_me" for call in client.calls)
        # Client always disconnected at the end of the flow.
        assert client.calls[-1][0] == "disconnect"

    async def test_auto_label(self, db_setup, mk_sessions, cipher) -> None:
        service = make_service(mk_sessions, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        result = await service.submit_code(ADMIN, "54321")
        repo = VoiceRepository(mk_sessions)
        accounts = await repo.list_accounts()
        assert accounts[0].label == "Account 1"

    async def test_custom_label_and_limits(self, db_setup, mk_sessions, cipher) -> None:
        service = make_service(mk_sessions, cipher=cipher)
        await service.begin(ADMIN, label="Backup", max_sessions=3, priority=7)
        await service.submit_phone(ADMIN, PHONE, label="Backup")
        await service.submit_code(ADMIN, "54321")
        repo = VoiceRepository(mk_sessions)
        account = (await repo.list_accounts())[0]
        assert account.label == "Backup"
        assert account.max_sessions == 3
        assert account.priority == 7

    async def test_on_account_saved_hook(self, db_setup, mk_sessions, cipher) -> None:
        hook_state = SimpleNamespace(called=0)

        async def hook() -> None:
            hook_state.called += 1

        service = make_service(mk_sessions, cipher=cipher, on_saved=hook)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        await service.submit_code(ADMIN, "54321")
        assert hook_state.called == 1


# ----------------------------------------------------------------------
# Admin binding & authorization
# ----------------------------------------------------------------------
class TestAdminBinding:
    async def test_other_admin_cannot_continue(self, db_setup, mk_sessions, cipher) -> None:
        service = make_service(mk_sessions, cipher=cipher)
        await service.begin(ADMIN)
        # A different admin has no context — cannot hijack the flow.
        result = await service.submit_phone(ADMIN + 1, PHONE)
        assert result.state is LoginState.EXPIRED
        assert result.ok is False

    async def test_begin_restarts_existing_flow(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient()
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        assert client.connected
        # Starting over disposes the previous client.
        await service.begin(ADMIN)
        assert client.disconnected is True


# ----------------------------------------------------------------------
# Error paths
# ----------------------------------------------------------------------
class TestErrorPaths:
    async def test_invalid_code_is_retryable(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient(
            sign_in_error=_fake_error("PhoneCodeInvalidError")
        )
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        result = await service.submit_code(ADMIN, "00000")
        assert result.state is LoginState.WAITING_FOR_CODE
        assert result.retry is True
        assert service.active_state(ADMIN) is LoginState.WAITING_FOR_CODE

    async def test_expired_code_is_retryable(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient(
            sign_in_error=_fake_error("PhoneCodeExpiredError")
        )
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        result = await service.submit_code(ADMIN, "00000")
        assert result.retry is True
        assert "expired" in result.message.lower()

    async def test_invalid_password_is_retryable(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient(
            needs_password=True,
        )
        # First submit_code → 2FA; then a wrong password error.
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        await service.submit_code(ADMIN, "12345")
        client._sign_in_error = _fake_error("PasswordHashInvalidError")
        result = await service.submit_password(ADMIN, "wrong")
        assert result.state is LoginState.WAITING_FOR_2FA
        assert result.retry is True
        # A correct retry then completes the flow.
        client._sign_in_error = None
        final = await service.submit_password(ADMIN, "right")
        assert final.state is LoginState.COMPLETED

    async def test_flood_wait_fails_cleanly(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient(
            sign_in_error=_fake_error("FloodWaitError", seconds=120)
        )
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        result = await service.submit_code(ADMIN, "12345")
        assert result.state is LoginState.FAILED
        assert "120" in result.message
        assert client.disconnected
        assert service.active_state(ADMIN) is None

    async def test_invalid_phone_at_code_request(
        self, db_setup, mk_sessions, cipher
    ) -> None:
        client = FakeTelethonClient(
            send_code_error=_fake_error("PhoneNumberInvalidError")
        )
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        result = await service.submit_phone(ADMIN, PHONE)
        assert result.state is LoginState.FAILED
        assert result.ok is False
        assert client.disconnected

    async def test_duplicate_account_detected(self, db_setup, mk_sessions, cipher) -> None:
        # Pre-existing account with the same Telegram id.
        repo = VoiceRepository(mk_sessions)
        await repo.create(
            "Existing",
            cipher.encrypt("existing-session"),
            telegram_id=999000111,
            username="voice_acc",
        )
        client = FakeTelethonClient()
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        result = await service.submit_code(ADMIN, "54321")
        assert result.state is LoginState.FAILED
        assert "already connected" in result.message
        assert client.disconnected
        # No second row was created.
        assert len(await repo.list_accounts(include_disabled=True)) == 1

    async def test_voice_not_configured(self, mk_sessions, cipher) -> None:
        service = make_service(mk_sessions, settings=_settings(voice_enabled=False), cipher=cipher)
        result = await service.begin(ADMIN)
        assert result.state is LoginState.FAILED
        assert "not configured" in result.message


# ----------------------------------------------------------------------
# Cancellation & expiry
# ----------------------------------------------------------------------
class TestCancellation:
    async def test_cancel_disconnects_client(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient()
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        result = await service.cancel(ADMIN)
        assert result.state is LoginState.CANCELLED
        assert client.disconnected
        assert service.active_state(ADMIN) is None

    async def test_cancel_without_flow(self, db_setup, mk_sessions, cipher) -> None:
        service = make_service(mk_sessions, cipher=cipher)
        result = await service.cancel(ADMIN)
        assert result.state is LoginState.IDLE

    async def test_no_account_created_after_cancel(
        self, db_setup, mk_sessions, cipher
    ) -> None:
        service = make_service(mk_sessions, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        await service.cancel(ADMIN)
        repo = VoiceRepository(mk_sessions)
        assert await repo.list_accounts() == []

    async def test_gc_expires_abandoned_flow(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient()
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        # Simulate the idle timeout passing.
        context = service._contexts[ADMIN]
        context.last_activity -= LOGIN_IDLE_TIMEOUT_SECONDS + 1
        expired = await service.gc()
        assert ADMIN in expired
        assert client.disconnected
        assert service.active_state(ADMIN) is None

    async def test_expired_flow_rejects_code(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient()
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        context = service._contexts[ADMIN]
        context.last_activity -= LOGIN_IDLE_TIMEOUT_SECONDS + 1
        result = await service.submit_code(ADMIN, "12345")
        assert result.state is LoginState.EXPIRED
        assert result.ok is False


# ----------------------------------------------------------------------
# Wizard handler integration (service ↔ handlers, fake Telegram objects)
# ----------------------------------------------------------------------
class TestWizardHandlers:
    async def test_handlers_use_shared_service(self) -> None:
        """The CLI fallback imports the same service class as the wizard."""
        import importlib.util
        from pathlib import Path

        spec = importlib.util.spec_from_file_location(
            "add_voice_account_cli",
            Path("scripts/add_voice_account.py"),
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        assert module.VoiceLoginService is VoiceLoginService


# ----------------------------------------------------------------------
# Secrets never reach logs or results
# ----------------------------------------------------------------------
class TestSecretHygiene:
    async def test_no_phone_in_messages(self, db_setup, mk_sessions, cipher) -> None:
        from dataclasses import asdict

        client = FakeTelethonClient()
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        result = await service.submit_phone(ADMIN, PHONE)
        assert PHONE not in result.message
        assert PHONE not in repr(result)
        assert PHONE not in str(asdict(result))

    async def test_no_session_string_in_result(self, db_setup, mk_sessions, cipher) -> None:
        from dataclasses import asdict

        client = FakeTelethonClient()
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        result = await service.submit_code(ADMIN, "54321")
        assert SECRET_SESSION not in repr(result)
        assert SECRET_SESSION not in str(asdict(result))

    async def test_phone_only_masked_hint_stored(self, db_setup, mk_sessions, cipher) -> None:
        client = FakeTelethonClient()
        service = make_service(mk_sessions, client=client, cipher=cipher)
        await service.begin(ADMIN)
        await service.submit_phone(ADMIN, PHONE)
        await service.submit_code(ADMIN, "54321")
        repo = VoiceRepository(mk_sessions)
        account = (await repo.list_accounts())[0]
        assert PHONE not in (account.phone_hint or "")
        assert account.phone_hint == "+98***89"

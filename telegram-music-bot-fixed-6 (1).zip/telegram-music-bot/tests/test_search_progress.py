"""Animated search UX tests — progress reporter + timeout-bounded aggregator.

Everything runs with fake Telegram messages, fake music sources, a virtual
clock and a virtual sleeper: the ten-second escalation is verified **without
sleeping ten real seconds**, and no test performs network I/O.

Covers (master prompt §5.7 / §12):
immediate acknowledgement, same-message edits, ten-second escalation,
fast/slow providers, per-source timeout + partial failure, overall timeout
with partial results, empty results, total failure, cancellation,
superseding searches, animation cleanup, RetryAfter back-off, query
escaping, final keyboard/pagination and duplicate-track prevention.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from typing import Any

import pytest

from app.cache.redis import MemoryCache
from app.errors import MusicSourceError
from app.music.models import TrackResult
from app.music.search import SearchAggregator
from app.bot.search_progress import (
    DEFAULT_ESCALATION_TEXT,
    SPINNER_FRAMES,
    SearchProgressReporter,
    cancel_active,
)


# ----------------------------------------------------------------------
# Fakes
# ----------------------------------------------------------------------
class FakeStatusMessage:
    """The single progress message — records every edit."""

    def __init__(self) -> None:
        self.edits: list[tuple[str, Any]] = []
        self.fail_with: Exception | None = None
        self.fail_once = False

    async def edit_text(self, text: str, **kwargs: Any) -> "FakeStatusMessage":
        if self.fail_with is not None:
            exc, self.fail_with = self.fail_with, None
            if not self.fail_once:
                self.fail_with = None
            raise exc
        self.edits.append((text, kwargs.get("reply_markup")))
        return self

    @property
    def last_text(self) -> str:
        return self.edits[-1][0] if self.edits else ""


class FakeChat:
    def __init__(self, chat_id: int = 101) -> None:
        self.id = chat_id


class FakeOriginMessage:
    """The message the user sent — answers with a FakeStatusMessage."""

    def __init__(self, chat_id: int = 101) -> None:
        self.chat = FakeChat(chat_id)
        self.answered: list[str] = []

    async def answer(self, text: str, **kwargs: Any) -> FakeStatusMessage:
        self.answered.append(text)
        status = FakeStatusMessage()
        status.edits.append((text, kwargs.get("reply_markup")))
        return status


class FakeClock:
    """Manually advanced monotonic clock."""

    def __init__(self, start: float = 0.0) -> None:
        self.now = start

    def __call__(self) -> float:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += seconds


class FakeSleeper:
    """Sleep that advances the fake clock instead of blocking."""

    def __init__(self, clock: FakeClock) -> None:
        self.clock = clock
        self.sleeps: list[float] = []

    async def __call__(self, seconds: float) -> None:
        self.sleeps.append(seconds)
        self.clock.advance(seconds)
        await asyncio.sleep(0)  # yield control to the event loop


class FakeSource:
    """A music source stub with a scriptable delay / error / results."""

    def __init__(
        self,
        name: str,
        *,
        results: int = 0,
        delay: float = 0.0,
        error: Exception | None = None,
        configured: bool = True,
    ) -> None:
        self.name = name
        self._results = results
        self._delay = delay
        self._error = error
        self._configured = configured
        self.calls = 0

    def is_configured(self) -> bool:
        return self._configured

    async def search(self, query: str, limit: int = 10) -> list[TrackResult]:
        self.calls += 1
        if self._delay:
            await asyncio.sleep(self._delay)
        if self._error is not None:
            raise self._error
        return [
            TrackResult(
                title=f"{self.name} track {i} for {query}",
                artist="Artist",
                album=None,
                duration_seconds=180 + i,
                source=self.name.lower(),
                source_id=f"{self.name.lower()}-{i}",
            )
            for i in range(self._results)
        ]


def _make_reporter(
    *,
    chat_id: int = 101,
    clock: FakeClock | None = None,
    sleeper: FakeSleeper | None = None,
    escalation_after: float = 10.0,
    edit_interval: float = 3.0,
    source_names: list[str] | None = None,
) -> tuple[SearchProgressReporter, FakeOriginMessage, FakeClock, FakeSleeper]:
    clock = clock or FakeClock()
    sleeper = sleeper or FakeSleeper(clock)
    origin = FakeOriginMessage(chat_id)
    reporter = SearchProgressReporter(
        origin,
        "Bang bang",
        source_names=source_names or [],
        escalation_text=DEFAULT_ESCALATION_TEXT,
        edit_interval=edit_interval,
        escalation_after=escalation_after,
        clock=clock,
        sleeper=sleeper,
    )
    return reporter, origin, clock, sleeper


# ----------------------------------------------------------------------
# Reporter: acknowledgement and animation
# ----------------------------------------------------------------------
class TestAcknowledgement:
    async def test_immediate_ack_before_any_edit(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter()
        status = await reporter.start()
        # The acknowledgement is the FIRST recorded content.
        assert "Searching Music" in origin.answered[0]
        assert "Bang bang" in origin.answered[0]
        assert "Finding matching tracks" in origin.answered[0]
        assert "Sources: Initializing" in origin.answered[0]
        assert status is not None
        reporter.stop()

    async def test_query_is_escaped(self) -> None:
        origin = FakeOriginMessage()
        reporter = SearchProgressReporter(origin, "<b>Bang & bang</b>")
        await reporter.start()
        assert "&lt;b&gt;Bang &amp; bang&lt;/b&gt;" in origin.answered[0]
        reporter.stop()


class TestAnimation:
    async def test_spinner_edits_same_message(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter()
        status = await reporter.start()
        # Advance 4 frames of virtual time.
        for _ in range(4):
            await asyncio.sleep(0)  # let the animation task run one loop pass
        reporter.stop()
        texts = [text for text, _ in status.edits]
        # At least the acknowledgement + one spinner frame were rendered.
        assert len(texts) >= 2
        assert any(frame in text for text in texts for frame in SPINNER_FRAMES)

    async def test_ten_second_escalation_with_mocked_clock(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter(escalation_after=10.0)
        status = await reporter.start()
        # Advance virtual time in 3-second ticks — 10 virtual seconds pass
        # without any real waiting.
        for _ in range(4):
            await asyncio.sleep(0)
        clock.advance(12.0)  # jump past the escalation deadline
        await asyncio.sleep(0)
        await asyncio.sleep(0)
        reporter.stop()
        texts = [text for text, _ in status.edits]
        assert any("Still Searching" in text for text in texts), texts
        assert any("Babby, I'm trying hard" in text for text in texts)
        assert any("taking longer than usual" in text for text in texts)

    async def test_no_duplicate_content_edits(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter()
        status = await reporter.start()
        for _ in range(6):
            await asyncio.sleep(0)
        reporter.stop()
        texts = [text for text, _ in status.edits]
        # Identical consecutive frames are skipped by design.
        assert len(texts) == len(set(texts))

    async def test_provider_status_lines_real_only(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter(
            source_names=["Local Library", "Audius", "Jamendo"]
        )
        await reporter.start()
        reporter.on_progress("Local Library", "done", 3)
        reporter.on_progress("Audius", "timeout", 0)
        reporter.on_progress("Jamendo", "error", 0)
        await asyncio.sleep(0)
        reporter.stop()
        texts = "\n".join(text for text, _ in reporter._status_message.edits)
        assert "✓ Local Library" in texts
        assert "⌛ Audius — timed out" in texts
        assert "✗ Jamendo — unavailable" in texts
        assert "Checking remaining sources" not in texts  # all reported

    async def test_partial_provider_status_shows_remaining(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter(
            source_names=["Local Library", "Audius"]
        )
        await reporter.start()
        reporter.on_progress("Local Library", "done", 3)
        await asyncio.sleep(0)
        reporter.stop()
        text = "\n".join(text for text, _ in reporter._status_message.edits)
        assert "✓ Local Library" in text
        assert "◉ Checking remaining sources…" in text

    async def test_stop_cancels_animation_task(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter()
        await reporter.start()
        task = reporter._task
        assert task is not None and not task.done()
        reporter.stop()
        await asyncio.sleep(0)
        assert task.done() or task.cancelled()

    async def test_new_search_supersedes_old(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter(chat_id=55)
        await reporter.start()
        old_task = reporter._task
        # A new search for the same chat cancels the old animation.
        cancel_active(55)
        await asyncio.sleep(0)
        assert old_task is not None and old_task.cancelled()

    async def test_finish_results_stops_animation(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter()
        status = await reporter.start()
        await reporter.finish_results("🎵 done", keyboard=None)
        assert reporter.is_stopped
        assert status.edits[-1][0] == "🎵 done"

    async def test_finish_empty_and_error(self) -> None:
        reporter, origin, clock, sleeper = _make_reporter()
        await reporter.start()
        await reporter.finish_empty()
        assert "No Tracks Found" in reporter._status_message.last_text
        assert "Try another title" in reporter._status_message.last_text

        reporter2, _, _, _ = _make_reporter(chat_id=102)
        await reporter2.start()
        await reporter2.finish_error()
        assert "Search Temporarily Unavailable" in reporter2._status_message.last_text
        assert "try again shortly" in reporter2._status_message.last_text

    async def test_retry_after_backs_off(self) -> None:
        class RetryAfter(Exception):
            retry_after = 2.5

        reporter, origin, clock, sleeper = _make_reporter()
        status = await reporter.start()
        status.fail_with = RetryAfter()
        # First edit raises RetryAfter → reporter sleeps (virtual) and retries.
        await reporter._edit("spin frame")
        assert 2.5 in sleeper.sleeps
        # The retry after back-off succeeded in editing.
        assert status.edits[-1][0] == "spin frame"

    async def test_edit_failure_never_crashes(self) -> None:
        class BadEdit(Exception):
            pass

        reporter, origin, clock, sleeper = _make_reporter()
        status = await reporter.start()
        status.fail_with = BadEdit()
        await reporter._edit("frame 1")  # must not raise
        reporter.stop()


# ----------------------------------------------------------------------
# Aggregator: concurrency, timeouts, partial results
# ----------------------------------------------------------------------
class TestAggregatorTimeouts:
    async def test_fast_provider_returns_quickly(self) -> None:
        fast = FakeSource("Fast", results=3)
        slow = FakeSource("Slow", results=2, delay=30.0)
        aggregator = SearchAggregator(
            [slow, fast], MemoryCache(), per_source_timeout=1.0, overall_timeout=2.0
        )
        progress: list[tuple[str, str, int]] = []
        results = await aggregator.search(
            "Bang bang", on_progress=lambda n, s, c: progress.append((n, s, c))
        )
        # The slow source hit the per-source timeout; fast results returned.
        assert all(r.source == "fast" for r in results)
        assert len(results) == 3
        statuses = {name: status for name, status, _ in progress}
        assert statuses["Fast"] == "done"
        assert statuses["Slow"] == "timeout"

    async def test_overall_timeout_returns_partial(self) -> None:
        slow = FakeSource("SlowA", results=2, delay=5.0)
        slower = FakeSource("SlowB", results=2, delay=5.0)
        aggregator = SearchAggregator(
            [slow, slower], MemoryCache(),
            per_source_timeout=60.0, overall_timeout=0.2,
        )
        results = await aggregator.search("Bang bang")
        # Overall budget hit before either source finished → partial (empty).
        assert results == []
        # But with one source fast enough, its results survive the cutoff.
        fast = FakeSource("Fast", results=2)
        aggregator2 = SearchAggregator(
            [fast, slower], MemoryCache(),
            per_source_timeout=60.0, overall_timeout=0.2,
        )
        results2 = await aggregator2.search("Bang bang 2")
        assert len(results2) == 2
        assert all(r.source == "fast" for r in results2)

    async def test_source_error_isolated(self) -> None:
        broken = FakeSource("Broken", error=MusicSourceError("500"))
        fine = FakeSource("Fine", results=1)
        aggregator = SearchAggregator([broken, fine], MemoryCache())
        progress: list[tuple[str, str, int]] = []
        results = await aggregator.search(
            "q", on_progress=lambda n, s, c: progress.append((n, s, c))
        )
        assert len(results) == 1
        statuses = {name: status for name, status, _ in progress}
        assert statuses["Broken"] == "error"
        assert statuses["Fine"] == "done"

    async def test_concurrent_execution(self) -> None:
        """Both sources run in parallel — total time ≈ one source, not two."""
        a = FakeSource("A", results=1, delay=0.2)
        b = FakeSource("B", results=1, delay=0.2)
        aggregator = SearchAggregator([a, b], MemoryCache(), per_source_timeout=5.0)
        loop = asyncio.get_running_loop()
        started = loop.time()
        results = await aggregator.search("q")
        elapsed = loop.time() - started
        assert len(results) == 2
        assert elapsed < 0.38  # parallel, not 0.4 sequential

    async def test_progress_callback_exception_isolated(self) -> None:
        def bad_callback(name: str, status: str, count: int) -> None:
            raise RuntimeError("callback bug")

        source = FakeSource("S", results=1)
        aggregator = SearchAggregator([source], MemoryCache())
        results = await aggregator.search("q", on_progress=bad_callback)
        assert len(results) == 1  # search unaffected by callback crash

    async def test_cache_hit_reports_progress(self) -> None:
        source = FakeSource("S", results=1)
        cache = MemoryCache()
        aggregator = SearchAggregator([source], cache)
        await aggregator.search("cached query")  # populate cache
        source.calls = 0
        progress: list[tuple[str, str, int]] = []
        results = await aggregator.search(
            "cached query", on_progress=lambda n, s, c: progress.append((n, s, c))
        )
        assert len(results) == 1
        assert source.calls == 0  # served from cache
        assert progress == [("cache", "done", 1)]

    async def test_unconfigured_sources_skipped(self) -> None:
        unconfigured = FakeSource("Off", configured=False)
        aggregator = SearchAggregator([unconfigured], MemoryCache())
        results = await aggregator.search("q")
        assert results == []
        assert unconfigured.calls == 0

    async def test_dedupe_across_sources(self) -> None:
        r = TrackResult(
            title="Same Song", artist="Same Artist", album=None,
            duration_seconds=100, source="a", source_id="1",
        )

        class DupSource(FakeSource):
            async def search(self, query: str, limit: int = 10) -> list[TrackResult]:
                return [r, TrackResult(
                    title="Same Song", artist="Same Artist", album=None,
                    duration_seconds=100, source="a", source_id="2",
                )]

        aggregator = SearchAggregator([DupSource("A"), DupSource("B")], MemoryCache())
        results = await aggregator.search("q")
        assert len(results) == 1


# ----------------------------------------------------------------------
# Resolver: no duplicate track rows (search persistence)
# ----------------------------------------------------------------------
class TestNoDuplicateTracks:
    async def test_resolve_same_source_id_twice(self, db_setup, mk_sessions) -> None:
        from app.database.repositories.music import (
            AlbumRepository,
            ArtistRepository,
            GenreRepository,
            TrackRepository,
        )
        from app.music.resolver import TrackResolver

        resolver = TrackResolver(
            TrackRepository(mk_sessions),
            ArtistRepository(mk_sessions),
            AlbumRepository(mk_sessions),
            GenreRepository(mk_sessions),
        )
        result = TrackResult(
            title="Bang Bang", artist="Artist", album=None, duration_seconds=200,
            source="audius", source_id="track-xyz",
        )
        first = await resolver.resolve(result)
        second = await resolver.resolve(result)
        assert first.id == second.id
        repo = TrackRepository(mk_sessions)
        matches = await repo.get_by_source("audius", "track-xyz")
        assert matches is not None and matches.id == first.id
        # No duplicate rows were created for the same source track
        # (the fixture seeds 8 unrelated local tracks).
        audius_tracks = [t for t in await repo.recent(limit=100) if t.source == "audius"]
        assert len(audius_tracks) == 1

    async def test_different_recordings_not_merged(self, db_setup, mk_sessions) -> None:
        from app.database.repositories.music import (
            AlbumRepository,
            ArtistRepository,
            GenreRepository,
            TrackRepository,
        )
        from app.music.resolver import TrackResolver

        resolver = TrackResolver(
            TrackRepository(mk_sessions),
            ArtistRepository(mk_sessions),
            AlbumRepository(mk_sessions),
            GenreRepository(mk_sessions),
        )
        a = TrackResult(
            title="Bang Bang", artist="Artist", album=None, duration_seconds=200,
            source="audius", source_id="t1",
        )
        b = TrackResult(
            title="Bang Bang (Remix)", artist="Artist", album=None, duration_seconds=210,
            source="audius", source_id="t2",
        )
        first = await resolver.resolve(a)
        second = await resolver.resolve(b)
        assert first.id != second.id


# ----------------------------------------------------------------------
# Group-safety: animation never leaks into groups
# ----------------------------------------------------------------------
class TestGroupSafety:
    async def test_reporter_only_created_by_private_flow(self) -> None:
        """The reporter module is only imported by the private search flow."""
        import inspect

        from app.bot.handlers import search as search_handlers

        source = inspect.getsource(search_handlers.run_search)
        assert "SearchProgressReporter(" in source
        # Group playback handler must not use the reporter.
        from app.bot.handlers import groups as group_handlers

        group_source = inspect.getsource(group_handlers)
        assert "SearchProgressReporter" not in group_source

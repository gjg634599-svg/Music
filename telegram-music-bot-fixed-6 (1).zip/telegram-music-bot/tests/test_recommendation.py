"""Recommendation engine tests: pure scoring, similarity and the engine."""

from __future__ import annotations

from types import SimpleNamespace

from app.cache.redis import MemoryCache
from app.database.repositories.settings import BotSettingsRepository
from app.recommendation.engine import RecommendationEngine
from app.recommendation.profile import ProfileBuilder, TasteProfile
from app.recommendation.scoring import (
    CandidateTrack,
    RecommendationWeights,
    score_candidates,
)
from app.recommendation.similarity import (
    genre_overlap,
    tempo_closeness,
    title_token_overlap,
)

from .conftest import build_services

# ---------------------------------------------------------------------------
# Pure similarity metrics
# ---------------------------------------------------------------------------


class TestSimilarity:
    def test_genre_overlap_empty_sets(self) -> None:
        assert genre_overlap(set(), {1, 2}) == 0.0
        assert genre_overlap({1}, set()) == 0.0

    def test_genre_overlap_identical(self) -> None:
        assert genre_overlap({1, 2}, {1, 2}) == 1.0

    def test_genre_overlap_disjoint(self) -> None:
        assert genre_overlap({1, 2}, {3, 4}) == 0.0

    def test_genre_overlap_partial(self) -> None:
        # intersection 1, union 3 → 1/3
        assert abs(genre_overlap({1, 2}, {2, 3}) - 1 / 3) < 1e-9

    def test_title_token_overlap_edges(self) -> None:
        assert title_token_overlap("", "neon sunrise") == 0.0
        assert title_token_overlap("neon sunrise", "neon sunrise") == 1.0
        assert title_token_overlap("neon sunrise", "velvet night") == 0.0
        # one shared token of three total → 1/3
        assert abs(title_token_overlap("neon sunrise", "retro sunrise") - 1 / 3) < 1e-9

    def test_tempo_closeness(self) -> None:
        assert tempo_closeness(None, 120) == 0.5
        assert tempo_closeness(120, 120) == 1.0
        assert tempo_closeness(120, 180) == 0.0


# ---------------------------------------------------------------------------
# Pure scoring
# ---------------------------------------------------------------------------


def _profile(**overrides) -> TasteProfile:
    defaults: dict = dict(
        liked_track_ids=set(),
        liked_artist_ids=set(),
        liked_genre_ids=set(),
        recent_track_ids=set(),
        recent_artist_ids=set(),
        skipped_track_ids=set(),
        play_counts={},
        artist_weights={},
    )
    defaults.update(overrides)
    return TasteProfile(**defaults)


def _candidate(track_id: int, artist_id: int, **kw) -> CandidateTrack:
    return CandidateTrack(track_id=track_id, artist_id=artist_id, **kw)


class TestScoring:
    def test_same_artist_beats_unrelated(self) -> None:
        """A candidate from the liked artist outranks an unrelated one."""
        profile = _profile(liked_artist_ids={1})
        seed = _candidate(100, artist_id=1, normalized_title="neon sunrise")
        same_artist = _candidate(101, artist_id=1, normalized_title="totally different")
        unrelated = _candidate(102, artist_id=99, normalized_title="neon sunrise")

        scored = {
            item.track_id: item.score
            for item in score_candidates(
                [same_artist, unrelated],
                profile,
                RecommendationWeights(),
                seed=seed,
                playlist_context_ids=set(),
            )
        }
        assert scored[101] > scored[102]

    def test_recently_played_penalty_reduces_score(self) -> None:
        profile = _profile(recent_track_ids={101})
        fresh = _candidate(101, artist_id=1, popularity=50)
        weights = RecommendationWeights()

        base = score_candidates(
            [fresh], _profile(), weights, seed=None, playlist_context_ids=set()
        )[0].score
        penalized = score_candidates(
            [fresh], profile, weights, seed=None, playlist_context_ids=set()
        )[0].score
        assert penalized == base - weights.recently_played_penalty

    def test_skipped_penalty_reduces_score(self) -> None:
        profile = _profile(skipped_track_ids={101})
        candidate = _candidate(101, artist_id=1, popularity=50)
        weights = RecommendationWeights()

        base = score_candidates(
            [candidate], _profile(), weights, seed=None, playlist_context_ids=set()
        )[0].score
        penalized = score_candidates(
            [candidate], profile, weights, seed=None, playlist_context_ids=set()
        )[0].score
        assert penalized == base - weights.skipped_track_penalty

    def test_same_track_penalty_is_largest(self) -> None:
        seed = _candidate(101, artist_id=1, normalized_title="song")
        candidate = _candidate(101, artist_id=1, normalized_title="song")
        weights = RecommendationWeights()

        base = score_candidates(
            [candidate], _profile(), weights, seed=None, playlist_context_ids=set()
        )[0].score
        with_seed = score_candidates(
            [candidate], _profile(), weights, seed=seed, playlist_context_ids=set()
        )[0].score
        # With the seed present the identical candidate gains title+artist
        # similarity but loses the (dominant) same-track penalty → net drop.
        assert with_seed == (
            base
            + weights.track_similarity
            + weights.artist_similarity
            - weights.same_track_penalty
        )
        assert with_seed < base
        assert weights.same_track_penalty > weights.recently_played_penalty
        assert weights.same_track_penalty > weights.skipped_track_penalty

    def test_results_sorted_descending_and_deduped(self) -> None:
        candidates = [
            _candidate(1, 1, popularity=10),
            _candidate(2, 1, popularity=90),
            _candidate(2, 1, popularity=90),  # duplicate id
        ]
        scored = score_candidates(
            candidates, _profile(), RecommendationWeights(),
            seed=None, playlist_context_ids=set(),
        )
        assert [item.track_id for item in scored] == [2, 1]
        assert scored[0].score >= scored[1].score
        assert scored[0].reason  # every pick carries a reason


class TestWeightsFromDict:
    def test_defaults_from_none(self) -> None:
        assert RecommendationWeights.from_dict(None) == RecommendationWeights()

    def test_override(self) -> None:
        weights = RecommendationWeights.from_dict({"popularity": 5.0})
        assert weights.popularity == 5.0
        assert weights.artist_similarity == RecommendationWeights().artist_similarity

    def test_unknown_keys_ignored_and_bad_values_fall_back(self) -> None:
        weights = RecommendationWeights.from_dict(
            {"nonsense": 1.0, "popularity": "not-a-number"}
        )
        assert weights == RecommendationWeights()


# ---------------------------------------------------------------------------
# ProfileBuilder aggregation (duck-typed history / liked repositories)
# ---------------------------------------------------------------------------


def _history_row(row_id: int, track_id: int, *, skipped: bool = False):
    return SimpleNamespace(id=row_id, track_id=track_id, skipped=skipped)


def _track_model(track_id: int, artist_id: int, genre_ids: tuple[int, ...]):
    return SimpleNamespace(
        id=track_id,
        artist_id=artist_id,
        genres=[SimpleNamespace(id=genre_id) for genre_id in genre_ids],
    )


class StubHistoryRepo:
    def __init__(self, rows: list) -> None:
        self._rows = rows

    async def user_history(self, user_tg_id: int, limit: int = 200) -> list:
        return self._rows


class StubLikedRepo:
    def __init__(self, tracks: list) -> None:
        self._tracks = tracks

    async def list_tracks(self, user_tg_id: int, limit: int = 500) -> list:
        return self._tracks


class TestProfileBuilder:
    async def test_build_user_aggregates_history(self) -> None:
        history = StubHistoryRepo(
            [
                _history_row(3, 30),
                _history_row(2, 20, skipped=True),
                _history_row(1, 10),
            ]
        )
        liked = StubLikedRepo([_track_model(10, 100, (5,))])
        builder = ProfileBuilder(history, liked, tracks=None)

        profile = await builder.build_user(101)
        assert profile.play_counts == {30: 1, 20: 1, 10: 1}
        assert profile.recent_track_ids == {30, 20, 10}
        assert profile.skipped_track_ids == {20}
        assert profile.liked_track_ids == {10}
        assert profile.liked_artist_ids == {100}
        assert profile.liked_genre_ids == {5}
        assert not profile.is_empty

    async def test_empty_profile_is_allowed(self) -> None:
        builder = ProfileBuilder(StubHistoryRepo([]), StubLikedRepo([]), tracks=None)
        profile = await builder.build_user(101)
        assert profile.is_empty


# ---------------------------------------------------------------------------
# RecommendationEngine on the seeded database
# ---------------------------------------------------------------------------


class TestRecommendationEngine:
    async def test_returns_track_not_seed_and_not_excluded(
        self, db_setup, mk_sessions
    ) -> None:
        services = build_services(mk_sessions)
        seed_id = db_setup.track_ids_by_title["Neon Sunrise"]
        excluded_id = db_setup.track_ids_by_title["Retro Sunrise"]

        picks = await services.reco_engine.recommend_for_user(
            101, seed_id, limit=3, exclude={excluded_id}
        )
        assert 1 <= len(picks) <= 3
        for pick in picks:
            assert pick.track_id != seed_id
            assert pick.track_id not in {excluded_id}
            assert pick.track_id in db_setup.track_ids
            assert pick.reason

    async def test_respects_limit_and_empty_exclude(
        self, db_setup, mk_sessions
    ) -> None:
        services = build_services(mk_sessions)
        seed_id = db_setup.track_ids_by_title["Neon Sunrise"]

        picks = await services.reco_engine.recommend_for_user(101, seed_id, limit=2)
        assert len(picks) <= 2

    async def test_recommend_for_group_shape(self, db_setup, mk_sessions) -> None:
        services = build_services(mk_sessions)
        seed_id = db_setup.track_ids_by_title["Crystal Meadow"]
        picks = await services.reco_engine.recommend_for_group(
            -100999, seed_id, limit=2
        )
        assert picks
        assert all(pick.track_id != seed_id for pick in picks)

    async def test_zero_limit_returns_empty(self, db_setup, mk_sessions) -> None:
        services = build_services(mk_sessions)
        assert (
            await services.reco_engine.recommend_for_user(101, None, limit=0) == []
        )

    async def test_weights_override_changes_ranking(self, db_setup, mk_sessions) -> None:
        """Setting 'recommendation_weights' in bot_settings changes the ranking."""
        seed_id = db_setup.track_ids_by_title["Neon Sunrise"]
        settings_repo = BotSettingsRepository(mk_sessions)
        bundle = build_services(mk_sessions)

        # Default weights: title+genre overlap dominate → "Retro Sunrise".
        default_engine = RecommendationEngine(
            bundle.tracks_repo,
            bundle.profiles,
            settings_repo,
            MemoryCache(),
        )
        default_top = await default_engine.recommend_for_user(101, seed_id, limit=1)
        assert default_top, "engine must produce a recommendation"

        # Popularity-only weights → the most popular track must win.
        await settings_repo.set(
            "recommendation_weights",
            {
                "track_similarity": 0.0,
                "artist_similarity": 0.0,
                "genre_similarity": 0.0,
                "user_preference": 0.0,
                "popularity": 5.0,
                "playlist_context": 0.0,
                "recently_played_penalty": 0.0,
                "skipped_track_penalty": 0.0,
                "same_track_penalty": 6.0,
            },
            updated_by=1,
        )
        popularity_engine = RecommendationEngine(
            bundle.tracks_repo,
            bundle.profiles,
            settings_repo,
            MemoryCache(),  # fresh cache → no stale ranking
        )
        popularity_top = await popularity_engine.recommend_for_user(
            101, seed_id, limit=1
        )
        assert popularity_top, "engine must produce a recommendation"

        most_popular_id = db_setup.track_ids_by_title["Popular Anthem"]
        assert popularity_top[0].track_id == most_popular_id
        assert default_top[0].track_id != popularity_top[0].track_id

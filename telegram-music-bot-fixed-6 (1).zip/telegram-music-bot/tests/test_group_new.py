"""Group-mode /new — radio-style fresh-releases browse with one-tap queue.

Covers the round-7 feature: ``group_new_releases_keyboard`` (one-tap
``grp:newq:<id>`` rows + ``grp:new:<page>`` pagination), the
``_render_new_group`` renderer and the ``cmd_new`` / ``cb_new_browse`` /
``cb_new_browse_page`` / ``cb_new_queue`` handlers in the groups router.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from time import monotonic
from types import SimpleNamespace
from typing import Any

import pytest

from app.bot.commands import group_commands
from app.bot.handlers import groups as groups_module
from app.bot.keyboards.group import GROUP_NEW_PAGE_SIZE, group_new_releases_keyboard

from .conftest import FakeCallback, FakeMessage

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
_BASE = datetime(2026, 1, 1, tzinfo=UTC)


def _mk_track(index: int) -> SimpleNamespace:
    """A track stand-in with the attributes the renderer/keyboard touch."""
    return SimpleNamespace(
        id=index,
        title=f"Track {index}",
        artist=SimpleNamespace(name="Test Artist"),
        duration_seconds=30 + index,
        created_at=_BASE + timedelta(minutes=index),
    )


class _StubMusic:
    """Duck-typed MusicService for renderer tests (no DB required)."""

    def __init__(self, tracks: list[Any] | None = None, total: int | None = None) -> None:
        self._tracks = tracks
        self._total = total if total is not None else len(tracks or [])
        self.calls: list[dict[str, int]] = []

    async def new_releases(self, *, limit: int, offset: int) -> tuple[list[Any], int]:
        self.calls.append({"limit": limit, "offset": offset})
        if self._tracks is not None:
            return self._tracks[offset : offset + limit], self._total
        count = max(0, self._total - offset)
        window = [_mk_track(offset + i + 1) for i in range(min(count, limit))]
        return window, self._total

    async def get_track(self, track_id: int) -> Any:
        return _mk_track(track_id)


class _StubPlayback:
    """Records enqueue/now_playing calls; returns configured results."""

    def __init__(self, *, size: int = 3, active: bool = True) -> None:
        self.size = size
        self.active = active
        self.enqueued: list[dict[str, Any]] = []

    async def now_playing(self, owner: Any) -> dict[str, Any]:
        return {"status": "playing" if self.active else "idle", "track": _mk_track(1)}

    async def enqueue(
        self,
        owner: Any,
        chat_id: int,
        bot: Any,
        track_id: int,
        user_tg_id: int,
        *,
        edit_message: Any = None,
    ) -> int:
        self.enqueued.append(
            {
                "owner": (owner.kind, owner.id),
                "chat_id": chat_id,
                "track_id": track_id,
                "user_tg_id": user_tg_id,
                "edit_message": edit_message,
            }
        )
        return self.size


class _Recorder:
    """Generic async call recorder (users/groups/permissions/analytics)."""

    def __init__(self, result: Any = None) -> None:
        self.result = result
        self.calls: list[dict[str, Any]] = []

    async def __call__(self, *args: Any, **kwargs: Any) -> Any:
        self.calls.append({"args": args, "kwargs": kwargs})
        return self.result


def _services(
    music: Any,
    *,
    playback: Any = None,
    allowed: bool = True,
    analytics: Any = None,
) -> SimpleNamespace:
    """Duck-typed ServiceContainer for the group handler tests."""
    user_row = SimpleNamespace(id=1)
    group_row = SimpleNamespace(id=10)
    return SimpleNamespace(
        music=music,
        playback=playback or _StubPlayback(),
        users=SimpleNamespace(get_or_create=_Recorder(user_row)),
        groups=SimpleNamespace(
            get_or_create=_Recorder(group_row),
            sync_member=_Recorder(None),
        ),
        permissions=SimpleNamespace(can=_Recorder(allowed)),
        analytics=SimpleNamespace(track=analytics or _Recorder(None)),
        admin=SimpleNamespace(
            appearance=SimpleNamespace(message=_Recorder("custom text"))
        ),
    )


@pytest.fixture()
def admin_cache():
    """Control the module-level chat-admin cache around a test."""
    saved = dict(groups_module._ADMIN_CACHE)
    groups_module._ADMIN_CACHE.clear()
    yield groups_module._ADMIN_CACHE
    groups_module._ADMIN_CACHE.clear()
    groups_module._ADMIN_CACHE.update(saved)


def _seed_admin(cache: dict, chat_id: int, user_id: int, is_admin: bool) -> None:
    cache[(chat_id, user_id)] = (monotonic(), is_admin)


def _group_callback(data: str, *, user_id: int = 555, chat_id: int = -777) -> FakeCallback:
    """A FakeCallback attached to a group message with a stub bot."""
    callback = FakeCallback(data, user_id=user_id, chat_id=chat_id, chat_type="group")
    callback.bot = SimpleNamespace(get_chat_member=_Recorder(SimpleNamespace(status="member")))
    return callback


# ---------------------------------------------------------------------------
# Keyboard
# ---------------------------------------------------------------------------
class TestGroupNewReleasesKeyboard:
    def test_track_rows_are_one_tap_queue_buttons(self) -> None:
        kb = group_new_releases_keyboard(1, 1, [_mk_track(5), _mk_track(6)])
        first, second = kb.inline_keyboard[0], kb.inline_keyboard[1]
        assert first[0].callback_data == "grp:newq:5"
        assert second[0].callback_data == "grp:newq:6"
        assert first[0].text.startswith("1. Track 5")
        assert " · Test Artist" in first[0].text

    def test_numbering_is_global_across_pages(self) -> None:
        kb = group_new_releases_keyboard(2, 3, [_mk_track(11)])
        assert kb.inline_keyboard[0][0].text.startswith(
            f"{GROUP_NEW_PAGE_SIZE + 1}. Track 11"
        )

    def test_first_page_nav_has_next_only(self) -> None:
        kb = group_new_releases_keyboard(1, 3, [_mk_track(1)])
        nav = kb.inline_keyboard[-2]
        assert [b.text for b in nav] == ["📄 1/3", "➡️"]
        assert nav[0].callback_data == "grp:new:1"
        assert nav[-1].callback_data == "grp:new:2"

    def test_middle_page_shows_both(self) -> None:
        kb = group_new_releases_keyboard(2, 3, [_mk_track(9)])
        nav = kb.inline_keyboard[-2]
        assert [b.text for b in nav] == ["⬅️", "📄 2/3", "➡️"]
        assert nav[0].callback_data == "grp:new:1"
        assert nav[-1].callback_data == "grp:new:3"

    def test_last_page_shows_only_prev(self) -> None:
        kb = group_new_releases_keyboard(3, 3, [_mk_track(17)])
        nav = kb.inline_keyboard[-2]
        assert [b.text for b in nav] == ["⬅️", "📄 3/3"]
        assert nav[0].callback_data == "grp:new:2"

    def test_single_page_has_no_nav_row(self) -> None:
        kb = group_new_releases_keyboard(1, 1, [_mk_track(1)])
        assert kb.inline_keyboard[-1][0].text == "🔙 Back"

    def test_back_button_targets_group_dashboard(self) -> None:
        kb = group_new_releases_keyboard(1, 2, [_mk_track(1)])
        assert kb.inline_keyboard[-1][0].callback_data == "grp:home"

    def test_non_integer_ids_are_skipped(self) -> None:
        kb = group_new_releases_keyboard(
            1, 1, [SimpleNamespace(id=None, title="x"), _mk_track(2)]
        )
        flat = [b.callback_data for row in kb.inline_keyboard for b in row]
        assert flat == ["grp:newq:2", "grp:home"]

    def test_long_labels_are_truncated(self) -> None:
        long_track = SimpleNamespace(
            id=9, title="T" * 80, artist=SimpleNamespace(name="A" * 80)
        )
        kb = group_new_releases_keyboard(1, 1, [long_track])
        assert len(kb.inline_keyboard[0][0].text) <= 48

    def test_callback_data_within_telegram_limit(self) -> None:
        kb = group_new_releases_keyboard(12, 99, [_mk_track(1_000_000), _mk_track(2)])
        for row in kb.inline_keyboard:
            for button in row:
                assert len(button.callback_data.encode()) <= 64

    def test_empty_track_list_renders_back_only(self) -> None:
        kb = group_new_releases_keyboard(1, 1, [])
        assert len(kb.inline_keyboard) == 1
        assert kb.inline_keyboard[0][0].callback_data == "grp:home"


# ---------------------------------------------------------------------------
# Screen renderer
# ---------------------------------------------------------------------------
class TestRenderNewGroup:
    async def test_header_hint_and_numbered_lines(self) -> None:
        from app.bot.handlers.groups import _render_new_group

        tracks = [_mk_track(1), _mk_track(2)]
        text, keyboard = await _render_new_group(_services(_StubMusic(tracks, total=2)), 1)

        assert "NEW RELEASES" in text
        assert "2 tracks" in text
        assert "Tap a track to add it to the queue." in text
        assert text.count("🎵") == 2
        assert "1." in text and "2." in text
        assert keyboard.inline_keyboard[0][0].callback_data == "grp:newq:1"

    async def test_page_beyond_total_clamps_to_last(self) -> None:
        from app.bot.handlers.groups import _render_new_group

        stub = _StubMusic(total=9)
        text, _ = await _render_new_group(_services(stub), page=99)

        # 9 tracks / 8 per page → page 99 clamps to page 2 (offset 8)
        assert "2 of 2" in text
        assert len(stub.calls) == 2
        assert stub.calls[1]["offset"] == 8

    async def test_empty_catalog_state(self) -> None:
        from app.bot.handlers.groups import _render_new_group

        text, keyboard = await _render_new_group(_services(_StubMusic([], total=0)), 1)

        assert "NEW RELEASES" in text
        assert "catalog is empty" in text
        assert keyboard.inline_keyboard[-1][0].callback_data == "grp:home"

    async def test_multi_page_footer(self) -> None:
        from app.bot.handlers.groups import _render_new_group

        text, _ = await _render_new_group(_services(_StubMusic(total=25)), 1)

        assert "freshest first" in text
        assert "1 of 4" in text  # 25 tracks / 8 per page


# ---------------------------------------------------------------------------
# /new command + browse callbacks
# ---------------------------------------------------------------------------
class TestGroupNewCommand:
    async def test_cmd_new_sends_browse_page(self) -> None:
        from app.bot.handlers.groups import cmd_new

        message = FakeMessage(text="/new", chat_type="group", chat_id=-777)
        await cmd_new(message, _services(_StubMusic(total=3)))

        assert len(message.answered) == 1
        text, kwargs = message.answered[0]
        assert "NEW RELEASES" in text
        assert "3 tracks" in text
        assert kwargs.get("parse_mode") == "HTML"
        assert kwargs.get("reply_markup") is not None

    async def test_cmd_new_syncs_membership(self) -> None:
        from app.bot.handlers.groups import cmd_new

        services = _services(_StubMusic(total=1))
        message = FakeMessage(text="/new", chat_type="group", chat_id=-777)
        await cmd_new(message, services)

        assert len(services.groups.get_or_create.calls) == 1
        assert len(services.groups.sync_member.calls) == 1

    async def test_cb_new_browse_edits_screen(self) -> None:
        from app.bot.handlers.groups import cb_new_browse

        callback = _group_callback("grp:new")
        await cb_new_browse(callback, _services(_StubMusic(total=2)))

        assert len(callback.message.edited) == 1
        text, kwargs = callback.message.edited[0]
        assert "NEW RELEASES" in text
        assert kwargs.get("reply_markup") is not None
        assert callback.answers  # the callback is answered

    async def test_cb_new_browse_page_renders_page_n(self) -> None:
        from app.bot.handlers.groups import cb_new_browse_page

        callback = _group_callback("grp:new:2")
        await cb_new_browse_page(callback, _services(_StubMusic(total=17)))

        text, _ = callback.message.edited[0]
        assert "2 of 3" in text  # 17 tracks / 8 per page
        assert "9." in text  # second page starts at track 9

    def test_new_page_regex_never_matches_queue_payload(self) -> None:
        # ``grp:newq:<id>`` must never be consumed by the pagination filter.
        assert groups_module._NEW_PAGE_RE.match("grp:newq:5") is None
        assert groups_module._NEW_PAGE_RE.match("grp:new:2") is not None
        assert groups_module._NEW_PAGE_RE.match("grp:new") is None


# ---------------------------------------------------------------------------
# One-tap queue callback (permission-gated)
# ---------------------------------------------------------------------------
class TestGroupNewQueueCallback:
    async def test_allowed_enqueue_toast(self, admin_cache) -> None:
        from app.bot.handlers.groups import cb_new_queue

        callback = _group_callback("grp:newq:5")
        _seed_admin(admin_cache, -777, 555, True)
        playback = _StubPlayback(size=4, active=True)
        services = _services(_StubMusic(total=9), playback=playback, allowed=True)

        await cb_new_queue(callback, services)

        assert len(playback.enqueued) == 1
        call = playback.enqueued[0]
        assert call["track_id"] == 5
        assert call["user_tg_id"] == 555
        assert call["owner"] == ("group", -777)
        assert callback.answers[0][0] == "➕ Added to queue (#4)"

    async def test_idle_session_starts_playback(self, admin_cache) -> None:
        from app.bot.handlers.groups import cb_new_queue

        callback = _group_callback("grp:newq:7")
        _seed_admin(admin_cache, -777, 555, True)
        playback = _StubPlayback(size=1, active=False)
        services = _services(_StubMusic(total=9), playback=playback, allowed=True)

        await cb_new_queue(callback, services)

        assert callback.answers[0][0] == "🎵 Now playing"

    async def test_permission_denied_alerts(self, admin_cache) -> None:
        from app.bot.handlers.groups import cb_new_queue

        callback = _group_callback("grp:newq:5")
        _seed_admin(admin_cache, -777, 555, True)
        services = _services(_StubMusic(total=9), allowed=False)

        await cb_new_queue(callback, services)

        text, show_alert = callback.answers[0]
        assert "permission" in str(text).lower()
        assert show_alert is True

    async def test_invalid_track_id_answered(self, admin_cache) -> None:
        from app.bot.handlers.groups import cb_new_queue

        callback = _group_callback("grp:newq:notanumber")
        _seed_admin(admin_cache, -777, 555, True)

        await cb_new_queue(callback, _services(_StubMusic(total=1)))

        assert callback.answers[0][0] == "❌ Invalid track."

    async def test_missing_track_answered(self, admin_cache) -> None:
        from app.bot.handlers.groups import cb_new_queue

        callback = _group_callback("grp:newq:99")
        _seed_admin(admin_cache, -777, 555, True)
        music = _StubMusic(total=1)
        music.get_track = _Recorder(None)  # type: ignore[method-assign]
        services = _services(music)

        await cb_new_queue(callback, services)

        assert "Couldn't find" in str(callback.answers[0][0])

    async def test_analytics_event_fired(self, admin_cache) -> None:
        from app.bot.handlers.groups import cb_new_queue

        callback = _group_callback("grp:newq:5")
        _seed_admin(admin_cache, -777, 555, True)
        analytics = _Recorder(None)
        services = _services(_StubMusic(total=9), analytics=analytics)

        await cb_new_queue(callback, services)

        assert len(analytics.calls) == 1
        event = analytics.calls[0]
        assert event["args"][0] == "group_play"
        assert event["kwargs"]["payload"]["source"] == "new_releases"


# ---------------------------------------------------------------------------
# Wiring / registration / docs
# ---------------------------------------------------------------------------
class TestGroupNewWiring:
    def test_new_command_in_group_menu(self) -> None:
        names = [c.command for c in group_commands()]
        assert "new" in names

    def test_new_row_in_default_group_help(self) -> None:
        from app.database.defaults import DEFAULT_MESSAGES

        assert "/new" in DEFAULT_MESSAGES["group_help"]
        assert "tap to queue" in DEFAULT_MESSAGES["group_help"]

    def test_new_row_in_default_commands_template(self) -> None:
        from app.database.defaults import DEFAULT_MESSAGES

        template = DEFAULT_MESSAGES["commands"]
        assert "/new" in template

    def test_new_mentioned_in_default_help(self) -> None:
        from app.database.defaults import DEFAULT_MESSAGES

        assert "/new" in DEFAULT_MESSAGES["help"]

    def test_router_registers_new_handlers(self) -> None:
        callbacks = {h.callback.__name__ for h in groups_module.router.callback_query.handlers}
        messages = {h.callback.__name__ for h in groups_module.router.message.handlers}
        assert {"cb_new_browse", "cb_new_browse_page", "cb_new_queue"} <= callbacks
        assert "cmd_new" in messages

    def test_group_help_fallback_mentions_new(self) -> None:
        assert "/new" in groups_module.GROUP_HELP_FALLBACK

    def test_page_size_matches_private_new(self) -> None:
        from app.bot.keyboards.library import NEW_PAGE_SIZE

        assert GROUP_NEW_PAGE_SIZE == NEW_PAGE_SIZE

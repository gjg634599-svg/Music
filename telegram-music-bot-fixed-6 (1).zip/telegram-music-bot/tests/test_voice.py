"""Voice engine tests: manager lifecycle, assignment, failover, repositories.

Runs entirely without Telethon: accounts are stubs backed by real ORM
``VoiceAccount`` rows and a ``FakeTransport``; the repositories and the
manager logic are the real production classes.
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from app.cache.redis import LockManager, MemoryCache
from app.config import Settings, VoiceSettings
from app.database.repositories.voice import VoiceRepository
from app.errors import VoiceAccountOfflineError, VoiceNotJoinedError, ValidationError
from app.playback.events import EventBus
from app.voice.assignment import AssignmentStrategy
from app.voice.failover import FailoverController
from app.voice.manager import VoiceManager

GROUP_A = -101
GROUP_B = -102


def _voice_settings() -> Settings:
    return Settings(
        bot_token="123456:pytest",
        telegram_api_id=1,
        telegram_api_hash="hash",
        voice=VoiceSettings(encryption_key="k" * 44, max_sessions_per_account=2),
    )


class FakeTransport:
    def __init__(self) -> None:
        self.played: list[tuple[int, Path]] = []
        self.paused: list[int] = []
        self.resumed: list[int] = []
        self.volumes: list[tuple[int, int]] = []
        self.left: list[int] = []
        self.joined: list[int] = []

    async def join(self, group_tg_id: int) -> None:
        self.joined.append(group_tg_id)

    async def play(self, group_tg_id: int, path: Path, *args, **kwargs) -> None:
        self.played.append((group_tg_id, Path(path)))

    async def pause(self, group_tg_id: int) -> None:
        self.paused.append(group_tg_id)

    async def resume(self, group_tg_id: int) -> None:
        self.resumed.append(group_tg_id)

    async def set_volume(self, group_tg_id: int, volume: int) -> None:
        self.volumes.append((group_tg_id, volume))

    async def leave(self, group_tg_id: int) -> None:
        self.left.append(group_tg_id)

    async def is_connected(self, group_tg_id: int) -> bool:
        return group_tg_id in {g for g, _ in self.played} or group_tg_id in self.joined


class StubAccount:
    """VoiceAccountClient stand-in (no Telethon)."""

    def __init__(self, model, transport: FakeTransport) -> None:
        self.model = model
        self._transport = transport
        self.connected = True

    @property
    def label(self) -> str:
        return self.model.label

    @property
    def telegram_id(self):
        return self.model.telegram_id

    @property
    def username(self):
        return self.model.username

    @property
    def is_connected(self) -> bool:
        return self.connected

    @property
    def transport(self) -> FakeTransport:
        return self._transport

    @property
    def active_sessions(self) -> int:
        return self._active

    @active_sessions.setter
    def active_sessions(self, value: int) -> None:
        self._active = max(0, int(value))

    @property
    def max_sessions(self) -> int:
        return int(self.model.max_sessions or 0)

    async def connect(self) -> None:
        self.connected = True

    async def disconnect(self) -> None:
        self.connected = False


async def _make_account(repo: VoiceRepository, label: str, *, priority: int = 0):
    row = await repo.create(
        label, f"encrypted-session-{label}", max_sessions=2, priority=priority
    )
    return row


@pytest.fixture
async def voice_env(db_setup, mk_sessions, tmp_path):
    """Repository, event bus, manager and two stub accounts."""
    repo = VoiceRepository(mk_sessions)
    events = EventBus()
    cache = MemoryCache()
    locks = LockManager(cache)
    manager = VoiceManager(repo, _voice_settings(), None, cache, locks, events)

    await manager.start()  # empty DB → no accounts, subscribes events
    row_a = await _make_account(repo, "A", priority=10)
    row_b = await _make_account(repo, "B", priority=0)
    stub_a = StubAccount(row_a, FakeTransport())
    stub_b = StubAccount(row_b, FakeTransport())
    stub_a.active_sessions = 0
    stub_b.active_sessions = 0
    manager._accounts.clear()
    manager._accounts[int(row_a.id)] = stub_a
    manager._accounts[int(row_b.id)] = stub_b

    audio = tmp_path / "demo.opus"
    audio.write_bytes(b"OggS-fake-opus")

    env = SimpleNamespace(
        repo=repo,
        events=events,
        cache=cache,
        locks=locks,
        manager=manager,
        stub_a=stub_a,
        stub_b=stub_b,
        row_a=row_a,
        row_b=row_b,
        audio=audio,
    )
    try:
        yield env
    finally:
        await manager.shutdown()


# ---------------------------------------------------------------------------
# Repository roundtrips
# ---------------------------------------------------------------------------
class TestVoiceRepository:
    async def test_account_roundtrip(self, db_setup, mk_sessions) -> None:
        repo = VoiceRepository(mk_sessions)

        created = await repo.create(
            "Main",
            "enc-blob",
            telegram_id=42,
            username="main_bot",
            phone_hint="+98***1",
            max_sessions=3,
            priority=7,
        )
        assert created.id is not None
        assert created.status == "offline"

        fetched = await repo.get(created.id)
        assert fetched.label == "Main"
        assert fetched.max_sessions == 3
        assert fetched.priority == 7

        updated = await repo.update(created.id, label="Renamed", max_sessions=5)
        assert updated.label == "Renamed"
        assert updated.max_sessions == 5

        await repo.set_status(created.id, "degraded", error="flood")
        fetched = await repo.get(created.id)
        assert fetched.status == "degraded"
        assert fetched.last_error == "flood"

        with pytest.raises(ValidationError):
            await repo.set_status(created.id, "exploded")

        listed = await repo.list_accounts()
        assert [a.label for a in listed] == ["Renamed"]
        assert await repo.delete(created.id) is True
        assert await repo.get(created.id) is None

    async def test_health_records(self, db_setup, mk_sessions) -> None:
        repo = VoiceRepository(mk_sessions)
        account = await repo.create("H", "enc")

        await repo.record_health(account.id, "healthy", latency_ms=120)
        await repo.record_health(account.id, "degraded", latency_ms=2500, error="slow")
        fresh = await repo.get(account.id)
        assert fresh.last_health_check_at is not None

        latest = await repo.latest_health(account.id, limit=1)
        assert latest and latest[0].status == "degraded"

    async def test_session_and_event_roundtrip(self, db_setup, mk_sessions) -> None:
        repo = VoiceRepository(mk_sessions)
        account = await repo.create("S", "enc")
        session = await repo.create_session(GROUP_A, account.id)
        assert session.status == "joining"

        assert (await repo.get_active_by_group(GROUP_A)).id == session.id
        assert await repo.count_active_sessions() == 1

        await repo.update_session(session.id, status="playing")
        await repo.touch_heartbeat(session.id)
        assert (await repo.get_active_by_group(GROUP_A)).status == "playing"

        await repo.add_event(session.id, "play", {"path": "x.opus"})
        await repo.add_event(session.id, "pause")
        events = await repo.list_events(session.id)
        assert [e.event for e in events] == ["pause", "play"]  # newest first
        assert events[1].details == {"path": "x.opus"}

        await repo.end_session(session.id, "ended")
        assert await repo.get_active_by_group(GROUP_A) is None
        assert await repo.count_active_sessions() == 0

    async def test_assignments(self, db_setup, mk_sessions) -> None:
        repo = VoiceRepository(mk_sessions)
        account = await repo.create("As", "enc")
        session = await repo.create_session(GROUP_A, account.id)

        assignment = await repo.record_assignment(account.id, GROUP_A, session.id)
        active = await repo.active_assignments()
        assert len(active) == 1 and active[0].group_id == GROUP_A

        released = await repo.release_assignment_for_group(GROUP_A)
        assert released == 1
        assert await repo.active_assignments() == []


# ---------------------------------------------------------------------------
# Assignment strategy
# ---------------------------------------------------------------------------
class TestAssignmentStrategy:
    async def test_least_loaded_wins(self, voice_env) -> None:
        strategy = AssignmentStrategy()
        voice_env.stub_a.active_sessions = 2  # at capacity (max=2)
        picked = strategy.select([voice_env.stub_a, voice_env.stub_b])
        assert picked is voice_env.stub_b

    async def test_priority_ties_break(self, voice_env) -> None:
        strategy = AssignmentStrategy()
        voice_env.stub_a.active_sessions = 0
        voice_env.stub_b.active_sessions = 0
        picked = strategy.select([voice_env.stub_a, voice_env.stub_b])
        assert picked is voice_env.stub_a  # higher priority

    async def test_none_when_all_disconnected(self, voice_env) -> None:
        strategy = AssignmentStrategy()
        voice_env.stub_a.connected = False
        voice_env.stub_b.connected = False
        assert strategy.select([voice_env.stub_a, voice_env.stub_b]) is None


# ---------------------------------------------------------------------------
# Manager lifecycle
# ---------------------------------------------------------------------------
class TestVoiceManagerLifecycle:
    async def test_acquire_play_pause_release(self, voice_env) -> None:
        env = voice_env
        runtime = await env.manager.acquire(GROUP_A)
        assert runtime is not None
        assert runtime.group_id == GROUP_A
        # Least-loaded with equal load → higher priority account A.
        assert runtime.account is env.stub_a
        assert env.stub_a.active_sessions == 1

        await env.manager.play(GROUP_A, env.audio, duration=120)
        assert env.stub_a.transport.played == [(GROUP_A, env.audio)]
        session = await env.repo.get_active_by_group(GROUP_A)
        assert session.status == "playing"

        await env.manager.pause(GROUP_A)
        await env.manager.resume(GROUP_A)
        assert env.stub_a.transport.paused == [GROUP_A]
        assert env.stub_a.transport.resumed == [GROUP_A]

        await env.manager.set_volume(GROUP_A, 55)
        assert env.stub_a.transport.volumes == [(GROUP_A, 55)]

        await env.manager.release(GROUP_A)
        assert env.stub_a.transport.left == [GROUP_A]
        assert env.stub_a.active_sessions == 0
        assert await env.repo.count_active_sessions() == 0

    async def test_second_group_gets_least_loaded_account(self, voice_env) -> None:
        env = voice_env
        first = await env.manager.acquire(GROUP_A)
        second = await env.manager.acquire(GROUP_B)
        assert first.account is env.stub_a
        assert second.account is env.stub_b  # A is busy → B takes over

        await env.manager.release(GROUP_A)
        await env.manager.release(GROUP_B)

    async def test_play_auto_acquires(self, voice_env) -> None:
        env = voice_env
        await env.manager.play(GROUP_A, env.audio, duration=60)
        assert env.stub_a.transport.played == [(GROUP_A, env.audio)]
        await env.manager.stop_stream(GROUP_A)

    async def test_pause_without_session_raises(self, voice_env) -> None:
        with pytest.raises(VoiceNotJoinedError):
            await voice_env.manager.pause(GROUP_A)

    async def test_no_accounts_raises_offline(self, db_setup, mk_sessions, tmp_path):
        repo = VoiceRepository(mk_sessions)
        events = EventBus()
        manager = VoiceManager(
            repo, _voice_settings(), None, MemoryCache(), LockManager(MemoryCache()), events
        )
        await manager.start()
        try:
            assert await manager.acquire(GROUP_A) is None
            with pytest.raises(VoiceAccountOfflineError):
                await manager.play(GROUP_A, tmp_path / "x.opus", duration=10)
        finally:
            await manager.shutdown()

    async def test_status_and_list_active_sessions(self, voice_env) -> None:
        env = voice_env
        await env.manager.play(GROUP_A, env.audio, duration=60)

        status = await env.manager.status()
        assert status.total_accounts == 2
        assert status.active_sessions == 1
        assert {s.account_id for s in status.accounts} == {
            env.row_a.id,
            env.row_b.id,
        }

        sessions = await env.manager.list_active_sessions()
        assert len(sessions) == 1 and sessions[0].group_id == GROUP_A

        assert env.manager.has_accounts() is True

    async def test_disabled_settings_skip_start(self, db_setup, mk_sessions) -> None:
        repo = VoiceRepository(mk_sessions)
        await repo.create("X", "enc")
        settings = Settings(bot_token="123456:pytest")  # voice disabled
        manager = VoiceManager(
            repo, settings, None, MemoryCache(), LockManager(MemoryCache()), EventBus()
        )
        await manager.start()
        try:
            assert manager.has_accounts() is False
            assert await manager.is_voice_enabled() is False
        finally:
            await manager.shutdown()


# ---------------------------------------------------------------------------
# Failover
# ---------------------------------------------------------------------------
class TestFailover:
    async def test_handle_failure_marks_and_publishes(self, voice_env) -> None:
        env = voice_env
        await env.manager.play(GROUP_A, env.audio, duration=60)

        # Subscribe BEFORE the failure to observe the event (the manager's own
        # subscription is what performs the reassignment).
        received: list = []

        async def on_voice_failure(event) -> None:  # noqa: ANN001
            received.append(event)

        env.events.subscribe("voice_failure:-101", on_voice_failure)

        # The account died mid-playback.
        env.stub_a.connected = False

        await env.manager.failover.handle_failure(GROUP_A, error="FLOOD_WAIT")

        assert received and received[0].name == f"voice_failure:{GROUP_A}"
        assert received[0].data["group_id"] == GROUP_A

        # The DB account row is degraded with the error recorded.
        account = await env.repo.get(env.row_a.id)
        assert account.status == "degraded"
        assert account.last_error == "FLOOD_WAIT"

        # The manager re-assigned the group to the healthy account B.
        sessions = await env.repo.active_sessions()
        assert sessions and sessions[0].account_id == env.row_b.id
        assert env.stub_b.transport.played == []  # not playing yet, but leased

        await env.manager.release(GROUP_A)

    async def test_failover_is_idempotent_while_locked(self, voice_env) -> None:
        env = voice_env
        await env.manager.play(GROUP_A, env.audio, duration=60)

        # Hold the failover lock → a concurrent handle_failure is a no-op.
        lock = await env.locks.try_acquire(f"failover:{GROUP_A}", ttl=30)
        assert lock is not None
        try:
            await env.manager.failover.handle_failure(GROUP_A)
        finally:
            await lock.release()

        # The session was NOT marked failed (short-circuited).
        session = await env.repo.get_active_by_group(GROUP_A)
        assert session is not None and session.status == "playing"

        await env.manager.release(GROUP_A)


# ---------------------------------------------------------------------------
# Idle-timeout release (spec: "Leave VC after N minutes idle")
# ---------------------------------------------------------------------------
class TestIdleRelease:
    async def test_paused_idle_session_is_released(self, voice_env) -> None:
        env = voice_env
        await env.manager.play(GROUP_A, env.audio, duration=600)
        await env.manager.pause(GROUP_A)

        # Nothing released inside the idle window.
        assert await env.manager.release_idle_sessions(timeout_minutes=5) == []
        assert GROUP_A in env.manager._sessions

        # Age the session beyond the window.
        runtime = env.manager._sessions[GROUP_A]
        runtime._last_activity -= 6 * 60
        released = await env.manager.release_idle_sessions(timeout_minutes=5)

        assert released == [GROUP_A]
        assert GROUP_A not in env.manager._sessions
        session = await env.repo.get_active_by_group(GROUP_A)
        assert session is None  # ended by release()

        # The account slot was freed.
        assert env.stub_a.active_sessions == 0

    async def test_playing_session_is_never_released(self, voice_env) -> None:
        env = voice_env
        await env.manager.play(GROUP_A, env.audio, duration=600)
        runtime = env.manager._sessions[GROUP_A]
        runtime._last_activity -= 6 * 60  # "stale" timestamp while playing

        assert await env.manager.release_idle_sessions(timeout_minutes=5) == []
        assert GROUP_A in env.manager._sessions
        assert runtime.status == "playing"

        await env.manager.release(GROUP_A)

    async def test_user_interaction_resets_idle_window(self, voice_env) -> None:
        env = voice_env
        await env.manager.play(GROUP_A, env.audio, duration=600)
        runtime = env.manager._sessions[GROUP_A]
        runtime._last_activity -= 6 * 60
        await env.manager.pause(GROUP_A)  # interaction → _touch_activity()

        assert runtime.idle_seconds < 60
        assert await env.manager.release_idle_sessions(timeout_minutes=5) == []
        assert GROUP_A in env.manager._sessions

        await env.manager.release(GROUP_A)

    async def test_per_group_resolver_overrides_default(self, voice_env) -> None:
        env = voice_env
        await env.manager.play(GROUP_A, env.audio, duration=600)
        await env.manager.play(GROUP_B, env.audio, duration=600)
        await env.manager.pause(GROUP_A)
        await env.manager.pause(GROUP_B)
        for runtime in env.manager._sessions.values():
            runtime._last_activity -= 6 * 60

        async def resolver(group_tg_id: int) -> float:
            return 1 if group_tg_id == GROUP_A else 60

        released = await env.manager.release_idle_sessions(
            timeout_minutes=30, resolver=resolver
        )
        assert released == [GROUP_A]  # only the 1-minute group was released
        assert GROUP_B in env.manager._sessions

        await env.manager.release(GROUP_B)

    async def test_idle_release_publishes_event(self, voice_env) -> None:
        env = voice_env
        received: list[str] = []

        async def on_idle(event) -> None:
            received.append(event.name)

        env.events.subscribe("voice:idle_released", on_idle)
        await env.manager.play(GROUP_A, env.audio, duration=600)
        await env.manager.pause(GROUP_A)
        runtime = env.manager._sessions[GROUP_A]
        runtime._last_activity -= 6 * 60

        await env.manager.release_idle_sessions(timeout_minutes=5)
        assert received == ["voice:idle_released"]

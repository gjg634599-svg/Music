"""EventBus tests: pub/sub, topic prefixes, isolation, wait_for."""

from __future__ import annotations

import asyncio

import pytest

from app.playback.events import Event, EventBus


@pytest.fixture
def bus() -> EventBus:
    return EventBus()


def recorder(bucket: list):
    async def handler(event: Event) -> None:
        bucket.append(event)
    return handler


class TestPubSub:
    async def test_subscribe_and_publish(self, bus: EventBus) -> None:
        received: list[Event] = []
        bus.subscribe("track_end:user:101", recorder(received))

        await bus.publish("track_end:user:101", track_id=7, reason="timer")

        assert len(received) == 1
        event = received[0]
        assert event.name == "track_end:user:101"
        assert event.data == {"track_id": 7, "reason": "timer"}

    async def test_multiple_subscribers_all_called(self, bus: EventBus) -> None:
        first: list[Event] = []
        second: list[Event] = []
        bus.subscribe("topic", recorder(first))
        bus.subscribe("topic", recorder(second))

        await bus.publish("topic", x=1)

        assert len(first) == 1 and len(second) == 1

    async def test_unsubscribe_stops_delivery(self, bus: EventBus) -> None:
        received: list[Event] = []
        handler = recorder(received)
        bus.subscribe("topic", handler)
        bus.unsubscribe("topic", handler)
        bus.unsubscribe("topic", handler)  # double unsubscribe is safe

        await bus.publish("topic")
        assert received == []

    async def test_publish_without_subscribers_is_noop(self, bus: EventBus) -> None:
        await bus.publish("nobody:listening", data=123)  # must not raise


class TestTopicPrefixes:
    async def test_prefix_subscriber_receives_specific_events(self, bus: EventBus) -> None:
        received: list[Event] = []
        bus.subscribe("track_end", recorder(received))  # prefix subscription

        await bus.publish("track_end:user:101", track_id=1)
        await bus.publish("track_end:group:-100999", track_id=2)

        assert [e.name for e in received] == [
            "track_end:user:101",
            "track_end:group:-100999",
        ]

    async def test_unrelated_events_not_delivered(self, bus: EventBus) -> None:
        received: list[Event] = []
        bus.subscribe("track_end", recorder(received))

        await bus.publish("queue_empty:user:101")

        assert received == []

    async def test_specific_beats_prefix_isolation(self, bus: EventBus) -> None:
        """A subscriber for one owner never sees another owner's events."""
        user_events: list[Event] = []
        group_events: list[Event] = []
        bus.subscribe("track_end:user:101", recorder(user_events))
        bus.subscribe("track_end:group:-100999", recorder(group_events))

        await bus.publish("track_end:user:101", track_id=9)

        assert len(user_events) == 1
        assert group_events == []

    async def test_prefix_and_exact_subscribers_both_fire(self, bus: EventBus) -> None:
        prefix: list[Event] = []
        exact: list[Event] = []
        bus.subscribe("voice_failure", recorder(prefix))
        bus.subscribe("voice_failure:-100999", recorder(exact))

        await bus.publish("voice_failure:-100999", error="disconnected")

        assert len(prefix) == 1 and len(exact) == 1


class TestHandlerRobustness:
    async def test_failing_handler_does_not_break_others(self, bus: EventBus) -> None:
        good: list[Event] = []

        async def bad(event: Event) -> None:
            raise RuntimeError("boom")

        bus.subscribe("topic", bad)
        bus.subscribe("topic", recorder(good))

        await bus.publish("topic")  # must not propagate

        assert len(good) == 1

    async def test_sync_handler_supported(self, bus: EventBus) -> None:
        received: list[Event] = []

        def sync_handler(event: Event) -> None:  # not a coroutine
            received.append(event)

        bus.subscribe("topic", sync_handler)
        await bus.publish("topic")
        assert len(received) == 1


class TestWaitFor:
    async def test_returns_published_event(self, bus: EventBus) -> None:
        async def publish_later() -> None:
            await asyncio.sleep(0.02)
            await bus.publish("autoplay_selected", track_id=5)

        task = asyncio.create_task(publish_later())
        event = await bus.wait_for("autoplay_selected", timeout=1.0)
        await task

        assert event.name == "autoplay_selected"
        assert event.data["track_id"] == 5

    async def test_already_published_after_wait_starts(self, bus: EventBus) -> None:
        """The subscription is registered before awaiting — a fast publish wins."""
        asyncio.get_running_loop().call_soon(
            lambda: asyncio.create_task(bus.publish("instant", value=1))
        )
        event = await bus.wait_for("instant", timeout=1.0)
        assert event.data == {"value": 1}

    async def test_timeout_raises(self, bus: EventBus) -> None:
        with pytest.raises(asyncio.TimeoutError):
            await bus.wait_for("never:comes", timeout=0.05)

    async def test_cleans_up_subscription_after_timeout(self, bus: EventBus) -> None:
        with pytest.raises(asyncio.TimeoutError):
            await bus.wait_for("ghost", timeout=0.01)
        # The temporary wait_for handler must not linger on the bus.
        assert not bus._handlers.get("ghost")

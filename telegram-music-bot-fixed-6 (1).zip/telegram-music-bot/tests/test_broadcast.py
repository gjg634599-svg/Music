"""Broadcast engine tests: composer, rate-limit classification and worker."""

from __future__ import annotations

from types import SimpleNamespace

import pytest
from aiogram.exceptions import (
    TelegramForbiddenError,
    TelegramNetworkError,
    TelegramRetryAfter,
)
from sqlalchemy import select

from app.broadcast.composer import (
    buttons_to_keyboard,
    from_copy_message,
    from_media_group,
    from_media_message,
    from_text,
    validate_buttons,
)
from app.broadcast.rate_limit import classify
from app.broadcast.worker import BroadcastWorker
from app.config import Settings
from app.database.models.broadcast import BroadcastDelivery, BroadcastTarget
from app.database.repositories.broadcast import BroadcastRepository
from app.errors import ValidationError
from app.playback.events import EventBus

from .conftest import build_services


def _exc(cls, message: str, **kwargs):
    return cls(method=None, message=message, **kwargs)


# ---------------------------------------------------------------------------
# Composer
# ---------------------------------------------------------------------------
class TestComposer:
    def test_from_text(self) -> None:
        draft = from_text("Hello world", buttons=[{"label": "Site", "url": "https://x.io"}])
        assert draft.content_type == "text"
        assert draft.text == "Hello world"
        assert draft.buttons == [{"label": "Site", "url": "https://x.io"}]

    def test_from_text_rejects_empty_and_huge(self) -> None:
        with pytest.raises(ValidationError):
            from_text("   ")
        with pytest.raises(ValidationError):
            from_text("x" * 5000)

    def test_from_media_message_photo(self) -> None:
        message = SimpleNamespace(
            animation=None,
            photo=[SimpleNamespace(file_id="small"), SimpleNamespace(file_id="big")],
            video=None,
            voice=None,
            audio=None,
            document=None,
            caption="cover",
        )
        draft = from_media_message(message)
        assert draft.content_type == "photo"
        assert draft.media == [{"type": "photo", "file_id": "big"}]
        assert draft.caption == "cover"

    def test_from_media_message_animation_before_document(self) -> None:
        message = SimpleNamespace(
            animation=SimpleNamespace(file_id="gif1"),
            photo=None,
            video=None,
            voice=None,
            audio=None,
            document=SimpleNamespace(file_id="doc1", mime_type="video/mp4"),
            caption=None,
        )
        draft = from_media_message(message)
        assert draft.content_type == "animation"

    def test_from_copy_message(self) -> None:
        message = SimpleNamespace(
            chat=SimpleNamespace(id=-100), message_id=7, caption=None, text="body"
        )
        draft = from_copy_message(message)
        assert draft.content_type == "copy"
        assert draft.copy_source == {"chat_id": -100, "message_ids": [7]}

    def test_from_media_group_album(self) -> None:
        messages = [
            SimpleNamespace(
                photo=[SimpleNamespace(file_id="p1")],
                video=None,
                document=None,
                caption="album caption",
            ),
            SimpleNamespace(
                photo=None,
                video=SimpleNamespace(file_id="v1"),
                document=None,
                caption=None,
            ),
        ]
        draft = from_media_group(messages)
        assert draft.content_type == "album"
        assert draft.caption == "album caption"
        assert draft.media == [
            {"type": "photo", "file_id": "p1"},
            {"type": "video", "file_id": "v1"},
        ]

    def test_album_rejects_non_media_items(self) -> None:
        messages = [
            SimpleNamespace(photo=None, video=None, document=None, caption=None)
        ]
        with pytest.raises(ValidationError):
            from_media_group(messages)

    def test_button_validation_schemes(self) -> None:
        validate_buttons(None)  # no buttons is fine
        validate_buttons([{"label": "A", "url": "https://example.com"}])
        validate_buttons([{"label": "B", "url": "tg://resolve?domain=x"}])

        for bad in (
            [{"label": "X", "url": "javascript:alert(1)"}],
            [{"label": "X", "url": "data:text/html,hi"}],
            [{"label": "X", "url": "http://insecure.example"}],
            [{"label": "X", "url": "file:///etc/passwd"}],
        ):
            with pytest.raises(ValidationError):
                validate_buttons(bad)

    def test_button_validation_shape(self) -> None:
        with pytest.raises(ValidationError):  # missing label
            validate_buttons([{"url": "https://x.io"}])
        with pytest.raises(ValidationError):  # missing url
            validate_buttons([{"label": "X"}])
        with pytest.raises(ValidationError):  # too many
            validate_buttons(
                [{"label": f"b{i}", "url": "https://x.io"} for i in range(9)]
            )

    def test_buttons_to_keyboard_rows_of_two(self) -> None:
        keyboard = buttons_to_keyboard(
            [{"label": f"b{i}", "url": "https://x.io"} for i in range(3)]
        )
        assert [len(row) for row in keyboard.inline_keyboard] == [2, 1]
        assert buttons_to_keyboard(None) is None


# ---------------------------------------------------------------------------
# Rate limiter classification
# ---------------------------------------------------------------------------
class TestClassify:
    def test_retry_after_is_flood_with_seconds(self) -> None:
        kind, seconds = classify(_exc(TelegramRetryAfter, "Too Many Requests", retry_after=12))
        assert kind == "flood"
        assert seconds == 12

    def test_forbidden_is_permanent(self) -> None:
        assert classify(_exc(TelegramForbiddenError, "bot was blocked by the user"))[0] == "permanent"

    def test_network_error_is_retry(self) -> None:
        assert classify(_exc(TelegramNetworkError, "connection timed out"))[0] == "retry"

    def test_bad_request_chat_not_found_is_permanent(self) -> None:
        from aiogram.exceptions import TelegramBadRequest

        kind, _ = classify(_exc(TelegramBadRequest, "Bad Request: chat not found"))
        assert kind == "permanent"

    def test_generic_bad_request_is_retry(self) -> None:
        from aiogram.exceptions import TelegramBadRequest

        assert classify(_exc(TelegramBadRequest, "Bad Request: message is not modified"))[0] == "retry"

    def test_oserror_is_retry(self) -> None:
        assert classify(OSError("socket gone"))[0] == "retry"


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------
class NoopLimiter:
    """Rate limiter fake — instant sends, instant backoff."""

    async def wait(self) -> None:
        return None

    async def backoff(self, attempt: int) -> None:
        return None

    def classify(self, exc: BaseException):
        return classify(exc)


class RecordingBot:
    """Bot fake: sends succeed; chat ids in fail_on raise a permanent error."""

    def __init__(self, fail_on: set[int] | None = None, on_send=None) -> None:
        self.fail_on = fail_on or set()
        self.on_send = on_send
        self.sent: list[int] = []
        self.failed: list[int] = []

    async def send_message(self, chat_id: int, text: str, **kwargs) -> None:
        if self.on_send is not None:
            await self.on_send(self, chat_id)
        if chat_id in self.fail_on:
            self.failed.append(chat_id)
            raise _exc(TelegramForbiddenError, "bot was blocked by the user")
        self.sent.append(chat_id)
        return SimpleNamespace(message_id=len(self.sent))


async def _create_broadcast(repo: BroadcastRepository, targets, **kwargs) -> int:
    broadcast = await repo.create(
        created_by=1,
        content_type=kwargs.pop("content_type", "text"),
        target_type="all_users",
        text=kwargs.pop("text", "Hello!"),
        **kwargs,
    )
    await repo.set_targets(broadcast.id, targets)
    await repo.set_status(broadcast.id, "pending")
    return broadcast.id


async def _target_statuses(mk_sessions, broadcast_id: int) -> list[str]:
    async with mk_sessions() as session:
        result = await session.execute(
            select(BroadcastTarget.status)
            .where(BroadcastTarget.broadcast_id == broadcast_id)
            .order_by(BroadcastTarget.id.asc())
        )
        return [row[0] for row in result.all()]


async def _deliveries(mk_sessions, broadcast_id: int) -> list[BroadcastDelivery]:
    async with mk_sessions() as session:
        result = await session.execute(
            select(BroadcastDelivery).where(
                BroadcastDelivery.broadcast_id == broadcast_id
            )
        )
        return list(result.scalars().all())


def _worker(bot, repo) -> BroadcastWorker:
    return BroadcastWorker(bot, repo, NoopLimiter(), Settings(bot_token="x" * 50), EventBus())


class TestBroadcastWorker:
    async def test_run_once_mixed_delivery(self, db_setup, mk_sessions) -> None:
        """3 targets: 2 delivered, 1 permanent failure → completed."""
        repo = BroadcastRepository(mk_sessions)
        bid = await _create_broadcast(
            repo, [("user", 201), ("user", 202), ("user", 203)]
        )
        bot = RecordingBot(fail_on={202})
        worker = _worker(bot, repo)

        done = await worker.run_once(bid)
        assert done is True

        stats = await repo.stats(bid)
        assert stats["sent_count"] == 2
        assert stats["failed_count"] == 1
        assert stats["status"] == "completed"
        assert stats["remaining"] == 0

        statuses = await _target_statuses(mk_sessions, bid)
        assert statuses.count("sent") == 2
        assert statuses.count("failed") == 1

        deliveries = await _deliveries(mk_sessions, bid)
        assert len(deliveries) == 3
        failed = [d for d in deliveries if not d.ok]
        assert len(failed) == 1 and failed[0].chat_id == 202
        assert failed[0].error  # error text recorded

    async def test_retry_failed_re_attempts(self, db_setup, mk_sessions) -> None:
        repo = BroadcastRepository(mk_sessions)
        bid = await _create_broadcast(repo, [("user", 201), ("user", 202)])
        bot = RecordingBot(fail_on={202})
        worker = _worker(bot, repo)

        await worker.run_once(bid)
        assert (await repo.stats(bid))["failed_count"] == 1

        # The chat recovered — retry_failed re-queues the failed target.
        bot.fail_on.clear()
        requeued = await worker.retry_failed(bid)
        assert requeued == 1

        await worker.run_once(bid)
        stats = await repo.stats(bid)
        assert stats["sent_count"] == 2
        assert stats["failed_count"] == 0
        assert stats["status"] == "completed"

    async def test_pause_mid_run_and_resume(self, db_setup, mk_sessions) -> None:
        """A status flip mid-run stops delivery; resuming completes it."""
        repo = BroadcastRepository(mk_sessions)
        targets = [("user", 1000 + i) for i in range(30)]
        bid = await _create_broadcast(repo, targets)

        async def flip_to_paused(bot, chat_id):
            if len(bot.sent) + len(bot.failed) == 3:
                await repo.set_status(bid, "paused")

        bot = RecordingBot(on_send=flip_to_paused)
        worker = _worker(bot, repo)

        done = await worker.run_once(bid)
        assert done is True

        statuses = await _target_statuses(mk_sessions, bid)
        # Status re-check happens every 25 targets: 25 delivered, rest pending.
        assert statuses.count("sent") == 25
        assert statuses.count("pending") == 5
        assert (await repo.stats(bid))["status"] == "paused"

        # Resume: the worker picks up the remaining targets.
        await repo.set_status(bid, "pending")
        done = await worker.run_once(bid)
        assert done is True
        stats = await repo.stats(bid)
        assert stats["status"] == "completed"
        assert stats["sent_count"] == 30

    async def test_cancel_marks_remaining_skipped(self, db_setup, mk_sessions) -> None:
        repo = BroadcastRepository(mk_sessions)
        targets = [("user", 2000 + i) for i in range(30)]
        bid = await _create_broadcast(repo, targets)

        async def flip_to_cancelled(bot, chat_id):
            if len(bot.sent) + len(bot.failed) == 2:
                await repo.set_status(bid, "cancelled")

        bot = RecordingBot(on_send=flip_to_cancelled)
        worker = _worker(bot, repo)

        done = await worker.run_once(bid)
        assert done is True

        statuses = await _target_statuses(mk_sessions, bid)
        assert statuses.count("sent") == 25
        assert statuses.count("skipped") == 5
        stats = await repo.stats(bid)
        assert stats["status"] == "cancelled"
        assert stats["completed_at"] is not None

    async def test_run_once_ignores_unrunnable_states(self, db_setup, mk_sessions) -> None:
        repo = BroadcastRepository(mk_sessions)
        bid = await _create_broadcast(repo, [("user", 1)])
        worker = _worker(RecordingBot(), repo)

        await worker.run_once(bid)  # completes it
        assert await worker.run_once(bid) is False  # completed → not runnable
        assert await worker.run_once(99999) is False  # unknown id

    async def test_process_all_runs_pending_campaigns(self, db_setup, mk_sessions) -> None:
        repo = BroadcastRepository(mk_sessions)
        bid_a = await _create_broadcast(repo, [("user", 301), ("user", 302)])
        bid_b = await _create_broadcast(repo, [("user", 303)])
        bot = RecordingBot()
        worker = _worker(bot, repo)

        await worker.process_all()

        for bid in (bid_a, bid_b):
            stats = await repo.stats(bid)
            assert stats["status"] == "completed"
            assert stats["remaining"] == 0

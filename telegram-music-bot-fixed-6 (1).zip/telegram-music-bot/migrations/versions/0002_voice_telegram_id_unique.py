"""voice_accounts: unique telegram_id (duplicate-account prevention)

Revision ID: 0002_voice_telegram_id_unique
Revises: 0001_initial
Create Date: 2025-10-10

Backward-compatible, non-destructive migration:

1. Before creating the unique index, pre-existing duplicate telegram_id rows
   are merged: for every duplicated Telegram id only the newest row (highest
   id) keeps it, older duplicates have their telegram_id cleared. No rows,
   sessions or history are deleted.
2. The plain index from the baseline is replaced by a unique index. NULL
   telegram_id values (legacy rows whose identity was never captured) remain
   allowed — both PostgreSQL and SQLite treat NULLs as distinct inside
   unique indexes.

Downgrade restores the plain (non-unique) index; cleared telegram_id values
are not restored (they were duplicates by definition).
"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
from sqlalchemy import inspect, text

# revision identifiers, used by Alembic.
revision: str = "0002_voice_telegram_id_unique"
down_revision: Union[str, None] = "0001_initial"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_TABLE = "voice_accounts"
_OLD_INDEX = "ix_voice_accounts_telegram_id"
_NEW_INDEX = "uq_voice_accounts_telegram_id"


def upgrade() -> None:
    bind = op.get_bind()

    # 1. Merge duplicates — keep telegram_id only on the newest row.
    bind.execute(
        text(
            "UPDATE voice_accounts SET telegram_id = NULL "
            "WHERE telegram_id IS NOT NULL AND id NOT IN ("
            "  SELECT MAX(id) FROM voice_accounts "
            "  WHERE telegram_id IS NOT NULL GROUP BY telegram_id"
            ")"
        )
    )

    # 2. Replace the plain index with a unique one.
    _drop_index_if_exists(bind, _OLD_INDEX, _TABLE)
    _drop_index_if_exists(bind, _NEW_INDEX, _TABLE)
    op.create_index(_NEW_INDEX, _TABLE, ["telegram_id"], unique=True)


def downgrade() -> None:
    bind = op.get_bind()
    _drop_index_if_exists(bind, _NEW_INDEX, _TABLE)
    op.create_index(_OLD_INDEX, _TABLE, ["telegram_id"], unique=False)


def _drop_index_if_exists(bind, index_name: str, table_name: str) -> None:
    """Drop an index only when it actually exists (dialect-safe)."""
    inspector = inspect(bind)
    existing = {idx["name"] for idx in inspector.get_indexes(table_name)}
    if index_name in existing:
        op.drop_index(index_name, table_name=table_name)

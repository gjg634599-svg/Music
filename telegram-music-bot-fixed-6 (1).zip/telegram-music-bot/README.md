# Telegram Music Bot

A complete, Telegram-native music platform: stream music personally in your
private chat with the bot, play it in group voice chats through a fleet of
managed userbot accounts, and let a Spotify-style recommendation engine keep
the music going with autoplay. It ships with a full admin panel inside
Telegram — user and group management, broadcasts, appearance editor, dynamic
buttons, voice-account management, statistics and an audit log — plus
PostgreSQL, Redis, background workers and an FFmpeg audio pipeline. No
external frontend, no web dashboard: everything happens in Telegram.

**Documentation:** [Command Reference](#command-reference) ·
[Configuration](#configuration) ·
[Security Policy](SECURITY.md) ·
[Contributing Guide](CONTRIBUTING.md) ·
[Module Contracts](CONTRACTS.md)

---

## Features

### Personal Mode (private chat)

- Dashboard with dynamic, admin-configurable buttons (`/start`) — including
  🎧 Now Playing and 📋 Queue entries on fresh installs
- Music search across all configured sources with paginated results
  (each result shows artist, duration and provider)
- **Search in DM → play in a group voice chat**: press Play on any track in
  a private chat, pick one of your groups (or send a group link — public
  `t.me/<name>`, `@name` or a private `t.me/+hash` invite) and the bot
  resolves the target, verifies the voice chat, account access, your
  membership and permissions, then streams the selected track in that
  group's voice chat — with pause/skip/stop/queue controls right in your DM
  (see [DM → Group Playback](#dm--group-playback))
- Track pages: play, download, like, add to playlist, share
- Likes library and recently played history
- **New releases browse (`/new`)**: the freshest playable catalog tracks,
  newest first, with real offset pagination (8 per page) — also reachable as
  the `🆕 New Releases` button in *My Library*. Unplayable tracks never
  appear; an out-of-range page (stale keyboard) jumps to the last real page
  instead of showing an empty screen.
- Playlists: create, rename, delete, add/remove tracks, shuffle-play — plus one-tap export as a forwardable text message (track list with artists, durations and total runtime) and import from pasted/forwarded text (a new playlist is rebuilt from catalog matches)
- Personal queue with Now Playing controls (pause/resume/next/shuffle/repeat)
- Autoplay: when the queue runs dry, the recommendation engine refills it
  based on your taste profile
- **Listening stats (`/mystats`)**: total plays, unique tracks, liked count,
  total listening time, top-5 tracks and top-3 artists — aggregated from
  the listening history (also available as the `📊 My Stats` dashboard button)
- Audio uploads: send an audio file to the bot and it is probed (ffprobe),
  deduplicated and added to your library and the local catalog
- Music links: paste a link from a supported source and the bot resolves it
  to a playable track

#### Playlist export & import round-trip

Playlists can leave and re-enter the bot as plain text:

1. **Export** (📤 button on any playlist page) sends a standalone, forwardable
   message — numbered tracks with artists, per-track durations and the total
   runtime.
2. **Import** (📥 button in *My Playlists*) accepts that text back — forwarded
   or pasted — or any plain numbered list such as
   `1. Title — Artist`. Each line is resolved through the multi-source
   search; the best match (exact normalized title + artist scores highest)
   is added to a brand-new playlist.

Behaviour details:

- The import creates the playlist **only when at least one line matched**,
  so a failed import never leaves an empty shell behind.
- Lines without a plausible match are reported back (up to five listed).
- Duplicate lines collapse to one track; at most 50 lines per import.
- HTML entities (`&amp;`, `&lt;`…) round-trip exactly, so an export imported
  on another instance rebuilds identical titles.
- Matching uses the same normalization as the dedupe layer
  (`app/music/normalizer.py`), so casing, punctuation and
  `(Official Video)`-style suffix noise do not break a match.

For contributors — the import conversation is a two-step FSM
(`PlaylistFSM.importing` in `app/bot/handlers/playlists.py`): the 📥 button
enters the state and prompts for the text; the private-only text handler
parses and resolves it. A failed import keeps the FSM state so the user can
retry immediately, while any other navigation clears it. The parser
(`parse_export_text`) and the matching/scoring helpers live in
`app/users/playlists.py` and are covered by `tests/test_library_playlists.py`.

### Group Mode (voice chats)

- Playback in group voice chats via userbot accounts joined over MTProto
- Group queue with position ordering, shuffle and per-group queue limits
- Permission modes: `everyone`, `admins`, or `admins + DJs` per action
- Silent by default: the bot responds to commands and button presses only
  (see [Silent Group Mode](#silent-group-mode))
- Group commands: `/play`, `/new`, `/queue`, `/nowplaying`, `/skip`, `/pause`,
  `/resume`, `/stop`, `/shuffle`, `/repeat`, `/volume`, `/settings`, `/help`
- One Now Playing message per group, edited in place instead of spamming

### Voice Engine

- Multiple Telegram **user accounts** act as voice-chat participants
  (Telethon + py-tgcalls)
- Load balancing: sessions assigned to the account with the fewest active
  sessions (priority as tie-breaker), respecting a per-account session cap
- Health checks: accounts are periodically probed and marked
  `healthy` / `degraded` / `offline` / `auth_required`
- Automatic failover: on failure the session is released, the account is
  marked degraded and the group is reassigned to a healthy account
- Sessions are encrypted at rest (Fernet) — plaintext session strings never
  touch the database or the logs
- **Private-group automatic joining**: when a playback command arrives in a
  private group the voice account is not a member of, the bot creates a
  dedicated invite link and the account joins through it (see below)
- Optional subsystem: without API credentials the rest of the bot keeps
  working and the voice engine reports disabled

#### Private-group playback & automatic joining

Playing in a group's voice chat requires the *voice account* to be a member
of the group — that is a Telegram-level requirement, and joining the group
is a separate operation from joining its voice chat. The bot handles both:

1. **Membership check** — before playback the account's group membership is
   verified through MTProto (`channels.getParticipant` for supergroups,
   `messages.getFullChat` for basic groups). Positive results are cached for
   `VOICE_MEMBERSHIP_CACHE_SECONDS` to avoid needless API calls.
2. **Automatic join** — when the account is not a member and
   `VOICE_AUTO_JOIN_ENABLED` is on (default), the **bot** account creates
   a dedicated invite link for the group (Bot API `createChatInviteLink` —
   the bot must be a group admin with the *Invite users via link*
   permission) and the voice account imports it via Telethon's
   `ImportChatInviteRequest`. A dedicated link is used instead of
   `exportChatInviteLink` because exporting may rotate the group's
   PRIMARY link — the one the owner may have published elsewhere.
3. **Verification** — after joining, membership is re-checked. Groups with
   join requests enabled surface as "approval pending" (an admin must
   accept the request before playback can start).

Safety properties (all covered by tests):

- Links are only requested for groups where an authorized playback command
  occurred — the bot never tries to join unrelated groups.
- Created links are cached (`VOICE_INVITE_LINK_CACHE_SECONDS`) so the bot
  does not spam link creations.
- A failed join puts the group on a cooldown (`VOICE_JOIN_COOLDOWN_SECONDS`)
  — no endless retries, no Telegram flood wars. Expired links trigger
  exactly one re-creation, invalid/banned results drop the cached link.
- Every failure mode maps to an actionable user message (bot lacks invite
  permission, link expired/revoked, account banned, join request pending,
  flood wait with the server-provided retry time).
- Invite links and hashes are **never logged** (only host + length).
- Admins can check any account's access to any group: Voice Engine →
  Accounts → *Group Access* (reports member / not member / unknown, the
  auto-join state and any active cooldown).

If automatic joining cannot work in your setup (bot not admin, join
requests moderated, etc.), simply invite the voice account manually once —
the membership check then short-circuits and playback proceeds directly.

#### Voice session lifecycle (idle release)

A voice session is not held forever. The background idle loop
(`app/application.py::_voice_idle_loop`, 60 s cadence) releases sessions
that are **not playing** and have seen **no user interaction** for longer
than the configured timeout:

| Setting | Default | Where to change |
| --- | --- | --- |
| `VOICE_IDLE_TIMEOUT_MINUTES` | `5` | `.env` (global default) |
| `idle_timeout_minutes` (per group) | `None` → env default | `/settings` in the group |

Rules the release follows (all covered by tests):

- A session that is **playing** is never released — live playback wins.
- Any user interaction (play, pause, resume, skip, stop) resets the idle
  window for that group's session.
- The per-group setting overrides the env default, so one group can hold
  its slot for an hour while another releases after five minutes.
- Release publishes a `voice:idle_released` event and frees the account
  slot for load balancing immediately.

### Recommendation Engine

- Deterministic, weighted scoring across nine components:
  track similarity, artist similarity, genre similarity, user preference,
  popularity, playlist context, plus penalties for recently played,
  skipped and repeated tracks
- Taste profiles built from likes, listening history and play counts —
  separately per **user** and per **group** (aggregated from members)
- Admin-tunable: all weights live in the `recommendation_weights` bot
  setting and can be edited from the admin panel, no restart required
- Every autoplay pick is logged as a recommendation event for analytics

#### Tuning the weights

The final score of a candidate track is:

```
score = 1.0·track_sim + 1.5·artist_sim + 1.2·genre_sim + 2.0·user_pref
      + 0.6·popularity + 0.8·playlist_ctx
      − 2.5·recently_played − 1.8·skipped − 6.0·same_track
```

| Weight (bot setting key) | Default | Raises / lowers |
| --- | --- | --- |
| `track_similarity` | `1.0` | tracks similar to what you already play |
| `artist_similarity` | `1.5` | the artists you already listen to |
| `genre_similarity` | `1.2` | genres present in your taste profile |
| `user_preference` | `2.0` | your overall taste profile overlap |
| `popularity` | `0.6` | globally popular tracks |
| `playlist_context` | `0.8` | context of the playlist autoplay started from |
| `recently_played_penalty` | `2.5` | tracks played in the last hours |
| `skipped_track_penalty` | `1.8` | tracks you skipped |
| `same_track_penalty` | `6.0` | the track that just finished |

Tuning recipes:

- **More variety** — raise `recently_played_penalty` (e.g. `4.0`) and
  lower `artist_similarity` (e.g. `0.8`): autoplay wanders further from
  the last few tracks.
- **More comfort / familiar** — raise `artist_similarity` and
  `user_preference`, lower penalties: autoplay loops closer to your
  library.
- **Discovery mode** — raise `popularity` *down* (`0.2`) and
  `genre_similarity` up (`1.8`) to favor off-genre-but-related picks.

Weights apply immediately per candidate evaluation — no restart, no cache
flush needed. `recommendation_options` (`candidate_limit`, `min_score`)
control the candidate pool size and the acceptance threshold. The engine
is deterministic (seeded tie-breaks), so the same history always yields
the same picks — which also makes A/B tuning reproducible. When you later
plug in an ML model, it replaces `scoring.py` only; profiles, candidate
sourcing and the settings plumbing stay unchanged.

### Admin Panel (inside Telegram)

- `/admin` panel with role-based access: `super_admin`, `admin`, `moderator`
- User management (search, inspect, block/unblock) and group management
- Broadcasts: create, preview, send, pause, stop, retry failed, history
- Appearance editor: edit every bot message template and the bot logo
- Dynamic buttons builder: add, edit, reorder, enable/disable start-screen
  buttons (callback, URL, add-to-group deep link types)
- Voice accounts: list, enable/disable, reconnect, delete, inspect sessions
- Statistics: users, groups, plays, likes, autoplay picks, broadcasts,
  system health
- Settings: recommendation weights, autoplay, feature flags, broadcast limits
- Maintenance mode (global pause, optionally letting groups keep playing)
- Audit log of admin actions

### Broadcast System

- Content types: text, photo, video, audio, document, animation, voice,
  media-group albums, and copy-message (re-send an existing message as-is)
- URL buttons (https/tg only — javascript/data URLs are rejected)
- Targeting segments: all/active/inactive users, users by language, users
  with groups, specific user IDs, all/active groups, specific groups
- Worker-based delivery: runs in the background worker process, decoupled
  from the bot
- Telegram FloodWait aware: respects `retry_after`, exponential backoff on
  transient errors, permanent failures (blocked, kicked, deactivated) are
  recorded without retry
- Progress reporting, pause/resume, stop/cancel and retry-failed controls
- Rate-capped by design (default 25 messages/second, configurable)

### Infrastructure

- PostgreSQL with SQLAlchemy 2.0 async + Alembic migrations (33 tables)
- SQLite demo fallback: the bot runs with just `BOT_TOKEN`, no database
  server required
- Redis for caching, rate limiting, distributed locks and the job queue —
  with transparent in-memory fallbacks when Redis is not configured
- Background workers: audio processing, metadata extraction, audio sending,
  cleanup, broadcasts and voice health checks — with retries and a
  dead-letter queue
- FFmpeg audio pipeline: probing, opus 48 kHz stereo transcoding for voice
  chats, artwork extraction, demo track synthesis
- Internal health endpoint (`GET /health`) used by the Docker healthcheck
- Structured logging (text or JSON) with automatic secret redaction
- Per-user and per-group rate limiting, SSRF-protected URL processing,
  upload validation and sandboxed file storage

---

## Architecture

The application is organized in four layers:

```text
+=====================================================================+
|                     BOT CONTROL PLANE (aiogram 3.x)                  |
|   message handlers (personal / group / admin)                        |
|   callback handlers  -  inline keyboards  -  FSM states              |
|   middleware gates: silent-group, rate limit, logging, auth          |
+-----------------------^-----------------------------+----------------+
                        | updates / callbacks         |
+-----------------------+-----------------------------v----------------+
|                           MUSIC PLATFORM                             |
|   music: sources (local / Jamendo / Audius / direct URL), search     |
|   aggregation, metadata probing, track resolution                    |
|   playback: queue, session state, autoplay, playback controller      |
|   recommendation: taste profiles, weighted scoring, engine           |
|   users: library, history, playlists   groups: settings, permissions |
|   broadcast: composer, targets, rate limiter, worker                 |
|   admin: permissions, appearance, buttons, settings, stats, audit    |
+-----------------------^-----------------------------+----------------+
                        | tracks / opus files           |
+-----------------------+-----------------------------v----------------+
|                    VOICE ENGINE (MTProto userbots)                   |
|   VoiceManager facade  -  account clients (Telethon)                 |
|   session runtimes (heartbeat + duration timers)                     |
|   health monitor  -  assignment strategy  -  failover controller     |
|   NativeTransport (py-tgcalls)  ->  group voice chats                |
|   FFmpeg toolkit: probe / opus transcode / artwork                   |
+-----------------------^-----------------------------+----------------+
                        | repositories / events          |
+-----------------------+-----------------------------v----------------+
|                           INFRASTRUCTURE                             |
|   PostgreSQL + Alembic (repositories over async sessions)            |
|   Redis or in-memory: cache, rate limits, locks, job queue           |
|   background workers (WorkerManager)  -  health endpoint             |
|   security: SSRF validation, Fernet encryption, secret redaction     |
+=====================================================================+
```

### Packages

| Package | Purpose |
| --- | --- |
| `app/admin` | Admin panel services: roles/permissions, appearance, buttons, settings, statistics, audit |
| `app/audio` | FFmpeg toolkit, audio processor (voice/send preparation), heavy-job pipeline |
| `app/bot` | aiogram layer: `handlers/`, `callbacks/`, `keyboards/`, `middleware/`, `services.py` (the `ServiceContainer` injected into every handler) |
| `app/broadcast` | Broadcast composer, target segments, Telegram rate limiter, broadcast worker |
| `app/cache` | Cache/rate-limit/lock protocols with Redis and in-memory implementations |
| `app/database` | Async engine, 33 ORM `models/`, `repositories/` (the only path to the DB), seeded defaults |
| `app/groups` | Group lifecycle, settings, permission modes, silent-mode logic |
| `app/music` | Music platform: `sources/` (local, Jamendo, Audius, direct URL), search aggregation, metadata, resolver, `MusicService` facade |
| `app/playback` | Queue manager, session state, autoplay, playback controller, event bus |
| `app/recommendation` | Taste profiles, similarity metrics, weighted scoring, recommendation engine |
| `app/security` | SSRF-safe URL validation, callback/upload validation, Fernet `SessionCipher`, secret masking |
| `app/users` | User lifecycle, likes library, listening history, playlists |
| `app/voice` | Voice engine: transports, account clients, session runtimes, health, assignment, failover, `VoiceManager` |
| `app/workers` | Job types, task registry, `WorkerManager` (Redis list or in-memory queue) |
| `app/utils` | Formatting, pagination, Telegram helpers (`safe_edit`, `edit_or_send`, `safe_answer`), time helpers |

### Update flow

1. A Telegram update arrives (message or callback query).
2. Middleware gates run first: silent-group filtering (non-command group
   messages are dropped), rate limiting (search/heavy/command/group buckets),
   request logging, and the auth gate (admin-panel guard for `adm:` callbacks,
   maintenance mode, blocked users).
3. The handler receives the update plus the shared `ServiceContainer` and
   calls a service (music, playback, groups, admin, ...).
4. Services contain all business logic and talk to the database exclusively
   through repositories (`app/database/repositories/`) on async sessions.
5. For group playback: the playback controller asks the queue for the next
   track, the audio processor prepares an opus file, and the voice session
   manager acquires an account (least-loaded, healthy), joins the group
   voice chat through py-tgcalls and plays — publishing `track_end` events
   back onto the event bus so the queue auto-advances.

---

## Requirements

- Python 3.12 or newer
- FFmpeg (and ffprobe, installed alongside) — audio probing, transcoding,
  artwork extraction
- PostgreSQL 16+ for production (or nothing: SQLite is used automatically
  for local demos and tests)
- Redis, optional (in-memory fallbacks are used when `REDIS_URL` is unset)
- A Telegram bot token from [@BotFather](https://t.me/BotFather)
- For the voice engine only: Telegram API ID/API hash from
  [my.telegram.org](https://my.telegram.org) and one or more Telegram user
  accounts to act as voice-chat participants

---

## Quick Start (local)

```bash
# 1. Get the project and enter the directory
cd telegram-music-bot

# 2. Create and activate a virtualenv
python3 -m venv .venv
source .venv/bin/activate          # Linux / macOS / WSL
# .venv\Scripts\activate           # Windows (cmd / PowerShell)

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure
cp .env.example .env               # then edit .env and set BOT_TOKEN
# (Windows: copy .env.example .env)

# 5. Create the database schema
alembic upgrade head

# 6. Run
python run.py
```

Or let the setup script do steps 2-4 for you (it also generates a
`VOICE_SESSION_ENCRYPTION_KEY`):

```bash
bash scripts/dev_setup.sh
```

> The file may not carry the executable bit in your copy — run it with
> `bash` as shown, or `chmod +x scripts/dev_setup.sh` once.

Demo mode works out of the box with just `BOT_TOKEN`:

- No `DATABASE_URL` set → a local SQLite database (`storage/musicbot.db`)
  is created automatically.
- No `REDIS_URL` set → in-memory cache, rate limits and locks are used.
- No voice accounts → personal mode fully works; group playback reports
  that no voice account is available.

To give search and autoplay something to play, seed a small demo catalog
(requires FFmpeg; it synthesizes short demo tracks and artwork):

```bash
python scripts/seed_catalog.py
```

Process roles:

```bash
python run.py                  # bot + workers in one process (default)
python run.py --role bot       # Telegram bot process only
python run.py --role worker    # background workers only
```

---

## Docker

The stack is defined in `docker-compose.yml` (Compose V2, no `version` key):

| Service | Image | Role |
| --- | --- | --- |
| `postgres` | `postgres:16-alpine` | PostgreSQL database (no host ports; internal network only) |
| `redis` | `redis:7-alpine` | Cache, rate limits, locks, job queue (append-only persistence) |
| `bot` | built from `Dockerfile` | Telegram bot process (`python run.py --role bot`) |
| `worker` | built from `Dockerfile` | Background workers (`python run.py --role worker`) |

`bot` and `worker` share the same image — Compose builds it once and only the
`command:` differs. Both run `alembic upgrade head` before starting; on a
cold database they may race, in which case the loser exits and is restarted
by `restart: unless-stopped` once the schema exists.

```bash
# 1. Configure (never commit .env)
cp .env.example .env     # edit BOT_TOKEN (and optionally ADMIN_IDS, etc.)

# 2. Build and start
docker compose up -d --build

# 3. Watch the logs
docker compose logs -f bot

# 4. Stop
docker compose down              # add -v to also drop the postgres/redis volumes
```

Notes:

- `postgres` and `redis` are **not** published to the host — they live on the
  internal Compose network. To inspect PostgreSQL from the host, uncomment
  the `ports:` block in `docker-compose.yml`.
- `./storage` is bind-mounted into both bot and worker at `/app/storage`
  (music files, downloads, artwork, temp).
- The image runs as the unprivileged `musicbot` user and includes FFmpeg.
  The Dockerfile healthcheck polls `http://127.0.0.1:$HEALTH_PORT/health`
  with a plain Python one-liner (no curl needed).
- `docker compose exec bot python scripts/add_voice_account.py ...` is the
  supported way to add voice accounts to a containerized deployment
  (interactive login prompts work through `docker compose exec -it` when
  attached to a TTY).

---

## Configuration

All configuration comes from environment variables, optionally via a `.env`
file in the working directory (loaded automatically by python-dotenv).
Invalid values fail fast at startup with an actionable message.

| Variable | Default | Description |
| --- | --- | --- |
| `BOT_TOKEN` | *(required)* | Bot token from @BotFather. |
| `TELEGRAM_API_ID` | *(unset)* | Telegram API id from my.telegram.org. Required for the voice engine. Must be set together with `TELEGRAM_API_HASH`. |
| `TELEGRAM_API_HASH` | *(unset)* | Telegram API hash. Must be set together with `TELEGRAM_API_ID`. |
| `DATABASE_URL` | `sqlite+aiosqlite:///./storage/musicbot.db` | `postgresql+asyncpg://user:pass@host:5432/dbname` for production. Only `postgresql+asyncpg://` and `sqlite+aiosqlite://` schemes are accepted. |
| `REDIS_URL` | *(unset)* | e.g. `redis://localhost:6379/0`. Unset (or unreachable at startup) → in-memory fallbacks. |
| `ADMIN_IDS` | *(unset)* | Comma-separated Telegram user IDs granted `super_admin` rights. |
| `MAINTENANCE_MODE` | `false` | Start the bot in maintenance mode. Normally toggled at runtime from the admin panel. |
| `VOICE_SESSION_ENCRYPTION_KEY` | *(unset)* | Fernet key encrypting voice-account sessions at rest. Required for the voice engine. |
| `MAX_VOICE_SESSIONS_PER_ACCOUNT` | `5` | Maximum simultaneous group calls joined by one voice account. |
| `VOICE_HEALTH_CHECK_INTERVAL` | `60` | Seconds between voice-account health checks. |
| `VOICE_IDLE_TIMEOUT_MINUTES` | `5` | Minutes after which an idle voice session is released. |
| `VOICE_AUTO_JOIN_ENABLED` | `true` | Let voice accounts join private groups via a bot-created invite link when they are not members yet (see [Private-group playback & automatic joining](#private-group-playback--automatic-joining)). |
| `VOICE_JOIN_COOLDOWN_SECONDS` | `300` | Cooldown after a failed auto-join attempt for the same group. |
| `VOICE_INVITE_LINK_CACHE_SECONDS` | `600` | How long a created invite link is reused before creating a new one. |
| `VOICE_MEMBERSHIP_CACHE_SECONDS` | `600` | How long a positive membership check is trusted before re-checking. |
| `FFMPEG_PATH` | `ffmpeg` | Path or name of the ffmpeg binary. |
| `FFPROBE_PATH` | `ffprobe` | Path or name of the ffprobe binary. |
| `MAX_AUDIO_SIZE_MB` | `45` | Cap for files delivered through the Bot API (personal playback / direct-URL tracks sent as audio). Hard cap 49 — Telegram's bot upload limit is 50 MB. |
| `VOICE_MAX_AUDIO_SIZE_MB` | `200` | Cap for voice-chat streaming downloads (played locally via ffmpeg, never re-uploaded; bounded 1–2000). Long DJ mixes exceed 45 MiB — this cap keeps group playback working while bounding disk usage. |
| `STORAGE_DIR` | `storage` | Root directory for music files, downloads, artwork and temp files. |
| `AUTOPLAY_ENABLED` | `true` | Refill an empty queue with recommendations by default. |
| `GROUP_SILENT_MODE` | `true` | Ignore non-command group messages (see Silent Group Mode). |
| `GROUP_COMMAND_AUTO_DELETE` | `true` | Best-effort deletion of RECOGNIZED group command messages after they are handled (`/play`, `/play@Bot`, …). Never touches private chats or plain messages; missing `delete_message` permission degrades silently. |
| `PROGRESS_EDIT_INTERVAL` | `15` | Seconds between live progress edits of the group Now Playing message (playhead bar + elapsed time). `0` disables the live ticker. |
| `DEFAULT_GROUP_QUEUE_LIMIT` | `50` | Default per-group queue length. |
| `RATE_LIMIT_SEARCH_PER_MINUTE` | `10` | Search requests per user per minute. |
| `RATE_LIMIT_HEAVY_PER_MINUTE` | `3` | Heavy operations (downloads, uploads) per user per minute. |
| `RATE_LIMIT_COMMANDS_PER_MINUTE` | `30` | Bot commands per user per minute. |
| `RATE_LIMIT_GROUP_PER_MINUTE` | `20` | Commands per user per minute inside groups. |
| `BROADCAST_RATE_PER_SECOND` | `25` | Broadcast send rate cap (validated to be within (0, 30]). |
| `BROADCAST_WORKER_CONCURRENCY` | `2` | Parallel delivery tasks inside the broadcast worker. |
| `BROADCAST_MAX_RETRIES` | `3` | Send attempts per broadcast target before marking it failed. |
| `JAMENDO_CLIENT_ID` | *(unset)* | Jamendo API client id. Unset → the Jamendo source is skipped. |
| `LOG_LEVEL` | `INFO` | `DEBUG`, `INFO`, `WARNING`, `ERROR`. |
| `LOG_FORMAT` | `text` | `text` or `json` structured logging. |
| `HEALTH_PORT` | `8080` | Port for the internal `GET /health` endpoint. `0` disables it. |
| `HTTP_TIMEOUT` | `20` | Timeout in seconds for outbound HTTP (music sources, file downloads). |
| `DOWNLOAD_CACHE_RETENTION_HOURS` | `72` | How long a fully-downloaded cached track stays on disk (completed download cache, `storage/downloads`). `0` disables cleanup. Files backing ACTIVE playback are always protected; permanent uploads/artwork/database files are never touched. |
| `DOWNLOAD_CACHE_CLEANUP_INTERVAL_MINUTES` | `60` | How often the completed-download-cache sweeper runs. `0` disables the periodic job. |

Validation highlights (see `app/config.py`):

- `BOT_TOKEN` is required and must look like a Telegram bot token.
- `TELEGRAM_API_ID` and `TELEGRAM_API_HASH` must be set as a pair.
- `DATABASE_URL` must use `postgresql+asyncpg://` or `sqlite+aiosqlite://`.
- `BROADCAST_RATE_PER_SECOND` must be in (0, 30].
- `MAX_AUDIO_SIZE_MB` cannot exceed 49.
- `VOICE_MAX_AUDIO_SIZE_MB` must be within 1–2000.
- `DOWNLOAD_CACHE_RETENTION_HOURS` / `DOWNLOAD_CACHE_CLEANUP_INTERVAL_MINUTES` cannot be negative.
- `PROGRESS_EDIT_INTERVAL` cannot be negative.
- `HEALTH_PORT` must be in 0-65535 (0 disables the endpoint).

Volume note: `/volume` and the player's ± buttons use a human **0–100
percent** scale (persisted per group). The voice engine maps the percent
to its internal 0–200 scale automatically.

Generate a voice encryption key:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

---

## Database

- ORM models live in `app/database/models/` (33 tables: users and
  preferences, likes/history/search history, artists/albums/genres/tracks,
  playlists, queues and playback sessions, groups/members/settings, admins
  and audit logs, bot settings/messages/assets/buttons, broadcasts and
  deliveries, voice accounts/health/sessions/events/assignments, analytics
  and recommendation events).
- Every write goes through a repository class in
  `app/database/repositories/` on top of async SQLAlchemy sessions.
- Schema changes are managed with Alembic:

```bash
alembic upgrade head       # apply all migrations (PostgreSQL production)
alembic current            # show the applied revision
```

- In demo mode (no `DATABASE_URL`), SQLite tables are created automatically
  on first start — no migration step needed. Migrations are the way to go
  for PostgreSQL, which is exactly what `docker-compose.yml` runs before
  each service starts.

---

## Telegram Setup

1. **Create the bot.** Message [@BotFather](https://t.me/BotFather), send
   `/newbot`, choose a name and username, and copy the token into
   `BOT_TOKEN` in your `.env`.
2. **Keep Privacy Mode ON.** The bot is command-driven — it only needs to
   see commands and button presses. With privacy mode enabled it also stays
   perfectly quiet in groups, which is exactly what the silent-group design
   expects. Disabling privacy mode is not required and not recommended.
3. **Command lists.** The bot registers its private-chat and group command
   menus with Telegram automatically at startup, so `/setcommands` is
   optional. The menus are:

   | Scope | Commands |
   | --- | --- |
   | Private chat | `/start`, `/search`, `/playlists`, `/liked`, `/new`, `/history`, `/mystats`, `/settings`, `/commands`, `/group`, `/help` (plus `/admin` for admins) |
   | Groups | `/play`, `/search`, `/new`, `/queue`, `/nowplaying`, `/skip`, `/pause`, `/resume`, `/stop`, `/shuffle`, `/repeat`, `/volume`, `/settings`, `/help` |

4. **Voice engine credentials (optional).** Log in at
   [my.telegram.org](https://my.telegram.org), open *API development tools*,
   create an application and copy the **api_id** and **api_hash** into
   `TELEGRAM_API_ID` / `TELEGRAM_API_HASH`. These are only needed for group
   voice-chat playback; without them the voice engine stays disabled and
   everything else works.

---

## Command Reference

Every command below is implemented in `app/bot/handlers/` and covered by the
smoke-test suite. Group commands are also gated by the silent-mode rules
(see [Silent Group Mode](#silent-group-mode)).

### Personal (private chat)

| Command | What it does |
| --- | --- |
| `/start` | The dashboard: dynamic admin-configurable buttons, quick stats |
| `/search <query>` | Multi-source search with paginated inline results |
| `/playlists` | List playlists, create/rename/delete, add tracks, export as shareable text (📤 button) and import from text (📥 button) |
| `/liked` | Liked songs library |
| `/new` | Browse the newest catalog tracks — freshest first, 8 per page (also the 🆕 button in My Library) |
| `/history` | Recently played tracks |
| `/mystats` | Listening stats: plays, unique tracks, likes, listening time, top tracks and artists |
| `/nowplaying` | Now Playing screen with playback controls |
| `/queue` | The personal queue (reorder, clear) |
| `/skip` / `/pause` / `/resume` / `/stop` | Personal playback control |
| `/shuffle` / `/repeat` / `/volume <0-100>` | Shuffle, repeat mode, volume |
| `/settings` | Personal preferences (autoplay, defaults) |
| `/group` | "Add me to a group" deep link |
| `/commands` / `/help` / `/about` | Command list, help, about |
| *(send audio file)* | Upload -> ffprobe -> dedupe -> your library + catalog |
| *(send music link)* | Resolve to a playable track from the supported sources |

### Group (voice chats)

| Command | What it does |
| --- | --- |
| `/play <query>` (alias `/p`) | Search and queue a track into the group voice chat |
| `/search <query>` | Search inside the group (results as buttons + Now Playing / Queue follow-up row) |
| `/new` | Radio-style fresh-releases browse: numbered tracks, one-tap **tap-to-queue** buttons (permission-gated), ⬅️/➡️ pagination |
| `/queue` (alias `/q`) | Show the group queue with positions, durations, requesters and total time |
| `/nowplaying` (alias `/np`) | Re-render the single Now Playing message |
| `/skip` (alias `/next`) / `/pause` / `/resume` / `/stop` | Playback control (permission-checked) |
| `/shuffle` / `/repeat` / `/volume <0-100>` | Queue shuffle, repeat, volume (percent) |
| `/settings` | Group settings: permissions, queue limit, idle timeout |
| `/help` | Group-specific help text |

> The Now Playing message itself carries the full control panel —
> ⏸ Pause / ⏭ Skip / 🔀 Shuffle / 🔁 Repeat / 🔉🔊 volume steps / 📋 Queue /
> 🛑 Stop — every button permission-checked per press.

> Permission modes (`everyone` / `admins` / `admins + DJs`) control who may
> run playback commands -- see `/settings` in the group.

### Admin (private chat, role-guarded)

| Command | What it does |
| --- | --- |
| `/admin` | The admin panel root (role-aware sections) |
| `/admin` -> *Users* | Search, inspect, block/unblock users |
| `/admin` -> *Groups* | Inspect groups, settings, playback state |
| `/admin` -> *Broadcast* | Compose, preview, send, pause, stop, retry failed |
| `/admin` -> *Appearance* | Edit message templates, logo, dashboard buttons |
| `/admin` -> *Voice* | Accounts list, enable/disable, reconnect, delete |
| `/admin` -> *Stats* | Users, groups, plays, broadcasts, recommendations |
| `/admin` -> *Settings* | Recommendation weights, autoplay, feature flags |
| `/admin` -> *Audit* | Admin action audit log |

---

## Voice Account Setup

Group voice-chat playback is performed by real Telegram **user accounts**
joined to the call over MTProto (Telethon + py-tgcalls). Two supported
ways to connect an account — both use the **same login service**
(`app/voice/login.py`), so validation, duplicate detection, encryption and
cleanup behave identically:

### 1. In-chat login wizard (recommended)

Admins with the `voice` permission can add accounts entirely from Telegram:

```
/admin → Voice Engine → Voice Accounts → ➕ Add Account → 🔗 Connect Account
```

The wizard walks through phone number → login code → 2FA password (when
enabled) in the admin's **private chat**:

- the acknowledgement, progress and result all edit **one message**;
- every step re-validates the admin's `voice` permission and binds to the
  admin who started the flow — nobody else can continue or hijack it;
- phone / code / password messages are deleted after reading, never echoed,
  never logged (only a pre-masked phone hint like `+98***89` is stored);
- login codes can be re-sent; invalid codes and passwords are retryable;
- Telegram FloodWait is reported with the exact wait;
- duplicates (same Telegram id) are detected before anything is stored;
- the session is Fernet-encrypted before being written to the database and
  the account pool reloads automatically — the wizard never needs a restart;
- abandoned flows expire after 10 minutes of inactivity and clean up their
  temporary MTProto connection.

> The wizard distinguishes **authentication** from **playback readiness**:
  a successful login proves the account works, not that voice-chat streaming
  works. Use the wizard's *Run Health Check* and then `/play` in a real group
  voice chat to verify end-to-end.

### 2. Server-side CLI (fallback)

For headless servers you can still run the interactive script:

```bash
python scripts/add_voice_account.py --label "Account 1" --phone +15551234567

# optional per-account tuning
python scripts/add_voice_account.py --label "Backup" --phone +15551234567 \
    --max-sessions 3 --priority 10
```

The script drives the same state machine as the wizard: it sends a login
code to the Telegram app on that phone number, prompts you for it (plus the
two-factor password if enabled), encrypts the resulting session and stores
the account row. A `--label` is optional (auto-generated `Account N` when
omitted in the wizard).

The security model:

- Session strings are encrypted with the `VOICE_SESSION_ENCRYPTION_KEY`
  (Fernet) before being written to the database, and are decrypted only in
  memory when the account connects. They are never printed and never
  logged (the logging layer redacts `session*` fields and session-shaped
  strings anyway).
- Bot tokens are rejected as user-account credentials by the wizard and CLI.
- Each account has a session cap (`MAX_VOICE_SESSIONS_PER_ACCOUNT`) so a
  single account cannot be spread across too many simultaneous calls.

Operation:

- **Health checks.** Accounts are probed every
  `VOICE_HEALTH_CHECK_INTERVAL` seconds; statuses are
  `healthy` / `degraded` (slow) / `offline` / `auth_required`.
- **Assignment.** When a group starts playback, the account with the fewest
  active sessions (highest priority on ties) is chosen.
- **Failover.** If an account fails mid-session, the session is released,
  the account is marked degraded and the group is transparently reassigned
  to a healthy account.
- **Management.** Admins can list, enable/disable, reconnect and delete
  voice accounts from `/admin` → Voice.

Never paste session strings, login codes or passwords into any chat,
including the bot's own chat.

## Admin Setup

1. Set `ADMIN_IDS` in `.env` to a comma-separated list of Telegram user IDs
   (yours, plus any co-founders). These IDs are always `super_admin` and
   cannot be demoted or removed from the panel.
2. Start the bot and send `/admin` in the private chat.
3. Roles:

   | Role | Permissions |
   | --- | --- |
   | `super_admin` | Everything, plus managing admin roles and maintenance mode |
   | `admin` | Users, groups, broadcasts, appearance, buttons, voice accounts, settings, statistics |
   | `moderator` | Users, groups, statistics |

4. Add more admins from `/admin` → roles; every administrative action is
   written to the audit log (admin, action, target, result, timestamp).

To find your Telegram user ID, message a lookup bot such as
[@userinfobot](https://t.me/userinfobot) or check your Telegram settings.

---

## Music Sources

- **Local catalog** — tracks resolved from your database: audio files sent
  to the bot (uploads are probed, deduplicated by content hash and stored
  under `storage/music/`) and tracks seeded via scripts.
- **Jamendo** — Creative Commons music via the Jamendo API. Register for a
  free client id at <https://devportal.jamendo.com> and set
  `JAMENDO_CLIENT_ID`. Unset → the source is simply skipped.
- **Audius** — the public Audius API, no key required. Enabled by default.
- **Direct audio links** — `https`/`http` links to audio files are
  validated (SSRF checks, size cap) and downloaded on demand.
- **Search** fans out to all configured sources in parallel, merges and
  deduplicates results, and caches them for five minutes.

Policy: the bot integrates **authorized sources only**. Known streaming
platforms that do not permit API playback (Spotify, YouTube, SoundCloud,
Deezer, Apple Music) are explicitly rejected with a clear error — there is
no ripping, scraping or DRM circumvention. Respect the license terms of any
catalog you connect (Jamendo content is Creative Commons).

---

## Search Experience (animated, private chat)

Every private-chat search gets immediate feedback — one status message,
edited in place through the whole flow:

1. **Immediate acknowledgement** — `🔎 Searching Music / Query: … / ⏳ Finding
   matching tracks…` is sent the moment the query is accepted, before any
   provider is contacted. Nobody waits in silence.
2. **Spinner animation** — the same message cycles a lightweight
   `◉ ○ ○ ○` spinner (~every 3 s, inside Telegram's edit rate limits) while
   the sources run **concurrently** (local catalog, Jamendo, Audius).
3. **Provider-aware progress** — real statuses only, updated when the actual
   source operation completes: `✓ Local Library`, `⌛ Audius — timed out`,
   `✗ Jamendo — unavailable`, `◉ Checking remaining sources…`. Nothing is
   invented; no fake percentages.
4. **Ten-second escalation** — if sources are slow, the message becomes
   `🎧 Still Searching…` with a playful, **admin-customizable** text
   (message key `search_slow`, editable from `/admin` → Appearance):
   default *“🥹 Babby, I'm trying hard! Some music sources are taking longer
   than usual.”*
5. **Final results on the same message** — `🎵 Search Results / Query / Found:
   N tracks` with the standard numbered keyboard and pagination. No results →
   `🎵 No Tracks Found` with a 🔄 Search Again button; every source failed →
   `⚠️ Search Temporarily Unavailable` with retry.

Timeouts are bounded: each source gets 8 s, the whole search 12 s — a slow
provider can no longer stall the search (a straggler is cancelled and usable
partial results are returned). A new search in the same chat supersedes any
still-running animation, so stale progress can never overwrite newer results.
Group chats never animate — see [Silent Group Mode](#silent-group-mode).

---

---

## DM → Group Playback

Search in a private chat, listen together in a group voice chat — the full
workflow with honest confirmation at every step:

1. **Play in a DM opens the destination chooser** — your known groups (the
   bot saw you in them), a *🔗 Send a group link* option, and the classic
   *🎧 Play here* (private audio file) fallback.
2. **Group links resolve through the voice account** (MTProto): public
   `t.me/<username>` links, bare `@usernames` and private invite links
   (`t.me/+hash`, `t.me/joinchat/<hash>`, `tg://join?invite=`). Broadcast
   channels and user links are rejected with a clear reason; dead, expired
   or revoked invites say exactly that; join-request groups report
   *approval pending*.
3. **Every prerequisite is verified before anything plays**: the group has
   an ACTIVE voice chat, the voice account can access the group
   (auto-join via the documented invite flow when
   `VOICE_AUTO_JOIN_ENABLED`), the requesting user is a member of the
   target group, and the group's permission model allows them to start
   playback. Each failure explains what a user or group admin must do.
4. **Playback is routed to the target group** — never the DM chat id: the
   group's own queue and voice session, isolated per group, with an
   in-flight execution lock so repeated clicks / duplicate messages can
   never double-start playback. Success is confirmed only after the
   controller actually started (a busy group reports *Added to the queue,
   position #N* instead).
5. **Controls stay in your DM**: `dmc:` buttons (pause / skip / stop /
   queue) scoped to that group and permission-checked on every press — plus
   the same controls in the group chat itself.

Pending operations live in the FSM (per user+chat, JSON-serializable,
Redis-friendly) and expire after 10 minutes with a recovery message.
**Back** returns to the previous screen (link prompt → chooser → track
page), **Cancel** clears only the pending operation (your search state and
other users' operations are untouched; nothing is played), **X** dismisses
the interface only. The three are deliberately distinct behaviours.

### Provider identity (search → catalog → playback)

Every catalog row keeps its original provider identity: an Audius track
cached earlier remains `source='audius'` with its Audius track id (the
database primary key never masquerades as a provider id). Stream resolution
routes through the track's own provider adapter using the provider-specific
id — Audius search results (which carry no media URL by design) resolve
behind `get_stream()` and are cached on the row. Legacy duplicate rows
created by an older version self-heal on first playback and are hidden from
catalog browsing.

---

## Player UI / UX

The player interface follows the patterns established music bots and
music-player interfaces converge on (the references actually inspected
during the round-4 redesign are listed in
[docs/TELEGRAM_COMPATIBILITY_AUDIT.md](docs/TELEGRAM_COMPATIBILITY_AUDIT.md)
§17):

- **One Now Playing layout everywhere** — the personal player, the group
  control message, the dashboard screen and the DM control screen render
  through a single shared builder: title, artist, playhead progress bar
  `▬▬▬▬▬●─────────` with clamped `1:23 / 3:53` timecodes, active-mode
  badges (🔀 Shuffle · 🔁 Repeat: All · 🤖 Autoplay), optional requester
  attribution and the queue count.
- **Stateful toggles** — Shuffle and Repeat buttons carry their current
  mode on the label (`🔀 Shuffle: On`, `🔁 Repeat: One`), on every player
  and queue keyboard, in DMs and groups alike. A press always shows what
  it changes.
- **No clipped labels on narrow screens** — the player uses the compact
  reference-bot layout: short (≤16-char) labels in two-button rows
  (`⏸️ Pause | ⏭️ Skip`, `🔀 Shuffle On | 🔁 Repeat: Off`,
  `🤖 Autoplay ON | 📋 Queue`, `🔉 Vol − | 🔊 Vol +`) with Stop as the
  full-width safety row — no row ever truncates (production screenshots
  once showed "Shuffle: Of…" from longer labels).
- **🤖 Autoplay ON/OFF button** — a dedicated toggle on the group player
  panel (and the group queue view) flips the REAL per-group autoplay
  setting, syncs the admin settings screen to the same truth, reflects
  the actual state on the label, and re-renders the player message
  immediately. Permission-checked per press like Shuffle/Repeat.
- **Full persistent group control panel** — Pause / Skip / Shuffle /
  Repeat / Autoplay / Queue / `🔉 Vol − / 🔊 Vol +` steps (±25 within
  0–100 percent, target value on the label) / Stop ride on the Now
  Playing message; every button is permission-checked per press against
  that group's model.
- **Live progress** — the group Now Playing message refreshes its
  playhead bar and elapsed time every `PROGRESS_EDIT_INTERVAL` seconds
  (default 15, `0` disables), and shows the next queued track
  (`⏭ Up next: …`) while one waits.
- **Queues with context** — upcoming entries show durations, group queues
  show who requested what (deep `tg://user` mentions with best-known
  names) and every queue view totals the time (`📋 4 in queue · ≈ 11 min`).
- **No dead ends** — private search results end with a
  `🔄 New Search | 🏠 Home` row (previously escaping the results screen
  required `/start`); group search results carry a
  `🎧 Now Playing | 📋 Queue` follow-up row; empty and error screens offer
  the recovery action inline.
- **Command aliases** — `/p /q /np /next` mirror play/queue/nowplaying/skip
  in groups (documented in `/commands` and the group help).
- **Honest onboarding** — `/start` walks a 3-step quick start; the search
  prompt suggests what to try; no-results explains how to recover; the
  empty queue invites the next play.
- **One status message per group request** — group `/play` and `/search`
  answer instantly with a single acknowledgement (`🔎 Searching… / Query: …`)
  that is edited through the request's life: `⬇️ Loading track…` once a
  match is found, then into the Now Playing control (via the controller's
  `edit_message` passthrough), the queue confirmation, the results screen
  or the failure text. A slow provider chain (search + download can span
  ~30 s) never leaves the member staring at dead air, and the chat sees
  exactly one message per request — no animation, keeping groups quiet.
  Every outcome edit is fail-safe: if the status message can no longer be
  edited, the outcome arrives as a fresh reply instead.

---

## Silent Group Mode

The bot is a quiet group citizen by design:

- An outer middleware drops every group/supergroup message that does not
  contain a bot-command entity **addressed to this bot** — ordinary
  messages, photos, stickers, mentions, replies and commands qualified for
  another bot (`/play@SomeOtherBot`) never reach any handler.
- Callback queries (button presses) always pass through.
- The bot never posts unsolicited group messages: there is no welcome
  message on join; join/leave events are only recorded in the database.
- Search progress animations exist only in private chats and can never
  leak into a group.
- The gate is controlled by `GROUP_SILENT_MODE` (default `true`) and the
  decision logic is a pure function (`app/groups/silent_mode.py`),
  covered by the automated test suite (`tests/`).

To verify it yourself:

```bash
pytest
```

The tests assert that non-command group messages are dropped, commands
for other bots are dropped, and own/unqualified commands plus callbacks
are processed.

---

## Project Structure

```text
telegram-music-bot/
├── run.py                     # entry point: --role bot|worker|all
├── requirements.txt           # Python dependencies
├── .env.example               # documented environment template
├── alembic.ini                # Alembic configuration
├── Dockerfile                 # production image (python:3.12-slim + ffmpeg)
├── docker-compose.yml         # postgres + redis + bot + worker stack
├── .dockerignore              # build-context exclusions (secrets, caches, data)
├── CONTRACTS.md               # binding module interface spec for contributors
├── SECURITY.md                # threat model, secrets policy, deploy checklist
├── CONTRIBUTING.md            # dev setup, hard rules, PR checklist
├── app/
│   ├── application.py         # Application: wires and runs every subsystem
│   ├── config.py              # typed settings, env parsing, validation
│   ├── logging.py             # structured logging + secret redaction filter
│   ├── errors.py              # error taxonomy with user-facing messages
│   ├── storage.py             # sandboxed file storage service
│   ├── admin/                 # admin services (roles, appearance, buttons, ...)
│   ├── audio/                 # FFmpeg toolkit, processor, pipeline
│   ├── bot/                   # aiogram layer
│   │   ├── handlers/          # message handlers: personal, group, admin
│   │   ├── callbacks/         # inline button handlers
│   │   ├── keyboards/         # inline keyboard builders
│   │   ├── middleware/        # silent-group, rate-limit, logging, auth gates
│   │   └── services.py        # ServiceContainer shared by all handlers
│   ├── broadcast/             # composer, targets, rate limiter, worker
│   ├── cache/                 # cache/rate-limit/lock: Redis + memory
│   ├── database/
│   │   ├── models/            # 35 ORM tables
│   │   ├── repositories/      # the only data-access path
│   │   ├── base.py            # declarative base
│   │   ├── engine.py          # async engine + session factory
│   │   └── defaults.py        # seeded messages/settings/buttons
│   ├── groups/                # group service, settings, permissions, silent mode
│   ├── music/
│   │   ├── sources/           # local, Jamendo, Audius, direct-URL sources
│   │   └── ...                # models, normalizer, search, metadata, resolver, service
│   ├── playback/              # queue, sessions, autoplay, controller, events
│   ├── recommendation/        # profiles, similarity, scoring, engine
│   ├── security/              # validation (SSRF), encryption, secrets
│   ├── users/                 # user service, library, history, playlists
│   ├── voice/                 # transports, accounts, sessions, health, failover
│   ├── workers/               # jobs, task registry, worker manager
│   └── utils/                 # formatting, pagination, telegram, time
├── migrations/
│   └── versions/              # Alembic migration scripts
├── scripts/
│   ├── dev_setup.sh           # local setup helper (venv + deps + .env + key)
│   ├── add_voice_account.py   # server-side voice-account CLI
│   └── seed_catalog.py        # generate a demo catalog (FFmpeg-synthesized)
├── storage/                   # runtime data: music/, downloads/, artwork/, tmp/
└── tests/                     # pytest suite (incl. silent-group mode)
```

---

## Troubleshooting

| Symptom | Cause and fix |
| --- | --- |
| Startup error: `BOT_TOKEN is required...` | `BOT_TOKEN` is missing from the environment/`.env`. Copy `.env.example` to `.env` and set it. |
| Startup error: `DATABASE_URL must be a postgresql+asyncpg:// or sqlite+aiosqlite:// URL` | Use one of the two supported schemes. Plain `postgres://` or sync drivers are rejected on purpose. |
| `alembic: command not found` | The virtualenv is not activated (`source .venv/bin/activate`) or dependencies were not installed (`pip install -r requirements.txt`). |
| Log warning: voice engine disabled | `TELEGRAM_API_ID` / `TELEGRAM_API_HASH` and/or `VOICE_SESSION_ENCRYPTION_KEY` are not set. Personal mode keeps working; group playback requires them. |
| Group `/play` answers "no voice account available" | No voice account exists or none is healthy. Add one via the admin wizard (`/admin` → Voice → Add Account) or `python scripts/add_voice_account.py` (see [Voice Account Setup](#voice-account-setup)). |
| Group `/play` answers "❌ Couldn't download this track" | The track had no resolvable stream (dead provider link). **Fixed in this build**: Audius tracks resolve their stream at play time via the source's stream endpoint, expired URLs are re-resolved once, and downloaded content is validated before playback. Try the track again or pick another result. |
| Group `/play` answers "the voice account is not a member of this group" | `VOICE_AUTO_JOIN_ENABLED=false`, or the account was never added. Enable auto-join or invite the voice account manually once. |
| Group `/play` answers "I couldn't get an invitation link" | The bot is not a group admin with the *Invite users via link* permission (Bot API `exportChatInviteLink` requirement). Grant the permission or add the voice account manually. |
| Group `/play` answers "A join request was sent — a group admin must approve it" | The group has join requests enabled; an admin must accept the voice account's request in the group before playback works. |
| Group `/play` answers "Telegram is limiting join requests" | A FloodWait was hit — the message includes the server-provided wait time; the group is also on the auto-join cooldown meanwhile. Retry later. |
| Admin "Group Access" shows *unknown* | The voice account never interacted with that group (entity not in its Telethon session) — it is treated as not a member; auto-join is attempted when enabled. |
| Voice wizard answers "the voice engine is not configured" | `TELEGRAM_API_ID`, `TELEGRAM_API_HASH` and `VOICE_SESSION_ENCRYPTION_KEY` must all be set on the server before accounts can be connected. |
| `ImportError` mentioning `ntgcalls` / voice transport unavailable | An incompatible ntgcalls version is installed. The requirements pin `py-tgcalls>=2.2,<3` (which pulls a compatible `ntgcalls>=2.1,<3`); reinstall with `pip install -r requirements.txt --force-reinstall py-tgcalls`. |
| Errors mentioning ffmpeg / ffprobe | FFmpeg is not installed or not on `PATH`. Install it (`sudo apt install ffmpeg`, `brew install ffmpeg`, `winget install ffmpeg`) or set `FFMPEG_PATH`/`FFPROBE_PATH`. |
| Log warning: Redis unavailable, falling back to memory | `REDIS_URL` points at a Redis that is not reachable. Start it (`docker compose up -d redis`) or unset `REDIS_URL` for single-process local use. |
| `TelegramServerError: 409 Conflict` | Another process is polling with the same bot token (for example a local run and the Docker stack at once). Run exactly one bot process per token. |
| Broadcast seems slow | By design: sends are capped at `BROADCAST_RATE_PER_SECOND` (default 25/s) and respect Telegram FloodWait. A large audience simply takes a while; watch progress in the panel. |
| Healthcheck marks the container unhealthy | `HEALTH_PORT` is set to `0` in `.env` (the Dockerfile check then exits 0 — if you overrode it, remove the override) or the app failed to bind. Check `docker compose logs bot`. |

---

## Security

> Full threat model, secret inventory, deployment checklist and reporting
> process: see **[SECURITY.md](SECURITY.md)**.

- **Secrets via environment only.** No tokens or keys are hardcoded; `.env`
  is excluded from version control (`.gitignore`) and from image builds
  (`.dockerignore`).
- **No secrets in logs.** The structured logging pipeline supports every
  record style used by aiogram/Telethon (parameterized, mapping-based,
  with tracebacks) without the stdlib "--- Logging error ---" failures,
  and redacts secrets on three layers: sensitive key names in structured
  fields, mapping-args values, and pattern-based masking of rendered text
  (bot tokens, API hashes, session strings, phone numbers, `key=value`
  leaks).
- **Encrypted voice sessions.** Telegram session strings are Fernet-encrypted
  at rest; decrypted only in memory, never printed, and manageable only via
  the admin login wizard or the server-side CLI (which share one service).
- **SSRF-protected URL handling.** Outbound fetches allow only http/https,
  block private/loopback/link-local networks, cap URL length and download
  size, and sanitize filenames; storage paths are sandboxed under
  `STORAGE_DIR`. **Redirects are followed manually with a fresh SSRF
  validation of every hop** — a public redirector can never bounce a
  download into a private network, and JSON provider APIs do not follow
  redirects at all.
- **Upload validation.** Audio uploads are checked against MIME/extension
  allowlists and the size cap before being probed and stored.
- **Rate limiting.** Per-user/per-group fixed windows for search, heavy
  operations, commands and group commands.
- **Permission checks.** Group action permissions (everyone/admins/DJ), the
  admin role hierarchy and the admin-panel callback guard.
- **Broadcast safety.** URL buttons are restricted to https/tg; javascript
  and data URLs are rejected.
- **Audit logs.** Admin actions are recorded with actor, action, target and
  result.

---

## License / Credits

This project is a self-hostable bot template — you are responsible for
complying with the terms of every service you connect it to. Contributions
follow [CONTRIBUTING.md](CONTRIBUTING.md).

- [Jamendo](https://www.jamendo.com) — Creative Commons music catalog,
  accessed via their developer API (<https://devportal.jamendo.com>).
- [Audius](https://audius.co) — public API, no key required.
- [FFmpeg](https://ffmpeg.org) — audio probing, transcoding and artwork
  extraction (LGPL/GPL components, used as an external binary).
- Built on [aiogram](https://aiogram.dev), [SQLAlchemy](https://www.sqlalchemy.org),
  [Alembic](https://alembic.sqlalchemy.org), [Telethon](https://docs.telethon.dev),
  [py-tgcalls](https://github.com/pytgcalls/pytgcalls), [redis-py](https://redis.io/docs/latest/develop/clients/redis-py/),
  [PostgreSQL](https://www.postgresql.org) and [Redis](https://redis.io).

---

## Testing & Verification

```bash
# full automated suite (no Telegram, no network, no credentials needed)
pytest
```

Current verified state: **970 tests passed** (Python 3.12, aiogram 3.31,
Telethon 1.45, py-tgcalls 2.3.3/ntgcalls 2.2.5, SQLAlchemy 2.1) —
including the **round-6 audit suite** (startup recovery of stale
playing/paused sessions — the root cause of "queued track never plays"
after a restart; the group-start failure policy: honest idle reset +
bounded front-requeue (dropped after a second consecutive failure so
broken sources cannot loop); the live-voice-lease cross-check that
corrects stale persisted statuses at enqueue time in the controller,
group handler and DM flow; DM→group flow ordering: auto-join BEFORE the
voice-chat verdict so live-but-invisible calls are no longer reported
missing; volume scale unification (human 0–100 percent, engine mapping
internal); the completed download-cache cleanup with active-playback
protection, symlink safety and permanent-tree scope locks; the group
command auto-delete middleware matrix; the live progress ticker; the
`⏭ Up next` rendering; new configuration parsing; repeated-`/start`
housekeeping — 50 new regression locks) —
covering the **round-4 production regression suite** (the
`MediaStream(loop=…)` TypeError that killed every playback at the final
transport step — reproduced against the real installed py-tgcalls 2.3.3
and locked; the `can't parse entities: Unsupported start tag "song"`
HTML rejection — reproduced with a Telegram-tag parser and locked;
duplicate command registration guard — 13 tests), the **round-4
continuation suites** (the `name 'UnsupportedUrlError' is not defined`
NameError that broke every unsupported-link reply in private chats —
runtime-verified fix plus an AST import guard; the group status-message
lifecycle: ack before the provider call, edit → loading → Now Playing /
queue confirmation / failure, fail-safe fallbacks, controller
`edit_message` passthrough — 23 tests), the **UX overhaul
suite** (shared Now Playing renderer, playhead progress bar, queue
totals and requester mentions, stateful Shuffle/Repeat buttons, the
group control panel with volume steps and its `grp:` namespace
discipline, dead-end-free search results, command aliases, defaults
HTML safety — 59 tests), the **source-identity regression suite** (the
confirmed `source='local'` corruption chain end-to-end: catalog search
keeps the original provider identity, the resolver reuses the existing
row, playback routes stream resolution to the right adapter with the
provider id — 18 tests with the real `LocalSource`, real `TrackResolver`
and real `SearchAggregator`), the **DM→group workflow suite** (link
resolution for public/private/invite/channel/reject paths, voice-chat
and membership prerequisite checks, honest success/failure screens,
Back/Cancel/X semantics, expiry, duplicate-click suppression, DM group
controls with permission checks, group-keyboard routing — 52 tests,
plus a dispatcher-level routing verification for group vs private
`trk:` button scoping), the **download/playback pipeline regression
suite** (Audius stream resolution, absolute-path contract, expired-URL
re-resolution, content validation, concurrency safety), the
**private-group invite-join matrix**, the logging regression matrix, the
voice-account login wizard (mocked MTProto), the animated search flow
(virtual clock), group silence (command targeting), SSRF redirect
safety, dependency compatibility and all pre-existing feature suites.

Live Telegram behaviour (real polling, real MTProto login, real voice-chat
streaming, **live private-group auto-join, live Audius playback**) requires
production credentials and is tracked feature-by-feature in
**[docs/TELEGRAM_COMPATIBILITY_AUDIT.md](docs/TELEGRAM_COMPATIBILITY_AUDIT.md)**
(round 4: §16 root causes, §17 the UX benchmark references actually
inspected, §18 round-4 results, §19 continuation round — the third
production bug and the group status-message UX).
